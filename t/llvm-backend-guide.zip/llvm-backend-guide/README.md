# LLVM Backend Guide

Open `llvm-backend-guide.html` in a browser: all seven wikis in one file, with one navigation tree and working links between parts.

| Part | Topic | Pages |
| --- | --- | --- |
| 1 | Target Bring-up End to End | 14 |
| 2 | SelectionDAG Instruction Selection | 21 |
| 3 | Calling Conventions and Call Lowering | 11 |
| 4 | Instruction Scheduling | 10 |
| 5 | Register Allocation | 27 |
| 6 | Frame Lowering | 11 |
| 7 | The MC Layer | 12 |

`wikis/` holds the original separate wikis (HTML and Markdown sources) in their original layout, so their relative cross-links keep working.
Parts 1 and 3-7 cite LLVM commit a2171756; Part 2 cites 7a941df. Diagrams are rendered by mermaid in the browser.
