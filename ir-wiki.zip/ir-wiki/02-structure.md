# Structure: Modules, Functions, Blocks and Values

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/IR/Function.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Function.h)
- [llvm/include/llvm/IR/BasicBlock.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/BasicBlock.h)
- [llvm/include/llvm/IR/Value.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Value.h)
- [llvm/include/llvm/IR/User.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/User.h)
- [llvm/include/llvm/IR/Use.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Use.h)

</details>

An LLVM IR program is a tree of containers: a module holds functions and globals, a function holds basic blocks, and a basic block holds instructions. On top of that tree sits a graph: every instruction that uses a value points to it, and every value keeps a list of its uses. This page explains both.

## Purpose and Scope

This page covers the containers (`Module`, `Function`, `BasicBlock`, `Instruction`), the value hierarchy (`Value`, `User`, `Use`), globals, attributes and metadata. Instruction semantics are on the following pages, starting with [Arithmetic](#arithmetic).

## The Containment Tree

```mermaid
flowchart TD
    M["Module (one .ll file)"] --> G["GlobalVariable @counter"]
    M --> F1["Function @main"]
    M --> F2["Function @helper (declaration only)"]
    F1 --> A["Argument %argc"]
    F1 --> B1["BasicBlock entry"]
    F1 --> B2["BasicBlock loop"]
    B1 --> I1["Instruction %x = add ..."]
    B1 --> I2["Terminator br label %loop"]
```

A complete module (illustrative):

```llvm
; ModuleID = 'example.c'
source_filename = "example.c"
target datalayout = "e-m:e-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

@counter = global i32 0, align 4          ; a global variable

declare i32 @puts(ptr)                     ; a declaration: no body

define i32 @bump(i32 %by) #0 {             ; a definition: has blocks
entry:
  %old = load i32, ptr @counter, align 4
  %new = add i32 %old, %by
  store i32 %new, ptr @counter, align 4
  ret i32 %new
}

attributes #0 = { nounwind }
```

| Level | Class | What it holds |
| --- | --- | --- |
| Module | `Module` | Globals, functions, the target triple and data layout, named metadata |
| Function | `Function` | Arguments, a list of basic blocks (none for a `declare`), attributes |
| Basic block | `BasicBlock` | A list of instructions; the last one is a terminator |
| Instruction | `Instruction` | An opcode, a type and operands |

`Function` derives from `GlobalObject`: a function is a global value, and its name `@bump` is its address. `BasicBlock` derives from `Value`, which is why a block label such as `label %loop` can be an operand of a branch.

**Sources:** [llvm/include/llvm/IR/Function.h:65](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Function.h#L65), [llvm/include/llvm/IR/BasicBlock.h:61](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/BasicBlock.h#L61)

## Basic Blocks and Terminators

A basic block is a sequence of instructions with one entry (the top) and one exit (the terminator at the bottom). Control never jumps into the middle of a block. Two rules follow:

1. Every block ends in exactly one terminator (`ret`, `br`, `switch`, `unreachable`, ...). `BasicBlock::getTerminator()` returns it, or null if the block is malformed.
2. `phi` instructions, if any, must come first in the block, see [SSA and Phi](#ssa-phi).

The first block of a function is its *entry block*. It has no predecessors, and it is where `alloca`s for local variables are conventionally placed.

**Sources:** [llvm/include/llvm/IR/BasicBlock.h:237](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/BasicBlock.h#L237)

## Values, Users and Uses

Almost everything in IR is a `Value`: arguments, instructions, basic blocks, functions, globals and constants. A `User` is a value that has operands, which includes every instruction. Each operand slot is a `Use`, which links the user to the value it uses.

```mermaid
classDiagram
    Value <|-- Argument
    Value <|-- BasicBlock
    Value <|-- User
    User <|-- Instruction
    User <|-- Constant
    Constant <|-- GlobalValue
    GlobalValue <|-- GlobalObject
    GlobalObject <|-- Function
    GlobalObject <|-- GlobalVariable
    class Value { type, name, use list }
    class User { operand list of Use }
    class Use { Val, Parent user }
```

For `%new = add i32 %old, %by`:

- The `add` instruction is a `User` with two `Use`s.
- Use 0 points to `%old` (the `load`), use 1 points to `%by` (an `Argument`).
- `%old` keeps the `add` on its use list, so `%old->users()` finds it.

Because SSA gives each value exactly one definition, the def-use graph is just these pointers. `V->replaceAllUsesWith(W)` walks `V`'s use list and redirects every `Use` to `W`; this is the basic move of most transformations.

```cpp
// Illustrative: print every instruction that uses value V.
for (User *U : V->users())
  if (auto *I = dyn_cast<Instruction>(U))
    errs() << *I << "\n";
```

**Sources:** [llvm/include/llvm/IR/Value.h:75](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Value.h#L75), [llvm/include/llvm/IR/User.h:44](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/User.h#L44), [llvm/include/llvm/IR/Use.h:35](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Use.h#L35)

## Names and Numbering

| Prefix | Scope | Examples |
| --- | --- | --- |
| `@` | Module (global) | `@main`, `@counter`, `@puts` |
| `%` | Function (local) | `%a`, `%sum`, `%entry` |
| `!` | Metadata | `!0`, `!dbg`, `!tbaa` |
| `#` | Attribute group | `#0` |

Names are optional. An unnamed value is printed with a number, `%0`, `%1`, ..., assigned in order through the function, which is why Clang output is full of `%0`, `%1`. Names are only for humans; passes compare `Value*` pointers, never names.

## Attributes and Metadata

**Attributes** are facts attached to functions, parameters or return values that passes may rely on:

| Attribute | Meaning |
| --- | --- |
| `nounwind` | The function never throws an exception |
| `readnone` / `memory(none)` | The function does not touch memory |
| `noalias` on a `ptr` parameter | No other pointer visible to the function aliases it (like C `restrict`) |
| `nonnull`, `dereferenceable(N)` | Pointer facts |
| `noinline`, `alwaysinline`, `optnone` | Inliner and optimizer controls |

**Metadata** is extra information that may be dropped without changing the meaning of the program: debug locations (`!dbg`), type-based alias info (`!tbaa`), loop hints (`!llvm.loop`), branch weights (`!prof`). It is written after the instruction:

```llvm
%v = load i32, ptr %p, align 4, !tbaa !5   ; illustrative
```

## Key Points

- Module, function, block, instruction is a strict containment tree.
- Every block ends in exactly one terminator.
- Everything is a `Value`; operands are `Use`s; use lists give def-use chains for free.