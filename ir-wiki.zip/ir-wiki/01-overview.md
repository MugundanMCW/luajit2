# LLVM IR Overview

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/IR/Instruction.def](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def)
- [llvm/include/llvm/IR/Value.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Value.h)
- [llvm/include/llvm/IR/Function.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Function.h)
- [llvm/lib/Passes/PassRegistry.def](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def)

</details>

LLVM IR (intermediate representation) is the language that sits between a front end such as Clang and a back end such as the AArch64 code generator. A front end translates source code into IR, the optimizer rewrites IR into faster IR, and a back end translates IR into machine code. This wiki explains IR from the ground up: what it looks like, what each instruction does, and the analyses (CFG, dominance, data flow) that passes use to transform it.

> **Note on examples.** Every IR listing in this wiki is **illustrative**: hand-written to match what LLVM produces, but not captured from a tool run. The local build at the time of writing had no `clang` or `opt`. Line-numbered source citations were checked against the LLVM checkout at commit `a2171756`.

## Purpose and Scope

This wiki is for readers who have never worked with LLVM IR. It covers:

| Topic | Page |
| --- | --- |
| How a module is organised | [Structure](#structure) |
| Types | [Type System](#types) |
| The instruction set | [Arithmetic](#arithmetic), [Compare and Select](#compare), [Memory](#memory), [Control Flow](#control-flow) |
| SSA form and `phi` | [SSA and Phi](#ssa-phi) |
| Program analysis | [CFG and Loops](#cfg), [Dominance](#dominance), [Data-flow Analysis](#dataflow) |
| Writing and using passes | [Writing a Pass](#writing-a-pass), [Common Passes](#common-passes) |
| Practice | [Exercises, Tooling and Glossary](#tooling-glossary) |

What happens after the optimizer, when IR becomes machine instructions, is covered by the [SelectionDAG wiki](../selectiondag-wiki.html#overview) and the [Target Bring-up wiki](../bringup-wiki/bringup-wiki.html#overview).

## Why an IR Exists

Without a shared IR, every language would need its own optimizer and its own back end for every processor: *N* languages times *M* targets. With one IR in the middle, each front end only emits IR and each back end only consumes it, so the work is *N + M*, and every optimization written once on IR benefits every language and every target.

```mermaid
flowchart LR
    C["C / C++ (Clang)"] --> IR["LLVM IR"]
    R["Rust (rustc)"] --> IR
    S["Swift"] --> IR
    IR --> OPT["Optimizer (opt passes)"]
    OPT --> IR2["Optimized IR"]
    IR2 --> A64["AArch64 back end"]
    IR2 --> X86["X86 back end"]
    IR2 --> GPU["GPU back ends"]
```

LLVM IR has three properties that make it convenient to optimize:

| Property | Meaning | Why it helps |
| --- | --- | --- |
| Typed | Every value has a type such as `i32`, `double` or `ptr` | Passes can check that a rewrite keeps types consistent; the verifier rejects ill-typed IR |
| SSA (static single assignment) | Each value is assigned exactly once | The definition of a value is a single instruction, so "where did this come from?" is a pointer lookup, see [SSA and Phi](#ssa-phi) |
| Low level but target independent | Instructions are close to machine operations (add, load, branch) but there are unlimited virtual registers and no fixed calling convention | Optimizations can reason about real costs without knowing the target |

## A First Look

This C function:

```c
int add(int a, int b) { return a + b; }
```

becomes, after optimization, roughly this IR (illustrative):

```llvm
define i32 @add(i32 %a, i32 %b) {
entry:
  %sum = add nsw i32 %a, %b
  ret i32 %sum
}
```

Reading it line by line:

- `define i32 @add(i32 %a, i32 %b)` defines a function named `@add` that returns an `i32` (32-bit integer). Names starting with `@` are global (functions and global variables); names starting with `%` are local to the function.
- `entry:` is the label of a basic block, a straight-line list of instructions.
- `%sum = add nsw i32 %a, %b` adds two `i32` values. `nsw` ("no signed wrap") records that C signed overflow is undefined, see [Arithmetic](#arithmetic).
- `ret i32 %sum` returns the result. Every basic block ends with exactly one such *terminator* instruction.

## The Three Forms

The same IR exists in three interchangeable forms:

| Form | File | Produced by | Read by |
| --- | --- | --- | --- |
| Text assembly | `.ll` | `clang -S -emit-llvm`, `llvm-dis`, `opt -S` | Humans, `llvm-as`, `opt`, `llc` |
| Bitcode | `.bc` | `clang -c -emit-llvm`, `llvm-as`, `opt` | `opt`, `llc`, `llvm-dis`, the linker for LTO |
| In memory | C++ objects | The IR parser or bitcode reader | Passes |

```mermaid
flowchart LR
    LL[".ll text"] -->|llvm-as| BC[".bc bitcode"]
    BC -->|llvm-dis| LL
    LL -->|parse| MEM["In-memory Module<br/>(Function, BasicBlock, Instruction)"]
    BC -->|read| MEM
    MEM -->|print| LL
    MEM -->|write| BC
```

The text and bitcode forms are lossless encodings of the in-memory form. Passes only ever see the in-memory form: a `Module` containing `Function`s, each containing `BasicBlock`s, each containing `Instruction`s, all of which derive from `Value`.

**Sources:** [llvm/include/llvm/IR/Value.h:75](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Value.h#L75), [llvm/include/llvm/IR/Function.h:65](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Function.h#L65)

## The Instruction Set at a Glance

All IR opcodes are listed in one file, `Instruction.def`, grouped by kind:

| Group | Lines | Examples | Page |
| --- | --- | --- | --- |
| Terminators | 126-139 | `ret`, `br`, `switch`, `invoke`, `unreachable` | [Control Flow](#control-flow) |
| Unary | 142-144 | `fneg` | [Arithmetic](#arithmetic) |
| Binary | 147-168 | `add`, `fmul`, `sdiv`, `shl`, `xor` | [Arithmetic](#arithmetic) |
| Memory | 171-179 | `alloca`, `load`, `store`, `getelementptr`, atomics | [Memory](#memory) |
| Casts | 184-199 | `trunc`, `zext`, `sext`, `sitofp`, `bitcast` | [Arithmetic](#arithmetic) |
| Other | 207-223 | `icmp`, `fcmp`, `phi`, `call`, `select`, `freeze` | [Compare](#compare), [SSA and Phi](#ssa-phi) |

**Sources:** [llvm/include/llvm/IR/Instruction.def:126-223](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def#L126-L223)

## Where Passes Fit

The optimizer is a sequence of *passes*. Each pass either analyses IR (computing facts such as the dominator tree) or transforms it (for example promoting stack variables to registers). `opt` runs passes by name; the names are registered in `PassRegistry.def`, for example `mem2reg` at line 491 and `print<domtree>` at line 522.

```text
opt -S -passes=mem2reg in.ll -o out.ll
opt -disable-output -passes='print<domtree>' in.ll
```

**Sources:** [llvm/lib/Passes/PassRegistry.def:491](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L491), [llvm/lib/Passes/PassRegistry.def:522](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L522)

## How to Read This Wiki

1. [Overview](#overview) (this page).
2. [Structure](#structure): modules, functions, blocks, instructions, values and uses.
3. [Type System](#types).
4. [Arithmetic, Bitwise and Casts](#arithmetic).
5. [Compare and Select](#compare).
6. [Memory](#memory).
7. [Control Flow](#control-flow).
8. [SSA and Phi](#ssa-phi).
9. [CFG and Loops](#cfg).
10. [Dominance](#dominance).
11. [Data-flow Analysis](#dataflow).
12. [Writing a Pass](#writing-a-pass).
13. [Common Passes](#common-passes).
14. [Exercises, Tooling and Glossary](#tooling-glossary).