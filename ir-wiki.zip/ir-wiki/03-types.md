# Type System

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/IR/Type.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Type.h)
- [llvm/include/llvm/IR/DerivedTypes.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/DerivedTypes.h)

</details>

Every value in LLVM IR has a type, and every instruction states the types it works on. Types are simple and structural: there are no classes, no signed versus unsigned integers, and only one kind of pointer. This page lists the types a beginner meets and how they are written.

## Purpose and Scope

This page covers integer, floating-point, pointer, vector, array, struct, function, `void` and `label` types, and how they are represented in C++ by `Type` and its subclasses. How instructions use these types is covered in [Arithmetic](#arithmetic) and [Memory](#memory).

## The Type Kinds

Each `Type` object has a `TypeID` that says which kind it is. The enum is in `Type.h`:

| Kind | Written as | `TypeID` | C++ class |
| --- | --- | --- | --- |
| Integer | `i1`, `i8`, `i32`, `i64`, any `iN` | `IntegerTyID` | `IntegerType` |
| Floating point | `half`, `bfloat`, `float`, `double`, `fp128` | `HalfTyID`, `FloatTyID`, `DoubleTyID`, ... | `Type` |
| Pointer | `ptr`, `ptr addrspace(N)` | `PointerTyID` | `PointerType` |
| Fixed vector | `<4 x i32>`, `<2 x double>` | `FixedVectorTyID` | `FixedVectorType` |
| Scalable vector | `<vscale x 4 x i32>` | `ScalableVectorTyID` | `ScalableVectorType` |
| Array | `[10 x i32]` | `ArrayTyID` | `ArrayType` |
| Struct | `{ i32, ptr }`, `%struct.Point` | `StructTyID` | `StructType` |
| Function | `i32 (i32, ptr)` | `FunctionTyID` | `FunctionType` |
| Void | `void` | `VoidTyID` | `Type` |
| Label | `label` (a basic block) | `LabelTyID` | `Type` |

`Type` provides predicates such as `isIntegerTy()`, `isPointerTy()`, `isStructTy()` and `isArrayTy()` that test the `TypeID`.

**Sources:** [llvm/include/llvm/IR/Type.h:46-79](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Type.h#L46-L79), [llvm/include/llvm/IR/Type.h:257-282](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Type.h#L257-L282)

## Integers Have No Sign

`i32` is just 32 bits. Whether those bits are signed is decided by the *instruction*: `sdiv` versus `udiv`, `icmp slt` versus `icmp ult`, `sext` versus `zext`. C `int` and `unsigned` both become `i32`.

`i1` is the boolean type: comparisons produce it and conditional branches consume it.

```llvm
; illustrative
%q1 = sdiv i32 %a, %b        ; signed division
%q2 = udiv i32 %a, %b        ; unsigned division of the same bits
%lt = icmp slt i32 %a, %b    ; i1 result
```

**Sources:** [llvm/include/llvm/IR/DerivedTypes.h:42](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/DerivedTypes.h#L42)

## Pointers Are Opaque

Older LLVM had typed pointers such as `i32*`. Current LLVM has one pointer type, `ptr`, that says nothing about what it points to. The type of the data comes from the instruction that accesses it:

```llvm
; illustrative
%x = load i32, ptr %p          ; read 4 bytes as i32
%y = load double, ptr %p       ; read 8 bytes as double from the same pointer
```

Only the address space can differ (`ptr addrspace(1)` is common on GPUs). If you read old tutorials, mentally replace every `T*` with `ptr` and remove the `bitcast`s between pointer types.

**Sources:** [llvm/include/llvm/IR/DerivedTypes.h:758](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/DerivedTypes.h#L758)

## Aggregates: Arrays and Structs

| Type | Example | Element access |
| --- | --- | --- |
| Array | `[4 x float]` | Same type for every element; index can be a variable in `getelementptr` |
| Struct (literal) | `{ i32, double }` | Fields can differ; field index must be a constant |
| Struct (identified) | `%struct.Point = type { i32, i32 }` | Same, but has a name and can be recursive through `ptr` |
| Packed struct | `<{ i8, i32 }>` | No padding between fields |

```llvm
; illustrative
%struct.Node = type { i32, ptr }         ; int value; struct Node *next
@table = global [3 x i32] [i32 1, i32 2, i32 3]
```

How these map to byte offsets (alignment and padding) is decided by the module's `target datalayout` string. See [Memory](#memory) for the `getelementptr` arithmetic.

**Sources:** [llvm/include/llvm/IR/DerivedTypes.h:278](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/DerivedTypes.h#L278), [llvm/include/llvm/IR/DerivedTypes.h:458](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/DerivedTypes.h#L458)

## Vectors

A vector type holds a fixed number of scalars that one instruction processes together, for SIMD:

```llvm
; illustrative
%s = add <4 x i32> %a, %b                       ; four adds at once
%e = extractelement <4 x i32> %s, i32 0          ; take lane 0
```

Scalable vectors, `<vscale x 4 x i32>`, have a length that is a multiple of a runtime constant `vscale`; they model AArch64 SVE and RISC-V V.

**Sources:** [llvm/include/llvm/IR/DerivedTypes.h:490](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/DerivedTypes.h#L490), [llvm/include/llvm/IR/DerivedTypes.h:650](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/DerivedTypes.h#L650)

## Function Types

A function type is a return type and a list of parameter types, optionally variadic:

```llvm
; illustrative
declare i32 @printf(ptr, ...)       ; type: i32 (ptr, ...)
declare void @free(ptr)             ; type: void (ptr)
```

Functions themselves are values of type `ptr`; the function type is stored separately and used by `call`.

**Sources:** [llvm/include/llvm/IR/DerivedTypes.h:165](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/DerivedTypes.h#L165)

## Types Are Unique

Types are created once per `LLVMContext` and shared: there is exactly one `i32` object, so passes compare types by pointer, `A->getType() == B->getType()`. In C++ you get them with calls such as `Type::getInt32Ty(Ctx)`, `PointerType::getUnqual(Ctx)` and `ArrayType::get(Elt, N)`.

## Key Points

- Integers carry no sign; instructions decide signedness.
- There is one pointer type, `ptr`; loads and stores state the accessed type.
- Struct and array layout comes from the data layout string.