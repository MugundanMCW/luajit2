# Exercises, Tooling and Glossary

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Passes/PassRegistry.def](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def)
- [llvm/include/llvm/IR/Instruction.def](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def)

</details>

This page collects the command-line tools for working with IR, a set of exercises that follow the order of the wiki, and a glossary of the terms used on earlier pages.

## Purpose and Scope

This page covers the IR tools (`clang`, `opt`, `llvm-as`, `llvm-dis`, `llc`, `lli`), the most useful `opt` options, exercises with hints, and a glossary. All command lines are illustrative; the expected results in the exercises were worked out by hand, not captured from a tool run.

## Tools

| Tool | Input | Output | Typical use |
| --- | --- | --- | --- |
| `clang -S -emit-llvm` | C/C++ | `.ll` | See what IR a C function becomes |
| `clang -c -emit-llvm` | C/C++ | `.bc` | Bitcode for LTO or `opt` |
| `opt` | `.ll` / `.bc` | `.ll` / `.bc` / analysis printouts | Run passes |
| `llvm-as` | `.ll` | `.bc` | Assemble text to bitcode |
| `llvm-dis` | `.bc` | `.ll` | Disassemble bitcode to text |
| `llc` | `.ll` / `.bc` | `.s` / `.o` | Run the back end |
| `lli` | `.ll` / `.bc` | program output | Execute IR directly with the JIT |
| `llvm-link` | several `.bc` | one `.bc` | Merge modules |

## Useful Commands

```text
# Unoptimised IR, but still optimisable by opt (no optnone attribute):
clang -O0 -Xclang -disable-O0-optnone -S -emit-llvm f.c -o f.ll

# Optimised IR, without the names Clang would discard in release builds kept:
clang -O2 -S -emit-llvm -fno-discard-value-names f.c -o f.O2.ll

# Run single passes, check the result:
opt -S -passes='mem2reg,verify' f.ll -o f.m2r.ll

# Analyses:
opt -disable-output -passes='print<domtree>' f.m2r.ll
opt -disable-output -passes='print<postdomtree>' f.m2r.ll
opt -disable-output -passes='print<loops>' f.m2r.ll
opt -disable-output -passes=dot-cfg f.m2r.ll          # writes .<fn>.dot files

# See what each pass in -O2 does:
opt -S -O2 -print-after-all f.ll 2> trace.txt
opt -S -O2 -print-changed f.ll 2> changes.txt         # only passes that changed IR
opt -disable-output -O2 -debug-pass-manager f.ll      # pass and analysis order
```

The names after `-passes=` come from `PassRegistry.def`, for example `verify` (line 564), `dot-cfg` (line 436) and the printers at lines 522-530.

**Sources:** [llvm/lib/Passes/PassRegistry.def:436](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L436), [llvm/lib/Passes/PassRegistry.def:522-530](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L522-L530), [llvm/lib/Passes/PassRegistry.def:564](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L564)

## Exercises

Each exercise names the page it practises.

1. **Read IR** ([Overview](#overview), [Structure](#structure)). Compile `int sq(int x) { return x * x; }` with `-O2 -S -emit-llvm`. Identify the function definition, the block label, the terminator and every attribute group. Expected core: `%mul = mul nsw i32 %x, %x` then `ret i32 %mul`.
2. **Signedness** ([Type System](#types), [Compare](#compare)). Compile `int lt(int a, int b){return a<b;}` and the same with `unsigned`. Which `icmp` predicate changes? *(Hint: `slt` vs `ult`; nothing else changes.)*
3. **Flags** ([Arithmetic](#arithmetic)). Why does `int f(int x){return x+1 > x;}` fold to `return 1` at `-O2`, but the `unsigned` version does not? *(Hint: `nsw`.)*
4. **GEP by hand** ([Memory](#memory)). For `struct S { char c; int i; long l; }` on AArch64, give the byte offsets of `c`, `i`, `l`, and write the GEP for `&s[2].l`. *(Answer: 0, 4, 8; size 16; offset 2*16+8 = 40; `getelementptr inbounds %struct.S, ptr %s, i64 2, i32 2`.)*
5. **Control flow** ([Control Flow](#control-flow)). Compile a `switch` with four cases. Find the `switch` instruction and its default target. Then compile at `-O2` and see whether it stays a `switch` or becomes a table lookup.
6. **mem2reg** ([SSA and Phi](#ssa-phi)). Take `max(a,b)` written with `if`/`else` and a local variable. Run `opt -passes=mem2reg` and find the `phi`. Then add `simplifycfg` and confirm it becomes a `select`.
7. **Escaping alloca** ([SSA and Phi](#ssa-phi)). Add `foo(&x);` to exercise 6. Why does `mem2reg` now leave `x` in memory? *(Hint: `isAllocaPromotable`.)*
8. **CFG and loops** ([CFG and Loops](#cfg)). For a nested `for` loop, run `print<loops>` and identify each loop's header, latch and depth. Draw the CFG with `dot-cfg`.
9. **Dominance by hand** ([Dominance](#dominance)). For the CFG `entry→A, A→B, A→C, B→D, C→D, D→E, E→A, E→exit`, compute the idom of each block and DF(B), DF(D), DF(E). Check with `print<domtree>`. *(Answer: idom(A)=entry, idom(B)=idom(C)=idom(D)=A, idom(E)=D, idom(exit)=E; DF(B)=DF(C)={D}, DF(D)=DF(E)={A}.)*
10. **Liveness** ([Data-flow Analysis](#dataflow)). Run the worklist algorithm by hand on `B1: a=1; b=2 → B2: c=a+b; if c<10 → (B3: a=c → B2) | B4: return b`. Which variables are live into B2? *(Answer: {a, b}.)*
11. **Your first pass** ([Writing a Pass](#writing-a-pass)). Build `CountInstsPass` and print, per function, the count of each opcode name (`I.getOpcodeName()`). Compare before and after `-O2`.
12. **Transformation** ([Writing a Pass](#writing-a-pass)). Extend `MulToShiftPass` to rewrite `udiv x, 2^k` into `lshr x, k`. Why is the same rewrite wrong for `sdiv`? *(Hint: try `-1 / 2`.)*
13. **Pipeline** ([Common Passes](#common-passes)). Write a loop with an invariant multiply. Run `mem2reg,loop-simplify,licm` and find where the multiply moved.

## Glossary

| Term | Meaning | Page |
| --- | --- | --- |
| Alloca | Stack allocation instruction; returns a `ptr` | [Memory](#memory) |
| Analysis | A pass that computes a cached result without changing IR | [Writing a Pass](#writing-a-pass) |
| Back edge | A CFG edge whose target dominates its source | [CFG and Loops](#cfg) |
| Basic block | Straight-line instructions ending in one terminator | [Structure](#structure) |
| Bitcode | The binary `.bc` form of IR | [Overview](#overview) |
| Canonical form | The one shape passes agree to use for an idiom | [Common Passes](#common-passes) |
| CFG | Control flow graph of blocks and terminator edges | [CFG and Loops](#cfg) |
| Critical edge | Edge from a multi-successor block to a multi-predecessor block | [CFG and Loops](#cfg) |
| Data layout | Module string that fixes sizes, alignment and endianness | [Type System](#types) |
| Dominance frontier | Blocks where a block's dominance ends; where `phi`s go | [Dominance](#dominance) |
| Dominator tree | Tree of immediate dominators | [Dominance](#dominance) |
| Fast-math flags | Per-instruction permission to relax IEEE floating-point rules | [Arithmetic](#arithmetic) |
| GEP | `getelementptr`, address arithmetic without memory access | [Memory](#memory) |
| Header | The entry block of a natural loop | [CFG and Loops](#cfg) |
| Intrinsic | Built-in function named `llvm.*` | [Control Flow](#control-flow) |
| Latch | Loop block with a back edge to the header | [CFG and Loops](#cfg) |
| Liveness | Whether a value may be read later | [Data-flow Analysis](#dataflow) |
| Metadata | Optional extra information (`!dbg`, `!tbaa`) | [Structure](#structure) |
| Module | The top-level container: one `.ll` file | [Structure](#structure) |
| `nsw` / `nuw` | No signed / unsigned wrap promise | [Arithmetic](#arithmetic) |
| Opaque pointer | The single `ptr` type, with no pointee type | [Type System](#types) |
| Phi | Instruction choosing a value by incoming edge | [SSA and Phi](#ssa-phi) |
| Poison | Value from a broken promise; UB only when it reaches a side effect | [Arithmetic](#arithmetic) |
| Post-dominance | Dominance on the reversed CFG | [Dominance](#dominance) |
| Preheader | Unique block outside a loop that enters the header | [CFG and Loops](#cfg) |
| `PreservedAnalyses` | What a pass returns to say which analyses are still valid | [Writing a Pass](#writing-a-pass) |
| SSA | Static single assignment: one definition per value | [SSA and Phi](#ssa-phi) |
| Terminator | Last instruction of a block (`br`, `ret`, `switch`, ...) | [Control Flow](#control-flow) |
| Use | One operand slot linking a user to a value | [Structure](#structure) |
| Value | Base class of almost everything in IR | [Structure](#structure) |
| Worklist | Queue of items to revisit until a fixed point | [Data-flow Analysis](#dataflow) |

**Sources:** [llvm/include/llvm/IR/Instruction.def:126-223](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def#L126-L223)

## Where to Go Next

- How IR becomes machine instructions: [SelectionDAG wiki](../selectiondag-wiki.html#overview).
- How a new target plugs into that: [Target Bring-up wiki](../bringup-wiki/bringup-wiki.html#overview).