# Control Flow Graph and Loops

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/IR/CFG.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/CFG.h)
- [llvm/lib/Analysis/CFG.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Analysis/CFG.cpp)
- [llvm/include/llvm/Support/GenericLoopInfo.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Support/GenericLoopInfo.h)
- [llvm/include/llvm/Analysis/LoopInfo.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Analysis/LoopInfo.h)
- [llvm/lib/Passes/PassRegistry.def](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def)

</details>

The control flow graph (CFG) of a function has one node per basic block and one edge for each way a terminator can jump. LLVM does not store the CFG as a separate data structure: successors are read from the terminator's operands, and predecessors are found by walking the block's use list. Loops are found from the CFG by the `LoopInfo` analysis.

## Purpose and Scope

This page covers predecessors and successors, the entry and exit blocks, critical edges, and natural loops with their header, preheader, latch and exits. The dominance theory that loop detection relies on is on [Dominance](#dominance).

## Successors and Predecessors

| Query | How LLVM answers it | Cost |
| --- | --- | --- |
| `successors(BB)` | The block operands of `BB`'s terminator | Constant per successor |
| `predecessors(BB)` | Users of `BB` (as a `Value`) that are terminators | Walks the use list |
| `pred_empty(BB)` | No predecessors (entry block, or unreachable) | |
| `BB->getSinglePredecessor()` | The one predecessor, or null | |

```cpp
// Illustrative: print the CFG edges of a function.
for (BasicBlock &BB : F)
  for (BasicBlock *Succ : successors(&BB))
    errs() << BB.getName() << " -> " << Succ->getName() << "\n";
```

Because a block is a `Value` and every branch uses it as an operand, the predecessor list is just the block's use list filtered to terminators. That is why `pred_begin` is an iterator over uses.

**Sources:** [llvm/include/llvm/IR/CFG.h:99-119](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/CFG.h#L99-L119), [llvm/include/llvm/IR/CFG.h:147](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/CFG.h#L147), [llvm/include/llvm/IR/CFG.h:170](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/CFG.h#L170)

## A Worked CFG

Using `@sum` from [SSA and Phi](#ssa-phi):

```mermaid
flowchart TD
    E["entry"] --> C["for.cond<br/>(phis, icmp, br)"]
    C -->|true| B["for.body"]
    C -->|false| X["for.end<br/>ret"]
    B -->|back edge| C
```

| Block | Predecessors | Successors |
| --- | --- | --- |
| `entry` | none | `for.cond` |
| `for.cond` | `entry`, `for.body` | `for.body`, `for.end` |
| `for.body` | `for.cond` | `for.cond` |
| `for.end` | `for.cond` | none (returns) |

`opt -passes=dot-cfg in.ll` writes one Graphviz `.dot` file per function (`.sum.dot` here), which `dot -Tpng` turns into a picture. The pass is registered as `FUNCTION_PASS("dot-cfg", CFGPrinterPass())`.

**Sources:** [llvm/lib/Passes/PassRegistry.def:436](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L436)

## Unreachable Blocks

A block with no path from the entry block is *unreachable*. It is valid IR, but analyses such as the dominator tree treat it specially and most passes skip it. `simplifycfg` deletes such blocks.

## Critical Edges

An edge A → B is **critical** if A has more than one successor and B has more than one predecessor. In the diamond below, the edge `entry → join` is critical:

```mermaid
flowchart TD
    E["entry: br %c, %then, %join"] --> T["then"]
    E -->|critical| J["join"]
    T --> J
```

There is nowhere to put code that should run only on that edge: putting it at the end of `entry` also runs it on the way to `then`, and putting it at the start of `join` also runs it when coming from `then`. Passes that need to insert code on edges, such as PHI elimination or partial redundancy elimination, *split* the edge by inserting a new empty block between A and B. `isCriticalEdge(TI, SuccNum)` tests an edge, and `SplitCriticalEdge` in `BasicBlockUtils` splits it.

**Sources:** [llvm/lib/Analysis/CFG.cpp:106-112](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Analysis/CFG.cpp#L106-L112)

## Natural Loops

A **back edge** is an edge whose target dominates its source (the target is always reached before the source). Each back edge defines a natural loop: the target is the loop **header**, and the loop body is every block that can reach the back edge's source without going through the header.

| Part | Definition | In `@sum` |
| --- | --- | --- |
| Header | The single entry block of the loop; dominates every block in it | `for.cond` |
| Latch | A block with a back edge to the header | `for.body` |
| Preheader | The single block outside the loop that branches to the header, and only to it | `entry` |
| Exiting block | A loop block with a successor outside the loop | `for.cond` |
| Exit block | A block outside the loop reached from an exiting block | `for.end` |

Loops nest: an inner loop's blocks are a subset of the outer loop's. `LoopInfo` builds a forest of `Loop` objects, each with its blocks and its sub-loops. The accessors are on `LoopBase`: `getHeader()` returns the first block, `getLoopPreheader()` and `getLoopLatch()` return null if there is no unique one.

Many loop passes need a preheader (a place to hoist code into) and a single latch. The `loop-simplify` pass creates them, which is why it runs before `licm` and other loop passes.

**Sources:** [llvm/include/llvm/Support/GenericLoopInfo.h:59](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Support/GenericLoopInfo.h#L59), [llvm/include/llvm/Support/GenericLoopInfo.h:105](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Support/GenericLoopInfo.h#L105), [llvm/include/llvm/Support/GenericLoopInfo.h:310-320](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Support/GenericLoopInfo.h#L310-L320), [llvm/include/llvm/Analysis/LoopInfo.h:40](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Analysis/LoopInfo.h#L40), [llvm/include/llvm/Analysis/LoopInfo.h:433](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Analysis/LoopInfo.h#L433)

## Printing Loops

`opt -disable-output -passes='print<loops>' sum.ll` prints the loop forest. For `@sum` the output has this shape (illustrative):

```text
Loop info for function 'sum':
Loop at depth 1 containing: %for.cond<header><exiting>,%for.body<latch>
```

The printer is `LoopPrinterPass`, registered as `print<loops>`; the analysis it prints is `LoopAnalysis`.

**Sources:** [llvm/include/llvm/Analysis/LoopInfo.h:594-605](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Analysis/LoopInfo.h#L594-L605), [llvm/lib/Passes/PassRegistry.def:526](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L526)

## Key Points

- The CFG is implicit: successors come from terminators, predecessors from use lists.
- A critical edge goes from a multi-successor block to a multi-predecessor block; split it to insert code on it.
- A natural loop has one header; `loop-simplify` gives it a preheader and a single latch.