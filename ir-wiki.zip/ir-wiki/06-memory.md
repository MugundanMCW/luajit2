# Memory: alloca, load, store and getelementptr

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/IR/Instruction.def](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def)
- [llvm/include/llvm/IR/Instructions.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h)

</details>

SSA values live in unlimited virtual registers, but programs also need memory: stack variables, globals, the heap and anything reached through a pointer. LLVM IR touches memory only through a few explicit instructions. `alloca` reserves stack space, `load` reads, `store` writes, and `getelementptr` computes addresses without touching memory at all.

## Purpose and Scope

This page covers `alloca`, `load`, `store`, `getelementptr` (with worked offset calculations), and gives a short introduction to atomics and fences. How `mem2reg` removes most `alloca`s is on [SSA and Phi](#ssa-phi).

## The Memory Instructions

| Opcode | C++ class | Purpose |
| --- | --- | --- |
| `alloca` | `AllocaInst` | Reserve space in the current function's stack frame |
| `load` | `LoadInst` | Read a value of a stated type from an address |
| `store` | `StoreInst` | Write a value to an address |
| `getelementptr` | `GetElementPtrInst` | Compute an address from a base pointer and indices |
| `fence` | `FenceInst` | Order memory operations between threads |
| `cmpxchg` | `AtomicCmpXchgInst` | Atomic compare and exchange |
| `atomicrmw` | `AtomicRMWInst` | Atomic read-modify-write (`add`, `xchg`, `max`, ...) |

**Sources:** [llvm/include/llvm/IR/Instruction.def:171-179](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def#L171-L179)

## alloca

```llvm
%x = alloca i32, align 4             ; illustrative: int x;
%buf = alloca [16 x i8], align 1     ; char buf[16];
```

`alloca` returns a `ptr` to fresh stack memory that is freed automatically when the function returns. The memory starts uninitialised. Clang puts every local variable, and every parameter, in an `alloca` in the entry block, because that is easy to generate; `mem2reg` later turns most of them into SSA values.

**Sources:** [llvm/include/llvm/IR/Instructions.h:65](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L65)

## load and store

```llvm
; illustrative: x = x + 1;
%old = load i32, ptr %x, align 4
%new = add nsw i32 %old, 1
store i32 %new, ptr %x, align 4
```

- `load <type>, ptr <addr>` reads. Because pointers are opaque, the type is written on the instruction.
- `store <type> <value>, ptr <addr>` writes. The value comes first, then the address. `store` produces no value.
- `align N` promises that the address is a multiple of N. Lying about alignment is undefined behaviour.
- `volatile` (`load volatile i32, ...`) forbids the optimizer from removing or merging the access, for memory-mapped hardware.

**Sources:** [llvm/include/llvm/IR/Instructions.h:197](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L197), [llvm/include/llvm/IR/Instructions.h:338](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L338)

## getelementptr

`getelementptr` (GEP) computes `base + offset`, where the offset comes from walking a type with a list of indices. **It never reads memory**; it only does arithmetic. Its form is:

```text
%p = getelementptr [inbounds] <source element type>, ptr %base, <idx0>, <idx1>, ...
```

The rules:

1. The first index steps over whole copies of the source element type, as in C pointer arithmetic `base + idx0`.
2. Each later index steps into the current type: an array index picks an element, a struct index (always a constant `i32`) picks a field.

### Worked Examples

These assume the AArch64 data layout: `i32` is 4 bytes, `ptr` and `i64` are 8 bytes, aligned to their size.

**Array element.** `int a[10]; ... &a[i]`

```llvm
; illustrative
@a = global [10 x i32] zeroinitializer
%p = getelementptr inbounds [10 x i32], ptr @a, i64 0, i64 %i
```

Index 0 steps over 0 whole arrays, index `%i` picks element `i`: offset = 0 * 40 + i * 4.

The same address can be written with a simpler source type, and newer Clang usually emits this form:

```llvm
%p = getelementptr inbounds i32, ptr @a, i64 %i      ; offset = i * 4
```

**Struct field.** `struct Point { int x; int y; }; ... &pts[1].y`

```llvm
; illustrative
%struct.Point = type { i32, i32 }
%q = getelementptr inbounds %struct.Point, ptr %pts, i64 1, i32 1
```

Index 1 steps over one whole `Point` (8 bytes); field index 1 picks `y` at offset 4 within it. Total offset 12.

**Struct with padding.** `struct Node { int v; struct Node *next; }; ... &n->next`

```llvm
; illustrative
%struct.Node = type { i32, ptr }
%nx = getelementptr inbounds %struct.Node, ptr %n, i64 0, i32 1
```

`ptr` is 8-byte aligned, so there are 4 padding bytes after `v` and `next` is at offset 8, not 4. The data layout decides this, not the GEP.

| Example | Indices | Offset in bytes |
| --- | --- | --- |
| `&a[i]` | `0, %i` on `[10 x i32]` | `4*i` |
| `&pts[1].y` | `1, 1` on `{i32, i32}` | `8 + 4 = 12` |
| `&n->next` | `0, 1` on `{i32, ptr}` | `8` |

### inbounds

`inbounds` promises that the base and the result point into the same allocated object (or one past its end). If that is false the result is poison. It lets alias analysis assume that `&a[i]` cannot point into some other variable.

A common beginner mistake is to think GEP dereferences a pointer. `p->next->v` needs two GEPs with a `load` between them, because following `next` reads memory:

```llvm
; illustrative: p->next->v
%nextaddr = getelementptr inbounds %struct.Node, ptr %p, i64 0, i32 1
%next = load ptr, ptr %nextaddr, align 8
%vaddr = getelementptr inbounds %struct.Node, ptr %next, i64 0, i32 0
%v = load i32, ptr %vaddr, align 4
```

**Sources:** [llvm/include/llvm/IR/Instructions.h:1034](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L1034)

## Atomics, Briefly

For multi-threaded code, loads and stores can be atomic with an ordering, and there are three extra instructions:

```llvm
; illustrative
%v = load atomic i32, ptr %p acquire, align 4
store atomic i32 1, ptr %p release, align 4
%old = atomicrmw add ptr %counter, i32 1 seq_cst
%pair = cmpxchg ptr %p, i32 %expected, i32 %new seq_cst seq_cst
fence seq_cst
```

The orderings (`monotonic`, `acquire`, `release`, `acq_rel`, `seq_cst`) follow the C++11 memory model. `cmpxchg` returns a `{ i32, i1 }` struct: the old value and whether the exchange happened. Most optimizations leave atomics alone.

## Key Points

- Only `load`, `store`, atomics and calls touch memory; `getelementptr` is pure arithmetic.
- The first GEP index steps over whole objects; later indices step into arrays and structs.
- Clang emits an `alloca` per local variable; `mem2reg` removes most of them.