# Compare and Select

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/IR/InstrTypes.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/InstrTypes.h)
- [llvm/include/llvm/IR/Instructions.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h)
- [llvm/include/llvm/IR/Instruction.def](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def)

</details>

Comparisons produce an `i1` (true or false). `icmp` compares integers and pointers, `fcmp` compares floating-point values, and `select` picks one of two values based on an `i1`. Together they express every `if`, `?:`, `min` and `max` in a program.

## Purpose and Scope

This page covers `icmp` and its ten predicates, `fcmp` and its sixteen predicates (including what "ordered" means), and `select`. Using an `i1` to branch is on [Control Flow](#control-flow).

## icmp

The form is `%c = icmp <pred> <type> %a, %b`. Because integers carry no sign (see [Type System](#types)), the predicate says whether to compare as signed or unsigned:

| Predicate | Meaning | C example (`int a, b`) | C example (`unsigned a, b`) |
| --- | --- | --- | --- |
| `eq` | equal | `a == b` | `a == b` |
| `ne` | not equal | `a != b` | `a != b` |
| `sgt` / `ugt` | greater than | `a > b` | `a > b` |
| `sge` / `uge` | greater or equal | `a >= b` | `a >= b` |
| `slt` / `ult` | less than | `a < b` | `a < b` |
| `sle` / `ule` | less or equal | `a <= b` | `a <= b` |

```llvm
; illustrative: int is_neg(int x) { return x < 0; }
%c = icmp slt i32 %x, 0
%r = zext i1 %c to i32
ret i32 %r
```

The same bits give different answers: for `%x = -1` (all ones), `icmp slt i32 %x, 0` is true but `icmp ult i32 %x, 0` is false, because unsigned all-ones is the largest value.

`icmp` also works on vectors, giving a vector of `i1`, and on `ptr`, comparing addresses.

In C++ the predicates are the `CmpInst::Predicate` enum; `ICMP_EQ` is 32 through `ICMP_SLE` at 41.

**Sources:** [llvm/include/llvm/IR/InstrTypes.h:728](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/InstrTypes.h#L728), [llvm/include/llvm/IR/InstrTypes.h:761-773](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/InstrTypes.h#L761-L773), [llvm/include/llvm/IR/Instructions.h:1262](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L1262)

## fcmp and NaN

Floating-point comparison has a complication: NaN (not a number) is unordered, it is neither less than, equal to nor greater than anything, including itself. Every `fcmp` predicate therefore states what to return when either operand is NaN:

- **Ordered** predicates (`o` prefix) return false if either operand is NaN.
- **Unordered** predicates (`u` prefix) return true if either operand is NaN.

| Ordered | Unordered | Relation |
| --- | --- | --- |
| `oeq` | `ueq` | equal |
| `one` | `une` | not equal |
| `ogt` | `ugt` | greater than |
| `oge` | `uge` | greater or equal |
| `olt` | `ult` | less than |
| `ole` | `ule` | less or equal |
| `ord` | `uno` | "neither is NaN" / "at least one is NaN" |
| `false` | `true` | always false / always true |

C's `a == b` on doubles is `fcmp oeq`; C's `a != b` is `fcmp une`, because `NaN != NaN` is true in C. `isnan(x)` can be written `fcmp uno double %x, %x`.

The enum comment in `InstrTypes.h` shows the encoding: four bits U, L, G, E (unordered, less, greater, equal), and each predicate is the set of outcomes for which it is true. For example `FCMP_OEQ = 1` is just E and `FCMP_UNO = 8` is just U.

**Sources:** [llvm/include/llvm/IR/InstrTypes.h:740-760](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/InstrTypes.h#L740-L760), [llvm/include/llvm/IR/Instructions.h:1495](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L1495)

## select

`%r = select i1 %c, <type> %t, <type> %f` is `c ? t : f` without a branch. Both `%t` and `%f` are already computed; `select` only chooses.

```llvm
; illustrative: int max(int a, int b) { return a > b ? a : b; }
define i32 @max(i32 %a, i32 %b) {
entry:
  %gt = icmp sgt i32 %a, %b
  %r = select i1 %gt, i32 %a, i32 %b
  ret i32 %r
}
```

The optimizer turns small `if`/`else` diamonds into `select` when both sides are cheap and safe to compute (`simplifycfg` does this, see [Common Passes](#common-passes)), because a select avoids a branch that may be mispredicted. The back end can lower `select` to a conditional move such as AArch64 `csel`.

A vector `select` takes a vector of `i1` and picks per lane. Recognised `select` shapes such as `min`/`max` are often rewritten to intrinsics such as `llvm.smax.i32`.

**Sources:** [llvm/include/llvm/IR/Instructions.h:1776](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L1776), [llvm/include/llvm/IR/Instruction.def:207-212](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def#L207-L212)

## Key Points

- `icmp` predicates pick signed or unsigned; `fcmp` predicates pick what NaN means.
- Results are `i1`; use `zext` to turn one into a C `int`.
- `select` chooses between two already computed values without branching.