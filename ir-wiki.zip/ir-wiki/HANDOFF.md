# Handoff: LLVM IR Basics Wiki

## Status

- All 14 pages are written (`01-overview.md` … `14-tooling-glossary.md`). The HTML is built at `ir-wiki/ir-wiki.html` with `python %TEMP%\rawiki\wiki_build.py ir`. The citation range check and cross-wiki link check both pass.
- The `"ir"` entry is in the `WIKIS` table of `%TEMP%\rawiki\wiki_build.py`.
- **Not done:** the wiki is not yet in `llvm-backend-guide.zip`. The user asked to leave the zip alone for now.
- **Not done:** real tool output. Every IR listing, printer output and C++ example is marked *illustrative*. The local build (`c:\source\llvm-project\build\Release\bin`) only has `llc`, `FileCheck`, `llvm-tblgen`, `llvm-min-tblgen`, `count` and `not`. `opt` can be built from the existing tree (`tools\opt\opt.vcxproj`). `clang` cannot: `LLVM_ENABLE_PROJECTS` is empty, so getting it needs a reconfigure and a full clang build.

## Facts found in this checkout (a2171756) that differ from older tutorials

- `br` is two classes, `UncondBrInst` and `CondBrInst`; there is no `BranchInst`. The text syntax is still `br` (`LLParser::parseBr`).
- There is a new cast, `ptrtoaddr`.
- The plugin header is `llvm/include/llvm/Plugins/PassPlugin.h`, not `Passes/`. `LLVM_PLUGIN_API_VERSION` is 2.
- `HelloWorldPass` uses `OptionalPassInfoMixin`, and `PassManager.h` says real passes should use `RequiredPassInfoMixin` or `OptionalPassInfoMixin`.
- `llvm/docs/LangRef.rst` is not in the checkout, so it is not cited.

## To add real output later

1. Build `opt` (and `llvm-as`/`llvm-dis`) in `c:\source\llvm-project\build` (Release).
2. Run the commands on page 14. Replace the illustrative listings on pages 8, 9, 10 and 13 with real `opt -passes=mem2reg`, `print<loops>`, `print<domtree>` and pass before/after output, and drop the "illustrative" labels on those blocks.
3. For the input IR (`clang -S -emit-llvm`), either reconfigure with `-DLLVM_ENABLE_PROJECTS=clang` or keep the hand-written `.ll` inputs, labelled as such.
4. Page 12: compile the example passes. Check whether `-load-pass-plugin` works on this Windows build (`LLVM_ENABLE_PLUGINS`); if not, register the passes in `PassRegistry.def` instead.
5. Rebuild with `python %TEMP%\rawiki\wiki_build.py ir`.

## To add to the combined guide

Add a tuple for `ir-wiki` to `WIKIS` in `%TEMP%\rawiki\guide_build.py`, placed first (Part 0 or Part 1, before bring-up). Then run `python %TEMP%\rawiki\guide_build.py`, which rebuilds `llvm-backend-guide.zip`.

## Conventions

Pages follow the other wikis: `# Title`, a `<details>` "Relevant source files" block, a lead paragraph, `## Purpose and Scope`, and sections ending in `**Sources:**` lines. Each citation links to GitHub at commit a2171756, in the form `https://github.com/llvm/llvm-project/blob/` + commit + `/llvm/...#Lx-Ly`. `verify.py` checks only that each file exists and that each line range fits in it. Line contents were checked by hand with `Select-String` before citing.

## Page ids

overview, structure, types, arithmetic, compare, memory, control-flow, ssa-phi, cfg, dominance, dataflow, writing-a-pass, common-passes, tooling-glossary