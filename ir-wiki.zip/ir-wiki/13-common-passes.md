# Common Passes

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Passes/PassRegistry.def](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def)
- [llvm/lib/Transforms/Utils/PromoteMemoryToRegister.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Utils/PromoteMemoryToRegister.cpp)
- [llvm/lib/Transforms/InstCombine/InstructionCombining.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/InstCombine/InstructionCombining.cpp)
- [llvm/lib/Transforms/Scalar/SimplifyCFGPass.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/SimplifyCFGPass.cpp)
- [llvm/lib/Transforms/Scalar/GVN.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/GVN.cpp)
- [llvm/lib/Transforms/Scalar/LICM.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/LICM.cpp)
- [llvm/lib/Transforms/Scalar/DCE.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/DCE.cpp)

</details>

A handful of passes do most of the work in every optimization pipeline. Each is simple to describe in terms of the ideas from earlier pages: `mem2reg` builds SSA, `instcombine` rewrites instruction patterns, `simplifycfg` cleans up the CFG, `gvn` removes redundant computations, `licm` moves work out of loops, and `dce` deletes unused code. This page shows what each one does with a small before/after example.

> All before/after IR on this page is **illustrative**, written by hand to show the typical effect of each pass. It was not produced by running `opt`.

## Purpose and Scope

This page covers six passes, the analyses each relies on, and the source location of each `run` method. It is not a full description of any of them: `instcombine` alone has thousands of rewrite rules. Writing your own pass is on [Writing a Pass](#writing-a-pass).

## Summary

| Pass name | What it does | Relies on | Entry point |
| --- | --- | --- | --- |
| `mem2reg` | Promote `alloca`s to SSA values, insert `phi`s | Dominator tree | `PromoteMemToReg` |
| `instcombine` | Local algebraic rewrites and canonicalisation | Known bits, simplify queries | `InstCombinePass::run` |
| `simplifycfg` | Merge, remove and simplify blocks and branches | CFG only | `SimplifyCFGPass::run` |
| `gvn` | Remove redundant computations and loads | Dominator tree, memory dependence, alias analysis | `GVNPass::run` |
| `licm` | Hoist loop-invariant code out of loops, sink code below them | Loop info, dominator tree, MemorySSA | `LICMPass::run` |
| `dce` / `adce` | Delete instructions whose results are unused | Use lists; `adce` also post-dominators | `DCEPass::run` |

**Sources:** [llvm/lib/Passes/PassRegistry.def:410](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L410), [llvm/lib/Passes/PassRegistry.def:432](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L432), [llvm/lib/Passes/PassRegistry.def:491](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L491), [llvm/lib/Passes/PassRegistry.def:609-621](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L609-L621)

## mem2reg

Covered in detail on [SSA and Phi](#ssa-phi).

```llvm
; before                                  ; after
%x = alloca i32                           ;
store i32 %a, ptr %x                      ;
%v = load i32, ptr %x                     ;
%r = add i32 %v, 1                        %r = add i32 %a, 1
```

In the standard `-O` pipelines its job is done by `sroa`, which also splits structs and arrays into separate scalars first.

**Sources:** [llvm/lib/Transforms/Utils/PromoteMemoryToRegister.cpp:1259](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Utils/PromoteMemoryToRegister.cpp#L1259)

## instcombine

`instcombine` visits instructions one at a time and replaces each with a simpler or more canonical equivalent. It keeps a worklist: whenever it changes an instruction, that instruction's users go back on the list, and it runs until the worklist is empty.

```llvm
; before
%a = add i32 %x, 0          ; x + 0
%b = mul i32 %a, 8          ; x * 8
%c = sub i32 0, %b
%d = sub i32 %y, %c         ; y - (0 - b)

; after
%b = shl i32 %x, 3
%d = add i32 %y, %b
```

Typical rules: identities (`x+0`, `x*1`, `x&x`), strength reduction (`mul` by a power of two to `shl`), constant folding, removing double negation, and putting constants on the right (`add 1, %x` becomes `add %x, 1`) so that other rules only need to match one form.

*Canonicalisation* matters as much as simplification: if every pass can rely on one shape for an idiom, each pass needs fewer patterns.

**Sources:** [llvm/lib/Transforms/InstCombine/InstructionCombining.cpp:5777](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/InstCombine/InstructionCombining.cpp#L5777), [llvm/lib/Transforms/InstCombine/InstructionCombining.cpp:6255](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/InstCombine/InstructionCombining.cpp#L6255)

## simplifycfg

`simplifycfg` cleans up the CFG: it deletes unreachable blocks, merges a block into its only predecessor, removes empty forwarding blocks, folds branches on constants, and turns small `if`/`else` diamonds into `select`.

Continuing the `@pick` example from [SSA and Phi](#ssa-phi):

```llvm
; before (after mem2reg)
entry:
  %tobool = icmp ne i32 %c, 0
  br i1 %tobool, label %if.then, label %if.else
if.then:
  br label %if.end
if.else:
  br label %if.end
if.end:
  %x.0 = phi i32 [ 1, %if.then ], [ 2, %if.else ]
  ret i32 %x.0

; after
entry:
  %tobool = icmp ne i32 %c, 0
  %x.0 = select i1 %tobool, i32 1, i32 2
  ret i32 %x.0
```

Three blocks and two branches became one block. `instcombine` might then simplify the `select` further.

**Sources:** [llvm/lib/Transforms/Scalar/SimplifyCFGPass.cpp:378](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/SimplifyCFGPass.cpp#L378)

## gvn

Global value numbering gives every computed value a number such that two instructions get the same number when they are certain to compute the same result. If an instruction's number was already computed by an instruction that dominates it, the second one is replaced by the first.

```llvm
; before
%a1 = add i32 %x, %y
%v1 = load i32, ptr %p
call void @use(i32 %a1, i32 %v1)
%a2 = add i32 %x, %y          ; same as %a1
%v2 = load i32, ptr %p        ; same as %v1 if nothing wrote *p in between
call void @use(i32 %a2, i32 %v2)

; after (assuming @use cannot write *p, e.g. it is memory(none))
%a1 = add i32 %x, %y
%v1 = load i32, ptr %p
call void @use(i32 %a1, i32 %v1)
call void @use(i32 %a1, i32 %v1)
```

The arithmetic part needs only SSA and dominance. The load part needs memory dependence and alias analysis: GVN must prove that no store or call in between could have changed `*p`. This is the "available expressions" idea from [Data-flow Analysis](#dataflow), done sparsely on SSA values.

**Sources:** [llvm/lib/Transforms/Scalar/GVN.cpp:892](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/GVN.cpp#L892), [llvm/lib/Transforms/Scalar/GVN.cpp:3315](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/GVN.cpp#L3315)

## licm

Loop-invariant code motion moves computations whose operands do not change inside a loop out to the loop's preheader (see [CFG and Loops](#cfg)), so they run once instead of every iteration.

```llvm
; before
loop:
  %i = phi i64 [ 0, %entry ], [ %i.next, %loop ]
  %scale = mul i64 %n, 4               ; %n is defined outside the loop
  %off = add i64 %i, %scale
  ...
  br i1 %done, label %exit, label %loop

; after
entry:                                 ; the preheader
  %scale = mul i64 %n, 4
  br label %loop
loop:
  %i = phi i64 [ 0, %entry ], [ %i.next, %loop ]
  %off = add i64 %i, %scale
  ...
```

`hoistRegion` walks the loop's blocks in dominator-tree order and hoists an instruction when all its operands are defined outside the loop and moving it is safe: it must not trap (a division might, if the loop could run zero times) and, for loads, nothing in the loop may write that memory. `sinkRegion` does the reverse, moving code that is only needed after the loop into the exit blocks. LICM is a loop pass: `LICMPass::run` takes a `Loop &`.

**Sources:** [llvm/lib/Transforms/Scalar/LICM.cpp:311](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/LICM.cpp#L311), [llvm/lib/Transforms/Scalar/LICM.cpp:567](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/LICM.cpp#L567), [llvm/lib/Transforms/Scalar/LICM.cpp:896](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/LICM.cpp#L896)

## dce and adce

`dce` deletes instructions that have no uses and no side effects, using the worklist described on [Data-flow Analysis](#dataflow):

```llvm
; before
%a = add i32 %x, 1
%b = mul i32 %a, 2        ; %b is never used
ret i32 %x

; after
ret i32 %x
```

Deleting `%b` makes `%a` unused too, so it is deleted next. Stores and calls with side effects are kept even if they produce no used value.

`adce` (aggressive DCE) works the other way: it assumes everything is dead, marks as live only instructions with side effects and whatever they transitively use, and deletes the rest. With post-dominance (see [Dominance](#dominance)) it can also delete branches whose outcome does not affect any live instruction, and so remove whole loops that compute nothing.

**Sources:** [llvm/lib/Transforms/Scalar/DCE.cpp:89-110](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/DCE.cpp#L89-L110)

## How They Work Together

No single pass does much alone; each one creates opportunities for the others. A typical sequence on Clang output:

```mermaid
flowchart LR
    S["sroa / mem2reg<br/>SSA from allocas"] --> I1["instcombine<br/>simplify"]
    I1 --> C["simplifycfg<br/>clean CFG"]
    C --> L["licm<br/>hoist from loops"]
    L --> G["gvn<br/>remove redundancy"]
    G --> I2["instcombine"]
    I2 --> D["dce / adce"]
```

Try it on a file of your own:

```text
opt -S -passes='mem2reg,instcombine,simplifycfg' in.ll
opt -S -passes='mem2reg,loop-simplify,licm,gvn,dce' in.ll
opt -S -O2 in.ll                       ; the full default pipeline
opt -S -O2 -print-after-all in.ll 2> trace.txt   ; IR after every pass
```

## Key Points

- `mem2reg` builds SSA; `instcombine` and `simplifycfg` clean up locally and in the CFG.
- `gvn` removes redundant values and loads; `licm` moves invariant work to the preheader.
- `dce`/`adce` remove what other passes left unused; passes are run repeatedly because each enables the others.