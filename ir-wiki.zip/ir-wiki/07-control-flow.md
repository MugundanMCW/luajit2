# Control Flow: br, switch, ret and call

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/IR/Instruction.def](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def)
- [llvm/include/llvm/IR/Instructions.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h)
- [llvm/lib/AsmParser/LLParser.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/AsmParser/LLParser.cpp)

</details>

Inside a basic block, instructions run top to bottom. Between blocks, control moves only through the *terminator* at the end of each block. A terminator either jumps to other blocks (`br`, `switch`), leaves the function (`ret`), or states that control can never reach that point (`unreachable`). `call` is not a terminator: execution comes back to the next instruction after the call.

## Purpose and Scope

This page covers `ret`, unconditional and conditional `br`, `switch`, `unreachable` and `call`, and gives a short introduction to `invoke` and exceptions. How terminators form a graph is on [CFG and Loops](#cfg).

## The Terminators

`Instruction.def` lists the terminators first, in lines 126-139:

| Opcode (text) | C++ class | Successors | Purpose |
| --- | --- | --- | --- |
| `ret` | `ReturnInst` | none | Return from the function |
| `br label %d` | `UncondBrInst` | 1 | Unconditional jump |
| `br i1 %c, label %t, label %f` | `CondBrInst` | 2 | Two-way conditional jump |
| `switch` | `SwitchInst` | many | Multi-way jump on an integer |
| `indirectbr` | `IndirectBrInst` | many | Jump to a computed block address |
| `invoke` | `InvokeInst` | 2 | Call that may throw |
| `resume`, `cleanupret`, `catchret`, `catchswitch` | ... | | Exception handling |
| `unreachable` | `UnreachableInst` | none | Control never gets here |
| `callbr` | `CallBrInst` | many | `asm goto` |

> **Version note.** Older LLVM releases, and most tutorials, use a single `BranchInst` class for both kinds of `br`. In this checkout it is split into `UncondBrInst` and `CondBrInst`. The text syntax is unchanged: the parser reads `br` and creates one class or the other depending on whether a condition is present.

**Sources:** [llvm/include/llvm/IR/Instruction.def:126-139](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def#L126-L139), [llvm/lib/AsmParser/LLParser.cpp:8050-8071](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/AsmParser/LLParser.cpp#L8050-L8071)

## ret

```llvm
ret i32 %v        ; illustrative: return a value
ret void          ; return from a void function
```

The type must match the function's return type. A function may contain several `ret` instructions, one in each exit block.

**Sources:** [llvm/include/llvm/IR/Instructions.h:3065](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L3065)

## br

```llvm
; illustrative: int abs(int x) { if (x < 0) x = -x; return x; }
define i32 @abs(i32 %x) {
entry:
  %neg = icmp slt i32 %x, 0
  br i1 %neg, label %then, label %done     ; conditional: CondBrInst

then:
  %nx = sub nsw i32 0, %x
  br label %done                           ; unconditional: UncondBrInst

done:
  %r = phi i32 [ %nx, %then ], [ %x, %entry ]
  ret i32 %r
}
```

- The condition of a conditional `br` must be an `i1`, usually from `icmp` or `fcmp`.
- Targets are written `label %name`. A label is a `BasicBlock` value used as an operand.
- If the condition is poison, the behaviour is undefined (see [Arithmetic](#arithmetic)).
- The `phi` in `done` chooses `%x` or `%nx` depending on which block came before; this is explained on [SSA and Phi](#ssa-phi).

**Sources:** [llvm/include/llvm/IR/Instructions.h:3151](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L3151), [llvm/include/llvm/IR/Instructions.h:3217](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L3217)

## switch

```llvm
; illustrative: switch (op) { case 0: ...; case 1: ...; default: ... }
switch i32 %op, label %default [
  i32 0, label %case0
  i32 1, label %case1
]
```

A `switch` names a default target, then a list of constant values and their targets. The back end lowers it to a jump table, a binary search of compares, or a bit test, whichever is cheaper. `simplifycfg` may turn a short chain of `icmp`/`br` into a `switch`, or the reverse.

**Sources:** [llvm/include/llvm/IR/Instructions.h:3296](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L3296)

## unreachable

`unreachable` says that execution can never get here. Clang emits it after a call to a `noreturn` function such as `abort()`, and at the end of a non-void function that falls off its end. Optimizers treat reaching it as undefined behaviour, so they may delete any code path that must lead to it.

```llvm
call void @abort()        ; illustrative
unreachable
```

**Sources:** [llvm/include/llvm/IR/Instructions.h:4662](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L4662)

## call

```llvm
; illustrative
%r = call i32 @add(i32 %a, i32 %b)
call void @free(ptr %p)
%r2 = tail call i32 %fnptr(i32 1)          ; indirect call through a pointer
%m = call i32 @llvm.smax.i32(i32 %a, i32 %b) ; an intrinsic
```

- The callee is a `ptr`: either a function name (direct call) or any pointer value (indirect call).
- The function type is written on the call, so with opaque pointers the call itself states the parameter types.
- `tail` is a hint that the call can reuse the caller's stack frame; `musttail` makes that required.
- Functions whose names start with `llvm.` are *intrinsics*: built-in operations such as `llvm.memcpy`, `llvm.smax` or `llvm.dbg.value` that passes and back ends understand directly.

How a call becomes argument registers and a branch-and-link instruction is covered by the [Calling Conventions wiki](../callconv-wiki/callconv-wiki.html#overview).

**Sources:** [llvm/include/llvm/IR/Instructions.h:1597](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instructions.h#L1597), [llvm/include/llvm/IR/Instruction.def:211](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def#L211)

## invoke and landingpad, Briefly

In C++, a call that may throw must say where to go if it does. `invoke` is a call that is also a terminator with two successors:

```llvm
; illustrative
%r = invoke i32 @may_throw()
        to label %ok unwind label %lpad

ok:
  ret i32 %r

lpad:
  %ex = landingpad { ptr, i32 } cleanup
  ; run destructors, then:
  resume { ptr, i32 } %ex
}
```

On a normal return control goes to `%ok`. If an exception is thrown it goes to `%lpad`, whose first instruction must be a `landingpad`. A plain `call` inside a function compiled with exceptions enabled is allowed only if the callee is `nounwind`, or if an exception may simply propagate out of the caller.

## Key Points

- Every block ends in exactly one terminator, and only terminators move control between blocks.
- In this checkout `br` is two classes, `UncondBrInst` and `CondBrInst`; the text form is still `br`.
- `call` returns to the next instruction; `invoke` is a call that is also a terminator.