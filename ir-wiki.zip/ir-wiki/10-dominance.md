# Dominance, Dominator Tree and Dominance Frontier

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/IR/Dominators.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Dominators.h)
- [llvm/include/llvm/Support/GenericDomTree.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Support/GenericDomTree.h)
- [llvm/include/llvm/Analysis/DominanceFrontier.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Analysis/DominanceFrontier.h)
- [llvm/include/llvm/Analysis/PostDominators.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Analysis/PostDominators.h)
- [llvm/lib/Passes/PassRegistry.def](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def)

</details>

Block A *dominates* block B if every path from the entry block to B passes through A. Dominance answers "is this value guaranteed to have been computed here?", which is what SSA, loop detection, code motion and `phi` placement all need. LLVM computes it once per function as a *dominator tree* and keeps it up to date as passes change the CFG.

## Purpose and Scope

This page defines dominance, immediate dominators, the dominator tree, the dominance frontier and post-dominance, works through an example, and shows the LLVM classes and printer passes. Use of these in `mem2reg` is on [SSA and Phi](#ssa-phi).

## Definitions

| Term | Definition |
| --- | --- |
| A **dominates** B | Every path from entry to B goes through A. Every block dominates itself. |
| A **strictly** (properly) dominates B | A dominates B and A ≠ B |
| **Immediate dominator** idom(B) | The strict dominator of B closest to B. Every block except entry has exactly one. |
| **Dominator tree** | Tree with an edge idom(B) → B for every B. The entry block is the root. |
| **Dominance frontier** DF(A) | Blocks B such that A dominates a predecessor of B but does not strictly dominate B: where A's dominance "ends" |
| A **post-dominates** B | Every path from B to a function exit goes through A |

## A Worked Example

(illustrative CFG)

```mermaid
flowchart TD
    E["entry"] --> A["A"]
    A --> B["B"]
    A --> C["C"]
    B --> D["D"]
    C --> D
    D --> A
    D --> X["exit"]
```

| Block | Dominators | idom | Dominance frontier |
| --- | --- | --- | --- |
| entry | entry | none | {} |
| A | entry, A | entry | {A} (via the back edge from D) |
| B | entry, A, B | A | {D} |
| C | entry, A, C | A | {D} |
| D | entry, A, D | A | {A} |
| exit | entry, A, D, exit | D | {} |

Neither B nor C dominates D, because D can be reached through the other one. So D's idom is A. The dominator tree is:

```mermaid
flowchart TD
    E["entry"] --> A["A"]
    A --> B["B"]
    A --> C["C"]
    A --> D["D"]
    D --> X["exit"]
```

Reading the frontier: a variable assigned in B needs a `phi` in D, where B's value meets C's. A variable assigned in D needs a `phi` in A, where the value from the previous iteration meets the value from `entry`. That is exactly the rule `mem2reg` uses, with the frontier iterated because each new `phi` is itself a definition.

Since D → A goes to a block that dominates its source, it is a back edge, and A is a loop header; see [CFG and Loops](#cfg).

## The Dominator Tree in LLVM

`DominatorTree` is a `DominatorTreeBase<BasicBlock, false>` (the `false` means "not post-dominators"). Each node is a `DomTreeNode` with `getIDom()` and its children. The main queries:

| Call | Answers |
| --- | --- |
| `DT.dominates(A, B)` on blocks | Does block A dominate block B |
| `DT.dominates(Def, UseInst)` | Is `Def` available at instruction `UseInst` (handles instructions in the same block by order) |
| `DT.dominates(Def, U)` on a `Use` | Is `Def` available at this use; for a `phi` use, checks the end of the incoming block |
| `DT.properlyDominates(A, B)` | Strict dominance |
| `DT.getNode(BB)->getIDom()` | Immediate dominator |
| `DT.findNearestCommonDominator(A, B)` | Lowest block dominating both |

A pass obtains it from the analysis manager:

```cpp
// Illustrative
DominatorTree &DT = AM.getResult<DominatorTreeAnalysis>(F);
if (DT.dominates(Def, UserInst)) { /* safe to use Def here */ }
```

LLVM builds the tree with the Semi-NCA algorithm and can update it incrementally (`DomTreeUpdater`) when a pass adds or removes edges, rather than recomputing.

**Sources:** [llvm/include/llvm/IR/Dominators.h:122](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Dominators.h#L122), [llvm/include/llvm/IR/Dominators.h:140-175](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Dominators.h#L140-L175), [llvm/include/llvm/IR/Dominators.h:241](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Dominators.h#L241), [llvm/include/llvm/Support/GenericDomTree.h:112](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Support/GenericDomTree.h#L112), [llvm/include/llvm/Support/GenericDomTree.h:440-449](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Support/GenericDomTree.h#L440-L449)

## Printing the Tree

```text
opt -disable-output -passes='print<domtree>' example.ll
```

The output lists the tree with indentation by depth and DFS numbers in braces. For the example above it has this shape (illustrative):

```text
DominatorTree for function: example
=============================--------------------------------
Inorder Dominator Tree: DFSNumbers invalid: 0 slow queries.
  [1] %entry {4294967295,4294967295} [0]
    [2] %A {4294967295,4294967295} [1]
      [3] %B {4294967295,4294967295} [2]
      [3] %C {4294967295,4294967295} [2]
      [3] %D {4294967295,4294967295} [2]
        [4] %exit {4294967295,4294967295} [3]
Roots: %entry
```

The number in the first brackets is the depth. `print<postdomtree>` prints the post-dominator tree the same way.

**Sources:** [llvm/include/llvm/IR/Dominators.h:254](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Dominators.h#L254), [llvm/lib/Passes/PassRegistry.def:522](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L522), [llvm/lib/Passes/PassRegistry.def:530](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Passes/PassRegistry.def#L530)

## Dominance Frontier

`DominanceFrontier` stores DF(B) for every block. Most passes do not need the full table: `mem2reg` and SSA updating use `IDFCalculator`, which computes the *iterated* frontier of a set of blocks directly from the dominator tree (see [SSA and Phi](#ssa-phi)).

**Sources:** [llvm/include/llvm/Analysis/DominanceFrontier.h:43](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Analysis/DominanceFrontier.h#L43), [llvm/include/llvm/Analysis/DominanceFrontier.h:94](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Analysis/DominanceFrontier.h#L94), [llvm/include/llvm/Analysis/DominanceFrontier.h:134](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Analysis/DominanceFrontier.h#L134)

## Post-Dominance

Post-dominance is dominance on the reversed CFG, with the function exits as roots. In the example, D post-dominates B and C (both must pass through D to exit), and `exit` post-dominates everything.

It answers "if B runs, is A certain to run afterwards?". Uses include:

- **Control dependence**: B is control dependent on a branch if B post-dominates one successor of the branch but not the branch itself. Aggressive dead code elimination (`adce`) uses this to delete branches whose outcome does not matter.
- Sinking code to a point that is executed whenever the original was.

`PostDominatorTree` and `PostDominatorTreeAnalysis` are in `PostDominators.h`.

**Sources:** [llvm/include/llvm/Analysis/PostDominators.h:29](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Analysis/PostDominators.h#L29), [llvm/include/llvm/Analysis/PostDominators.h:48-64](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Analysis/PostDominators.h#L48-L64)

## Key Points

- A dominates B if every entry-to-B path goes through A; idom links form the dominator tree.
- The dominance frontier is where a block's dominance ends; `phi`s go at the iterated frontier of definitions.
- Post-dominance is dominance on the reversed CFG and gives control dependence.