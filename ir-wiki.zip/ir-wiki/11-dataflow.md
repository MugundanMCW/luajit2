# Data-flow Analysis

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/IR/Value.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Value.h)
- [llvm/include/llvm/IR/Use.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Use.h)
- [llvm/lib/Transforms/Utils/PromoteMemoryToRegister.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Utils/PromoteMemoryToRegister.cpp)
- [llvm/lib/Transforms/Scalar/DCE.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/DCE.cpp)

</details>

Data-flow analysis computes facts that hold at each point of a program, such as "which variables may still be read later" or "which assignments may reach here", by propagating information along CFG edges until nothing changes. Classic compiler textbooks present it on non-SSA code. In LLVM IR, SSA makes several of these analyses almost free, but the framework is still the way to think about anything that involves memory or whole-block facts.

## Purpose and Scope

This page covers the general framework (direction, transfer function, meet, fixed point), three classic analyses (liveness, reaching definitions, available expressions), the worklist algorithm, and how SSA use-def chains replace much of this in LLVM. All examples are illustrative and worked by hand.

## The Framework

Every data-flow analysis is defined by four choices:

| Choice | Meaning | Options |
| --- | --- | --- |
| Domain | What a fact is | Usually a set: of variables, definitions or expressions |
| Direction | Which way facts flow | **Forward** (from entry, along edges) or **backward** (from exits, against edges) |
| Transfer function | How a block changes the facts | Typically `OUT = GEN ∪ (IN − KILL)` |
| Meet | How facts from several edges combine | **Union** ("may" analyses) or **intersection** ("must" analyses) |

For a forward analysis on block B:

```text
IN[B]  = meet of OUT[P] over all predecessors P
OUT[B] = GEN[B] ∪ (IN[B] − KILL[B])
```

For a backward analysis swap the roles: `OUT[B]` is the meet over successors, and `IN[B]` is computed from `OUT[B]`.

Because loops make `IN` depend on `OUT` of later blocks, the equations are solved by iterating until no set changes: the *fixed point*. With finite sets and transfer functions that only ever grow (or only shrink) the sets, this always terminates.

## The Three Classic Analyses

| Analysis | Question | Direction | Meet | GEN[B] | KILL[B] |
| --- | --- | --- | --- | --- | --- |
| Liveness | Will this variable be read before being overwritten? | Backward | Union | Variables used in B before any assignment in B | Variables assigned in B |
| Reaching definitions | Which assignments may have produced the value here? | Forward | Union | Last assignment to each variable in B | Other assignments to the variables B assigns |
| Available expressions | Has `a+b` already been computed on *every* path, with `a`, `b` unchanged? | Forward | Intersection | Expressions computed in B and not later invalidated in B | Expressions using a variable assigned in B |

Uses: liveness drives register allocation and dead store elimination; reaching definitions drives constant propagation on non-SSA code; available expressions drives common subexpression elimination.

## Worked Example: Liveness

Non-SSA pseudo-code (illustrative), a loop that sums `i` into `s`:

```mermaid
flowchart TD
    B1["B1: s = 0; i = 0"] --> B2["B2: if i < n"]
    B2 -->|true| B3["B3: s = s + i; i = i + 1"]
    B3 --> B2
    B2 -->|false| B4["B4: return s"]
```

| Block | USE (GEN) | DEF (KILL) |
| --- | --- | --- |
| B1 | {} | {s, i} |
| B2 | {i, n} | {} |
| B3 | {s, i} | {s, i} |
| B4 | {s} | {} |

Equations: `OUT[B] = ∪ IN[S]` over successors S, `IN[B] = USE[B] ∪ (OUT[B] − DEF[B])`. Start with every set empty and process blocks in reverse order:

| Iteration | IN[B4] | IN[B3] | IN[B2] | IN[B1] |
| --- | --- | --- | --- | --- |
| 1 | {s} | {s, i} (OUT = IN[B2] = {} so far) | {i, n, s} | {n} |
| 2 | {s} | {s, i, n} (OUT = {i, n, s}) | {i, n, s} | {n} |
| 3 | no change | no change | no change | no change |

Result: `n` is live into the function, as expected for a parameter, and `s`, `i`, `n` are all live around the loop. In iteration 2 only B3 changed, which is why a worklist (below) is better than sweeping every block each time.

## The Worklist Algorithm

Instead of re-sweeping all blocks, keep a worklist of blocks whose input may have changed:

```text
for each block B: OUT[B] = {}            (backward analysis shown)
worklist = all blocks
while worklist not empty:
    B = worklist.pop()
    OUT[B] = ∪ IN[S] for S in successors(B)
    newIN  = USE[B] ∪ (OUT[B] − DEF[B])
    if newIN != IN[B]:
        IN[B] = newIN
        for P in predecessors(B): worklist.push(P)   (their OUT depends on IN[B])
```

Order matters for speed, not for the answer: forward analyses converge fastest in reverse post-order, backward analyses in post-order.

### A Real Worklist in LLVM

`mem2reg` needs to know in which blocks a stack variable is live on entry, so it can avoid inserting dead `phi`s. `PromoteMem2Reg::ComputeLiveInBlocks` is a small backward liveness analysis for one variable: it seeds a worklist with the blocks that load the variable before storing to it, then walks predecessors, adding each to the live-in set until it reaches a block that stores to the variable (a KILL).

`DCE.cpp` uses the same idea for a different fact, "this instruction is dead": `eliminateDeadCode` deletes trivially dead instructions, and each deletion pushes the instruction's operands onto a worklist because they may have just become dead.

**Sources:** [llvm/lib/Transforms/Utils/PromoteMemoryToRegister.cpp:1039](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Utils/PromoteMemoryToRegister.cpp#L1039), [llvm/lib/Transforms/Scalar/DCE.cpp:55-110](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Transforms/Scalar/DCE.cpp#L55-L110)

## What SSA Changes

In SSA every value has exactly one definition, and that definition dominates its uses. So:

| Classic analysis | In LLVM SSA |
| --- | --- |
| Reaching definitions | Not needed for SSA values: the operand *is* the single reaching definition (a use-def chain) |
| Def-use chains | Stored directly: `V->users()` / `V->uses()` |
| Liveness of a value | A value is live from its definition to its last use; computed from use lists and the dominator tree when needed (the back end does this for virtual registers) |
| Constant propagation | Sparse: propagate along def-use edges, not over every block (`sccp`) |
| Available expressions | Replaced by value numbering on SSA values (`gvn`, `early-cse`) |

These are called *sparse* analyses: information is attached to values and flows along def-use edges, instead of a set at every program point. They are much cheaper.

Classic dense data-flow is still needed for **memory**, which is not in SSA form: "has this location been written since?" depends on every store and call on every path. LLVM answers such questions with alias analysis and `MemorySSA`, which puts memory operations into an SSA-like form so the same sparse techniques work.

```cpp
// Illustrative: walking use-def and def-use chains.
for (Use &U : I->operands())       // use-def: what I reads
  errs() << "uses " << *U.get() << "\n";
for (User *Usr : I->users())       // def-use: who reads I
  errs() << "used by " << *Usr << "\n";
```

**Sources:** [llvm/include/llvm/IR/Value.h:75](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Value.h#L75), [llvm/include/llvm/IR/Use.h:35](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Use.h#L35)

## Key Points

- A data-flow analysis is a domain, a direction, a transfer function and a meet; iterate to a fixed point.
- A worklist only revisits blocks whose inputs changed.
- SSA turns reaching definitions and def-use chains into pointers; dense analysis remains for memory.