# Arithmetic, Bitwise and Cast Instructions

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/IR/Instruction.def](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def)
- [llvm/include/llvm/IR/InstrTypes.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/InstrTypes.h)
- [llvm/include/llvm/IR/Operator.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Operator.h)
- [llvm/include/llvm/IR/FMF.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/FMF.h)

</details>

Arithmetic instructions take two operands of the same type and produce a result of that type. Cast instructions change a value from one type to another. Both groups also carry optional *flags* (`nsw`, `nuw`, `exact`, fast-math flags) that record extra facts the optimizer may use.

## Purpose and Scope

This page covers the binary operators (integer, floating point, shifts and bitwise), the unary `fneg`, the poison-generating flags, fast-math flags and the cast instructions. Comparisons are on [Compare and Select](#compare).

## Binary Operators

Every binary operator has the form `%r = <op> [flags] <type> %a, %b`. Both operands and the result have the same type, which may be a scalar or a vector.

| Integer | Floating point | Meaning |
| --- | --- | --- |
| `add` | `fadd` | Addition |
| `sub` | `fsub` | Subtraction |
| `mul` | `fmul` | Multiplication |
| `udiv`, `sdiv` | `fdiv` | Division (unsigned, signed) |
| `urem`, `srem` | `frem` | Remainder |
| `shl` | | Shift left |
| `lshr`, `ashr` | | Shift right: logical (fill with 0) or arithmetic (copy sign bit) |
| `and`, `or`, `xor` | | Bitwise operations |

The unary `fneg` negates a floating-point value. In C++ all of these are `BinaryOperator` (or `UnaryOperator` for `fneg`), and `I->getOpcode()` tells them apart.

```llvm
; illustrative: (a * 4 + b) >> 1, all unsigned 32-bit
%m = mul i32 %a, 4
%s = add i32 %m, %b
%r = lshr i32 %s, 1
```

There is no `neg` or `not` instruction: `-x` is `sub i32 0, %x` and `~x` is `xor i32 %x, -1`.

**Sources:** [llvm/include/llvm/IR/Instruction.def:142-168](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def#L142-L168), [llvm/include/llvm/IR/InstrTypes.h:206](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/InstrTypes.h#L206)

## Undefined Behaviour: Poison and the Wrap Flags

Integer `add`, `sub`, `mul` and `shl` wrap around by default (modulo 2^N), like C unsigned arithmetic. Flags add a promise:

| Flag | Applies to | Promise | If broken |
| --- | --- | --- | --- |
| `nuw` | `add`, `sub`, `mul`, `shl` | No unsigned overflow | Result is **poison** |
| `nsw` | `add`, `sub`, `mul`, `shl` | No signed overflow | Result is poison |
| `exact` | `udiv`, `sdiv`, `lshr`, `ashr` | No non-zero remainder / no bits shifted out | Result is poison |
| `disjoint` | `or` | No bit is set in both operands | Result is poison |

Clang puts `nsw` on signed `int` arithmetic because signed overflow is undefined in C. That lets passes reason like a mathematician: with `nsw`, `(x + 1) > x` folds to `true`; without it, it does not, because `INT_MAX + 1` wraps to `INT_MIN`.

*Poison* is a special value meaning "this computation went wrong". It is not immediate undefined behaviour: it spreads through later arithmetic, and only becomes undefined behaviour when it reaches something with a side effect, such as a branch condition or a store address. `freeze` turns poison into an arbitrary but fixed value.

Division by zero is immediate undefined behaviour, not poison, which is why passes are careful about moving `udiv` and `sdiv`.

In C++, `OverflowingBinaryOperator` exposes `hasNoUnsignedWrap()` and `hasNoSignedWrap()`, and `PossiblyExactOperator` exposes `isExact()`.

**Sources:** [llvm/include/llvm/IR/Operator.h:78-84](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Operator.h#L78-L84), [llvm/include/llvm/IR/Operator.h:156](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Operator.h#L156)

## Fast-Math Flags

Floating-point instructions follow IEEE-754 by default, so `(a + b) + c` cannot be reassociated. Fast-math flags relax that per instruction:

| Flag | Allows |
| --- | --- |
| `reassoc` | Reassociation, `(a+b)+c` to `a+(b+c)` |
| `nnan` | Assume no NaN inputs or results |
| `ninf` | Assume no infinities |
| `nsz` | Ignore the sign of zero |
| `arcp` | Use `a * (1/b)` for `a / b` |
| `contract` | Fuse `a*b + c` into a fused multiply-add |
| `afn` | Use approximate math library functions |
| `fast` | All of the above |

```llvm
%s = fadd fast float %a, %b     ; illustrative, from -ffast-math
```

These flags live in `FastMathFlags` and are reached through `FPMathOperator`.

**Sources:** [llvm/include/llvm/IR/FMF.h:23-33](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/FMF.h#L23-L33), [llvm/include/llvm/IR/Operator.h:202](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Operator.h#L202)

## Casts

A cast is written `%r = <cast> <srcty> %v to <dstty>`.

| Cast | From | To | Example C source |
| --- | --- | --- | --- |
| `trunc` | wider integer | narrower integer | `(char)i` |
| `zext` | narrower integer | wider, filling with zeros | `(unsigned long)u` |
| `sext` | narrower integer | wider, copying the sign bit | `(long)i` |
| `fptrunc`, `fpext` | float type | smaller / larger float type | `(float)d`, `(double)f` |
| `fptoui`, `fptosi` | float | integer | `(int)f` |
| `uitofp`, `sitofp` | integer | float | `(double)i` |
| `ptrtoint`, `inttoptr` | pointer / integer | integer / pointer | `(uintptr_t)p` |
| `ptrtoaddr` | pointer | integer address only | (new in this LLVM version) |
| `bitcast` | any | same size, reinterpret the bits | `memcpy` type punning |
| `addrspacecast` | pointer | pointer in another address space | GPU code |

```llvm
; illustrative: long f(char c) { return c; }
%w = sext i8 %c to i64
```

`zext` can carry `nneg` (the input is non-negative) and `trunc` can carry `nuw`/`nsw` (no bits lost); breaking these promises gives poison.

All casts derive from `CastInst`.

**Sources:** [llvm/include/llvm/IR/Instruction.def:184-199](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/Instruction.def#L184-L199), [llvm/include/llvm/IR/InstrTypes.h:512](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/IR/InstrTypes.h#L512)

## Key Points

- Binary operators require matching operand and result types; signedness is in the opcode.
- `nsw`, `nuw` and `exact` are promises; breaking one gives poison, not a wrong number.
- Fast-math flags are per instruction, so one function can mix strict and fast code.