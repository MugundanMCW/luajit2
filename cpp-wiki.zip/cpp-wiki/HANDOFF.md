# Handoff: C++ for LLVM Development Wiki

## Status

- 10 beginner pages written (`01-overview.md` … `10-build-exercises.md`). HTML built at `cpp-wiki/cpp-wiki.html` with `python %TEMP%\rawiki\wiki_build.py cpp`: 10 sections, 10 nav entries, 23 Mermaid diagrams, 52 LLVM source citations in 13 files with 0 range problems, 0 cross-wiki link problems.
- The `"cpp"` entry is in the `WIKIS` table of `%TEMP%\rawiki\wiki_build.py`.
- **Not done:** the wiki is not in `llvm-backend-guide.zip` (left alone, as with the other new wikis).

## How the content was checked

- **Example programs.** Every code block starting with `// example: name` is a complete program followed by a `text` block with its expected output. `%TEMP%\cppwiki\check.py` extracts them, compiles each with MSVC 19.51 (`/std:c++17 /MD /EHs-c- /D_HAS_EXCEPTIONS=0`) against `c:\source\llvm-project\llvm\include`, `build\include` and `build\Release\lib\LLVMSupport.lib`, runs it, and compares stdout exactly. Last run: 12 examples, 0 problems. Re-run it after editing any example: `python %TEMP%\cppwiki\check.py`.
- **Citations.** Line numbers in `llvm/include/llvm/...` were taken from searches of the checkout at commit a2171756 (`Casting.h`, `SmallVector.h`, `StringRef.h`, `ArrayRef.h`, `DenseMap.h`, `Twine.h`, `STLFunctionalExtras.h`, `STLExtras.h`, `raw_ostream.h`, `Error.h`, `ErrorHandling.h`, `Value.h`, `Instructions.h`). `verify.py` checks only that the ranges exist.
- **External links.** All 25 cppreference, Wikipedia and llvm.org links in the built HTML returned HTTP 200 (`curl --ssl-no-revoke`).
- Snippets marked `illustrative` (IR-walking loops, pass fragments, bug examples) were not compiled. Books are cited by title only.

## Notes

- `SmallVector::isSmall()` is protected; the examples use `capacity()` instead.
- The local LLVM build is Release without assertions, so `cast<>` misuse is not caught by it.
- `llvm/docs/*.rst` is not in the checkout, so LLVM docs are linked on llvm.org instead.

## Page ids

overview, basics, classes, ownership, templates, adt, casting, errors, ranges, build-exercises

## To add to the combined guide

Add a tuple for `cpp-wiki` to `WIKIS` in `%TEMP%\rawiki\guide_build.py` (it fits before the IR wiki), then run `python %TEMP%\rawiki\guide_build.py`.