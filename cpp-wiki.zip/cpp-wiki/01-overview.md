# C++ for LLVM Development: Overview

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/Support/Casting.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Support/Casting.h)
- [llvm/include/llvm/ADT/SmallVector.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/ADT/SmallVector.h)
- [llvm/include/llvm/Support/Error.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Support/Error.h)
- [LLVM Coding Standards](https://llvm.org/docs/CodingStandards.html)
- [LLVM Programmer's Manual](https://llvm.org/docs/ProgrammersManual.html)

</details>

LLVM is written in modern C++ (C++17 at the commit this wiki uses). You do not need to know all of C++ to work on it, but you do need a particular subset, and LLVM adds its own replacements for some standard features. This wiki teaches exactly that subset, from the beginning, with small programs you can compile.

> **How the examples were checked.** Every code block whose first line is `// example: name` is a complete program. Each one was compiled with MSVC 19.51 (`/std:c++17`) against the LLVM headers and `LLVMSupport.lib` from the local build at commit `a2171756`, run, and its output compared with the text block shown under it. Other snippets are short fragments and are marked illustrative.

## Purpose and Scope

| # | Page | What you learn |
| --- | --- | --- |
| 1 | [Overview](#overview) | Why LLVM's C++ looks different, and a learning path |
| 2 | [C++ Basics](#basics) | Values, pointers, references, `const`, headers, namespaces |
| 3 | [Classes and RAII](#classes) | Constructors, destructors, inheritance, `virtual`, RAII |
| 4 | [Ownership and Move](#ownership) | Stack vs heap, `unique_ptr`, move semantics, who owns IR objects |
| 5 | [Templates and Lambdas](#templates) | Function and class templates, lambdas, `function_ref` |
| 6 | [LLVM Data Structures](#adt) | `SmallVector`, `ArrayRef`, `StringRef`, `DenseMap`, `Twine` |
| 7 | [LLVM-Style RTTI](#casting) | `isa<>`, `cast<>`, `dyn_cast<>`, `classof` |
| 8 | [Errors and Output](#errors) | `Error`, `Expected<T>`, `raw_ostream`, `assert`, `llvm_unreachable` |
| 9 | [Iterators and Ranges](#ranges) | Range-for, `auto`, `STLExtras`, deleting while iterating |
| 10 | [Building, Debugging, Exercises](#build-exercises) | Building against LLVM, sanitizers, exercises, glossary |

Once comfortable, continue with the [LLVM IR wiki](../ir-wiki/ir-wiki.html#overview) and its [Writing a Pass](../ir-wiki/ir-wiki.html#writing-a-pass) page.

## Why LLVM's C++ Looks Different

```mermaid
flowchart TD
    G["Goals: fast compile times, fast compiler,<br/>small binaries, portable"] --> NE["No exceptions<br/>→ llvm::Error / Expected"]
    G --> NR["No C++ RTTI (dynamic_cast)<br/>→ isa / cast / dyn_cast"]
    G --> AD["Avoid heap allocation in hot code<br/>→ SmallVector, StringRef, ArrayRef"]
    G --> IO["No iostream in libraries<br/>→ raw_ostream: outs(), errs()"]
```

| Standard C++ habit | LLVM's choice | Page |
| --- | --- | --- |
| `throw` / `try` / `catch` | Built with exceptions off; return `llvm::Error` or `Expected<T>` | [Errors and Output](#errors) |
| `dynamic_cast`, `typeid` | Built with RTTI off; use `isa<>`, `cast<>`, `dyn_cast<>` | [LLVM-Style RTTI](#casting) |
| `std::vector` everywhere | `SmallVector<T, N>` keeps the first N elements without a heap allocation | [LLVM Data Structures](#adt) |
| `const std::string &` parameters | `StringRef` (pointer + length, never copies) | [LLVM Data Structures](#adt) |
| `std::cout` | `llvm::outs()`, `llvm::errs()`, `dbgs()` | [Errors and Output](#errors) |
| `std::map` / `std::unordered_map` | `DenseMap` (open addressing, cache-friendly) | [LLVM Data Structures](#adt) |

These rules are stated in the [LLVM Coding Standards](https://llvm.org/docs/CodingStandards.html); the data structures and casting are explained in the [Programmer's Manual](https://llvm.org/docs/ProgrammersManual.html).

## A First Taste

This is what everyday LLVM code looks like. Each piece is explained on a later page.

```cpp
// example: taste
#include "llvm/ADT/SmallVector.h"
#include "llvm/ADT/StringRef.h"
#include "llvm/Support/raw_ostream.h"
using namespace llvm;

int main() {
  SmallVector<StringRef, 4> Names = {"add", "mul", "load"};
  for (StringRef N : Names)
    if (N.starts_with("l"))
      outs() << N << " is a memory op\n";
  outs() << Names.size() << " names\n";
}
```

```text
load is a memory op
3 names
```

**Sources:** [llvm/include/llvm/ADT/SmallVector.h:1249](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/ADT/SmallVector.h#L1249), [llvm/include/llvm/Support/Casting.h:547](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Support/Casting.h#L547), [llvm/include/llvm/Support/Error.h:159](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Support/Error.h#L159)

## A Learning Path

```mermaid
flowchart LR
    A["1. C++ basics<br/>pointers, references, const"] --> B["2. Classes, RAII,<br/>virtual functions"]
    B --> C["3. Ownership:<br/>unique_ptr, move"]
    C --> D["4. Templates, lambdas"]
    D --> E["5. LLVM ADT + casting<br/>+ Error"]
    E --> F["6. Read and modify<br/>a real pass"]
```

| Stage | Practise by |
| --- | --- |
| Basics to templates | Writing the small programs on pages 2-5 yourself |
| LLVM libraries | Compiling the examples on pages 6-9 against your LLVM build |
| Real code | Reading `llvm/lib/Transforms/Utils/HelloWorld.cpp`, then `DCE.cpp`, then writing a pass |

## Recommended Books and References

| Resource | Good for |
| --- | --- |
| Bjarne Stroustrup, *A Tour of C++* | A short modern overview for programmers |
| Bjarne Stroustrup, *Programming: Principles and Practice Using C++* | A full beginner course |
| Scott Meyers, *Effective Modern C++* | `auto`, move semantics, smart pointers, lambdas: exactly the C++11/14 features LLVM uses |
| [cppreference.com](https://en.cppreference.com/w/cpp/language/raii) | Precise reference for every language feature |
| [LLVM Programmer's Manual](https://llvm.org/docs/ProgrammersManual.html) | LLVM's own data structures and idioms |
| [LLVM Coding Standards](https://llvm.org/docs/CodingStandards.html) | The style and rules reviewers will expect |

## Key Points

- LLVM uses a disciplined subset of C++17 with exceptions and RTTI turned off.
- It replaces several standard tools with faster ones: `SmallVector`, `StringRef`, `DenseMap`, `raw_ostream`, `Error`, `isa/cast/dyn_cast`.
- Learn the language basics first, then the LLVM libraries, then read real passes.