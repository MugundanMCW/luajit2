# C++ Basics

<details>
<summary>Relevant source files</summary>

The following references were used as context for generating this wiki page:

- [cppreference: References](https://en.cppreference.com/w/cpp/language/reference)
- [cppreference: Undefined behavior](https://en.cppreference.com/w/cpp/language/ub)
- [Wikipedia: One Definition Rule](https://en.wikipedia.org/wiki/One_Definition_Rule)
- Book: Bjarne Stroustrup, *A Tour of C++*, chapters 1-3

</details>

This page covers the parts of C++ you meet on every line of LLVM code: values, pointers and references, `const`, headers and namespaces. If you already write C, most of it is familiar; the new parts are references and `const`-correctness, which LLVM uses everywhere.

## Purpose and Scope

This page covers variables and types, pointers, references, `const`, passing arguments, `nullptr`, headers and the one-definition rule, namespaces, and undefined behaviour. Classes are on [Classes and RAII](#classes).

## The House and Address Analogy

| Everyday | C++ |
| --- | --- |
| A house | An object in memory |
| The house's street address written on paper | A **pointer** (`T *`): can be changed, can be blank (`nullptr`) |
| A nickname for the house | A **reference** (`T &`): always refers to the same house, never blank |
| "Look but don't touch" sign | `const` |

## Pointers and References

```cpp
// example: refs
#include "llvm/Support/raw_ostream.h"
using namespace llvm;

void addOnePtr(int *P) { if (P) *P += 1; }   // may be null: must check
void addOneRef(int &R) { R += 1; }            // never null
int twice(const int &R) { return R * 2; }     // read-only

int main() {
  int X = 10;
  int *P = &X;      // P holds X's address
  int &R = X;       // R is another name for X
  addOnePtr(P);
  addOneRef(R);
  outs() << "X = " << X << ", twice = " << twice(X) << "\n";
  addOnePtr(nullptr);   // safe: the function checks
  outs() << "done\n";
}
```

```text
X = 12, twice = 24
done
```

```mermaid
flowchart LR
    P["P (int *)<br/>holds address of X"] --> X["X = 12"]
    R["R (int &)<br/>another name"] -.-> X
```

| | Pointer `T *` | Reference `T &` |
| --- | --- | --- |
| Can be null | Yes | No |
| Can be re-pointed | Yes | No |
| Access syntax | `*P`, `P->field` | `R`, `R.field` |
| LLVM convention | "May be null" or "optional" | "Always valid" |

**LLVM convention:** a function taking `Function &F` guarantees F exists; one taking `Instruction *I` might receive null (check the documentation). Most IR objects are passed around as pointers, e.g. `Value *`, `BasicBlock *`.

**Sources:** [cppreference: References](https://en.cppreference.com/w/cpp/language/reference)

## const

| Declaration | Meaning |
| --- | --- |
| `const int X = 5;` | X cannot change |
| `const Value *V` | Can't modify the value V points to; V itself can be reassigned |
| `Value *const V` | V can't be reassigned; the pointee can change |
| `int size() const;` (member function) | The function does not modify the object |

LLVM is const-correct: `F.getName()` works on a `const Function &` because `getName` is a `const` member. Getting this wrong produces confusing errors like "cannot convert `const Value *` to `Value *`" — the fix is usually to use the `const` version of a type throughout, not to cast `const` away.

## Passing Arguments

```mermaid
flowchart TD
    Q["How should a function take T?"] --> S{"Small and cheap to copy?<br/>(int, pointer, StringRef, ArrayRef)"}
    S -->|"yes"| V["By value: T"]
    S -->|"no"| M{"Will the function modify it?"}
    M -->|"yes"| R["By reference: T &"]
    M -->|"no"| C["By const reference: const T &"]
    M -->|"it takes ownership"| U["By value and move: std::unique_ptr<T>"]
```

## Headers, Declarations and the ODR

C++ code is split into **headers** (`.h`, declarations) and **source files** (`.cpp`, definitions).

```cpp
// illustrative: Counter.h
#ifndef MYPASS_COUNTER_H      // include guard: header body seen once per .cpp
#define MYPASS_COUNTER_H
namespace mypass {
int countDown(int N);         // declaration: "this exists somewhere"
}
#endif

// Counter.cpp
#include "Counter.h"
int mypass::countDown(int N) { return N > 0 ? N - 1 : 0; }   // definition
```

```mermaid
flowchart LR
    H["Counter.h<br/>declarations"] -->|"#include"| A["Counter.cpp"]
    H -->|"#include"| B["Main.cpp"]
    A -->|"compile"| AO["Counter.obj"]
    B -->|"compile"| BO["Main.obj"]
    AO --> L["linker"]
    BO --> L
    L --> EXE["program"]
```

The **one-definition rule (ODR)**: a non-inline function or global variable must be *defined* exactly once in the whole program. Defining a normal function in a header that two `.cpp` files include gives "multiply defined symbol" link errors; mark it `inline` or move it to a `.cpp`.

LLVM's include order rule (from the Coding Standards): the file's own header first, then LLVM headers, then system headers.

**Sources:** [Wikipedia: One Definition Rule](https://en.wikipedia.org/wiki/One_Definition_Rule)

## Namespaces

Everything in LLVM is in `namespace llvm`. In `.cpp` files LLVM code writes `using namespace llvm;`; in headers it never does, because that would leak into every includer. Helpers private to one `.cpp` go in an **anonymous namespace**, which gives them internal linkage:

```cpp
// illustrative
namespace {                       // only visible in this .cpp file
struct MyHelperPass { /* ... */ };
} // end anonymous namespace
```

## Undefined Behaviour

Some mistakes are not errors but **undefined behaviour (UB)**: the program may do anything, including appear to work.

| Example | Why it is UB |
| --- | --- |
| Reading an uninitialised variable | No defined value |
| Dereferencing null or a dangling pointer | No object there |
| Out-of-bounds array access | Past the object |
| Signed integer overflow | The standard says so (LLVM's `nsw` flag exploits this, see [LLVM IR: Arithmetic](../ir-wiki/ir-wiki.html#arithmetic)) |

Use the sanitizers described on [Building, Debugging, Exercises](#build-exercises) to catch UB.

**Sources:** [cppreference: Undefined behavior](https://en.cppreference.com/w/cpp/language/ub)

## Common Traps

- `int &R;` without initialising is an error: references must bind at once.
- Returning a reference or pointer to a local variable gives a dangling reference.
- `using namespace` in a header.
- Forgetting `const` on member functions, so they can't be called on const objects.

## Key Points

- Pointers may be null and can be re-pointed; references are always-valid aliases.
- Be `const`-correct; pass small things by value, big things by `const &`.
- Declarations in headers, definitions once in `.cpp` (ODR); LLVM lives in `namespace llvm`.