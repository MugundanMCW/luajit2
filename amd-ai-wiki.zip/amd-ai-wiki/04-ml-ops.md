# Key ML Operations: GEMM, Convolution, Attention and Quantization

<details>
<summary>Relevant source files</summary>

- Deeper coverage: [Arch: SIMD and GPU](../arch-wiki/arch-wiki.html#simd-gpu), [Arch: Caches and coherence](../arch-wiki/arch-wiki.html#caches-coherence)

</details>

The job description says "Familiar with key ML operations like GEMM, CONV". Almost every model spends most of its time in a small set of operators: matrix multiply, convolution (which is usually turned into a matrix multiply), attention, and a long tail of element-wise operations and normalisations. An AI-compiler engineer has to be able to count the work in each one, know where the data moves, and know how to make it fast.

## Purpose and Scope

This page gives the formulas for FLOP counts, output shapes and arithmetic intensity. It shows how GEMM is tiled, how convolution is mapped onto GEMM, why LLM decoding is limited by memory, and how int8 quantization works. All the worked numbers were checked with a short Python script.

## GEMM

`C[M,N] = A[M,K] x B[K,N]`. Each output element needs K multiply-adds, so:

- **FLOPs = 2·M·N·K.** One MAC (multiply-accumulate) counts as 2 FLOPs.
- **Minimum traffic** (each matrix read or written once) = (M·K + K·N + M·N) × bytes per element.
- **Arithmetic intensity** = FLOPs ÷ bytes. For square fp32 matrices of size n this is 2n³ / (12n²) = **n/6 FLOP/byte**. For n = 1024 that is about 170.7, which is comfortably compute-bound on most hardware.

A naive triple loop gets nowhere near that intensity. Every iteration of the inner loop reloads data from memory, because the working set does not fit in cache. **Tiling** fixes this.

```cpp
// C += A * B, row-major, with tiles that fit in cache or local memory
for (int i0 = 0; i0 < M; i0 += TM)
  for (int j0 = 0; j0 < N; j0 += TN)
    for (int k0 = 0; k0 < K; k0 += TK)           // stream K tiles through
      for (int i = i0; i < std::min(i0 + TM, M); ++i)
        for (int k = k0; k < std::min(k0 + TK, K); ++k) {
          float a = A[i * K + k];                 // reused across the j loop
          for (int j = j0; j < std::min(j0 + TN, N); ++j)
            C[i * N + j] += a * B[k * N + j];     // unit stride, vectorises
        }
```

Points to make in an answer:

- **Loop order matters.** With `i-k-j` order the inner loop runs along contiguous rows of B and C, so it vectorises. With `i-j-k` order the inner loop strides down a column of B.
- **Tile size:** choose TM, TN and TK so that the A, B and C tiles fit in L1 or L2, or in the NPU's local tile memory. Each tile of B is then reused TM times.
- **Register blocking:** a micro-kernel keeps a small block of C (for example 6×16) in vector registers. This is how BLIS and oneDNN reach peak speed.
- **Packing:** copy the tiles of A and B into contiguous buffers first, so the micro-kernel reads with unit stride and without TLB misses.
- On an NPU, the same hierarchy shows up as DDR, then a memory tile, then a compute tile's local memory, then the vector registers. The tiles are moved by DMA rather than by caches (see [page 6](#ryzen-ai-perf)).

## Convolution

The input is `N×C_in×H×W`, the weights are `C_out×C_in×K_h×K_w`, with stride S and padding P.

- **Output size:** `H_out = floor((H + 2P − K_h) / S) + 1`, and likewise for the width.
- **FLOPs** = 2 · N · C_out · H_out · W_out · C_in · K_h · K_w.

**Worked example.** The first layer of ResNet-50 takes a 224×224×3 input, uses 64 filters of size 7×7, stride 2 and padding 3:

- H_out = floor((224 + 6 − 7) / 2) + 1 = 111 + 1 = **112**.
- FLOPs = 2 · 64 · 112 · 112 · 3 · 7 · 7 = **236,027,904**, about 0.24 GFLOPs or 118 M MACs.

### Three ways to compute a convolution

| Method | Idea | Trade-off |
|---|---|---|
| **im2col + GEMM** | Unfold each input window into a column, then do one GEMM. In the example the GEMM is M = 64, K = 147 (3·7·7), N = 12,544 (112·112). | Reuses fast GEMM kernels, but the unfolded matrix is about K_h·K_w/S² times bigger than the input. |
| **Direct / implicit GEMM** | Compute the GEMM indices on the fly and never build the unfolded matrix. | No memory blow-up. This is what GPU and NPU kernels usually do. |
| **Winograd / FFT** | Transform the data to cut the number of multiplies. Winograd F(2×2, 3×3) needs 16 multiplies instead of 36, a 2.25× saving. | Less numerically accurate, which is risky for int8. Only worth it for some filter sizes. |

**Depthwise convolution** (MobileNet) applies one filter per channel, so FLOPs = 2·C·H_out·W_out·K². There is very little reuse, so it is memory-bound. That is why it is usually fused with the 1×1 (pointwise) convolution that follows it.

### Data layouts

- **NCHW:** each channel is a contiguous plane. This was PyTorch's default.
- **NHWC:** the channels of each pixel are contiguous. This suits GEMM-style convolutions and vector units, because a vector load reads several channels of one pixel at once. TFLite, and most NPUs, prefer it.
- **Blocked layouts** (for example `NCHW8c`, or tile formats specific to an NPU) group channels in blocks of the vector width.
- A compiler inserts layout transposes at the boundaries between partitions and tries to cancel out pairs of them. Every transpose that is left over is pure memory traffic.

## Attention and transformers

For one head, with sequence length L and head dimension d: `softmax(Q·Kᵀ / √d) · V`.

- Q·Kᵀ costs 2·L²·d FLOPs, and so does multiplying by V. The cost grows **quadratically with L**.
- **FlashAttention** works on tiles of Q, K and V, keeps a running maximum and sum so it can compute the softmax online, and never writes the L×L score matrix to DRAM. That turns a memory-bound operator into a compute-bound one.
- **Prefill** processes the whole prompt at once. It is made of GEMMs and is compute-bound.
- **Decode** produces one token at a time. Each step is a matrix-vector multiply that has to read **every weight**, so it is memory-bandwidth-bound.

**Decode upper bound.** A model with 7 billion parameters stored in 4-bit form takes 3.5 GB. With 100 GB/s of usable bandwidth, each token needs at least 3.5 GB ÷ 100 GB/s = 35 ms, so the ceiling is about **28.6 tokens per second**. The only ways to raise it are fewer bytes (quantization) or more bandwidth. Faster arithmetic does not help.

**KV cache size** = 2 (K and V) × layers × KV heads × head dim × sequence length × bytes per element. For Llama-2-7B (32 layers, 32 KV heads, head dim 128, fp16) that is 2·32·32·128·2 = **524,288 bytes = 0.5 MiB per token**, or **2 GiB at 4096 tokens**. Grouped-query attention (GQA) reduces the number of KV heads, and the cache shrinks in proportion.

## Other operators and fusion

- **Element-wise operations** (ReLU, GELU, add, scale) do about 1 FLOP per element that is loaded, so they are completely memory-bound. Fuse them into the epilogue of the GEMM or convolution before them, so their inputs never leave registers or local memory.
- **Reductions** (softmax, LayerNorm, RMSNorm) need a pass over the data to compute statistics. Use numerically stable forms, for example subtract the maximum before `exp`.
- **Typical fusions:** Conv+BatchNorm (fold the BN into the weights at compile time), Conv+Bias+ReLU, MatMul+Add+GELU, and QKV projection followed by attention.

## Quantization

Affine (asymmetric) quantization maps a real value x to an integer q:

- **Quantize:** `q = clamp(round(x / s) + z, qmin, qmax)`.
- **Dequantize:** `x ≈ s · (q − z)`.
- **Symmetric int8:** z = 0 and s = max|x| / 127. This makes the integer arithmetic simpler, and it is common for weights.

**Worked example.** For the range [−1.0, 2.0] in uint8: s = 3 / 255 ≈ 0.011765, and z = round(1.0 / s) = **85**. Then x = 0.6 gives q = round(0.6 / s) + 85 = 51 + 85 = **136**, and dequantizing gives (136 − 85) · s = 0.6 exactly.

How an int8 GEMM runs:

1. Multiply int8 × int8 and **accumulate in int32**, which avoids overflow for any realistic K.
2. Add the bias, already in int32.
3. **Requantize** with the combined scale `M = s_a · s_w / s_out`. Integer-only hardware applies it as a fixed-point multiplier followed by a right shift.
4. Clamp, which also applies a fused ReLU for free.

| Term | Meaning |
|---|---|
| Per-tensor vs per-channel | One scale for the whole tensor, or one per output channel. Per-channel weights are much more accurate for convolutions. |
| PTQ | Post-training quantization. Calibrate the ranges on a small dataset, using MinMax, percentile or entropy (KL) methods. |
| QAT | Quantization-aware training. Training uses fake-quantize nodes, so the model learns to tolerate rounding. |
| QDQ format | ONNX represents quantization as `QuantizeLinear` and `DequantizeLinear` pairs around float ops. The backend fuses each pattern into a true integer kernel. |
| W4A16, W8A8 | Bit widths for weights and activations. LLMs often use 4-bit weights with group-wise scales (AWQ, GPTQ) and 16-bit activations. |
| bf16 | 8 exponent bits like fp32, but only 7 mantissa bits. It keeps fp32's range, so it rarely needs scaling. Many NPUs support it natively. |

## Common traps

- Counting a MAC as 1 FLOP when the other side counts it as 2. Always say which convention you are using.
- Assuming that fewer FLOPs means faster. Depthwise convolutions and Winograd can be slower if they are bound by memory.
- Accumulating int8 products in int16, which overflows.
- Forgetting that every layout transpose and every quantize/dequantize pair left at a partition boundary costs memory traffic.

## Key Points

- GEMM costs 2·M·N·K FLOPs. Tiling and packing raise its arithmetic intensity until it becomes compute-bound.
- Convolution reduces to GEMM through im2col or implicit GEMM. Know the output-size and FLOP formulas and be able to apply them quickly.
- LLM decoding is bound by bandwidth (bytes of weights per token), while prefill is bound by compute.
- int8 quantization means int8 multiplies, int32 accumulation and a requantization step. Per-channel weight scales, QDQ fusion and calibration determine the accuracy.