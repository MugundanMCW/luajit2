# AI Frameworks and Compilers: PyTorch, ONNX Runtime, TVM, MLIR

<details>
<summary>Relevant source files</summary>

- Deeper coverage: [LLVM IR: Overview](../ir-wiki/ir-wiki.html#overview), [LLVM IR: Writing a pass](../ir-wiki/ir-wiki.html#writing-a-pass), [LLVM IR: Common passes](../ir-wiki/ir-wiki.html#common-passes)

</details>

The job description asks for "knowledge of AI frameworks like PyTorch, TensorFlow, ONNXRuntime, TVM, MLIR" and says the role will "contribute to the development and maintenance of AMD's AI compilers, and runtime". You do not need to have written every one of these. You do need to explain how a model gets from a training framework to machine code on an accelerator, and what each layer is responsible for.

## Purpose and Scope

This page traces the path from model to hardware, covers each framework in the role an interviewer cares about, and lists the standard graph-level and loop-level compiler optimisations.

## The model-to-hardware path

```mermaid
flowchart TB
  PT[PyTorch / TensorFlow model] -->|torch.export, torch.onnx.export, tf2onnx| ONNX[ONNX graph]
  PT -->|torch.compile / FX| FX[FX graph]
  ONNX --> Q[Quantizer<br/>QDQ insertion, calibration]
  Q --> ORT[ONNX Runtime session]
  ORT -->|partition by EP capability| EP1[NPU execution provider]
  ORT --> EP2[GPU EP]
  ORT --> EP3[CPU EP fallback]
  EP1 --> GC[Graph compiler<br/>fusion, layout, tiling, scheduling]
  GC --> KC[Kernel compiler<br/>MLIR / LLVM to device code]
  KC --> BIN[Device binary + runtime commands]
```

The layers to name, from top to bottom:

1. **Capture:** turn Python code into a static graph.
2. **Interchange:** ONNX.
3. **Quantize.**
4. **Partition** the graph across devices.
5. **Graph optimisations.**
6. **Kernel generation.**
7. **Runtime:** memory allocation, command submission and synchronisation.

## PyTorch

- **Eager mode** dispatches every op through the dispatcher to an ATen kernel chosen by device and dtype. This is flexible but carries per-op overhead, and the framework never sees the whole graph.
- **TorchScript** is the older way to capture a graph, by tracing or scripting. It is now being superseded.
- **`torch.compile`** has three parts. *TorchDynamo* captures FX graphs from Python bytecode and inserts graph breaks around code it cannot capture. *AOTAutograd* traces the backward pass. *TorchInductor* generates Triton kernels for GPUs or C++/OpenMP for CPUs.
- **`torch.export`** produces a whole-graph, ahead-of-time program that is suitable for deployment and for lowering to other compilers.
- **Custom ops and backends** plug into the dispatcher, or into the `torch.compile` backend hook.

## TensorFlow

- A static dataflow graph, originally built through sessions. TF2 runs eagerly by default and uses `tf.function` to trace graphs.
- **XLA** compiles HLO, a graph of high-level ops, with fusion and layout assignment. StableHLO is the MLIR-based version of HLO that serves as an interchange format.
- **TFLite** targets mobile and edge devices. It uses flatbuffer models and offloads to accelerators through *delegates*, the counterpart of ONNX Runtime's execution providers.

## ONNX and ONNX Runtime

**ONNX** is a protobuf graph format. A model contains a `GraphProto` of `NodeProto`s, initialisers (the weights) and value infos (shapes and types). Every model declares an **opset version**, which fixes the meaning of each operator.

**ONNX Runtime (ORT)** loads the model and runs these steps:

1. **Graph optimisations** at three levels: basic (constant folding, removing redundant nodes), extended (fusions such as GELU, LayerNorm and attention) and layout optimisations.
2. **Partitioning.** ORT walks the registered execution providers (EPs) in priority order. Each EP's `GetCapability()` claims the subgraphs it supports. Anything left unclaimed falls back to the CPU EP.
3. **Compilation.** An EP can either supply a kernel for each node, or **fuse** the subgraph it claimed into one compiled node through its `Compile()` method. NPU EPs usually take the second route.
4. **Execution.** A sequential or parallel executor runs the nodes, using an arena allocator for memory and IOBinding to keep tensors on the device.

Execution providers you should be able to name: CPU, CUDA, TensorRT, ROCm/MIGraphX (AMD GPUs), DirectML (Windows GPUs), OpenVINO, QNN (Qualcomm), and **Vitis AI EP**, which is AMD's EP for the Ryzen AI NPU.

**Interview angle:** "The model runs, but slowly, on the NPU EP. Why?"

- The graph was partitioned into many small pieces, so every boundary crossing costs a copy, a layout transform or a quantize/dequantize pair.
- Some unsupported ops fell back to the CPU.
- Dynamic shapes prevented ahead-of-time compilation.

Fixes: look at the partition report, replace or rewrite the unsupported ops, fix the shapes, and quantize to the dtype the NPU supports.

## TVM

- **Relay / Relax** is the graph-level IR. It handles fusion and layout and is retargetable.
- **TensorIR / TE** is the loop-level IR. You describe *what* to compute and then apply a *schedule*, a sequence of loop transformations such as split, reorder, tile, vectorize and bind-to-thread.
- **Auto-tuning** (AutoTVM, Ansor/MetaSchedule) searches the space of schedules, uses a learned cost model, and measures the best candidates on real hardware.
- The main idea to quote is the **separation of algorithm from schedule**, which comes from Halide.
- **BYOC** ("bring your own codegen") hands subgraphs to a vendor library or compiler. This plays the same role as an execution provider.

## MLIR

MLIR is a compiler framework for building IRs that have many levels, so that each level can be lowered progressively into the next.

| Concept | Meaning |
|---|---|
| Operation | The single unit of IR: `%r = dialect.op(%a, %b) {attrs} : (types) -> type`. Operations can contain regions, and regions contain blocks. |
| Dialect | A namespace of ops, types and attributes, for example `linalg`, `tensor`, `memref`, `scf`, `affine`, `vector`, `arith`, `gpu` and `llvm`. |
| Progressive lowering | For example: model dialect (TOSA, StableHLO, torch) → `linalg` on tensors → bufferization → `linalg` on memrefs → `scf`/`affine` loops → `vector` → `llvm` → LLVM IR. |
| Pattern rewriting | Declare `RewritePattern`s (or write them in DRR / PDLL). They are applied greedily up to a fixed point, or by a *conversion* that has a legality target, much like LLVM's legaliser. |
| Bufferization | Turns value-semantics `tensor`s into `memref` buffers, reusing buffers in place where it can. |
| Transform dialect | Writes the schedule (tile, fuse, vectorize) as IR, so it can be scripted. |

**Example: tiling a matmul in `linalg`.** This IR is illustrative, not compiler output.

```mlir
%C = linalg.matmul ins(%A, %B : tensor<256x512xi8>, tensor<512x128xi8>)
                   outs(%init : tensor<256x128xi32>) -> tensor<256x128xi32>
// after tiling 64x64x64: an scf.for nest over tiles, each doing
// linalg.matmul on tensor<64x64xi8> slices -> later mapped to an NPU core
```

**Why MLIR matters for an NPU:** AMD's open-source NPU toolchain, **MLIR-AIE** with the IRON Python API, represents the AI Engine array directly in MLIR. It has ops for tiles, buffers, locks, DMA "object FIFOs" and stream connections. Kernels for each core are compiled by an LLVM-based AIE compiler (Peano) or by the proprietary Chess compiler. Being able to explain "a spatial dataflow array described in MLIR" is a strong differentiator in this interview.

## Graph-level optimisations

| Optimisation | What it does | Why it helps |
|---|---|---|
| Constant folding | Precomputes subgraphs whose inputs are all constants, such as shape arithmetic or weight transforms. | Removes the work entirely. |
| Operator fusion | Merges a producer and its consumers, such as Conv+BN+ReLU or MatMul+bias+GELU. | Intermediate tensors stay on chip, so DRAM traffic drops. |
| Layout propagation | Chooses NHWC or a tiled layout once, and cancels transposes that undo each other. | Cuts transpose traffic. |
| Common subexpression elimination, dead code elimination | Standard SSA clean-ups. | Smaller graph. |
| QDQ folding | Fuses DQ → op → Q into a single integer kernel. | Makes true int8 execution possible. |
| Shape inference and specialisation | Makes shapes static so tiling can be chosen ahead of time. | Allows precompiled schedules. |
| Memory planning | Liveness-based arena with in-place reuse. | Lowers peak memory. |

## Loop- and kernel-level optimisations

Tiling, loop interchange, unrolling, vectorisation, software pipelining, double buffering (DMA the next tile while computing the current one), register blocking, data packing, and parallelising the work across cores or tiles. The compiler picks the parameters (tile sizes, unroll factors) with a cost model or with auto-tuning.

## Common traps

- Treating ONNX as a runtime. It is a file format. ONNX Runtime is the runtime.
- Assuming that every op in a model that runs "on the NPU" actually runs on the NPU. Always check the partitioning.
- Saying that MLIR replaces LLVM. MLIR usually lowers *to* LLVM IR for its final code generation.

## Key Points

- Know the whole path: capture → ONNX → quantize → partition across EPs → graph optimisation → kernel codegen → runtime.
- In ONNX Runtime, `GetCapability` decides placement and `Compile` fuses subgraphs, while the CPU EP is the fallback. Vitis AI EP is AMD's NPU path.
- TVM separates the algorithm from the schedule and adds auto-tuning. MLIR provides dialects and progressive lowering, and MLIR-AIE models AMD's NPU array.
- Fusion and layout choice usually beat micro-optimisation, because most of the cost is moving data.