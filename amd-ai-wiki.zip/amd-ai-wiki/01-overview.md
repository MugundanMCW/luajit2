# AMD SDE2 (Ryzen AI Compilers and Runtime): Interview Map

<details>
<summary>Relevant source files</summary>

- Job description: AMD Software Development Engineer 2, AI compilers and runtime for Ryzen AI SoC
- Companion wikis: [C++ for LLVM](../cpp-wiki/cpp-wiki.html#overview), [OS Interview](../os-wiki/os-wiki.html#overview), [Computer Architecture](../arch-wiki/arch-wiki.html#overview), [LLVM IR](../ir-wiki/ir-wiki.html#overview)

</details>

This wiki is a study guide for one specific interview. It takes each line of the job description, turns it into the concepts an interviewer is likely to probe, and gives a short answer for each. When a topic is covered in depth by one of the existing wikis, this wiki links to it instead of repeating it.

## Purpose and Scope

The role is about making AI models run fast on the **Ryzen AI SoC**. That chip combines a Zen CPU, a Radeon iGPU and an **XDNA NPU** on one die, and the job is to help build the compiler and runtime that map models onto it. Expect the interview to have four parts:

1. **Coding rounds:** C/C++, object-oriented design, data structures and algorithms.
2. **Systems fundamentals:** OS concepts and multithreaded programming.
3. **ML systems depth:** GEMM and convolution, quantization, frameworks (PyTorch, ONNX Runtime, TVM, MLIR), and compiler passes.
4. **Performance reasoning:** compute vs memory vs communication bottlenecks, profiling, and the trade-offs of the hardware.

## Job description to page map

```mermaid
flowchart LR
  JD[Job description] --> A[C++ and OOD<br/>page 2]
  JD --> B[DSA, OS, threads<br/>page 3]
  JD --> C[GEMM, CONV, quantization<br/>page 4]
  JD --> D[Frameworks and AI compilers<br/>page 5]
  JD --> E[Ryzen AI and performance<br/>page 6]
  JD --> F[Tools, behavioural, Q&A<br/>page 7]
```

| JD line | What they will actually test | Page |
|---|---|---|
| Strong OOP, C/C++, 2+ years | RAII, rule of 0/3/5, virtual dispatch cost, templates, move semantics | 2 |
| OO design principles | SOLID, composition vs inheritance, designing a pass manager or runtime API | 2 |
| DSA, OS, multithreading | Graphs (topological sort), hashing, heaps, mutex/condvar, thread pool, false sharing | 3 |
| GEMM, CONV | FLOP counts, tiling, im2col, data layouts, arithmetic intensity | 4 |
| PyTorch, TF, ONNXRuntime, TVM, MLIR | Graph capture, export to ONNX, execution providers, lowering pipelines, dialects | 5 |
| Compute, memory, communication trade-offs | Roofline, bandwidth limits, tiling to fit local memory, DMA overlap, CPU/GPU/NPU partitioning | 6 |
| Debuggers, Git, profilers | gdb/WinDbg, git bisect, perf/VTune/uProf, reading a profile | 7 |
| Communication, problem solving | STAR stories, explaining a performance win end to end | 7 |

## How to use this wiki

- Read pages 4 to 6 first if your ML-systems background is thinner than your C++ background. They are what makes this role different from a generic SDE interview.
- For each page, practise saying the **Key Points** out loud in under two minutes.
- Page 7 is a question bank. Answer each question before you read the given answer.

**Sources:** the job description supplied by the user.

## Key Points

- The role is about compilers and runtime for AI on a heterogeneous SoC (CPU, iGPU, NPU). Frame every answer around performance.
- The ML-systems topics (GEMM/CONV, quantization, ONNX Runtime, MLIR) are what set this role apart from a generic SDE role.
- C++, DSA, OS and threading are still a gate you have to pass. The companion wikis cover them in depth.