# Data Structures, OS and Multithreading

<details>
<summary>Relevant source files</summary>

- Deeper coverage: [OS: Threads](../os-wiki/os-wiki.html#threads), [OS: Synchronization](../os-wiki/os-wiki.html#synchronization), [OS: Deadlock](../os-wiki/os-wiki.html#deadlock), [OS: Virtual memory](../os-wiki/os-wiki.html#virtual-memory), [Arch: Caches and coherence](../arch-wiki/arch-wiki.html#caches-coherence), [Arch: Memory ordering](../arch-wiki/arch-wiki.html#memory-ordering)

</details>

The job description lists "Software Engineering principles, Data structure, algorithms, Operating Systems concepts and multithread programming". For an AI-compiler role, the coding round usually leans towards **graphs** (a model is a DAG of operators), **arrays and matrices**, and **concurrency** (runtimes are multithreaded).

## Purpose and Scope

This page covers the algorithms that map directly onto compiler and runtime work, the OS concepts that matter for an inference runtime, and the threading patterns you may be asked to write on a whiteboard.

## Algorithms that show up in AI-compiler interviews

| Problem shape | Algorithm | Complexity | Where it appears in the job |
|---|---|---|---|
| Order the operators of a model | Topological sort (Kahn's algorithm or DFS) | O(V+E) | Graph execution order, scheduling |
| Detect a cycle in a graph | DFS with three colours | O(V+E) | Validating a graph after a fusion pass |
| Group nodes into partitions | Union-find, BFS on connected components | about O(V+E) | Splitting a graph between CPU, GPU and NPU |
| Reuse buffers whose lifetimes do not overlap | Interval scheduling, greedy by end time | O(n log n) | Memory planner (tensor arena) |
| Choose the best tiling | Search over candidates with a cost model; DP | varies | Auto-tuning |
| Top-k, scheduling ready tasks | Heap / priority queue | O(log n) per operation | Kernel scheduling, beam search |
| Look up kernels by key | Hash map | O(1) on average | Operator registry |
| Matrix transpose, rotate, multiply | Index arithmetic, blocking | O(n^2) to O(n^3) | Layout transforms, GEMM |
| Prefix sum, sliding window | Scan, two pointers | O(n) | Reductions, convolution windows |

### Example: topological sort with Kahn's algorithm

```cpp
std::vector<int> topoSort(int n, const std::vector<std::vector<int>>& adj) {
  std::vector<int> indeg(n, 0), order;
  for (auto& outs : adj) for (int v : outs) ++indeg[v];
  std::queue<int> q;
  for (int i = 0; i < n; ++i) if (indeg[i] == 0) q.push(i);
  while (!q.empty()) {
    int u = q.front(); q.pop(); order.push_back(u);
    for (int v : adj[u]) if (--indeg[v] == 0) q.push(v);
  }
  if ((int)order.size() != n) throw std::runtime_error("cycle");  // not a DAG
  return order;
}
```

Follow-up questions to expect: "Which nodes can run in parallel?" Answer: every node in the queue at the same time, so process the queue in levels. "How do you minimise peak memory?" Prefer to schedule the node that frees the most tensors. That is a heuristic, because the exact problem is NP-hard.

### Example: a greedy memory planner

The tensors are intervals `[first_use, last_use]` with a size. Sort them by size, largest first. Give each tensor the lowest offset in the arena that does not overlap, in both offset and time, with any tensor already placed. This is how TFLite and ONNX Runtime style arenas cut peak memory. Questions about its complexity and its worst case are common.

## OS concepts that matter for an inference runtime

| Concept | Why it matters here |
|---|---|
| Process vs thread | A runtime is one process with a pool of worker threads. The driver and firmware run elsewhere. |
| Virtual memory, pages, TLB | Large tensors cause TLB misses, and huge pages help. Buffers shared with the NPU must be pinned (not pageable) and often physically contiguous or IOMMU-mapped. |
| User vs kernel mode, syscalls, ioctl | Kernel submission goes through the driver with an ioctl. Submitting in batches amortises the system-call cost. |
| DMA | The device copies memory without the CPU. The CPU must flush or invalidate its caches unless the memory is coherent. |
| Interrupts vs polling | Completion can be signalled by interrupt (low CPU use) or by polling a fence (lower latency). |
| Scheduling, priorities | Real-time and background inference compete for the CPU. Thread affinity matters on hybrid core layouts. |
| Memory-mapped files | `mmap` the model weights so they load lazily and are shared between processes. |

## Multithreading essentials

- **Data race:** two threads access the same location, at least one of them writes, and there is no synchronisation. This is undefined behaviour in C++.
- **Mutex and condition variable:** always wait in a loop on a predicate, because wake-ups can be spurious.
- **Atomics and memory order:** `relaxed` for counters, `acquire`/`release` to publish data, `seq_cst` as the safe default.
- **Deadlock:** the four Coffman conditions are mutual exclusion, hold-and-wait, no preemption and circular wait. Break circular wait by always taking locks in a fixed global order, or use `std::scoped_lock`.
- **False sharing:** two threads write different variables that sit on the same 64-byte cache line, so the line ping-pongs between cores. Fix it with `alignas(64)` padding.
- **Amdahl's law:** speedup = 1 / ((1-p) + p/n). With p = 0.9 the speedup can never exceed 10x, no matter how many cores you add.

### Example: a minimal thread pool

```cpp
class ThreadPool {
public:
  explicit ThreadPool(size_t n) {
    for (size_t i = 0; i < n; ++i)
      workers_.emplace_back([this] {
        for (;;) {
          std::function<void()> job;
          { std::unique_lock<std::mutex> lk(m_);
            cv_.wait(lk, [this] { return stop_ || !jobs_.empty(); });
            if (stop_ && jobs_.empty()) return;
            job = std::move(jobs_.front()); jobs_.pop(); }
          job();                                   // run outside the lock
        }
      });
  }
  void submit(std::function<void()> f) {
    { std::lock_guard<std::mutex> lk(m_); jobs_.push(std::move(f)); }
    cv_.notify_one();
  }
  ~ThreadPool() {
    { std::lock_guard<std::mutex> lk(m_); stop_ = true; }
    cv_.notify_all();
    for (auto& t : workers_) t.join();
  }
private:
  std::vector<std::thread> workers_;
  std::queue<std::function<void()>> jobs_;
  std::mutex m_; std::condition_variable cv_; bool stop_ = false;
};
```

Points to mention unprompted:

- The job runs outside the lock.
- `wait` uses a predicate.
- The destructor drains the queue and then joins every thread.
- Possible extensions: futures for return values, work-stealing deques to cut contention, and `parallel_for` that splits a range into chunks of about N/threads.

### Producer-consumer pipelining

An inference pipeline often overlaps three stages: preprocess on the CPU, run on the NPU, and postprocess on the CPU. Connect the stages with bounded queues (a mutex plus two condition variables, `not_full` and `not_empty`). This turns end-to-end latency into throughput, where each frame costs only as much as the slowest stage, because the other stages are working on other frames at the same time.

## Common traps

- Calling `notify` without changing the predicate under the lock, which causes lost wake-ups.
- Holding a lock while running a long job or calling a device API.
- Using `volatile` for synchronisation in C++. It provides no atomicity and no ordering.
- Doing the recursion in a recursive DFS topological sort without detecting cycles.

## Key Points

- Treat the model as a DAG. Topological sort, cycle detection, partitioning and lifetime-based memory planning are the core algorithms.
- Know which OS concepts touch the device: pinned memory, DMA, ioctl submission, coherence.
- Be able to write a correct thread pool and a bounded queue, and be able to explain false sharing and Amdahl's law.