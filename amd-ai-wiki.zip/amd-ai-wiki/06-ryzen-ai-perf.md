# Ryzen AI SoC and Performance Reasoning

<details>
<summary>Relevant source files</summary>

- Deeper coverage: [Arch: Memory ordering](../arch-wiki/arch-wiki.html#memory-ordering), [Arch: Multicore](../arch-wiki/arch-wiki.html#multicore), [Arch: SIMD and GPU](../arch-wiki/arch-wiki.html#simd-gpu)
- Public references: AMD Ryzen AI Software documentation, the MLIR-AIE / IRON repository (github.com/Xilinx/mlir-aie), AMD AI Engine (AIE-ML) architecture manual AM020

</details>

The job description asks for "understanding the performance implications on AI acceleration of different compute, memory, and communication configurations and hardware and software implementation choices". That is the core of the role. You need to reason quickly about whether a workload is limited by compute, by memory bandwidth, or by data movement and synchronisation, and about which processor in the SoC it belongs on.

## Purpose and Scope

This page describes the Ryzen AI SoC at the level an interviewer expects. It then covers the roofline model with worked numbers, how tiling and DMA overlap work on a spatial array, and a performance-debugging checklist.

> **Check before quoting.** Product numbers such as TOPS, tile counts and memory sizes vary between generations. The figures below are approximate, taken from public material, and were not checked against AMD's datasheets. Quote them as "roughly", or look them up again before the interview.

## The heterogeneous SoC

```mermaid
flowchart LR
  subgraph SoC[Ryzen AI SoC]
    CPU[Zen CPU cores<br/>AVX-512 / VNNI<br/>control, pre/post-processing, fallback ops]
    GPU[Radeon iGPU<br/>RDNA, high fp16 throughput<br/>large or float models]
    NPU[XDNA NPU<br/>AI Engine tile array<br/>low-power int8 / bf16 inference]
  end
  DDR[(Shared LPDDR5x memory)]
  CPU --- DDR
  GPU --- DDR
  NPU --- DDR
```

| Engine | Strengths | Typical use |
|---|---|---|
| CPU | Flexible, low launch latency, handles any operator | Control flow, small or irregular ops, fallback, tokenisation |
| iGPU | High throughput for fp16/bf16, mature software stack | Large float models, graphics-adjacent work |
| NPU (XDNA) | Best performance per watt for int8/bf16 GEMM and convolution, runs constantly in the background | Sustained, battery-friendly inference: camera effects, Copilot+ features, LLM offload |

The three engines **share DRAM**. Handing data from one to another needs no PCIe copy, but they still contend for the same bandwidth, and buffers have to be allocated so that every engine involved can reach them.

**Generations (approximate):** Phoenix (Ryzen 7040) had the first XDNA NPU at about 10 TOPS. Hawk Point (8040) reached about 16 TOPS. Strix Point (Ryzen AI 300) introduced XDNA 2 at about 50 TOPS, which meets the Copilot+ requirement of 40 or more.

## Inside the XDNA NPU: a spatial dataflow array

XDNA comes from the Xilinx Versal **AI Engine** architecture, specifically the AIE-ML variant. It is a 2D grid of tiles arranged in columns:

- **Compute tiles** each have a VLIW vector processor with SIMD MAC units, a small local data memory (about 64 KB on AIE-ML) and program memory. Each tile can also access its neighbours' memories directly.
- **Memory tiles** hold larger staging buffers (about 512 KB each on AIE-ML) with their own DMA engines. They are used to reshape and broadcast data.
- **Shim (interface) tiles** sit at the edge of the array and DMA data between DDR and the array.
- **Streaming interconnect** carries data between tiles, with **locks** for synchronisation between a producer and a consumer.

There are **no caches.** Software has to place every byte explicitly: the compiler or kernel author decides which tile holds which tile of data and programs the DMAs to move it. MLIR-AIE "object FIFOs" are the abstraction over this, a double-buffered channel between a producer and a consumer.

```mermaid
flowchart TB
  DDR[(DDR)] -->|shim DMA| MT[Memory tile<br/>~512 KB staging]
  MT -->|broadcast A tile| C1[Compute tile 1]
  MT -->|broadcast A tile| C2[Compute tile 2]
  MT -->|B tile 1| C1
  MT -->|B tile 2| C2
  C1 -->|C tile| MT
  C2 -->|C tile| MT
  MT -->|shim DMA| DDR
```

The usual GEMM mapping:

- Split C into tiles, one block for each compute tile.
- **Broadcast** a tile of A along a row of compute tiles and a tile of B along a column, so that each byte fetched from DDR is reused by many cores.
- Accumulate in each tile's local memory, and write C back only once per output tile.
- **Double buffer:** while the core computes on buffer 0, the DMA fills buffer 1, and then the two swap.

## The roofline model

Attainable performance = **min(peak compute, arithmetic intensity × memory bandwidth)**. The *ridge point*, peak ÷ bandwidth, is the intensity at which a kernel stops being memory-bound and becomes compute-bound.

Worked example, using round numbers: peak 50 TOPS int8 and 100 GB/s DDR bandwidth.

- **Ridge point** = 50e12 / 100e9 = **500 ops/byte**.
- **int8 GEMM, 1024³.** Ops = 2·1024³ ≈ 2.15 G. Bytes, counting A, B and an int8 C once each, = 3·1024² ≈ 3.15 MB. Intensity ≈ **683 ops/byte**, which is above the ridge, so the kernel is compute-bound if the tiling actually achieves that reuse.
- **int8 GEMV, 1024×1024 by 1024** (one decode step). Ops = 2·1024² ≈ 2.1 M. Bytes ≈ 1024² + 2·1024 ≈ 1.05 MB. Intensity ≈ **2 ops/byte**. The attainable rate is about 2 × 100 GB/s = **200 GOPS, only 0.4% of peak.** This is why decoding is limited by memory bandwidth and why 4-bit weights help.
- **Element-wise add** of int8 tensors does 1 op for every 3 bytes (two reads, one write), so its intensity is about 0.33. Never run it as a standalone kernel; fuse it.

```mermaid
xychart-beta
  title "Roofline (50 TOPS, 100 GB/s), log-ish sketch"
  x-axis "Arithmetic intensity (ops/byte)" [0.33, 2, 50, 500, 683]
  y-axis "Attainable TOPS" 0 --> 55
  line [0.033, 0.2, 5, 50, 50]
```

The roofline also applies at every level of the memory hierarchy: DDR to memory tile, memory tile to compute tile, and local memory to registers. A kernel is limited by the slowest level its data has to cross.

## Compute, memory and communication trade-offs

| Choice | Trade-off |
|---|---|
| Bigger tiles | More reuse and higher intensity, but they need more local memory, leave less room for double buffering, and waste more work on padding at the edges. |
| More cores on one layer | More compute, but each core gets a smaller tile (less reuse) and the broadcast or synchronisation overhead grows. |
| Lower precision (int8, int4, bf16) | Fewer bytes and more MACs per cycle, but some accuracy is lost and quantize/dequantize is needed at partition boundaries. |
| Layer fusion on chip | Intermediates never reach DDR, but there is pressure on local memory and the scheduling gets more complex. |
| Running one model across CPU, GPU and NPU | Each op runs on its best engine, but every handoff costs synchronisation, a cache flush or invalidate, and perhaps a layout or dtype conversion. |
| Batching | Higher throughput and better weight reuse, but higher latency. Batch 1 is the norm for interactive inference on a laptop. |
| Static vs dynamic shapes | Static shapes allow precompiled, tuned schedules. Dynamic shapes need padding into buckets, or a JIT. |

**Overlap arithmetic.** If a tile takes 10 µs to compute and 8 µs to DMA, single buffering takes 18 µs per tile and double buffering takes max(10, 8) = 10 µs, a 1.8× speedup. Once the DMA time is more than the compute time, the kernel is limited by bandwidth no matter what you do.

## A performance-debugging checklist

1. **Measure first.** Record end-to-end latency, then the time per operator and per partition. Use ORT profiling, the Ryzen AI or Vitis AI profiling tools, or AMD uProf for the CPU side.
2. **Check placement.** Find out which ops actually ran on the NPU, how many partitions there are, and whether any CPU fallback or copies happen between partitions.
3. **Classify each hot kernel.** Compare its achieved FLOP/s and bytes/s with the roofline. Is it limited by compute, by memory, or by latency and overhead?
4. **Memory-bound:** fuse operators, quantize, choose a better layout, improve tile reuse, cut transposes.
5. **Compute-bound:** check vector utilisation, the MAC data types, and the efficiency of the inner loop of the micro-kernel.
6. **Overhead-bound:** batch submissions, fuse small kernels, avoid synchronising per op, and reuse compiled graphs and buffers.
7. **Iterate and protect.** Re-measure after each change, and add a performance regression test.

## Common traps

- Quoting peak TOPS as if it were achievable. Real models usually reach a small fraction of peak, so explain why using the roofline.
- Forgetting that the CPU, GPU and NPU share DRAM bandwidth. Running a GPU workload can slow down the NPU.
- Optimising compute on a kernel that is bound by memory.
- Ignoring the first-run cost: compiling the model and loading it on the NPU can take far longer than one inference, so cache the compiled artifacts.

## Key Points

- Ryzen AI combines a Zen CPU, a Radeon iGPU and an XDNA NPU that share memory. Place each workload on the engine that suits it, and keep the number of handoffs low.
- XDNA is a spatial array with no caches. Explicit DMA, tiling, broadcast and double buffering decide how fast it runs.
- Use the roofline (min of peak and intensity × bandwidth) to classify any kernel. GEMM is compute-bound, while GEMV, decode and element-wise ops are memory-bound.
- Debug in this order: measure, check placement, classify against the roofline, fix the real bottleneck, measure again.