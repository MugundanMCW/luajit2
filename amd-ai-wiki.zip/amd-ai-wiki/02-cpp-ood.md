# C++ and Object-Oriented Design

<details>
<summary>Relevant source files</summary>

- Deeper coverage: [C++ for LLVM: Classes](../cpp-wiki/cpp-wiki.html#classes), [Ownership](../cpp-wiki/cpp-wiki.html#ownership), [Templates](../cpp-wiki/cpp-wiki.html#templates)

</details>

The job description asks for "strong object-oriented programming background, C/C++ preferred" and "good understanding of object-oriented design principles". In practice this means two kinds of question. Language-mechanics questions check that you know what the compiler does. Design questions check that you can structure a component such as a runtime, an operator registry or a pass manager.

## Purpose and Scope

This page lists the C++ facts that come up most often and the design principles, and then works through two design problems in the style of an AI-compiler interview.

## Language mechanics you must know cold

| Topic | One-line answer |
|---|---|
| RAII | Resources are acquired in a constructor and released in the destructor, so cleanup happens on every exit path, including exceptions. |
| Rule of 0/3/5 | If you write one of destructor, copy ctor, copy assign, move ctor or move assign, you probably need all five. Prefer none at all by holding `unique_ptr` and `vector` members. |
| `unique_ptr` vs `shared_ptr` | `unique_ptr` means a single owner and costs nothing extra. `shared_ptr` adds an atomic refcount and a control block, so use it only when ownership really is shared. |
| Move semantics | `std::move` is just a cast to an rvalue reference. The move constructor steals the buffer, leaving the source valid but unspecified. Mark moves `noexcept` so `vector` will use them when it grows. |
| Virtual dispatch | Each call goes through a vptr to a vtable. The costs are an indirect call, no inlining, and one pointer per object. Always give a polymorphic base a virtual destructor. |
| Static vs dynamic polymorphism | Templates and CRTP resolve at compile time, so calls inline but code size grows. Virtual functions resolve at run time and allow open extension. |
| `const` correctness | Use `const&` for parameters you only read. `const` member functions promise not to change observable state; `mutable` is for caches. |
| Object slicing | Copying a `Derived` into a `Base` by value loses the derived part. Pass by reference or pointer instead. |
| Undefined behaviour | Signed overflow, out-of-bounds access, use-after-free and data races are all UB. The optimiser may assume UB never happens. |
| `inline`, `constexpr`, templates in headers | Templates are instantiated at the point of use, so their definitions must be visible in the header. |
| Memory layout | Members are padded to their alignment. Ordering members from largest to smallest reduces padding. `alignas(64)` puts an object on its own cache line. |

### Example: a RAII device buffer

```cpp
class DeviceBuffer {
public:
  explicit DeviceBuffer(size_t bytes) : ptr_(device_alloc(bytes)), size_(bytes) {}
  ~DeviceBuffer() { if (ptr_) device_free(ptr_); }

  DeviceBuffer(const DeviceBuffer&) = delete;            // no accidental copies
  DeviceBuffer& operator=(const DeviceBuffer&) = delete;

  DeviceBuffer(DeviceBuffer&& o) noexcept
      : ptr_(std::exchange(o.ptr_, nullptr)), size_(std::exchange(o.size_, 0)) {}
  DeviceBuffer& operator=(DeviceBuffer&& o) noexcept {
    if (this != &o) { reset(); ptr_ = std::exchange(o.ptr_, nullptr);
                      size_ = std::exchange(o.size_, 0); }
    return *this;
  }
  void* data() const { return ptr_; }
  size_t size() const { return size_; }
private:
  void reset() { if (ptr_) device_free(ptr_); ptr_ = nullptr; size_ = 0; }
  void* ptr_; size_t size_;
};
```

`device_alloc` and `device_free` are placeholders for a real driver API such as XRT buffer objects or a HIP allocation. Interviewers like this example because it tests ownership, the rule of five, `noexcept` moves and self-assignment in a single class.

## Design principles (SOLID and friends)

| Principle | Meaning | AI-runtime example |
|---|---|---|
| **S**ingle responsibility | A class has one reason to change. | Keep the graph partitioner separate from the kernel launcher. |
| **O**pen/closed | Extend behaviour without editing existing code. | Register a new operator kernel without touching the dispatcher. |
| **L**iskov substitution | A subclass must work wherever its base is expected. | Every `ExecutionProvider` must honour the same `compile()` contract. |
| **I**nterface segregation | Prefer small interfaces to one large one. | Separate `Allocator` from `KernelLauncher`. |
| **D**ependency inversion | Depend on abstractions, not concrete classes. | The scheduler talks to `IDevice`, so it can be tested with a fake NPU. |
| Composition over inheritance | Build behaviour by holding objects, not by deep hierarchies. | A `Session` *has* an allocator and a set of providers. |

Common patterns worth naming in an answer: **Factory/Registry** (an operator name maps to a kernel creator), **Strategy** (choosing a tiling policy), **Visitor** (walking an IR graph), **Observer** (profiling hooks), **Pimpl** (a stable ABI for a runtime library) and **Builder** (constructing a graph).

## Design problem 1: an operator kernel registry

**Prompt:** "Design how a runtime picks a kernel for each node of an ONNX graph, for CPU, GPU and NPU."

```mermaid
classDiagram
  class Kernel { <<interface>> +compute(ctx) Status }
  class KernelKey { op: string; device: Device; dtype: DType }
  class KernelRegistry { +add(KernelKey, Creator) +find(KernelKey) Creator }
  class ExecutionProvider { <<interface>> +getCapability(graph) +compile(subgraph) }
  ExecutionProvider --> KernelRegistry
  KernelRegistry --> Kernel : creates
```

The points to make:

- Each kernel is keyed by (op type, opset version, device, data type).
- Providers register their kernels at static-initialisation time or when a plugin loads. This is the open/closed principle at work.
- The partitioner asks each provider in priority order which nodes it can take (`getCapability`), and anything left over falls back to the CPU.
- Kernels should be stateless and reusable across inferences. Per-call state lives in a context object, which makes concurrent sessions safe.

## Design problem 2: an extensible pass manager

**Prompt:** "Design a pass pipeline for a graph compiler."

- `Pass` is an interface with `run(Graph&) -> bool changed`, `name()`, and a declaration of what it requires and what it preserves.
- `PassManager` holds a `vector<unique_ptr<Pass>>`, runs the passes in order, and supports `--print-after` and timing hooks through the observer pattern.
- Analyses are cached and invalidated when a pass reports a change. This is the same idea as LLVM's new pass manager; see [Writing a pass](../ir-wiki/ir-wiki.html#writing-a-pass).
- A fixed-point loop (keep running until nothing changes) handles canonicalisation passes.

## Common traps

- Forgetting the virtual destructor in a polymorphic base.
- Calling a virtual function from a constructor. It dispatches to the base version.
- Returning a reference to a local.
- Using `shared_ptr` everywhere "just in case". Interviewers read this as unclear ownership.
- Writing `std::move` on a `const` object. It silently copies.

## Key Points

- Explain RAII and the rule of five with a concrete resource such as a device buffer.
- Weigh virtual dispatch against templates in terms of performance: indirect calls and lost inlining versus code size.
- For design questions, use registries, interfaces and composition, and say explicitly how the design is tested (fake devices) and extended (new operators or providers).