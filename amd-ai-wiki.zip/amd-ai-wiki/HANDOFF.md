# amd-ai-wiki: handoff notes

Interview-prep wiki for the AMD SDE2 role (Ryzen AI compilers and runtime). It has 7 pages and was built with `python %TEMP%\rawiki\wiki_build.py amdai`. The `WIKIS` key is `amdai` and the title is "AMD Ryzen AI SDE2 Interview Prep".

## Build result

- 7 sections and 6 mermaid blocks.
- 0 citation problems. The wiki has no source-code citations, so this check is empty.
- 0 cross-wiki link problems. The pages link to cpp-wiki, os-wiki, arch-wiki and ir-wiki.

## What was verified

- **Worked numbers:** every worked number on pages 4 and 6 was checked by `%TEMP%\amdwiki\check_numbers.py`, which printed `ALL OK`. This covers:
  - GEMM intensity
  - ResNet-50 conv1 shape, FLOPs and im2col dimensions
  - the Winograd saving
  - the decode bound
  - the KV cache size
  - the quantization example
  - Amdahl's law
  - the roofline ridge point, GEMM and GEMV intensity, and the chart values
  - the double-buffer speedup
- **Page 7 numeric answers:** these were checked by hand: 2·4096³ ≈ 137.4 G, and min(50, 20 × 0.1) = 2 TOPS.

## What was NOT verified

- **Product figures:** Ryzen AI TOPS per generation, AIE-ML tile memory sizes (about 64 KB and about 512 KB), and the Copilot+ threshold of 40 TOPS. These came from memory and were not checked against AMD datasheets or manual AM020. Page 6 says so in a callout.
- **Tool names:** Ryzen AI and Vitis AI profiling tool names, the Peano and Chess compilers, and the IRON API name. All are from memory.
- **Code snippets:** the snippets on pages 2 to 4 (DeviceBuffer, topological sort, thread pool, tiled GEMM) were not compiled. DeviceBuffer uses placeholder functions, `device_alloc` and `device_free`.
- **Example IR:** the MLIR on page 5 is illustrative and is labelled as such.
- **Rendering:** the `xychart-beta` roofline chart on page 6 needs Mermaid 10.6 or later. I did not check how it renders in the built HTML. If it does not render, replace it with a table.

## Not done

The wiki is not yet in `guide_build.py` or `llvm-backend-guide.zip`, which matches how the other new wikis were handled.