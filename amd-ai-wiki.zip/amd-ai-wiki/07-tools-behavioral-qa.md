# Tools, Behavioural Questions and the Question Bank

<details>
<summary>Relevant source files</summary>

- Related question banks: [OS: Interview Q&A](../os-wiki/os-wiki.html#interview-qa), [C++ for LLVM: Build and exercises](../cpp-wiki/cpp-wiki.html#build-exercises)

</details>

The job description asks for "experience with software development processes and tools such as debuggers, source code control systems (GitHub) and profilers" and "effective communication and problem-solving skills". This page covers the tooling answers interviewers expect, a template for behavioural answers, and a question bank that spans every page of this wiki.

## Purpose and Scope

Use this page in the last few days before the interview. Answer each question out loud before you read the answer given here.

## Debuggers

| Task | gdb / lldb | WinDbg / Visual Studio |
|---|---|---|
| Break at a function | `break foo` / `b foo` | `bp module!foo` |
| Break when a condition holds | `break f.cpp:42 if i==7` | Conditional breakpoint |
| Stop when memory changes | `watch var` (hardware watchpoint) | `ba w4 addr` / data breakpoint |
| Backtrace | `bt`, `frame N` | `k`, call stack window |
| All threads | `thread apply all bt` | `~*k` |
| Analyse a crash dump | `gdb prog core` | `.dump` / open the `.dmp`, then `!analyze -v` |

Points to mention:

- Build with `-g` (or `/Zi`) and keep symbols even for optimised builds.
- Run **AddressSanitizer** (`-fsanitize=address`) for use-after-free and out-of-bounds bugs, **ThreadSanitizer** for data races, and **UBSan** for undefined behaviour.
- Use valgrind or Dr. Memory where sanitizers are not available.
- For a numerical mismatch in a compiled model, **bisect the graph**. Compare the intermediate tensors of each layer against a reference CPU run, using a tolerance suited to int8, until you find the first layer that diverges.

## Source control (Git and GitHub)

- Know the everyday workflow: feature branches, small focused commits, `rebase -i` to tidy up before review, pull requests with CI, and code review.
- **`git bisect`** binary-searches the history for the commit that introduced a regression: `git bisect start; git bisect bad; git bisect good v1.2; git bisect run ./perf_test.sh`. This works for performance regressions too, provided the test script exits non-zero when the result is too slow.
- Explain the difference between merge and rebase. A merge preserves history. A rebase produces a linear history, but you must never rebase commits that are already shared.
- Other useful commands: `git blame` and `git log -S` for archaeology, `cherry-pick` for backports, `reflog` to recover lost work.

## Profilers

| Tool | Use |
|---|---|
| `perf` (Linux) | `perf stat` for counters (cycles, IPC, cache misses). `perf record -g` and `perf report` for hotspots, and flame graphs. |
| AMD uProf | Profiling for Zen CPUs: hotspots, IBS sampling, cache and memory analysis, power. |
| Intel VTune, Windows Performance Analyzer / ETW | Hotspots, threading and Windows system traces. |
| ONNX Runtime profiling | `SessionOptions.enable_profiling` writes a JSON trace with per-op and per-EP timings, which can be opened in Chrome tracing or Perfetto. |
| Ryzen AI / Vitis AI tools | Partition reports, NPU utilisation and timelines. Check the Ryzen AI documentation for the current tool names. |
| rocprof / Omniperf, RGP | AMD GPU kernel profiling. |

**How to read a profile:**

1. Find the top hotspots.
2. Classify each one: is it compute (low IPC with many stalls on the core, or full vector units), memory (high cache-miss and bandwidth counters) or overhead (many small calls, syscalls, locks)?
3. Form a hypothesis, change one thing, and measure again.

Always report the **median of several runs, after a warm-up**.

## Behavioural answers: the STAR template

Answer in four parts: **S**ituation, **T**ask, **A**ction (what *you* did, with technical detail) and **R**esult (a number, plus what you learned). Prepare four or five stories that can be adapted:

1. **A performance win.** Example structure: "Profiled X, found it was memory-bound at Y GB/s, fused or tiled it, and got Z× faster." This matches the core of the job description.
2. **A hard bug.** For example a race, a memory corruption or a compiler miscompile. Explain how you narrowed it down: sanitizers, bisecting, a minimal repro.
3. **A design decision with trade-offs.** Say what alternatives you considered and why you chose the one you did.
4. **Working across teams.** For example with hardware or architecture teams, or with an external partner, which the job description explicitly mentions.
5. **Learning something new quickly.** For example a new framework, an unfamiliar ISA or a new codebase.

Also have an answer to "Why AMD and Ryzen AI?" ready. A good one covers on-device AI, performance per watt, heterogeneous compute, and AMD's open-source stack (ROCm, MLIR-AIE, contributions to ONNX Runtime).

## Question bank

**C++ and design**

1. *Why must a polymorphic base class have a virtual destructor?* Deleting a derived object through a base pointer otherwise runs only the base destructor. That is undefined behaviour and usually leaks.
2. *When would you choose templates over virtual functions in a kernel library?* When the type or shape is known at compile time and the code is on a hot path. Calls inline and vectorise, at the cost of code size. Choose virtual functions when the choice is made at run time, or when plugins need to extend the library.
3. *Design a tensor class.* It holds a shape, strides, a dtype and a shared buffer with an offset, so that views need no copy. Allocation goes through a pluggable allocator. Mention contiguity checks, and make clear that ownership belongs to the buffer and not to the view.

**DSA, OS and threads**

4. *Give the execution order of a model graph, and say which nodes can run in parallel.* Run Kahn's topological sort by levels. All the nodes in one level are independent.
5. *Minimise memory for intermediate tensors.* Compute each tensor's lifetime interval, then pack them into an arena greedily, largest first or with best fit. Allow in-place reuse for element-wise ops.
6. *What is false sharing and how do you fix it?* Different variables written by different threads share a cache line. Pad or align each one to 64 bytes, or accumulate per thread and combine at the end.
7. *Why must DMA buffers be pinned?* The device uses physical or IOMMU addresses, and the OS could move or page out pageable memory while the transfer is still in flight.

**ML operations**

8. *How many FLOPs does a 4096×4096 by 4096×4096 GEMM take?* 2·4096³ ≈ 137.4 GFLOP.
9. *Why is LLM decoding memory-bound?* Each token is a GEMV that reads every weight once, giving about 2 ops per byte. That is far below the ridge point.
10. *How do you fold BatchNorm into a convolution?* w' = w·γ/√(σ²+ε) and b' = (b−μ)·γ/√(σ²+ε) + β, both computed at compile time.
11. *Why accumulate in int32 for an int8 GEMM?* Each product fits in 16 bits, and summing K of them needs about 16 + log₂K bits.
12. *Per-tensor or per-channel quantization for weights?* Per-channel, because the ranges of the output channels differ widely and one scale would waste resolution.

**Compilers and frameworks**

13. *How does ONNX Runtime decide what runs on the NPU?* Each EP's `GetCapability` claims nodes, in priority order. The EP fuses the claimed subgraphs into compiled nodes, and whatever is left runs on the CPU EP.
14. *What is progressive lowering in MLIR?* Converting step by step through dialects, from high-level ops to `linalg`, then loops and vectors, then `llvm`. Each step performs the optimisations that suit its level of abstraction.
15. *What is the difference between operator fusion and kernel tuning?* Fusion removes memory traffic between ops, at the graph level. Tuning picks the tile sizes, loop order and unroll factors inside one kernel.
16. *A new op is not supported by the NPU. What are your options?* Decompose it into ops that are supported, implement a kernel for it, fall back to the CPU while keeping the partition boundaries cheap, or rewrite the pattern at export time.

**Performance**

17. *Using the roofline model, the hardware does 50 TOPS at 100 GB/s and a kernel's intensity is 20 ops/byte. What is attainable?* min(50, 20 × 0.1) = 2 TOPS. It is memory-bound.
18. *How does double buffering help?* It overlaps DMA with compute, so the time per tile becomes max(compute, DMA) instead of their sum.
19. *A model is fast on its own but slow inside an app. Why?* Possible causes: competition for shared DRAM, the CPU running in a lower power state, extra copies in pre- or post-processing, recompiling on every run, or thread oversubscription.
20. *Throughput or latency for a laptop NPU?* Usually latency at batch size 1, together with energy per inference. Pipelining overlaps the stages without adding batching latency.

## Final checklist before the interview

- [ ] Derive the formulas for GEMM and convolution FLOPs, and for the roofline, from memory.
- [ ] Write a topological sort, a thread pool and a bounded queue in under 15 minutes each.
- [ ] Explain the path from PyTorch to ONNX to the ORT EP to the NPU in two minutes.
- [ ] Sketch the XDNA tile array and its GEMM tiling, including broadcast and double buffering.
- [ ] Have four STAR stories that each contain numbers.
- [ ] Re-check the current Ryzen AI product numbers and tool names in AMD's documentation.

## Key Points

- For debugging and profiling, name concrete tools and a method: sanitizers, bisecting the graph or the history, and measure → classify → fix.
- Behavioural answers should be STAR stories with numbers, and should match the job description: performance, cross-team work, learning.
- Rehearse the question bank out loud. Being clear and structured counts as much as being correct.