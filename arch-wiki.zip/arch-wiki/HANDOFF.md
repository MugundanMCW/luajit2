# Handoff: Computer Architecture Wiki

## Status

- 11 beginner pages written (`01-overview.md` … `11-glossary.md`). HTML built at `arch-wiki/arch-wiki.html` with `python %TEMP%\rawiki\wiki_build.py arch`: 11 sections, 11 nav entries, 46 Mermaid diagrams, 0 cross-wiki link problems.
- The `"arch"` entry is in the `WIKIS` table of `%TEMP%\rawiki\wiki_build.py`.
- **Not done:** the wiki is not in `llvm-backend-guide.zip` (left alone, as requested for the IR wiki).

## Sources and how they were checked

- This wiki cites Wikipedia, Arm documents and textbooks, not LLVM source, so `verify.py` reports 0 citations; it has nothing to check here.
- All 28 Wikipedia links in the built HTML were fetched and returned HTTP 200.
  - Reaching them needed `curl --ssl-no-revoke`: on this network the Windows certificate revocation check fails (`CRYPT_E_NO_REVOCATION_CHECK`).
  - Two URLs contain parentheses (`Hazard_(computer_architecture)`, `Multithreading_(computer_architecture)`). `build_html.py` cuts Markdown links at the first `)`, so they are written as `%28`/`%29`. Use the same encoding for any new URL with parentheses.
- Arm documentation pages (`developer.arm.com`, documents DDI 0487, 102336, 102474, 102476) returned HTTP 403 to scripted requests, so they are named by title and number but **not linked**. Add links after checking them in a browser.
- Textbook references (Patterson and Hennessy; Hennessy and Patterson) are named by chapter only.

## What is illustrative

Every diagram, timing table, code listing (Arm assembly, C, CUDA-style) and number (cache sizes, latencies, pipeline depths) is illustrative: it shows the idea, not any specific chip. The worked arithmetic (CPI, Amdahl's law table, cache address split, AMAT, self-check answers) was recomputed by hand.

## Page ids

overview, fundamentals, pipelining, branches, ilp, memory-ordering, caches-coherence, multicore, multithreading, simd-gpu, glossary

## To add to the combined guide

Add a tuple for `arch-wiki` to `WIKIS` in `%TEMP%\rawiki\guide_build.py` (it fits best first, as background before the IR and back-end wikis), then run `python %TEMP%\rawiki\guide_build.py`.