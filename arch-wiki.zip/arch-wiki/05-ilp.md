# Instruction-Level Parallelism

<details>
<summary>Relevant source files</summary>

The following references were used as context for generating this wiki page:

- [Wikipedia: Instruction-level parallelism](https://en.wikipedia.org/wiki/Instruction-level_parallelism)
- [Wikipedia: Superscalar processor](https://en.wikipedia.org/wiki/Superscalar_processor)
- [Wikipedia: Out-of-order execution](https://en.wikipedia.org/wiki/Out-of-order_execution)
- [Wikipedia: Register renaming](https://en.wikipedia.org/wiki/Register_renaming)
- [Wikipedia: Tomasulo's algorithm](https://en.wikipedia.org/wiki/Tomasulo%27s_algorithm)
- [Wikipedia: Speculative execution](https://en.wikipedia.org/wiki/Speculative_execution)
- Book: Hennessy and Patterson, *Computer Architecture: A Quantitative Approach*, chapter 3

</details>

Instruction-level parallelism (ILP) means running several instructions from the *same* program at the same time. A pipeline overlaps instructions in different stages; ILP goes further, starting two, four or eight instructions in the same cycle and running them in whatever order their inputs become ready, while still making the program behave as if it ran one instruction at a time.

## Purpose and Scope

This page covers dependences, superscalar issue, out-of-order execution, register renaming, the reorder buffer, speculation, and the limits of ILP, plus VLIW as the compiler-driven alternative. Running several *threads* at once is on [Multithreading](#multithreading).

## The Restaurant Kitchen Analogy

A recipe says: 1. boil water (10 min), 2. chop onions (3 min), 3. cook pasta in the water (8 min), 4. fry the onions (5 min).

| One cook, strict order | Several cooks, out of order |
| --- | --- |
| 10 + 3 + 8 + 5 = **26 min** | Cook A boils water then cooks pasta (18 min). Cook B chops then fries onions (8 min) at the same time. Done in **18 min** |

Steps 3 depends on step 1 and step 4 depends on step 2, but the two chains are independent. Finding and using such independent chains is exactly what ILP hardware does. The finished dish is the same, as long as nobody serves it before every step is done.

## Dependences Decide What Can Overlap

```text
// illustrative
I1: LDR X1, [X0]        // load a
I2: ADD X2, X1, #1      // needs X1 from I1
I3: LDR X3, [X0, #8]    // independent of I1, I2
I4: MUL X4, X3, X3      // needs X3 from I3
I5: ADD X5, X2, X4      // needs X2 and X4
```

```mermaid
flowchart TD
    I1["I1: LDR X1"] --> I2["I2: ADD X2 = X1+1"]
    I3["I3: LDR X3"] --> I4["I4: MUL X4 = X3*X3"]
    I2 --> I5["I5: ADD X5 = X2+X4"]
    I4 --> I5
```

The graph has two independent chains. A machine that can start two instructions per cycle can run I1 and I3 together, then I2 and I4, then I5: three steps instead of five. The **longest chain** (the critical path) sets the minimum time, no matter how wide the machine.

**Sources:** [Wikipedia: Instruction-level parallelism](https://en.wikipedia.org/wiki/Instruction-level_parallelism)

## Superscalar: More Than One per Cycle

A **superscalar** core fetches, decodes and issues several instructions per cycle and has several execution units.

```mermaid
flowchart LR
    F["Fetch<br/>4 instr/cycle"] --> D["Decode<br/>4 instr/cycle"]
    D --> ALU1["ALU 1"]
    D --> ALU2["ALU 2"]
    D --> MUL["Multiplier"]
    D --> LS["Load/store unit"]
    D --> BR["Branch unit"]
```

| Width | Ideal IPC | Ideal CPI |
| --- | --- | --- |
| Scalar (1-wide) | 1 | 1 |
| 2-wide | 2 | 0.5 |
| 4-wide | 4 | 0.25 |

In practice dependences, cache misses and branch mispredictions keep real IPC well below the width.

**Sources:** [Wikipedia: Superscalar processor](https://en.wikipedia.org/wiki/Superscalar_processor)

## In-Order versus Out-of-Order

An **in-order** core issues instructions strictly in program order. If I2 waits for a slow load, everything behind it waits too, even independent work.

An **out-of-order (OoO)** core lets instructions run as soon as their inputs are ready, then puts results back in program order at the end.

| Cycle | In-order (2-wide) | Out-of-order (2-wide) |
| --- | --- | --- |
| 1 | I1 (load starts) | I1, I3 (both loads start) |
| 2 | I2 waits for X1... | waiting for loads |
| 3 | ...still waiting | I2, I4 |
| 4 | I2, I3 | I5 |
| 5 | I4 | |
| 6 | I5 | |

(Illustrative timing, with a load taking 2 cycles.) The out-of-order core hides the load delay by doing other work meanwhile.

## The Out-of-Order Engine

```mermaid
flowchart LR
    F["Fetch + branch prediction"] --> D["Decode"]
    D --> R["Rename<br/>architectural to physical registers"]
    R --> ROB["Reorder buffer (ROB)<br/>remembers program order"]
    R --> IQ["Issue queue<br/>wait for operands"]
    IQ -->|"ready"| EX["Execution units<br/>ALUs, multiplier, load/store"]
    EX -->|"result"| IQ
    EX --> ROB
    ROB --> C["Commit / retire<br/>in program order"]
```

| Stage | Job |
| --- | --- |
| Fetch / decode | Bring in instructions along the predicted path ([Branches](#branches)) |
| **Rename** | Give each result a fresh physical register, removing false dependences |
| **Issue queue** (reservation stations) | Hold instructions until their inputs are ready, then send them to a free unit |
| Execute | Do the work, possibly out of order |
| **Reorder buffer (ROB)** | Keep instructions in program order; mark each done when it finishes |
| **Commit** (retire) | Make results permanent strictly in program order, oldest first |

The idea of waiting in reservation stations and broadcasting results comes from **Tomasulo's algorithm** (IBM, 1967).

**Sources:** [Wikipedia: Out-of-order execution](https://en.wikipedia.org/wiki/Out-of-order_execution), [Wikipedia: Tomasulo's algorithm](https://en.wikipedia.org/wiki/Tomasulo%27s_algorithm)

## Register Renaming

The program has only 31 general registers, so it reuses names a lot. That creates *false* dependences ([Pipelining](#pipelining) called them WAR and WAW):

```text
// illustrative
I1: LDR X1, [X0]       // X1 = a
I2: ADD X2, X1, #1     // uses a
I3: LDR X1, [X0, #8]   // X1 = b   (reuses the name X1!)
I4: ADD X3, X1, #2     // uses b
```

I3 cannot write `X1` before I2 has read it (WAR), even though `a` and `b` are unrelated. The hardware has many more **physical** registers (often a couple of hundred) than architectural ones and gives every new result its own:

| Instruction | Written as | After renaming |
| --- | --- | --- |
| I1 | `X1 = load` | `P10 = load` |
| I2 | `X2 = X1 + 1` | `P11 = P10 + 1` |
| I3 | `X1 = load` | `P12 = load` |
| I4 | `X3 = X1 + 2` | `P13 = P12 + 2` |

Now I1→I2 and I3→I4 are two independent chains. A **rename table** maps each architectural register to its current physical register. (This is the hardware version of the SSA form used in compilers, see [LLVM IR: SSA and Phi](../ir-wiki/ir-wiki.html#ssa-phi).)

**Sources:** [Wikipedia: Register renaming](https://en.wikipedia.org/wiki/Register_renaming)

## Speculation and the Reorder Buffer

The core fetches past predicted branches and runs those instructions before it knows the prediction was right. The ROB makes this safe:

```mermaid
flowchart TD
    A["Instruction finishes executing"] --> B["Marked done in ROB<br/>(result not yet permanent)"]
    B --> C{"Is it the oldest<br/>instruction in the ROB?"}
    C -->|"No"| W["Wait"]
    W --> C
    C -->|"Yes"| D{"Exception or<br/>mispredicted branch?"}
    D -->|"No"| E["Commit: update architectural state"]
    D -->|"Yes"| F["Flush it and everything younger<br/>restore rename table, refetch"]
```

Because commit is in order, an exception or misprediction can be handled as if the program ran one instruction at a time: this is called **precise exceptions**. Stores are held in a **store buffer** and only written to the cache at commit, so wrong-path stores never become visible.

Speculation can still leave traces in the caches, which is the root of the Spectre family of security attacks.

**Sources:** [Wikipedia: Speculative execution](https://en.wikipedia.org/wiki/Speculative_execution)

## VLIW: Letting the Compiler Do It

Instead of complex hardware finding parallel instructions at run time, a **VLIW** (very long instruction word) machine has the compiler pack independent operations into one wide instruction.

| | Out-of-order superscalar | VLIW |
| --- | --- | --- |
| Who finds parallelism | Hardware, at run time | Compiler, ahead of time |
| Hardware complexity | High | Low |
| Handles unpredictable delays (cache misses) | Well | Poorly: the whole bundle stalls |
| Typical use | General-purpose CPUs (Arm Cortex-A/X, x86) | DSPs (for example Qualcomm Hexagon), some accelerators |

## Limits of ILP

Even with perfect hardware, ILP is limited by:

| Limit | Why |
| --- | --- |
| True dependences | A chain of dependent instructions can't be shortened |
| Branch mispredictions | Each one throws away the speculative work |
| Cache misses | A load to main memory takes hundreds of cycles; the ROB fills up waiting |
| Window size | The core can only look ahead as far as its ROB and queues hold (a few hundred instructions) |
| Power and area | Width and window size grow cost faster than performance |

This "ILP wall" is why designers turned to many threads and many data items: [Multicore](#multicore), [Multithreading](#multithreading) and [SIMD and GPUs](#simd-gpu).

## Key Points

- ILP runs independent instructions from one program at the same time; dependences limit it.
- Out-of-order cores rename registers, wait in issue queues, execute when ready, and commit in order via the ROB.
- Speculation runs past predicted branches; in-order commit keeps the result correct and exceptions precise.