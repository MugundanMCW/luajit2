# Pipelining

<details>
<summary>Relevant source files</summary>

The following references were used as context for generating this wiki page:

- [Wikipedia: Instruction pipelining](https://en.wikipedia.org/wiki/Instruction_pipelining)
- [Wikipedia: Hazard (computer architecture)](https://en.wikipedia.org/wiki/Hazard_%28computer_architecture%29)
- Book: Patterson and Hennessy, *Computer Organization and Design* (Arm edition), chapter 4

</details>

Pipelining is an assembly line for instructions. Instead of finishing one instruction completely before starting the next, the processor splits the work into stages and keeps every stage busy with a different instruction. Each instruction still takes the same time from start to finish, but a new one finishes every cycle.

## Purpose and Scope

This page covers the laundry analogy, the classic five-stage pipeline, speedup, and the three kinds of hazard (structural, data, control) with their fixes: stalls, forwarding and reordering. Branches get their own page, [Branches and Remedies](#branches).

## The Laundry Analogy

Doing four loads of laundry, each needing wash (30 min), dry (30 min), fold (30 min):

**One at a time:** wash, dry and fold load 1, then start load 2. Four loads take 4 × 90 = **360 minutes**.

**Pipelined:** as soon as load 1 moves to the dryer, load 2 goes in the washer.

| Time (min) | 0-30 | 30-60 | 60-90 | 90-120 | 120-150 | 150-180 |
| --- | --- | --- | --- | --- | --- | --- |
| Washer | Load 1 | Load 2 | Load 3 | Load 4 | | |
| Dryer | | Load 1 | Load 2 | Load 3 | Load 4 | |
| Folding | | | Load 1 | Load 2 | Load 3 | Load 4 |

Four loads take **180 minutes**. Each load still takes 90 minutes, but one finishes every 30 minutes once the line is full. That is the whole idea: pipelining improves **throughput** (jobs per hour), not **latency** (time for one job).

## The Five-Stage Pipeline

The textbook pipeline uses the steps from [Fundamentals](#fundamentals) as stages:

```mermaid
flowchart LR
    IF["IF<br/>Instruction fetch"] --> ID["ID<br/>Decode, read registers"]
    ID --> EX["EX<br/>Execute (ALU)"]
    EX --> MEM["MEM<br/>Memory access"]
    MEM --> WB["WB<br/>Write back"]
```

Between stages sit **pipeline registers** that hold each instruction's partial results, so each stage works on its own instruction independently.

Five instructions flowing through (each column is one clock cycle):

| Instruction | C1 | C2 | C3 | C4 | C5 | C6 | C7 | C8 | C9 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| I1 | IF | ID | EX | MEM | WB | | | | |
| I2 | | IF | ID | EX | MEM | WB | | | |
| I3 | | | IF | ID | EX | MEM | WB | | |
| I4 | | | | IF | ID | EX | MEM | WB | |
| I5 | | | | | IF | ID | EX | MEM | WB |

From cycle 5 onward one instruction finishes every cycle, so the ideal CPI is 1.

### How Much Faster?

With *k* stages of equal length, the ideal speedup approaches *k*. For *n* instructions:

```text
Unpipelined time = n × k cycles
Pipelined time   = k + (n − 1) cycles     (k to fill the pipe, then 1 per instruction)
```

For 1000 instructions and 5 stages: 5000 versus 1004 cycles, a speedup of about 4.98.

In real chips the speedup is lower because stages are not equal (the slowest stage sets the clock), pipeline registers add delay, and **hazards** force the pipeline to wait.

**Sources:** [Wikipedia: Instruction pipelining](https://en.wikipedia.org/wiki/Instruction_pipelining)

## Hazards: When the Assembly Line Breaks

A **hazard** is a situation where the next instruction cannot do its stage in the next cycle.

```mermaid
flowchart TD
    H["Hazard"] --> S["Structural<br/>two instructions need the same hardware"]
    H --> D["Data<br/>an instruction needs a result not yet produced"]
    H --> C["Control<br/>we don't know which instruction comes next"]
    S --> S1["Fix: duplicate hardware<br/>(separate instruction and data caches)"]
    D --> D1["Fix: forwarding, stalls, reordering"]
    C --> C1["Fix: branch prediction<br/>(see Branches page)"]
```

### Structural Hazards

If instruction fetch (IF) and a load (MEM) both need memory in the same cycle and there is only one memory port, one must wait. Real processors avoid this with separate L1 instruction and data caches.

### Data Hazards

```text
ADD X1, X2, X3     // writes X1 in WB (cycle 5)
SUB X4, X1, X5     // wants X1 in ID   (cycle 3)  -- too early!
```

`SUB` reads `X1` two cycles before `ADD` writes it. This is a **read-after-write (RAW)** dependence, the only kind that is a true dependence.

| Name | Pattern | Is it real? |
| --- | --- | --- |
| RAW (read after write) | I2 reads what I1 writes | Yes, a true dependence: I2 needs I1's value |
| WAR (write after read) | I2 writes what I1 reads | Only a name clash; fixed by register renaming ([ILP](#ilp)) |
| WAW (write after write) | I2 writes what I1 writes | Only a name clash; fixed by renaming |

**Fix 1: Stall.** Insert empty cycles ("bubbles") until the value is ready.

| | C1 | C2 | C3 | C4 | C5 | C6 | C7 | C8 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADD | IF | ID | EX | MEM | WB | | | |
| SUB | | IF | stall | stall | ID | EX | MEM | WB |

Two wasted cycles.

**Fix 2: Forwarding (bypassing).** The result of `ADD` exists at the end of its EX stage (cycle 3). Extra wires send it straight to the ALU input for `SUB`'s EX stage in cycle 4, without waiting for write-back.

```mermaid
flowchart LR
    subgraph ADD["ADD X1, X2, X3"]
        A1["IF"] --> A2["ID"] --> A3["EX<br/>X1 computed"] --> A4["MEM"] --> A5["WB"]
    end
    subgraph SUB["SUB X4, X1, X5"]
        B1["IF"] --> B2["ID"] --> B3["EX<br/>uses X1"] --> B4["MEM"] --> B5["WB"]
    end
    A3 -->|"forward"| B3
```

No stall at all.

**The load-use case.** A load only gets its data at the end of MEM, so forwarding cannot fully hide it:

```text
LDR X1, [X0]       // X1 available after MEM (cycle 4)
ADD X2, X1, X3     // needs X1 at start of EX (cycle 4)  -> 1-cycle stall
```

**Fix 3: Reorder.** The compiler (or the hardware, see [ILP](#ilp)) moves an independent instruction into the gap:

```text
// before: 1 stall              // after: no stall
LDR X1, [X0]                    LDR X1, [X0]
ADD X2, X1, X3                  LDR X4, [X0, #8]   // independent, fills the gap
LDR X4, [X0, #8]                ADD X2, X1, X3
```

This is exactly what a compiler's instruction scheduler does, see the [Instruction Scheduling wiki](../sched-wiki/sched-wiki.html#overview).

**Sources:** [Wikipedia: Hazard (computer architecture)](https://en.wikipedia.org/wiki/Hazard_%28computer_architecture%29)

### Control Hazards

After a branch the processor does not know which instruction to fetch next until the branch is resolved, several stages later. That is big enough to need its own page: [Branches and Remedies](#branches).

## Deeper Pipelines

Splitting work into more, shorter stages allows a faster clock. Modern high-performance cores have well over 10 stages. The cost is that each hazard wastes more cycles: a branch resolved in stage 15 throws away up to 14 stages of work if it was guessed wrong.

| Pipeline depth | Clock | Cost of a mistake |
| --- | --- | --- |
| Short (5 stages) | Slower | Small |
| Deep (15-20 stages) | Faster | Large |

## Key Points

- Pipelining overlaps instruction stages; it improves throughput, not the latency of one instruction.
- Hazards are structural (shared hardware), data (RAW dependences) or control (branches).
- Forwarding removes most data stalls; a load followed immediately by its use still stalls unless reordered.