# Fundamentals: CPU, Memory and Instructions

<details>
<summary>Relevant source files</summary>

The following references were used as context for generating this wiki page:

- [Wikipedia: Von Neumann architecture](https://en.wikipedia.org/wiki/Von_Neumann_architecture)
- [Wikipedia: Instruction set architecture](https://en.wikipedia.org/wiki/Instruction_set_architecture)
- [Wikipedia: Memory hierarchy](https://en.wikipedia.org/wiki/Memory_hierarchy)
- Arm: *Arm Architecture Reference Manual for A-profile architecture* (DDI 0487)
- Book: Patterson and Hennessy, *Computer Organization and Design* (Arm edition), chapters 1-2

</details>

A computer is a machine that follows a list of very small instructions such as "add these two numbers" or "copy this number from memory". This page explains the parts of a computer, what an instruction looks like, the loop the processor runs forever, and how to measure how fast it is.

## Purpose and Scope

This page covers the von Neumann model (processor, memory, input/output), registers, the ALU and control unit, the instruction set, the fetch-decode-execute cycle, RISC versus CISC, and the basic performance equation. Overlapping instructions is the subject of [Pipelining](#pipelining).

## The Kitchen Analogy

Think of a cook in a kitchen:

| Kitchen | Computer | Notes |
| --- | --- | --- |
| The cook | **Processor (CPU)** | Does the work |
| The recipe book | **Program** in memory | A numbered list of steps |
| A bookmark | **Program counter (PC)** | Which step is next |
| The cook's two hands | **Registers** | A few things held right now; instant to use |
| The worktop | **Cache** | Small, close, fast |
| The pantry | **Main memory (RAM)** | Large, but a walk away |
| The supermarket | **Storage (SSD)** | Huge, very slow to reach |

The cook reads a step, does it, moves the bookmark, and repeats. A processor does exactly that, billions of times per second.

## The Von Neumann Model

Almost every computer follows the design described by John von Neumann in 1945: one memory holds both the program and its data, and the processor reads both from it over a shared path.

```mermaid
flowchart LR
    subgraph CPU["Processor (CPU)"]
        CU["Control unit<br/>decides what to do"]
        ALU["ALU<br/>arithmetic and logic"]
        REG["Registers<br/>X0..X30, SP, PC"]
        CU --> ALU
        REG <--> ALU
    end
    MEM["Memory<br/>program + data"] <-->|"address, data"| CPU
    IO["Input / output<br/>keyboard, screen, network"] <--> CPU
```

| Part | Job |
| --- | --- |
| **Registers** | Tiny, very fast storage inside the CPU. Arm A64 has 31 general-purpose 64-bit registers, `X0` to `X30` |
| **ALU** (arithmetic logic unit) | Adds, subtracts, compares, does AND/OR/shift |
| **Control unit** | Reads each instruction and tells the other parts what to do |
| **Program counter (PC)** | Holds the memory address of the next instruction |
| **Memory** | A long array of bytes, each with a numbered address |

Because instructions and data share the path to memory, the processor often waits for memory. This is called the **von Neumann bottleneck**, and caches ([Caches and Coherence](#caches-coherence)) exist mainly to ease it.

**Sources:** [Wikipedia: Von Neumann architecture](https://en.wikipedia.org/wiki/Von_Neumann_architecture)

## What an Instruction Looks Like

An instruction is a number, usually 4 bytes on Arm, that encodes one small operation. Written in assembly language it is readable:

```text
// illustrative Arm A64 assembly for:  total = price * qty + tax
LDR  X1, [X0]        // load price from memory address in X0 into X1
LDR  X2, [X0, #8]    // load qty from the next 8 bytes
MUL  X3, X1, X2      // X3 = X1 * X2
LDR  X4, [X0, #16]   // load tax
ADD  X5, X3, X4      // X5 = X3 + X4
STR  X5, [X0, #24]   // store total back to memory
```

Instructions fall into a few groups:

| Group | Examples | What it does |
| --- | --- | --- |
| Arithmetic / logic | `ADD`, `SUB`, `MUL`, `AND`, `LSL` | Compute on registers |
| Memory | `LDR` (load), `STR` (store) | Move data between memory and registers |
| Control flow | `B` (branch), `B.EQ`, `CBZ`, `BL` (call), `RET` | Change which instruction runs next |
| Compare | `CMP` | Set condition flags used by conditional branches |

Arm is a **load/store** architecture: arithmetic only works on registers, so data must be loaded first and stored afterwards. That is why the example above has more `LDR`s than calculations.

**Sources:** [Wikipedia: Instruction set architecture](https://en.wikipedia.org/wiki/Instruction_set_architecture)

## The Fetch-Decode-Execute Cycle

The processor runs this loop forever:

```mermaid
flowchart TD
    F["1. Fetch<br/>read instruction at PC from memory"] --> D["2. Decode<br/>what operation? which registers?"]
    D --> E["3. Execute<br/>ALU does the work"]
    E --> M["4. Memory<br/>load or store if needed"]
    M --> W["5. Write back<br/>put result in a register"]
    W --> P["6. Update PC<br/>next instruction, or branch target"]
    P --> F
```

Following `ADD X5, X3, X4` through the loop:

| Step | What happens |
| --- | --- |
| Fetch | Read the 4 bytes at the address in PC |
| Decode | It is an `ADD`; sources `X3` and `X4`; destination `X5` |
| Execute | ALU computes `X3 + X4` |
| Memory | Nothing to do: `ADD` does not touch memory |
| Write back | Result goes into `X5` |
| Update PC | PC = PC + 4 |

A simple processor does all six steps for one instruction before starting the next. [Pipelining](#pipelining) overlaps them.

## RISC and CISC

| | RISC (reduced instruction set) | CISC (complex instruction set) |
| --- | --- | --- |
| Examples | Arm, RISC-V | x86 |
| Instruction size | Fixed (Arm A64: 4 bytes) | Variable (x86: 1 to 15 bytes) |
| Memory access | Only loads and stores | Many instructions can read memory directly |
| Decoding | Simple | Complex |
| Instructions per program | More | Fewer |

In practice modern x86 chips translate their complex instructions into simple RISC-like internal operations ("micro-ops"), so inside, big RISC and CISC cores look much alike.

## Measuring Performance

The time a program takes is:

```text
Execution time = Instruction count × CPI × Clock period
```

| Term | Meaning | Decided by |
| --- | --- | --- |
| Instruction count | How many instructions run | Program, compiler, ISA |
| **CPI** (cycles per instruction) | Average clock cycles per instruction | Microarchitecture: pipeline, caches, prediction |
| Clock period | Length of one cycle (1 / frequency) | Circuit design and power |

**IPC** (instructions per cycle) is 1 / CPI. Big modern cores aim for IPC above 1 by running several instructions per cycle ([ILP](#ilp)).

### Worked Example

A program runs 2 billion instructions on a 2 GHz processor (clock period 0.5 ns).

| Design | CPI | Time |
| --- | --- | --- |
| Simple, non-pipelined, 5 cycles per instruction | 5 | 2×10⁹ × 5 × 0.5 ns = **5.0 s** |
| Pipelined, ideal | 1 | 2×10⁹ × 1 × 0.5 ns = **1.0 s** |
| Pipelined with stalls (cache misses, branches) | 1.5 | **1.5 s** |
| Superscalar, 2 per cycle | 0.5 | **0.5 s** |

The rest of this wiki is mostly about lowering CPI.

## The Memory Hierarchy

Fast memory is small and expensive; big memory is slow. So computers use layers:

```mermaid
flowchart TD
    R["Registers<br/>~1 KB, under 1 ns"] --> L1["L1 cache<br/>32-64 KB per core, ~1 ns"]
    L1 --> L2["L2 cache<br/>0.5-2 MB, ~3-5 ns"]
    L2 --> L3["L3 / system cache<br/>several MB shared, ~10-20 ns"]
    L3 --> RAM["Main memory (DRAM)<br/>GBs, ~80-100 ns"]
    RAM --> SSD["Storage (SSD)<br/>TBs, ~100 µs"]
```

Sizes and times are typical orders of magnitude, not figures for a particular chip. The trick that makes this work is **locality**: programs tend to reuse recent data (temporal locality) and use data next to recent data (spatial locality). See [Caches and Coherence](#caches-coherence).

**Sources:** [Wikipedia: Memory hierarchy](https://en.wikipedia.org/wiki/Memory_hierarchy)

## Key Points

- A CPU has registers, an ALU and a control unit; memory holds both program and data.
- The processor loops: fetch, decode, execute, memory, write back, update PC.
- Time = instructions × CPI × clock period; most architecture tricks reduce CPI.