# Multicore

<details>
<summary>Relevant source files</summary>

The following references were used as context for generating this wiki page:

- [Wikipedia: Multi-core processor](https://en.wikipedia.org/wiki/Multi-core_processor)
- [Wikipedia: Amdahl's law](https://en.wikipedia.org/wiki/Amdahl%27s_law)
- [Wikipedia: Non-uniform memory access](https://en.wikipedia.org/wiki/Non-uniform_memory_access)
- [Wikipedia: Flynn's taxonomy](https://en.wikipedia.org/wiki/Flynn%27s_taxonomy)
- Book: Hennessy and Patterson, *Computer Architecture: A Quantitative Approach*, chapter 5

</details>

A multicore processor puts several complete cores on one chip. Each core runs its own stream of instructions, so a program that splits its work into threads can finish sooner. Multicore became the main way to get more performance once clock speeds stopped rising ([Overview](#overview)). This page explains how the cores are connected, how much speedup to expect, and what slows multicore programs down.

> Numbers and chip layouts on this page are illustrative.

## Purpose and Scope

This page covers why chips went multicore, Flynn's classification, shared-memory organisation (private and shared caches, interconnect), heterogeneous big.LITTLE designs, Amdahl's and Gustafson's laws, NUMA, and the costs of synchronisation. Keeping the cores' caches consistent is on [Caches and Coherence](#caches-coherence); the order in which they see each other's writes is on [Memory and Ordering](#memory-ordering).

## The Office Analogy

| Office | Multicore chip |
| --- | --- |
| One worker, one desk | One core with its L1 cache |
| Hiring more workers | Adding cores |
| A shared filing cabinet | Shared L3 cache and main memory |
| Workers must agree who edits which file | Coherence and locks |
| A task only one person can do (signing the final report) | The **serial part** of a program |
| More workers than the hallway can handle | Memory bandwidth limits |

Ten workers can finish a big pile of independent forms ten times faster. They can't make one person's signature faster, and they slow down if they all queue at the same cabinet.

## Why Multicore?

```mermaid
flowchart TD
    A["Need more performance"] --> B{"Raise clock?"}
    B -->|"Power grows steeply with frequency and voltage"| X["Too hot"]
    A --> C{"Wider single core?"}
    C -->|"ILP wall: little extra gain"| Y["Diminishing returns"]
    A --> D["Put 2, 4, 8... cores on the chip<br/>each at a sensible clock"]
    D --> E["More total throughput<br/>if software uses threads"]
```

Two cores at moderate frequency usually give more total work per watt than one core pushed to a very high frequency, but only if the software runs in parallel.

## Flynn's Taxonomy

Flynn's 1966 classification counts instruction streams and data streams:

| | Single data | Multiple data |
| --- | --- | --- |
| **Single instruction** | **SISD**: a classic single core | **SIMD**: vector units, GPUs ([SIMD and GPUs](#simd-gpu)) |
| **Multiple instruction** | MISD: rare | **MIMD**: multicore, clusters (this page) |

**Sources:** [Wikipedia: Flynn's taxonomy](https://en.wikipedia.org/wiki/Flynn%27s_taxonomy)

## Organisation of a Multicore Chip

```mermaid
flowchart TB
    subgraph Chip["Multicore chip (illustrative)"]
        direction TB
        subgraph C0["Core 0"]
            P0["Pipeline"] --- L10["L1 I + L1 D"]
            L10 --- L20["Private L2"]
        end
        subgraph C1["Core 1"]
            P1["Pipeline"] --- L11["L1 I + L1 D"]
            L11 --- L21["Private L2"]
        end
        subgraph C2["Core 2"]
            P2["Pipeline"] --- L12["L1 I + L1 D"]
            L12 --- L22["Private L2"]
        end
        L20 --- IC["Interconnect<br/>(coherent: ring, mesh or crossbar)"]
        L21 --- IC
        L22 --- IC
        IC --- L3["Shared L3 / system level cache"]
    end
    L3 --- MC["Memory controller"] --- DRAM["DRAM"]
```

| Part | Shared or private | Role |
| --- | --- | --- |
| Pipeline, registers | Private | Runs one thread (or more, see [Multithreading](#multithreading)) |
| L1, often L2 | Private | Fast, close data |
| L3 / system level cache | Shared | Catches data used by several cores; reduces DRAM traffic |
| Interconnect | Shared | Carries requests and coherence messages between caches |
| Memory controller, DRAM | Shared | Total bandwidth is split among all cores |

All cores see one shared address space: this is **shared-memory multiprocessing** (SMP). Threads communicate simply by reading and writing memory, and the hardware keeps caches coherent.

**Sources:** [Wikipedia: Multi-core processor](https://en.wikipedia.org/wiki/Multi-core_processor)

## Heterogeneous Cores: big.LITTLE

Phones and laptops often mix core types on one chip. Arm calls this **big.LITTLE**, and later **DynamIQ**, which allows mixed core types in one cluster.

| Core type | Design | Used for |
| --- | --- | --- |
| Big (performance) | Wide, out-of-order, large caches, high clock | Bursts: launching an app, a game frame |
| Little (efficiency) | Narrow, often in-order, small | Background work, email sync, music |

```mermaid
flowchart LR
    T["Thread becomes runnable"] --> S{"Scheduler: how demanding?"}
    S -->|"Light / background"| L["Little core<br/>low power"]
    S -->|"Heavy / interactive"| B["Big core<br/>high performance"]
    L -->|"load grows"| B
    B -->|"load drops"| L
```

All cores implement the same architecture, so the operating system can move a thread between them at any time.

## How Much Faster? Amdahl's Law

If a fraction **p** of a program can run in parallel on **N** cores and the rest (1 − p) is serial:

```text
Speedup(N) = 1 / ((1 − p) + p / N)
```

| Parallel fraction p | 2 cores | 4 cores | 8 cores | 64 cores | Limit (∞ cores) |
| --- | --- | --- | --- | --- | --- |
| 50% | 1.33 | 1.60 | 1.78 | 1.97 | 2 |
| 90% | 1.82 | 3.08 | 4.71 | 8.77 | 10 |
| 95% | 1.90 | 3.48 | 5.93 | 15.4 | 20 |
| 99% | 1.98 | 3.88 | 7.48 | 39.3 | 100 |

The serial part sets a hard ceiling: with 10% serial work, no number of cores can give more than 10×.

```mermaid
flowchart LR
    subgraph One["1 core: 100 units"]
        S1["serial 10"] --> P1["parallel 90"]
    end
    subgraph Four["4 cores: 32.5 units (3.08x)"]
        S2["serial 10"] --> P2["parallel 90 / 4 = 22.5"]
    end
```

**Gustafson's law** gives the more hopeful view: with more cores people usually solve *bigger* problems, and the parallel part grows while the serial part stays the same, so scaled speedup ≈ (1 − p) + p × N.

**Sources:** [Wikipedia: Amdahl's law](https://en.wikipedia.org/wiki/Amdahl%27s_law)

## What Slows Multicore Programs Down

| Cost | Cause | See |
| --- | --- | --- |
| Serial sections | Code only one thread can run | Amdahl's law above |
| Locks and contention | Threads waiting for each other | Below |
| Coherence traffic | Shared data bouncing between caches; false sharing | [Caches and Coherence](#caches-coherence) |
| Memory bandwidth | All cores share the memory controllers | |
| Load imbalance | One thread gets more work and the others wait for it | |
| Barriers and atomics | Ordering instructions stall the pipeline | [Memory and Ordering](#memory-ordering) |

### Locks

A **lock** (mutex) lets only one thread at a time into a critical section. It is built on atomic read-modify-write instructions such as Arm `CAS` or `LDXR`/`STXR`.

```mermaid
sequenceDiagram
    participant T0 as Thread 0
    participant L as Lock
    participant T1 as Thread 1
    T0->>L: acquire (atomic CAS 0 -> 1)
    L-->>T0: success
    T1->>L: acquire
    L-->>T1: busy, wait / spin
    T0->>T0: critical section
    T0->>L: release (store-release 0)
    T1->>L: acquire again
    L-->>T1: success
```

A heavily used lock turns parallel code back into serial code, which shows up as a lower effective *p* in Amdahl's law.

## NUMA: When Memory Is Not Equally Far

Large servers have several chips (sockets), each with its own memory. A core reaches its own socket's memory faster than another socket's.

```mermaid
flowchart LR
    subgraph S0["Socket 0"]
        CA["Cores 0-31"] --- MA["Local memory A"]
    end
    subgraph S1["Socket 1"]
        CB["Cores 32-63"] --- MB["Local memory B"]
    end
    CA <-->|"slower remote access"| MB
    CB <-->|"slower remote access"| MA
```

This is **non-uniform memory access (NUMA)**. Operating systems try to place a thread's memory on the same socket as the thread ("first touch" allocation).

**Sources:** [Wikipedia: Non-uniform memory access](https://en.wikipedia.org/wiki/Non-uniform_memory_access)

## Key Points

- Multicore puts several full cores on a chip with private L1/L2, a shared L3 and a coherent interconnect.
- Amdahl's law: the serial fraction limits speedup, however many cores you add.
- Locks, coherence traffic, shared bandwidth and NUMA distance are the main costs; big.LITTLE trades performance for efficiency per thread.