# Multithreading in Hardware

<details>
<summary>Relevant source files</summary>

The following references were used as context for generating this wiki page:

- [Wikipedia: Multithreading (computer architecture)](https://en.wikipedia.org/wiki/Multithreading_%28computer_architecture%29)
- [Wikipedia: Simultaneous multithreading](https://en.wikipedia.org/wiki/Simultaneous_multithreading)
- Book: Hennessy and Patterson, *Computer Architecture: A Quantitative Approach*, chapter 3

</details>

A single thread often leaves a core idle: it waits for a cache miss, recovers from a mispredicted branch, or simply has no independent instruction ready. **Hardware multithreading** lets one core hold the state of several threads at once and switch to another thread whenever the current one stalls, so the expensive execution units stay busy. To the operating system each hardware thread looks like a separate CPU.

> Timelines on this page are illustrative.

## Purpose and Scope

This page covers what a hardware thread is, the difference between software and hardware threads, three styles of multithreading (coarse-grained, fine-grained, simultaneous), what is shared and duplicated, the benefits and costs, and how GPUs take the same idea much further. Multiple separate cores are on [Multicore](#multicore).

## The Chef with Several Dishes Analogy

A chef is cooking one dish and puts it in the oven for 20 minutes. Rather than stand and wait, the chef starts chopping for a second dish, and comes back to the first when the timer rings.

| Kitchen | Core |
| --- | --- |
| The chef | The execution units of one core |
| Each dish with its own recipe and progress | A hardware thread: its own registers and PC |
| Waiting for the oven | Waiting for a cache miss |
| Switching to another dish | Switching to another thread |
| One stove shared by all dishes | Caches and execution units shared by all threads |

The chef doesn't get faster at any single dish, but finishes more dishes per hour.

## Software Threads and Hardware Threads

| | Software thread | Hardware thread |
| --- | --- | --- |
| Created by | The program (`pthread_create`, `std::thread`) | Built into the core |
| Switched by | The operating system, thousands of cycles | The hardware, 0 to a few cycles |
| How many | As many as you like | Fixed: often 1, 2 or 4 per CPU core; many dozens per GPU core |

The operating system schedules software threads onto hardware threads. A 4-core chip with 2 hardware threads per core shows 8 "logical CPUs".

```mermaid
flowchart TD
    subgraph SW["Software threads (many)"]
        T1["T1"]
        T2["T2"]
        T3["T3"]
        T4["T4"]
        T5["T5"]
    end
    OS["Operating system scheduler"]
    T1 --> OS
    T2 --> OS
    T3 --> OS
    T4 --> OS
    T5 --> OS
    subgraph Core0["Core 0"]
        H0["HW thread 0"]
        H1["HW thread 1"]
    end
    subgraph Core1["Core 1"]
        H2["HW thread 0"]
        H3["HW thread 1"]
    end
    OS --> H0
    OS --> H1
    OS --> H2
    OS --> H3
```

## What Is Duplicated and What Is Shared

| Duplicated per hardware thread | Shared between threads on a core |
| --- | --- |
| Program counter | Execution units (ALUs, load/store, FP/SIMD) |
| Architectural registers (or their rename table) | Caches (L1, L2) and TLBs |
| Some status / system registers | Branch predictor tables |
| | Issue queues, reorder buffer, physical registers (split or shared) |

Duplicating a register file and a PC is cheap compared with a whole core, so a second hardware thread costs only a small amount of chip area.

## Three Styles

Each diagram row is one cycle; each box is an issue slot of a 4-wide core. A, B, C, D are four threads.

```mermaid
flowchart LR
    subgraph ST["Single thread"]
        direction TB
        s1["A A . ."]
        s2[". . . .  (cache miss)"]
        s3[". . . .  (cache miss)"]
        s4["A . . ."]
    end
    subgraph CG["Coarse-grained"]
        direction TB
        c1["A A . ."]
        c2["B B B .  (switched on miss)"]
        c3["B B . ."]
        c4["B . . ."]
    end
    subgraph FG["Fine-grained"]
        direction TB
        f1["A A . ."]
        f2["B B B ."]
        f3["C . . ."]
        f4["D D . ."]
    end
    subgraph SMT["Simultaneous (SMT)"]
        direction TB
        m1["A A B C"]
        m2["B B B D"]
        m3["C D D A"]
        m4["A B C D"]
    end
```

| Style | When it switches | Fills | Example uses |
| --- | --- | --- | --- |
| **Coarse-grained** (switch on event) | Only on a long stall such as a cache miss | Long stalls (vertical waste) | Some older and embedded designs |
| **Fine-grained** (interleaved) | Every cycle, round-robin between ready threads | Short and long stalls | Barrel processors, some DSPs, GPU warp schedulers |
| **Simultaneous multithreading (SMT)** | No switching: instructions from several threads issue in the *same* cycle | Stalls *and* unused slots within a cycle (horizontal waste) | Intel Hyper-Threading, AMD Zen, some Arm Neoverse and Cortex cores, IBM POWER |

**Vertical waste** is a whole cycle with nothing issued; **horizontal waste** is a cycle where only some issue slots are used. Only SMT removes both.

**Sources:** [Wikipedia: Multithreading (computer architecture)](https://en.wikipedia.org/wiki/Multithreading_%28computer_architecture%29), [Wikipedia: Simultaneous multithreading](https://en.wikipedia.org/wiki/Simultaneous_multithreading)

## SMT Inside an Out-of-Order Core

SMT fits naturally into the out-of-order engine from [ILP](#ilp): renaming turns each thread's registers into physical registers, so instructions from different threads can sit in the same issue queue without confusion.

```mermaid
flowchart LR
    FA["Fetch thread A"] --> R["Rename<br/>(one table per thread)"]
    FB["Fetch thread B"] --> R
    R --> IQ["Shared issue queue"]
    IQ --> EX["Shared execution units"]
    EX --> ROBA["Commit thread A in order"]
    EX --> ROBB["Commit thread B in order"]
```

Each thread still commits its own instructions in its own program order; the threads simply share the machinery in between.

## Benefits and Costs

| Benefit | Cost |
| --- | --- |
| Higher total throughput when threads stall a lot (memory-bound, branchy code) | Each thread runs somewhat slower than if it had the core alone |
| Cheap: a fraction of a core's area | Threads compete for caches, predictor entries and queues |
| Hides memory latency without software changes | Little gain for code that already uses the core fully (dense maths) |
| | Shared structures can leak information between threads (side channels), so some systems disable SMT for security |

Typical gains for two threads per core range from nothing to a few tens of percent, depending on the workload. It is never 2×, because the two threads share one set of execution units.

## The GPU Extreme

A GPU applies fine-grained multithreading at huge scale: each GPU core keeps dozens of thread groups (**warps** or **wavefronts**) resident at once and picks a ready one every cycle. When one group waits hundreds of cycles for memory, others run. This is how GPUs hide memory latency without large caches or out-of-order logic. See [SIMD and GPUs](#simd-gpu).

```mermaid
sequenceDiagram
    participant S as Warp scheduler
    participant W1 as Warp 1
    participant W2 as Warp 2
    participant W3 as Warp 3
    S->>W1: issue (load from memory)
    Note over W1: waiting ~hundreds of cycles
    S->>W2: issue
    S->>W3: issue
    S->>W2: issue
    S->>W3: issue
    Note over W1: data arrives
    S->>W1: issue (uses loaded data)
```

## Key Points

- A hardware thread is a PC plus a register set; several share one core's execution units and caches.
- Coarse-grained switches on long stalls, fine-grained every cycle, SMT issues from several threads in the same cycle.
- Multithreading raises throughput, not single-thread speed; GPUs push the same idea to dozens of threads per core.