# Glossary and Summary

<details>
<summary>Relevant source files</summary>

The following references were used as context for generating this wiki page:

- [Wikipedia: Computer architecture](https://en.wikipedia.org/wiki/Computer_architecture)
- [Wikipedia: Memory hierarchy](https://en.wikipedia.org/wiki/Memory_hierarchy)
- Book: Patterson and Hennessy, *Computer Organization and Design* (Arm edition)
- Book: Hennessy and Patterson, *Computer Architecture: A Quantitative Approach*

</details>

This page puts the whole wiki on one diagram, lists every term used on earlier pages with a one-line meaning, and suggests some self-check questions.

## Purpose and Scope

This page covers a one-picture summary, the glossary, self-check questions with answers, and further reading. It introduces no new ideas.

## The Whole Wiki in One Picture

```mermaid
flowchart TD
    GOAL["Run programs faster<br/>Time = Instructions × CPI × Clock period"] --> ONE["One instruction stream"]
    GOAL --> MANY["Many instruction streams"]
    GOAL --> DATA["Many data items"]
    GOAL --> MEMW["Waiting for memory"]

    ONE --> PIPE["Pipelining<br/>overlap stages"]
    PIPE --> HAZ["Hazards: structural, data, control"]
    HAZ --> FWD["Forwarding, stalls, reordering"]
    HAZ --> BP["Branch prediction, BTB, CSEL"]
    ONE --> ILP["ILP: superscalar, out-of-order,<br/>renaming, ROB, speculation"]

    MANY --> MC["Multicore<br/>Amdahl's law"]
    MANY --> MT["Hardware multithreading<br/>coarse, fine, SMT"]
    MC --> ORD["Memory ordering<br/>barriers, acquire/release"]
    MC --> COH["Cache coherence<br/>MESI, false sharing"]

    DATA --> SIMD["SIMD: Neon, SVE"]
    DATA --> GPU["GPU: SIMT, warps"]

    MEMW --> CACHE["Caches: lines, sets, AMAT"]
    CACHE --> COH
    MT --> GPU
```

| If your program is slow because... | Look at |
| --- | --- |
| It waits for memory a lot | [Caches and Coherence](#caches-coherence), [Multithreading](#multithreading) |
| It has many unpredictable branches | [Branches and Remedies](#branches) |
| It is one long chain of dependent operations | [ILP](#ilp) |
| It runs on one core while others are idle | [Multicore](#multicore) |
| Threads slow each other down | [Caches and Coherence](#caches-coherence) (false sharing), [Multicore](#multicore) (locks) |
| It does the same arithmetic on big arrays | [SIMD and GPUs](#simd-gpu) |
| Multithreaded code works on x86 but fails on Arm | [Memory and Ordering](#memory-ordering) |

## Glossary

| Term | Meaning | Page |
| --- | --- | --- |
| Acquire / release | One-way ordering on a load (acquire) or store (release); Arm `LDAR` / `STLR` | [Memory and Ordering](#memory-ordering) |
| ALU | Arithmetic logic unit: adds, compares, does logic | [Fundamentals](#fundamentals) |
| Amdahl's law | Speedup is limited by the serial fraction: 1 / ((1−p) + p/N) | [Multicore](#multicore) |
| AMAT | Average memory access time = hit time + miss rate × miss penalty | [Caches and Coherence](#caches-coherence) |
| Associativity | How many places (ways) in a cache a line may go | [Caches and Coherence](#caches-coherence) |
| Barrier (fence) | Instruction that orders memory accesses; Arm `DMB`, `DSB`, `ISB` | [Memory and Ordering](#memory-ordering) |
| big.LITTLE | Mixing fast and efficient cores on one chip | [Multicore](#multicore) |
| Branch predictor | Hardware that guesses branch direction | [Branches and Remedies](#branches) |
| BTB | Branch target buffer: remembers where branches go | [Branches and Remedies](#branches) |
| Cache line | The unit a cache stores and moves, typically 64 bytes | [Caches and Coherence](#caches-coherence) |
| Coherence | Keeping all copies of one address consistent | [Caches and Coherence](#caches-coherence) |
| Commit (retire) | Making an instruction's result permanent, in program order | [ILP](#ilp) |
| CPI / IPC | Cycles per instruction / instructions per cycle | [Fundamentals](#fundamentals) |
| Critical path | Longest chain of dependent instructions | [ILP](#ilp) |
| Divergence | Threads in one GPU warp taking different branch paths | [SIMD and GPUs](#simd-gpu) |
| False sharing | Different variables in one cache line causing coherence traffic | [Caches and Coherence](#caches-coherence) |
| Forwarding (bypassing) | Sending a result straight to a waiting instruction | [Pipelining](#pipelining) |
| Hardware thread | A PC plus registers sharing one core's execution units | [Multithreading](#multithreading) |
| Hazard | Something that stops the next pipeline step: structural, data, control | [Pipelining](#pipelining) |
| ILP | Instruction-level parallelism: independent instructions run together | [ILP](#ilp) |
| ISA | Instruction set architecture: the contract between software and hardware | [Overview](#overview) |
| Lane | One element slot in a SIMD register or GPU warp | [SIMD and GPUs](#simd-gpu) |
| Latency / throughput | Time for one job / jobs per unit time | [Pipelining](#pipelining) |
| Locality | Temporal: reuse soon; spatial: use nearby data | [Caches and Coherence](#caches-coherence) |
| MESI | Cache line states: Modified, Exclusive, Shared, Invalid | [Caches and Coherence](#caches-coherence) |
| Microarchitecture | How a particular chip implements the ISA | [Overview](#overview) |
| Misprediction penalty | Cycles lost when a branch guess is wrong | [Branches and Remedies](#branches) |
| NUMA | Memory access time depends on which socket owns the memory | [Multicore](#multicore) |
| Neon | Arm's fixed 128-bit SIMD extension | [SIMD and GPUs](#simd-gpu) |
| Occupancy | How many warps are resident on a GPU compute unit | [SIMD and GPUs](#simd-gpu) |
| Out-of-order execution | Running instructions when their inputs are ready, not in program order | [ILP](#ilp) |
| Pipeline | Splitting instruction processing into overlapping stages | [Pipelining](#pipelining) |
| Predicate | A per-lane on/off mask (SVE `P` registers) | [SIMD and GPUs](#simd-gpu) |
| Program counter (PC) | Address of the next instruction | [Fundamentals](#fundamentals) |
| RAW / WAR / WAW | Read-after-write (true), write-after-read and write-after-write (false) dependences | [Pipelining](#pipelining) |
| Register renaming | Mapping architectural registers to many physical ones to remove false dependences | [ILP](#ilp) |
| ROB | Reorder buffer: tracks program order for in-order commit | [ILP](#ilp) |
| Sequential consistency | All cores see one interleaving that respects each core's program order | [Memory and Ordering](#memory-ordering) |
| SIMD | Single instruction, multiple data | [SIMD and GPUs](#simd-gpu) |
| SIMT | Single instruction, multiple threads: the GPU model | [SIMD and GPUs](#simd-gpu) |
| SMT | Simultaneous multithreading: several threads issue in one cycle | [Multithreading](#multithreading) |
| Speculation | Running instructions before knowing they are needed | [ILP](#ilp) |
| Stall (bubble) | A cycle where a pipeline stage does no useful work | [Pipelining](#pipelining) |
| Store buffer | Queue holding stores before they reach the cache | [Memory and Ordering](#memory-ordering) |
| Superscalar | Issuing more than one instruction per cycle | [ILP](#ilp) |
| SVE | Arm's Scalable Vector Extension, 128 to 2048 bits | [SIMD and GPUs](#simd-gpu) |
| TSO | Total store order: x86's memory model | [Memory and Ordering](#memory-ordering) |
| VLIW | Very long instruction word: compiler packs parallel operations | [ILP](#ilp) |
| Von Neumann bottleneck | Program and data share one path to memory | [Fundamentals](#fundamentals) |
| Warp / wavefront | Group of GPU threads running in lockstep (32 or 64) | [SIMD and GPUs](#simd-gpu) |
| Write-back / write-through | Update memory on eviction / on every store | [Caches and Coherence](#caches-coherence) |

## Self-Check Questions

1. A program runs 1 billion instructions at CPI 2 on a 1 GHz clock. How long does it take? *(2 s.)* ([Fundamentals](#fundamentals))
2. Why does pipelining not make a single instruction finish sooner? *(It improves throughput, not latency.)* ([Pipelining](#pipelining))
3. `LDR X1,[X0]` is followed immediately by `ADD X2,X1,X3`. Why does forwarding not remove the stall completely? *(The load's data only arrives after MEM.)* ([Pipelining](#pipelining))
4. Why does a 2-bit counter mispredict a 10-iteration loop only once per run, when a 1-bit predictor misses twice? ([Branches and Remedies](#branches))
5. 25% of instructions are branches, 4% are mispredicted, the penalty is 20 cycles, base CPI is 1. What is the CPI? *(1 + 0.25 × 0.04 × 20 = 1.2.)* ([Branches and Remedies](#branches))
6. Which of RAW, WAR and WAW does register renaming remove? *(WAR and WAW.)* ([ILP](#ilp))
7. In the message-passing example, what must the producer and consumer use on Arm? *(Store-release and load-acquire, or barriers.)* ([Memory and Ordering](#memory-ordering))
8. A 64 KB, 8-way cache with 64-byte lines has how many sets? *(64 KB / 64 B = 1024 lines; / 8 = 128 sets.)* ([Caches and Coherence](#caches-coherence))
9. Two threads increment two different counters in one struct and run slower with two cores than with one. Why? *(False sharing.)* ([Caches and Coherence](#caches-coherence))
10. With 80% parallel code, what is the speedup on 8 cores, and the limit? *(1 / (0.2 + 0.1) = 3.33; limit 5.)* ([Multicore](#multicore))
11. Why does SMT never double performance? *(Both threads share the same execution units and caches.)* ([Multithreading](#multithreading))
12. Why is `if (threadIdx.x % 2)` slow on a GPU but `if (blockIdx.x % 2)` not? *(The first splits every warp; the second sends whole warps one way.)* ([SIMD and GPUs](#simd-gpu))

## Further Reading

| Resource | Good for |
| --- | --- |
| Patterson and Hennessy, *Computer Organization and Design* (Arm edition) | A full beginner course: the material of pages 2-8 in depth |
| Hennessy and Patterson, *Computer Architecture: A Quantitative Approach* | The next step: ILP, memory hierarchy, multicore, GPUs |
| Arm *Learn the architecture* guides (developer.arm.com): Memory Systems, Ordering, and Barriers (102336); Introducing Neon (102474); Introduction to SVE (102476) | Arm-specific detail for pages 6, 7 and 10 |
| *Arm Architecture Reference Manual for A-profile* (DDI 0487) | The definitive rules, for reference rather than reading |
| The Wikipedia articles linked from each page | Quick refreshers and further links |

For how compilers make use of all this, see the [Instruction Scheduling wiki](../sched-wiki/sched-wiki.html#overview) and the [LLVM IR wiki](../ir-wiki/ir-wiki.html#overview).