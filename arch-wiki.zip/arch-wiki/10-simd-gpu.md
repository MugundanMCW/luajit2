# SIMD and GPUs

<details>
<summary>Relevant source files</summary>

The following references were used as context for generating this wiki page:

- [Wikipedia: Single instruction, multiple data](https://en.wikipedia.org/wiki/Single_instruction,_multiple_data)
- [Wikipedia: Single instruction, multiple threads](https://en.wikipedia.org/wiki/Single_instruction,_multiple_threads)
- [Wikipedia: Graphics processing unit](https://en.wikipedia.org/wiki/Graphics_processing_unit)
- [Wikipedia: Flynn's taxonomy](https://en.wikipedia.org/wiki/Flynn%27s_taxonomy)
- Arm: *Learn the architecture: Introducing Neon* (document 102474) and *Introduction to SVE* (document 102476)
- Book: Hennessy and Patterson, *Computer Architecture: A Quantitative Approach*, chapter 4

</details>

Many programs do the same thing to lots of data: brighten every pixel, add two long arrays, multiply matrices for a neural network. **SIMD** (single instruction, multiple data) lets one instruction work on several data items at once. A **GPU** takes the idea much further, with thousands of simple lanes and many threads to hide memory delays. This page explains both, and when each is the right tool.

> Code, sizes and diagrams on this page are illustrative.

## Purpose and Scope

This page covers SIMD registers and lanes, Arm Neon and SVE, vectorising a loop, what stops vectorisation, the GPU execution model (SIMT, warps, divergence, occupancy), CPU versus GPU design, and the advantages and limits of GPUs. Multithreading in general is on [Multithreading](#multithreading).

## The Stamping Analogy

| One stamp | A stamp with 4 heads |
| --- | --- |
| Stamp one envelope per press | Stamp four envelopes per press |
| 100 envelopes = 100 presses | 100 envelopes = 25 presses |

SIMD is the 4-headed stamp. It only helps when the envelopes are lined up and all need the same stamp.

## SIMD on a CPU

A SIMD register holds several values side by side, called **lanes**. One instruction operates on every lane.

```mermaid
flowchart LR
    subgraph A["V1 (4 x 32-bit)"]
        a0["1"] --- a1["2"] --- a2["3"] --- a3["4"]
    end
    subgraph B["V2"]
        b0["10"] --- b1["20"] --- b2["30"] --- b3["40"]
    end
    subgraph C["V0 = V1 + V2  (one ADD)"]
        c0["11"] --- c1["22"] --- c2["33"] --- c3["44"]
    end
    A --> C
    B --> C
```

| Register width | Lanes of 8-bit | 16-bit | 32-bit | 64-bit |
| --- | --- | --- | --- | --- |
| 128 bits (Arm Neon) | 16 | 8 | 4 | 2 |

### Arm Neon and SVE

| | Neon (Advanced SIMD) | SVE / SVE2 (Scalable Vector Extension) |
| --- | --- | --- |
| Register width | Fixed 128 bits (`V0`-`V31`) | Chosen by the chip: 128 to 2048 bits, a multiple of 128 (`Z0`-`Z31`) |
| Same binary on wider hardware goes faster? | No | Yes: code is written "vector-length agnostic" |
| Loop tail (leftover elements) | Separate scalar loop | Handled by **predicate** registers (`P0`-`P15`) that switch lanes off |

```text
// illustrative:  for (i = 0; i < n; i++) c[i] = a[i] + b[i];   (float)

// Neon, 4 floats per step (tail loop not shown)
loop:
  LD1  {V0.4S}, [X0], #16     // load 4 floats from a
  LD1  {V1.4S}, [X1], #16     // load 4 floats from b
  FADD V2.4S, V0.4S, V1.4S    // 4 adds at once
  ST1  {V2.4S}, [X2], #16     // store 4 floats to c
  SUBS X3, X3, #4
  B.GT loop

// SVE, any vector length, tail handled by predicate
  MOV     X4, #0
  WHILELT P0.S, X4, X3        // lanes active while i < n
loop:
  LD1W    Z0.S, P0/Z, [X0, X4, LSL #2]
  LD1W    Z1.S, P0/Z, [X1, X4, LSL #2]
  FADD    Z2.S, Z0.S, Z1.S
  ST1W    Z2.S, P0, [X2, X4, LSL #2]
  INCW    X4                  // i += number of 32-bit lanes
  WHILELT P0.S, X4, X3
  B.FIRST loop
```

```mermaid
flowchart LR
    subgraph Pred["Last SVE step, n = 10, 8 lanes, i = 8"]
        p0["lane 0: i=8 ✔"] --- p1["lane 1: i=9 ✔"] --- p2["lane 2: off"] --- p3["... off"]
    end
```

**Sources:** [Wikipedia: Single instruction, multiple data](https://en.wikipedia.org/wiki/Single_instruction,_multiple_data)

### Who Writes SIMD Code?

| Way | Effort | Notes |
| --- | --- | --- |
| **Auto-vectorisation** by the compiler | None | Works for simple loops over arrays |
| **Intrinsics** (`vaddq_f32` in `arm_neon.h`) | Medium | Explicit control from C |
| Assembly | High | Rarely needed |
| Libraries (BLAS, image, ML) | None | Already optimised |

### What Stops Vectorisation

| Problem | Example | Why |
| --- | --- | --- |
| Loop-carried dependence | `a[i] = a[i-1] + 1` | Each element needs the previous one |
| Possible aliasing | `c` might overlap `a` | Compiler can't prove lanes are independent (`restrict` helps) |
| Irregular access | `a[idx[i]]` | Needs gather instructions; slower |
| Branches inside the loop | `if (a[i] > 0) ...` | Needs masks/predicates or `select` |
| Function calls | `f(a[i])` | Unless `f` can be inlined |

## GPUs: SIMD at Enormous Scale

A CPU core is built to run **one thread as fast as possible**: big caches, branch prediction, out-of-order execution. A GPU is built to run **huge numbers of simple threads** for maximum total throughput.

```mermaid
flowchart LR
    subgraph CPU["CPU: few powerful cores"]
        direction TB
        K1["Big core<br/>OoO, predictor"]
        K2["Big core"]
        K3["Big core"]
        K4["Big core"]
        BC["Large caches"]
    end
    subgraph GPU["GPU: many simple lanes"]
        direction TB
        S1["SM / compute unit<br/>32-64 lanes"]
        S2["SM"]
        S3["SM"]
        S4["... dozens more"]
        SC["Smaller caches,<br/>very high memory bandwidth"]
    end
```

| | CPU | GPU |
| --- | --- | --- |
| Goal | Low latency for one thread | High throughput for many |
| Cores | A few to a few dozen big ones | Dozens of compute units, thousands of lanes |
| Hiding memory delay | Large caches, out-of-order execution | Switching between many resident threads |
| Control logic per lane | Lots | Little: one instruction drives many lanes |
| Memory | Lower bandwidth, low latency | Very high bandwidth |
| Good at | Branchy, serial, irregular code | Regular, data-parallel code |

### SIMT: Threads That Move in Lockstep

You program a GPU as if each data item had its own thread (CUDA, OpenCL, Vulkan compute):

```c
// illustrative CUDA-style kernel: each thread handles one element
__global__ void add(float *a, float *b, float *c, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) c[i] = a[i] + b[i];
}
// launched with about n threads
```

The hardware groups threads into **warps** (NVIDIA, 32 threads) or **wavefronts** (AMD, 32 or 64). All threads in a warp run the same instruction at the same time on different data. This is called **SIMT** (single instruction, multiple threads): SIMD hardware presented as threads.

```mermaid
flowchart TD
    G["Grid: the whole job"] --> B1["Block 0"]
    G --> B2["Block 1"]
    G --> B3["Block ..."]
    B1 --> W1["Warp 0: threads 0-31"]
    B1 --> W2["Warp 1: threads 32-63"]
    W1 --> L["32 lanes run one instruction together"]
```

**Sources:** [Wikipedia: Single instruction, multiple threads](https://en.wikipedia.org/wiki/Single_instruction,_multiple_threads)

### Branch Divergence

If threads in one warp take different sides of an `if`, the warp runs **both** sides, switching lanes off as needed:

```c
if (threadIdx.x % 2 == 0)  x = A();   // even lanes
else                       x = B();   // odd lanes
```

```mermaid
flowchart LR
    S["Warp reaches if"] --> P1["Run A()<br/>even lanes on, odd off"]
    P1 --> P2["Run B()<br/>odd lanes on, even off"]
    P2 --> J["Lanes rejoin"]
```

Half the lanes sit idle during each side, so a divergent branch can halve throughput. Branches where a whole warp goes the same way cost almost nothing.

### Hiding Latency with Occupancy

Each compute unit keeps many warps resident and switches between them every cycle ([Multithreading](#multithreading)). **Occupancy** is how many warps are resident compared with the maximum. More warps means more work available while others wait for memory, but each warp needs registers, so register-heavy kernels get fewer warps.

### Memory Coalescing

GPU memory is fastest when the 32 threads of a warp access 32 neighbouring addresses: the hardware merges them into a few wide transactions. Scattered addresses turn one transaction into many.

| Access by thread *i* | Result |
| --- | --- |
| `a[i]` | Coalesced: one or a few transactions |
| `a[i * 32]` | Strided: up to 32 transactions |
| `a[random[i]]` | Scattered: slowest |

## Advantages of GPUs

| Advantage | Why |
| --- | --- |
| Huge throughput on data-parallel work | Thousands of lanes; graphics, matrix maths, ML training and inference |
| Performance per watt for such work | Little control logic per lane; most of the chip does arithmetic |
| High memory bandwidth | Wide memory buses (GDDR, HBM) |
| Latency tolerance | Many resident warps instead of large caches |
| Specialised units | Texture units, and matrix units (tensor cores) for ML |

### When a GPU Is the Wrong Tool

| Situation | Why |
| --- | --- |
| Serial or branchy code | Divergence and no single-thread speed |
| Small problems | Launch and data-copy overhead outweigh the gain |
| Irregular pointer chasing | Poor coalescing, no big caches |
| Frequent CPU↔GPU communication | Transfers over the bus are slow on discrete GPUs (less so on phones, where CPU and GPU share memory) |

```mermaid
flowchart TD
    Q["Is the work the same operation on lots of independent data?"] -->|"No"| CPU1["Use the CPU"]
    Q -->|"Yes"| S{"Is it small or short?"}
    S -->|"Yes"| SIMD["Use CPU SIMD (Neon / SVE)"]
    S -->|"No, large"| GPU1["Use the GPU"]
```

**Sources:** [Wikipedia: Graphics processing unit](https://en.wikipedia.org/wiki/Graphics_processing_unit), [Wikipedia: Flynn's taxonomy](https://en.wikipedia.org/wiki/Flynn%27s_taxonomy)

## Key Points

- SIMD runs one instruction on many lanes; Arm has fixed 128-bit Neon and scalable SVE with predicates.
- GPUs group threads into warps that run in lockstep (SIMT) and hide memory delay by switching warps.
- GPUs win on large, regular, data-parallel work; divergence, scattered memory and small jobs hurt them.