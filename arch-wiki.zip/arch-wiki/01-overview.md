# Computer Architecture Overview

<details>
<summary>Relevant source files</summary>

The following references were used as context for generating this wiki page:

- [Wikipedia: Computer architecture](https://en.wikipedia.org/wiki/Computer_architecture)
- [Wikipedia: Von Neumann architecture](https://en.wikipedia.org/wiki/Von_Neumann_architecture)
- [Wikipedia: Memory hierarchy](https://en.wikipedia.org/wiki/Memory_hierarchy)
- Book: Patterson and Hennessy, *Computer Organization and Design* (Arm edition)
- Book: Hennessy and Patterson, *Computer Architecture: A Quantitative Approach*

</details>

A computer processor does one simple thing over and over: fetch an instruction from memory, work out what it means, do it, and move on to the next one. Everything in this wiki is about doing that faster. Some techniques do more than one step at once (pipelining), some guess what comes next (branch prediction), some run independent instructions side by side (ILP), some keep data close (caches), and some use many processors together (multicore, GPUs).

> **How to read this wiki.** No prior hardware knowledge is assumed. Each page starts with an everyday analogy, then gives the real idea, then a diagram. Diagrams and worked examples are illustrative: they show the idea, not the exact design of any particular chip. Facts about Arm come from Arm's public architecture documents, named on each page.

## Purpose and Scope

This wiki explains the main ideas of computer organisation and architecture for complete beginners:

| # | Page | One-line summary |
| --- | --- | --- |
| 1 | [Overview](#overview) | This page: the big picture and a map of the wiki |
| 2 | [Fundamentals](#fundamentals) | CPU, memory, instructions, the fetch-execute cycle, performance |
| 3 | [Pipelining](#pipelining) | An assembly line for instructions, and what breaks it |
| 4 | [Branches and Remedies](#branches) | Why `if` statements slow the pipeline, and branch prediction |
| 5 | [Instruction-Level Parallelism](#ilp) | Superscalar, out-of-order execution, renaming, speculation |
| 6 | [Memory and Ordering](#memory-ordering) | Why other cores can see your writes in a surprising order |
| 7 | [Caches and Coherence](#caches-coherence) | Small fast memories, and keeping many copies in agreement |
| 8 | [Multicore](#multicore) | Many processors on one chip, Amdahl's law |
| 9 | [Multithreading](#multithreading) | One core running several threads to stay busy |
| 10 | [SIMD and GPUs](#simd-gpu) | One instruction on many data items, and why GPUs are fast |
| 11 | [Glossary](#glossary) | All the terms in one place |

How a compiler uses these ideas, for example to schedule instructions around pipeline delays, is covered in the [Instruction Scheduling wiki](../sched-wiki/sched-wiki.html#overview) and the [LLVM IR wiki](../ir-wiki/ir-wiki.html#overview).

## Organisation versus Architecture

The two words in the title mean different things:

| Term | Question it answers | Example |
| --- | --- | --- |
| **Architecture** (instruction set architecture, ISA) | What can a program ask the processor to do? | "There is an `ADD` instruction that adds two 64-bit registers" (Arm A64) |
| **Organisation** (microarchitecture) | How does the hardware actually do it? | "This chip has 4 adders and runs `ADD` in 1 cycle, out of order" |

Many different chips share one architecture. A small phone core and a large server core can both run the same Arm program, but they are built very differently inside.

```mermaid
flowchart TD
    P["Your program<br/>(machine code)"] --> ISA["Instruction set architecture<br/>the contract: Arm A64, x86-64, RISC-V"]
    ISA --> M1["Small core<br/>in-order, 1 instruction per cycle"]
    ISA --> M2["Big core<br/>out-of-order, 8 instructions per cycle"]
    ISA --> M3["Server core<br/>big caches, many cores"]
```

## The Big Picture

```mermaid
flowchart LR
    subgraph CPU["Processor chip"]
        direction TB
        C1["Core 0<br/>pipeline + registers"] --- L1a["L1 cache"]
        C2["Core 1<br/>pipeline + registers"] --- L1b["L1 cache"]
        L1a --- L2["Shared L2 / L3 cache"]
        L1b --- L2
        G["GPU<br/>many simple cores"] --- L2
    end
    L2 --- RAM["Main memory (DRAM)"]
    RAM --- D["Storage (SSD)"]
```

Read the picture from the inside out:

1. A **core** runs instructions. Inside it is a **pipeline** ([Pipelining](#pipelining)) that overlaps instructions, and **registers**, a few dozen very fast storage slots.
2. Each core has a small, fast **cache** that keeps recently used data close ([Caches and Coherence](#caches-coherence)).
3. Several cores share bigger, slower caches and finally **main memory** ([Multicore](#multicore)).
4. A **GPU** has many simple cores that all do the same thing to different data ([SIMD and GPUs](#simd-gpu)).

**Sources:** [Wikipedia: Computer architecture](https://en.wikipedia.org/wiki/Computer_architecture), [Wikipedia: Memory hierarchy](https://en.wikipedia.org/wiki/Memory_hierarchy)

## Why Speed Is Hard: Three Walls

For decades chips got faster mainly by raising the clock speed. That stopped around 2005, and the reasons explain why the rest of this wiki exists:

| Wall | Problem | Answer the industry chose | Page |
| --- | --- | --- | --- |
| **Memory wall** | Memory got faster far more slowly than processors. A trip to main memory costs hundreds of cycles | Caches, prefetching | [Caches and Coherence](#caches-coherence) |
| **ILP wall** | There is only so much independent work in one stream of instructions | Out-of-order execution, but with limits | [ILP](#ilp) |
| **Power wall** | A faster clock burns much more power and heat | More cores, SIMD units, GPUs, instead of a faster clock | [Multicore](#multicore), [SIMD and GPUs](#simd-gpu) |

```mermaid
flowchart TD
    A["Goal: run programs faster"] --> B["Do each step faster<br/>higher clock"]
    A --> C["Do steps at the same time<br/>parallelism"]
    A --> D["Wait less for data<br/>caches"]
    B --> B1["Limited by power and heat"]
    C --> C1["Within one instruction stream<br/>pipelining, ILP"]
    C --> C2["Across many threads<br/>multicore, multithreading"]
    C --> C3["Across many data items<br/>SIMD, GPU"]
```

## Key Points

- Architecture is the contract a program sees; organisation is how a chip implements it.
- A core repeatedly fetches, decodes and executes instructions; most tricks overlap or skip waiting in that loop.
- Clock speed stopped rising quickly, so modern speed comes from parallelism and caches.