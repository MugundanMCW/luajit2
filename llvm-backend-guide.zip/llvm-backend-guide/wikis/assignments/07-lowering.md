# Stage 6: TargetLowering, Arguments and Returns

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)
- [llvm/lib/Target/AArch64/AArch64CallingConvention.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td)

</details>
Tell SelectionDAG which types are legal and lower function entry and return.

## Purpose and Scope

`ToyTargetLowering` constructor, `ToyCallingConv.td` (`CC_Toy`, `RetCC_Toy`, `CSR_Toy`), `LowerFormalArguments`, `LowerReturn`, `CanLowerReturn`.

## Read First

- [TargetLowering setup](../bringup-wiki/bringup-wiki.html#targetlowering)
- [SelectionDAG legalization](../selectiondag-wiki.html#legalization)
- [CallingConv.td](../callconv-wiki/callconv-wiki.html#cc-td)
- [LowerFormalArguments](../callconv-wiki/callconv-wiki.html#formal-arguments)
- [LowerReturn](../callconv-wiki/callconv-wiki.html#lower-return)

## Tasks

1. `addRegisterClass(MVT::i32, &Toy::GPRRegClass)`, `computeRegisterProperties`, then `Expand` for `SDIV`, `SREM`, `UDIV`, `UREM`, rotates, `CTPOP`, `BR_CC`, `SELECT_CC`.
2. Calling convention exactly as in the [overview](#overview).
3. `ToyISD::RET` node and a `RET` pseudo or instruction with `isReturn`.

## Tests

`define void @f() { ret void }` reaches instruction selection (error should now be `Cannot select` or succeed if `RET` has a pattern). Six-argument `i32` function: `-stop-after=finalize-isel` shows two `%fixed-stack` loads.

## Done When

- [ ] `ret void` and `ret i32 %a` selected
- [ ] `i64` return splits into `r0`/`r1`
- [ ] `i128` return demoted to `sret`

Next: stage 7. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
