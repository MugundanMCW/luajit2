# Stage 1: Build Setup

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/CMakeLists.txt](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/CMakeLists.txt)

</details>
Get an LLVM build tree that can host a new experimental target and that reports errors usefully.

## Purpose and Scope

A configured build of LLVM with assertions, ready to add `Toy`.

## Read First

- [Layout and CMake](../bringup-wiki/bringup-wiki.html#layout-cmake)
- [Tooling and glossary](../bringup-wiki/bringup-wiki.html#tooling-glossary)

## Tasks

1. Configure a separate build directory with `-DCMAKE_BUILD_TYPE=Release -DLLVM_ENABLE_ASSERTIONS=ON -DLLVM_TARGETS_TO_BUILD=AArch64 -DLLVM_ENABLE_PROJECTS=clang`.
2. Build `llc`, `llvm-tblgen`, `llvm-mc`, `llvm-objdump`, `FileCheck` and `llvm-lit`.
3. Read `LLVM_ALL_EXPERIMENTAL_TARGETS` in `llvm/CMakeLists.txt`; you will add `Toy` there in stage 2.

## Tests

`llc --version` lists `aarch64`; `llc -debug-only=isel` is accepted (proves assertions are on).

## Done When

- [ ] Build finishes
- [ ] `-debug-only` works
- [ ] `llvm-lit llvm/test/CodeGen/AArch64/arm64-ccmp.ll` passes

Next: stage 2. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
