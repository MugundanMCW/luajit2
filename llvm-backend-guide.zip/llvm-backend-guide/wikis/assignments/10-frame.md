# Stage 9: Frame Lowering

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/PrologEpilogInserter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp)
- [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp)

</details>
Give every function a correct stack frame.

## Purpose and Scope

Real `emitPrologue`/`emitEpilogue`, `eliminateFrameIndex`, frame pointer support, large offsets.

## Read First

- [Frame lowering](../bringup-wiki/bringup-wiki.html#frame-lowering)
- [Frame wiki: PEI pass](../frame-wiki/frame-wiki.html#pei-pass)
- [Frame index elimination](../frame-wiki/frame-wiki.html#frame-index)
- [Frame custom backend](../frame-wiki/frame-wiki.html#custom-backend)

## Tasks

1. Prologue `addi sp, sp, -N`; epilogue before the first terminator.
2. `eliminateFrameIndex` rewrites `(FI, off)` to `(sp|fp, off + objectOffset + stackSize)`.
3. `hasFPImpl` for variable-sized objects and `-frame-pointer=all`; save/restore `r11`.
4. Offsets beyond `simm16`: `requiresRegisterScavenging`, build the address with `lui`/`ori`/`add` in a scavenged register.
5. Dynamic `alloca` (`DYNAMIC_STACKALLOC` expanded).

## Tests

Local array of 16 words, a 100 KB local array, a dynamic `alloca`, and the stage-8 spill test. Compare `-stop-before=prolog-epilog` and `-stop-after=prolog-epilog` MIR.

## Done When

- [ ] Stack stays 8-byte aligned
- [ ] Large frame compiles
- [ ] `-frame-pointer=all` works

## Stretch

CFI directives ([CFI](../frame-wiki/frame-wiki.html#cfi)) and shrink wrapping.

Next: stage 10. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
