# Stage 8: Registers, Copies and Spills

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp)
- [llvm/lib/Target/AArch64/AArch64InstrInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.cpp)

</details>
Make the register allocator work under pressure.

## Purpose and Scope

`copyPhysReg`, `storeRegToStackSlot`, `loadRegFromStackSlot`, `isLoadFromStackSlot`/`isStoreToStackSlot`, correct reserved registers.

## Read First

- [Registers and allocation](../bringup-wiki/bringup-wiki.html#registers-regalloc)
- [regalloc: TRI hooks](../regalloc-wiki/regalloc-wiki.html#tri-hooks)
- [regalloc: TII hooks](../regalloc-wiki/regalloc-wiki.html#tii-hooks)
- [regalloc: backend checklist](../regalloc-wiki/regalloc-wiki.html#backend-checklist)

## Tasks

1. `copyPhysReg` emits `addi rd, rs, 0` (or an `or`).
2. Spill/reload use `sw`/`lw` with a frame-index operand pair `(FI, 0)`.
3. Reserve `sp`; reserve `r11` only when `hasFP`.

## Tests

Write a function that keeps 20 values live at once (sum of 20 loaded values used twice). With `-O2`, MIR after `greedy` must contain spill slots and assembly must contain reloads, and the result must be correct when run in a simulator if you have one.

## Done When

- [ ] High-pressure test compiles at `-O0` (fast allocator) and `-O2` (greedy)
- [ ] No use of reserved registers

Next: stage 9. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
