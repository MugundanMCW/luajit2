# Stage 14: Capstone, a Complete Toy Backend

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [clang/lib/Basic/Targets.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/clang/lib/Basic/Targets.cpp)

</details>
Tie everything together: compile C with clang and prove the backend correct on a test suite.

## Purpose and Scope

A clang target (`clang/lib/Basic/Targets/Toy.{h,cpp}`) and a regression and execution test suite.

## Read First

- [Bring-up checklist](../bringup-wiki/bringup-wiki.html#checklist)
- [A minimal Toy target](../bringup-wiki/bringup-wiki.html#toy-walkthrough)

## Tasks

1. Add a clang `TargetInfo` for `toy` (type sizes matching the data layout, predefined `__toy__`).
2. Compile 10 programs at `-O0` and `-O2`: arithmetic, loops, recursion, arrays, structs by value, globals, `switch`, function pointers, `long long` math (libcalls), a spill-heavy function.
3. If you write or reuse a simple Toy simulator, run them and compare with host results; otherwise check assembly by hand against the ABI.
4. Keep everything as `lit` tests.

## Tests

`clang --target=toy-unknown-elf -O2 -c prog.c` succeeds for all 10 programs; the whole `llvm/test/CodeGen/Toy` directory passes under `llvm-lit`.

## Done When

- [ ] Every checklist item on the [bring-up checklist](../bringup-wiki/bringup-wiki.html#checklist) ticked

## Stretch

Varargs, tail calls, CFI and shrink wrapping, `llvm-mca` with your model, GlobalISel.

Next: stage 15. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
