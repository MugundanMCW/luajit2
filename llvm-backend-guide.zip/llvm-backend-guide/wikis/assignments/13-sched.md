# Stage 12: Scheduling Model

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/Target/TargetSchedule.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetSchedule.td)
- [llvm/lib/Target/AArch64/AArch64SchedA57.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64SchedA57.td)

</details>
Give the scheduler real latencies for an imagined in-order Toy core.

## Purpose and Scope

`ToySchedule.td` types on every instruction, a `ToyModel`, `ProcessorModel<"toy2", ...>`, `enableMachineScheduler`.

## Read First

- [Scheduling](../bringup-wiki/bringup-wiki.html#scheduling)
- [The scheduling model](../sched-wiki/sched-wiki.html#sched-model)
- [Scheduling custom backend](../sched-wiki/sched-wiki.html#custom-backend)

## Tasks

1. Model: `IssueWidth = 1`, `MicroOpBufferSize = 0`, load latency 3, multiply latency 4, `CompleteModel = 1`.
2. Resources: one ALU, one multiplier, one load/store unit.

## Tests

The dot-product function from the [scheduling walkthroughs](../sched-wiki/sched-wiki.html#aarch64-walkthroughs): compare `-stop-before/after=machine-scheduler` with `-mcpu=toy2`; loads should move ahead of the multiplies that use them.

## Done When

- [ ] TableGen reports no missing scheduling info
- [ ] Reordering visible in MIR

Next: stage 13. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
