# Stage 3: TableGen Skeleton

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64.td)
- [llvm/lib/Target/AArch64/AArch64RegisterInfo.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.td)

</details>
Describe the registers and an empty instruction set, and get every TableGen backend you need running.

## Purpose and Scope

`Toy.td`, `ToyRegisterInfo.td`, an empty `ToyInstrInfo.td`, and the `tablegen()` lines in CMake.

## Read First

- [The Target .td file](../bringup-wiki/bringup-wiki.html#target-td)
- [Registers and allocation](../bringup-wiki/bringup-wiki.html#registers-regalloc)
- [regalloc: TableGen registers](../regalloc-wiki/regalloc-wiki.html#tablegen-registers)

## Tasks

1. Define `R0`–`R15` with `HWEncoding` and `DwarfRegNum`; alias `SP`/`LR` names via `AltNames` or separate asm names.
2. Define `GPR : RegisterClass<"Toy", [i32], 32, (sequence "R%u", 0, 15)>`.
3. Write `Toy.td` with includes in dependency order and `def Toy : Target`.
4. Add `-gen-register-info`, `-gen-instr-info`, `-gen-subtarget`, `-gen-asm-writer`, `-gen-dag-isel`, `-gen-callingconv`, `-gen-emitter` to CMake.

## Tests

`llvm-tblgen -print-records -I llvm/include -I llvm/lib/Target/Toy Toy.td` succeeds; `ToyGenRegisterInfo.inc` contains `Toy::R15`.

## Done When

- [ ] All `.inc` files generate
- [ ] Register enum has 16 entries plus `NoRegister`

Next: stage 4. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
