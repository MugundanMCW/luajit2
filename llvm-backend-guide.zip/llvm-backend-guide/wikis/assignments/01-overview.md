# Assignments: Build the Toy Backend

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64.td)

</details>
A hands-on track that turns the guide into a working compiler backend. Each stage adds one piece of a backend for **Toy**, a small 32-bit RISC target, and ends with tests you can run. After the last stage, `clang --target=toy-unknown-elf -O2 -c` compiles small C programs to Toy ELF object files.

## Purpose and Scope

The stages follow the guide's bring-up order. Each one names the pages to read, the files to write, the tests to run, and a "done when" list. No solution code is provided: the Toy snippets in the guide are illustrative starting points, and these assignments were written from the guide, not compiled, so expect to adapt signatures to your LLVM version.

## The Toy Architecture

| Property | Value |
| --- | --- |
| Word | 32-bit, little endian, byte addressed |
| Registers | `r0`–`r15`; `r15` = `sp`, `r14` = `lr`, `r11` = frame pointer when used, `r0` reads as zero is **not** used (all general) |
| Calling convention | Args `r0`–`r3`, then stack (4-byte slots); return `r0`(/`r1`); callee-saved `r4`–`r11`, `lr`; stack 8-byte aligned, grows down |
| Data layout | `e-m:e-p:32:32-i64:64-n32-S64` |
| Instruction size | 4 bytes |

| Format | Bits | Instructions |
| --- | --- | --- |
| R | `op[31:26] rd[25:21] rs[20:16] rt[15:11] 0[10:0]` | `add sub and or xor sll srl sra mul slt sltu` |
| I | `op[31:26] rd[25:21] rs[20:16] imm16[15:0]` | `addi andi ori lui lw lh lb lbu lhu sw sh sb beq bne blt bge` |
| J | `op[31:26] imm26[25:0]` | `call` (pc-relative, word offset), `jmp` |
| Other | R form | `ret` (jump to `lr`), `jr rs` |

Pick any unused opcode numbers and write them in your `ToyInstrInfo.td`. Branch and `call` offsets are signed word offsets from the next instruction.

## Stages

| Stage | Builds | Milestone |
| --- | --- | --- |
| [1](#setup) | LLVM build with an experimental target | Build tree ready |
| [2](#registration) | Triple, TargetInfo, CMake | `llc --version` lists `toy` |
| [3](#tablegen) | `Toy.td`, registers, empty instruction set | TableGen runs |
| [4](#mc-asm) | MC descriptors, `MCAsmInfo`, instruction printer | Libraries link |
| [5](#targetmachine) | TargetMachine, Subtarget, PassConfig | `llc -march=toy` on an empty module |
| [6](#lowering) | TargetLowering, arguments and returns | `ret void` reaches selection |
| [7](#isel) | ALU instructions, selector, AsmPrinter | **First function prints** |
| [8](#regalloc) | Register hooks, copies, spills | Register pressure test passes |
| [9](#frame) | Frame lowering | Locals and spills on the stack |
| [10](#control-memory) | Loads, stores, globals, branches | Loops and arrays |
| [11](#calls) | Calls | Recursive `fib` |
| [12](#sched) | Scheduling model | Measurable reordering |
| [13](#objfiles) | Encodings, code emitter, ELF | **Object files** |
| [14](#capstone) | clang driver, test suite, extras | Complete backend |

## Working Rules

- Build LLVM with assertions; run every test with `-verify-machineinstrs`.
- Keep each stage's tests as `lit` files under `llvm/test/CodeGen/Toy/` (and `llvm/test/MC/Toy/` from stage 13), so later stages cannot silently break earlier ones.
- Compare against AArch64 when stuck: the guide links the AArch64 lines for every piece.
