# Stage 10: Memory, Globals and Control Flow

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64InstrInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.cpp)

</details>
Compile real loops: loads and stores of all widths, global addresses, compares and branches.

## Purpose and Scope

Load/store patterns with an address `ComplexPattern`, `GlobalAddress` lowering, branch instructions, `analyzeBranch`/`insertBranch`/`removeBranch`.

## Read First

- [TargetLowering: custom lowering](../bringup-wiki/bringup-wiki.html#targetlowering)
- [SelectionDAG: memory walkthrough](../selectiondag-wiki.html#aarch64-walkthroughs)
- [SelectionDAG: control flow](../selectiondag-wiki.html#aarch64-walkthroughs)

## Tasks

1. `SelectAddr` matching `(add base, simm16)`, frame indices and plain registers.
2. Sign/zero-extending loads and truncating stores (`lb`, `lbu`, `sb`, ...).
3. `GlobalAddress` custom-lowered to `ToyISD::HI`/`LO` → `lui` + `addi` with `%hi`/`%lo` operand flags printed by the instruction printer.
4. `BRCOND`/`SETCC` patterns using `beq`/`bne`/`blt`/`bge`/`slt`; unconditional `jmp`.
5. Branch analysis hooks so `-O2` branch folding and block placement work.

## Tests

Array sum loop, `strlen`, a `switch` (expanded to compares), a global counter increment.

## Done When

- [ ] Loops at `-O0` and `-O2`
- [ ] All load/store widths
- [ ] `-verify-machineinstrs` clean after branch folding

Next: stage 11. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
