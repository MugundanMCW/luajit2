# Stage 2: Target Registration

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/TargetInfo/AArch64TargetInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/TargetInfo/AArch64TargetInfo.cpp)
- [llvm/lib/TargetParser/TargetDataLayout.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/TargetParser/TargetDataLayout.cpp)

</details>
Make LLVM know that a `toy` target exists, before it can do anything.

## Purpose and Scope

`Triple::toy`, a data layout, the `TargetInfo` library and a CMake skeleton.

## Read First

- [Layout and CMake](../bringup-wiki/bringup-wiki.html#layout-cmake)
- [TargetMachine and Subtarget: data layout](../bringup-wiki/bringup-wiki.html#targetmachine-subtarget)

## Tasks

1. Add `toy` to `Triple::ArchType` and the triple parser/printer; add the data layout string from the [overview](#overview) in `TargetDataLayout.cpp`.
2. Add `Toy` to `LLVM_ALL_EXPERIMENTAL_TARGETS`; reconfigure with `-DLLVM_EXPERIMENTAL_TARGETS_TO_BUILD=Toy`.
3. Create `lib/Target/Toy/CMakeLists.txt` with `add_llvm_component_group(Toy)` and `TargetInfo/` with `getTheToyTarget()` and `LLVMInitializeToyTargetInfo()`.
4. Add empty `LLVMInitializeToyTarget`, `...TargetMC`, `...AsmPrinter` so the init macros link.

## Tests

`llc --version` shows `toy - Toy example`. A unit test or `llc -mtriple=toy-unknown-elf -o - empty.ll` reaches "no target machine" instead of "unknown triple".

## Done When

- [ ] Triple round-trips (`toy-unknown-elf`)
- [ ] `toy` registered
- [ ] Other targets still build

Next: stage 3. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
