# Stage 13: Object Files

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp)

</details>
Emit Toy ELF objects with correct encodings and relocations.

## Purpose and Scope

`Inst` encodings in TableGen, `ToyMCCodeEmitter`, fixup kinds, `ToyAsmBackend`, `ToyELFObjectWriter`.

## Read First

- [MC: code emitter](../mc-wiki/mc-wiki.html#code-emitter)
- [MC: asm backend](../mc-wiki/mc-wiki.html#asm-backend)
- [MC: fixups and relocations](../mc-wiki/mc-wiki.html#fixups-relocations)
- [MC checklist](../mc-wiki/mc-wiki.html#mc-checklist)

## Tasks

1. Fill `Inst{31-26}` etc. for every format from the [overview](#overview).
2. Fixups: `fixup_toy_hi16`, `fixup_toy_lo16`, `fixup_toy_branch16`, `fixup_toy_call26`; encoder methods for branch and call targets.
3. `applyFixup` resolves local branches; others become relocations (pick an unused `EM_` number and your own relocation numbers).

## Tests

`llc -filetype=obj` on the stage-11 tests; `llc -show-mc-encoding` matches hand-encoded instructions; `llvm-objdump -r` shows relocations for global and external calls.

## Done When

- [ ] Every instruction encodes
- [ ] Local branches resolved, external ones relocated

## Stretch

Asm parser and disassembler ([parser and disassembler](../mc-wiki/mc-wiki.html#parser-disassembler)) so `llvm-mc` and `llvm-objdump -d` work.

Next: stage 14. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
