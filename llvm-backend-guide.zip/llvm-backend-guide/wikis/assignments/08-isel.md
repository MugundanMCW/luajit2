# Stage 7: Instruction Selection and the First Function

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp)
- [llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp)

</details>
The first real milestone: a function with arithmetic compiles to Toy assembly.

## Purpose and Scope

R- and I-format ALU instructions with patterns, immediates, `ToyDAGToDAGISel`, `ToyAsmPrinter`, `ToyMCInstLower`.

## Read First

- [Instructions and ISel](../bringup-wiki/bringup-wiki.html#instructions-isel)
- [SelectionDAG pattern language](../selectiondag-wiki.html#pattern-language)
- [AsmPrinter and MC](../bringup-wiki/bringup-wiki.html#asmprinter-mc)
- [A minimal Toy target](../bringup-wiki/bringup-wiki.html#toy-walkthrough)

## Tasks

1. Instruction classes for R and I formats with `Sched<[]>` placeholders.
2. Patterns for `add sub and or xor shl srl sra mul setlt setult`; `simm16` and `uimm16` leaves.
3. Materialize 32-bit constants with `lui` + `ori` (a `Pat` on `imm`).
4. Selector with `SelectCode`; AsmPrinter with `MCInstLower`.
5. Minimal `ToyFrameLowering` (no frame) so PEI does not crash.

## Tests

```llvm
define i32 @f(i32 %a, i32 %b) { %s = add i32 %a, %b
  %m = mul i32 %s, 12345678
  ret i32 %m }
```
Expected shape (illustrative): `add r0, r0, r1` / `lui r1, ...` / `ori r1, r1, ...` / `mul r0, r0, r1` / `ret`. Add `lit` tests with `FileCheck`.

## Done When

- [ ] All ALU operations selected at `-O0` and `-O2`
- [ ] Large constants work
- [ ] `-verify-machineinstrs` clean

## Stretch

Add `-O2` patterns that fold `add` with an immediate into `addi`.

Next: stage 8. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
