# Stage 11: Calls

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)
- [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp)

</details>
Make functions call each other, including recursion and stack arguments.

## Purpose and Scope

`LowerCall`, `ToyISD::CALL`, `CALL` instruction (`isCall`, `Defs = [LR]`), call-frame pseudos, `getCallPreservedMask`.

## Read First

- [Calling conventions](../bringup-wiki/bringup-wiki.html#calling-conventions)
- [LowerCall](../callconv-wiki/callconv-wiki.html#lower-call)
- [Callconv custom backend](../callconv-wiki/callconv-wiki.html#custom-backend)
- [Frame: callee saves](../frame-wiki/frame-wiki.html#callee-saves)

## Tasks

1. Implement `LowerCall` following the Toy version on the [callconv custom backend page](../callconv-wiki/callconv-wiki.html#custom-backend).
2. `ADJCALLSTACKDOWN/UP` registered in the `ToyInstrInfo` constructor; `eliminateCallFramePseudoInstr`.
3. Save `lr` and used callee-saved registers in the prologue (default spill path).

## Tests

Recursive `fib(n)`, a call with six arguments, a call whose result is used after another call. Check `lr` is saved only in non-leaf functions.

## Done When

- [ ] Recursion correct
- [ ] Stack arguments at the right offsets
- [ ] Values live across calls are in callee-saved registers

## Stretch

Sibling calls ([tail calls](../callconv-wiki/callconv-wiki.html#tail-calls)) and varargs ([special arguments](../callconv-wiki/callconv-wiki.html#special-args)).

Next: stage 12. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
