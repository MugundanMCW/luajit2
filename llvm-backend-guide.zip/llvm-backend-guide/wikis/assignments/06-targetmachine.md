# Stage 5: TargetMachine and Subtarget

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)
- [llvm/lib/Target/AArch64/AArch64Subtarget.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Subtarget.cpp)

</details>
Create the per-compilation and per-CPU objects and the pass pipeline.

## Purpose and Scope

`ToyTargetMachine`, `ToySubtarget`, `ToyPassConfig`, empty `ToyInstrInfo`, `ToyRegisterInfo`, `ToyFrameLowering` stubs.

## Read First

- [TargetMachine and Subtarget](../bringup-wiki/bringup-wiki.html#targetmachine-subtarget)
- [regalloc: pass config hooks](../regalloc-wiki/regalloc-wiki.html#pass-config-hooks)

## Tasks

1. Constructor calls `CodeGenTargetMachineImpl(...)` with `TT.computeDataLayout()`, then `initAsmInfo()`.
2. Subtarget owns instr info, frame lowering and lowering; calls `ParseSubtargetFeatures`.
3. `ToyPassConfig::addInstSelector` adds your selector (stub for now).
4. `ToyRegisterInfo`: `getCalleeSavedRegs`, `getReservedRegs` (SP), `getFrameRegister` (stubs are fine).

## Tests

`llc -mtriple=toy-unknown-elf empty.ll -o -` (a module with no functions) prints a file header and exits 0.

## Done When

- [ ] Empty module compiles
- [ ] `-mcpu=generic` accepted

Next: stage 6. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
