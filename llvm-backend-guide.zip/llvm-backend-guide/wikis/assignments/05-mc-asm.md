# Stage 4: MC Layer for Assembly Output

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp)

</details>
Register the MC objects every tool needs: instruction, register and subtarget info, `MCAsmInfo`, and the instruction printer.

## Purpose and Scope

`MCTargetDesc/` with `ToyMCTargetDesc.cpp`, `ToyMCAsmInfo`, `ToyInstPrinter` and `LLVMInitializeToyTargetMC`.

## Read First

- [MC: custom backend](../mc-wiki/mc-wiki.html#custom-backend)
- [MC: MCAsmInfo and printer](../mc-wiki/mc-wiki.html#asminfo-printer)
- [AsmPrinter and MC](../bringup-wiki/bringup-wiki.html#asmprinter-mc)

## Tasks

1. `ToyMCAsmInfo : MCAsmInfoELF` with comment string `#`, 4-byte alignment, DWARF CFI.
2. `ToyInstPrinter` using generated `printInstruction`/`getRegisterName`; write `printOperand` for registers and immediates, and a memory operand printer `imm(reg)`.
3. Register asm info, instr info, register info, subtarget info and printer.

## Tests

Everything links; `llvm-mc -triple=toy-unknown-elf --version` runs (no parser yet).

## Done When

- [ ] `LLVMToyDesc` links without CodeGen
- [ ] No missing-factory crash when tools start

Next: stage 5. All Toy code and expected output on this page are **illustrative, not LLVM source and not tool output**; your exact output may differ.
