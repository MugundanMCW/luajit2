# Preparing Code for Allocation

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/TargetPassConfig.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/TargetPassConfig.cpp)
- [llvm/lib/CodeGen/PHIElimination.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PHIElimination.cpp)
- [llvm/lib/CodeGen/TwoAddressInstructionPass.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/TwoAddressInstructionPass.cpp)
- [llvm/lib/CodeGen/RegisterCoalescer.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegisterCoalescer.cpp)

</details>
The allocators expect code with no `PHI` instructions, with every tied-operand constraint already satisfied, and with as few `COPY`s as possible. Three passes produce that form: PHI elimination, two-address lowering and the register coalescer.

## Purpose and Scope

This page gives the big picture and shows the same loop at each step. The details are on [PHI Elimination and Two-Address Lowering](#phi-two-address) and [Register Coalescer](#coalescer).

## The Idea: Add Copies, Then Remove Them

The first two passes make the code correct for allocation by **adding** `COPY` instructions, many of them unnecessary. The coalescer then **removes** every copy it can prove is safe to remove. This split keeps each pass simple: PHI elimination and two-address lowering never have to be clever, because the coalescer cleans up after them.

```mermaid
flowchart LR
  A["SSA MIR<br/>PHIs, tied operands unmet"] --> B["PHIElimination<br/>PHI becomes COPYs"]
  B --> C["TwoAddressInstruction<br/>tied operands get a COPY"]
  C --> D["RegisterCoalescer<br/>merge COPY source and destination"]
  D --> E["Allocator input<br/>few COPYs, long live ranges"]
```

## One Loop, Three Snapshots

Source (after `LoopStrengthReduce`):

```llvm
loop:
  %lsr.iv = phi i64 [ %lsr.iv.next, %loop ], [ 0, %entry ]
  %acc = phi i32 [ 0, %entry ], [ %acc.next, %loop ]
  ...
  %acc.next = add i32 %acc, %v
  %lsr.iv.next = add nuw nsw i64 %lsr.iv, 1
```

**After two-address lowering** (`llc -mtriple=aarch64 -O2 -stop-after=twoaddressinstruction`): the two PHIs are gone and there are sixteen `COPY`s (eight in `bb.0`, seven in `bb.1`, one in `bb.2`).

```
bb.0.entry:
  %5:gpr32 = COPY killed $w1
  %4:gpr64common = COPY killed $x0
  %8:gpr32all = COPY $wzr
  %7:gpr32all = COPY killed %8
  %9:gpr64all = COPY $xzr
  %6:gpr64all = COPY killed %9
  %15:gpr64common = COPY killed %6
  %16:gpr32 = COPY killed %7

bb.1.loop:
  %1:gpr32 = COPY killed %16
  %0:gpr64common = COPY killed %15
  %10:gpr32 = LDRWroX %4, %0, 0, 1 :: (load (s32) from %ir.scevgep)
  %11:gpr32 = ADDWrr killed %1, killed %10
  %2:gpr32all = COPY killed %11
  %12:gpr64sp = nuw nsw ADDXri killed %0, 1, 0
  %3:gpr64all = COPY %12
  %13:gpr32 = COPY killed %12.sub_32
  dead $wzr = SUBSWrr killed %13, %5, implicit-def $nzcv
  %15:gpr64common = COPY killed %3
  %16:gpr32 = COPY %2
  Bcc 3, %bb.1, implicit killed $nzcv
  B %bb.2

bb.2.exit:
  $w0 = COPY killed %2
  RET_ReallyLR implicit killed $w0
```

Note that `%15` and `%16` are defined twice (once per predecessor): the code is no longer in SSA form.

**After the coalescer** (`-stop-after=register-coalescer`): only the copies that connect to physical registers are left.

```
bb.0.entry:
  %5:gpr32 = COPY $w1
  %4:gpr64common = COPY $x0
  %15:gpr64common = COPY $xzr
  %16:gpr32 = COPY $wzr

bb.1.loop:
  %10:gpr32 = LDRWroX %4, %15, 0, 1 :: (load (s32) from %ir.scevgep)
  %16:gpr32 = ADDWrr %16, %10
  %15:gpr64common = nuw nsw ADDXri %15, 1, 0
  dead $wzr = SUBSWrr %15.sub_32, %5, implicit-def $nzcv
  Bcc 3, %bb.1, implicit killed $nzcv
  B %bb.2

bb.2.exit:
  $w0 = COPY %16
  RET_ReallyLR implicit $w0
```

Each PHI's whole web of copies (`%0`, `%3`, `%6`, `%9`, `%12`, `%15`, and the 32-bit view `%13`) collapsed into a single register, `%15`, whose class was narrowed to the intersection `gpr64common`. The accumulator web became `%16`. The machine scheduler then moved the `ADDWrr` below the compare, which is the order you see in the allocated loop on [AArch64 Walkthroughs](#aarch64-walkthroughs).

**After allocation:**

- The copies of `$xzr`/`$wzr` became `mov x9, xzr` and `mov w8, wzr`.
- The copies from `$w1` and `$x0` disappeared, because `%5` and `%4` were given `$w1` and `$x0` (hints from the copies).
- `$w0 = COPY %16` stayed, as `mov w0, w8`. `%16` cannot be given `$w0`: the pointer `%4` lives in `$x0` for the whole loop, and `w0` is the low half of `x0`, so they share a register unit and interfere.

## Why Not Let the Allocator Handle Copies?

Greedy does try to give both sides of a copy the same register (through *hints*), and the rewriter deletes copies that end up as `$wN = COPY $wN`. But hints are only preferences that can be broken under pressure, while coalescing is a guarantee made before allocation starts. The trade-off is that coalescing makes live ranges longer, which can make allocation harder; the coalescer therefore refuses some merges (see [Register Coalescer](#coalescer)), and Greedy can undo a merge later by splitting.

## The Other Preparation Passes

| Pass | What it does to prepare |
| --- | --- |
| `ProcessImplicitDefs` | Deletes `IMPLICIT_DEF`s and marks their uses `undef`, so undefined values do not occupy registers |
| `DetectDeadLanes` | Marks sub-register lanes that are never read, so they do not extend liveness |
| `RenameIndependentSubregs` | If a register's sub-register parts are never used together, gives each part its own register |
| `MachineScheduler` | Reorders instructions within blocks; its pressure tracking tries to keep the number of simultaneously live values below the register count |

**Sources:** [llvm/lib/CodeGen/TargetPassConfig.cpp:1493-1530](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/TargetPassConfig.cpp#L1493-L1530)