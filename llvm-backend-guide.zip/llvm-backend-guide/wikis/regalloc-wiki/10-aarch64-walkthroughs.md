# AArch64 Walkthroughs

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/RegAllocGreedy.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegAllocGreedy.cpp)
- [llvm/lib/CodeGen/RegAllocFast.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegAllocFast.cpp)
- [llvm/lib/CodeGen/InlineSpiller.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/InlineSpiller.cpp)
- [llvm/lib/Target/AArch64/AArch64RegisterInfo.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.td)
- [llvm/lib/Target/AArch64/AArch64CallingConvention.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td)

</details>
Seven examples (six functions, one of them compiled twice) built with the `llc` from the pinned commit (LLVM 24.0.0git, release build), `-mtriple=aarch64 -O2` unless noted. Every MIR and assembly listing on this page is real output, trimmed only by removing assembler directives; `...` marks omitted lines.

## Purpose and Scope

Each example shows one idea from earlier pages in practice. Read them in order; each says what to look for.

| # | Example | Shows |
| --- | --- | --- |
| 1 | Straight-line arithmetic | Hints and identity copies |
| 2 | Value live across a call | Register masks and callee-saved registers |
| 3 | Simple loop | PHI elimination, coalescing, loop-carried values |
| 4 | Real spills | `InlineSpiller` stores and reloads |
| 5 | Forced pressure | `-stress-regalloc` |
| 6 | Loop containing a call | Callee-saved registers versus spilling |
| 7 | The same code at `-O0` | Fast allocator |

## 1. Straight-line Arithmetic

```llvm
define i32 @f(i32 %a, i32 %b, i32 %c) {
  %m = mul i32 %a, %b
  %s = add i32 %m, %c
  ret i32 %s
}
```

Before Greedy (`-stop-before=greedy`):

```
%1:gpr32 = COPY $w1
%0:gpr32 = COPY $w0
%2:gpr32 = COPY $w2
%4:gpr32 = MADDWrrr %0, %1, %2
$w0 = COPY %4
RET_ReallyLR implicit $w0
```

After the rewriter:

```
renamable $w0 = MADDWrrr killed renamable $w0, killed renamable $w1, killed renamable $w2
RET_ReallyLR implicit $w0
```

Assembly: `madd w0, w0, w1, w2` then `ret`.

**What to look for.** Each copy from or to `$wN` gave a [copy hint](#spill-weights). `%0` and `%4` don't interfere (`%0` dies exactly where `%4` is born, see [slot indexes](#liveness)), so both got `$w0`. All four copies became identity copies and [the rewriter](#rewriting-post-ra) deleted them.

## 2. A Value Live Across a Call

```llvm
declare i32 @g(i32)
define i32 @h(i32 %a, i32 %b) {
  %x = call i32 @g(i32 %a)
  %y = add i32 %x, %b
  ret i32 %y
}
```

Before Greedy:

```
%1:gpr32 = COPY $w1
%0:gpr32 = COPY $w0
ADJCALLSTACKDOWN 0, 0, implicit-def dead $sp, implicit $sp
$w0 = COPY %0
BL @g, csr_aarch64_aapcs, implicit-def dead $lr, implicit $sp, implicit $w0, implicit-def $sp, implicit-def $w0
ADJCALLSTACKUP 0, 0, implicit-def dead $sp, implicit $sp
%2:gpr32 = COPY $w0
$w0 = ADDWrr %2, %1
RET_ReallyLR implicit $w0
```

Assembly:

```
stp	x30, x19, [sp, #-16]!           // 16-byte Folded Spill
mov	w19, w1
bl	g
add	w0, w0, w19
ldp	x30, x19, [sp], #16             // 16-byte Folded Reload
ret
```

**What to look for.** `csr_aarch64_aapcs` on the `BL` is the [register mask](#registers-basics). It says every register outside `CSR_AArch64_AAPCS` is destroyed by the call. `%1` (`%b`) is live across the call, so [`checkInterference`](#framework) returns `IK_RegMask` for every caller-saved register. The first free register is callee-saved `w19`. Prologue insertion then saves `x19` (and `x30`, because there is a call). The `stp`/`ldp` are **not** allocator spills, even though the comment says "Spill".

## 3. A Simple Loop

```llvm
define i32 @sum(ptr %p, i32 %n) {
entry:
  br label %loop
loop:
  %i = phi i32 [0, %entry], [%i.next, %loop]
  %acc = phi i32 [0, %entry], [%acc.next, %loop]
  %idx = zext i32 %i to i64
  %addr = getelementptr i32, ptr %p, i64 %idx
  %v = load i32, ptr %addr
  %acc.next = add i32 %acc, %v
  %i.next = add i32 %i, 1
  %c = icmp ult i32 %i.next, %n
  br i1 %c, label %loop, label %exit
exit:
  ret i32 %acc.next
}
```

The snapshots after two-address lowering and after the coalescer are on [Preparing Code for Allocation](#preparation). After the rewriter:

```
bb.0.entry:
  liveins: $w1, $x0
  renamable $x9 = COPY $xzr
  renamable $w8 = COPY $wzr
bb.1.loop:
  liveins: $w1, $w8, $x0, $x9
  renamable $w10 = LDRWroX renamable $x0, renamable $x9, 0, 1 :: (load (s32) from %ir.scevgep)
  renamable $x9 = nuw nsw ADDXri killed renamable $x9, 1, 0
  dead $wzr = SUBSWrr renamable $w9, renamable $w1, implicit-def $nzcv
  renamable $w8 = ADDWrr killed renamable $w8, killed renamable $w10
  Bcc 3, %bb.1, implicit killed $nzcv
  B %bb.2
bb.2.exit:
  liveins: $w8
  $w0 = COPY killed renamable $w8
  RET_ReallyLR implicit $w0
```

Assembly:

```
sum:
	mov	x9, xzr
	mov	w8, wzr
.LBB0_1:
	ldr	w10, [x0, x9, lsl #2]
	add	x9, x9, #1
	cmp	w9, w1
	add	w8, w8, w10
	b.lo	.LBB0_1
	mov	w0, w8
	ret
```

**What to look for.**

- Each PHI became one register (`%15` → `x9`, `%16` → `w8`) after [coalescing](#coalescer). The loop has no copies at all.
- Registers come from the rotated [allocation order](#framework): `w8`, `x9`, `w10` first.
- `%15.sub_32` was rewritten to `$w9`: a [sub-register](#registers-basics) of `$x9`.
- `liveins:` lists appeared; [`addMBBLiveIns`](#rewriting-post-ra) computed them.
- `mov w0, w8` stays because `w0` overlaps `x0`, which holds the pointer through the whole loop.

## 4. Real Spills

24 volatile loads, all live across a call. Volatile loads cannot be rematerialised, and 24 values do not fit in the callee-saved registers.

```llvm
declare void @g()
define i32 @p(ptr %p) {
  %q1 = getelementptr i32, ptr %p, i64 1
  %v1 = load volatile i32, ptr %q1
  ...                                   ; %v2 .. %v24 the same way
  call void @g()
  %s1 = add i32 %v1, %v2
  ...                                   ; sum all 24
  ret i32 %s23
}
```

After the rewriter (spill and reload lines only):

```
STRWui killed renamable $w8, %stack.11, 0 :: (store (s32) into %stack.11)
STRWui killed renamable $w8, %stack.2, 0 :: (store (s32) into %stack.2)
... 13 stores in total ...
BL @g, csr_aarch64_aapcs, implicit-def dead $lr, implicit $sp, implicit-def $sp
renamable $w9 = LDRWui %stack.11, 0 :: (load (s32) from %stack.11)
renamable $w12 = LDRWui %stack.12, 0 :: (load (s32) from %stack.12)
... 13 reloads in total ...
```

Remark (`-pass-remarks-missed=regalloc`):

```
remark: <unknown>:0:0: 13 spills 1.300000e+01 total spills cost 13
reloads 1.300000e+01 total reloads cost generated in function
```

Assembly excerpt:

```
	stp	x20, x19, [sp, #144]            // 16-byte Folded Spill
	str	w8, [sp, #32]                   // 4-byte Spill
	stp	w8, w10, [sp, #48]              // 8-byte Folded Spill
	...
	bl	g
	ldp	w12, w9, [sp, #12]              // 8-byte Folded Reload
	ldr	w9, [sp, #52]                   // 4-byte Reload
```

**What to look for.**

- 11 values went into callee-saved `w19`–`w29`; the other 13 were [spilled](#inline-spiller), each to its own slot `%stack.0`–`%stack.12`.
- Each spill is `STRWui` right after its definition; each reload is `LDRWui` right before its use. These come from `AArch64InstrInfo::storeRegToStackSlot` and `loadRegFromStackSlot` ([TII hooks](#tii-hooks)).
- In MIR the slot is still a frame index with offset 0. Prologue/epilogue insertion turned it into `[sp, #32]`.
- The AArch64 load/store optimiser later paired adjacent slots, hence "8-byte Folded Spill".

**A spill that did not happen.** The first attempt at this test computed 12 values with `mul i32 %a, C` instead of loading them. It produced **no** allocator spills: 11 values went into callee-saved registers, and the constants were [rematerialised](#spilling-splitting) as `mov w24, #11` and so on. Only values that are expensive to recompute get spilled.

## 5. Forcing Pressure with -stress-regalloc

The loop from example 3, with every register class cut to 2 registers (`-stress-regalloc=2`):

```
sum:
	sub	sp, sp, #32
	mov	x9, xzr
	mov	w8, wzr
	str	w1, [sp, #12]                   // 4-byte Spill
	str	x0, [sp]                        // 8-byte Spill
.LBB0_1:
	str	w8, [sp, #28]                   // 4-byte Spill
	ldr	x8, [sp]                        // 8-byte Reload
	ldr	w8, [x8, x9, lsl #2]
	add	x9, x9, #1
	str	x9, [sp, #16]                   // 8-byte Spill
	str	w8, [sp, #24]                   // 4-byte Spill
	ldr	w8, [sp, #12]                   // 4-byte Reload
	cmp	w9, w8
	ldp	w9, w8, [sp, #24]               // 8-byte Folded Reload
	add	w8, w8, w9
	ldr	x9, [sp, #16]                   // 8-byte Reload
	b.lo	.LBB0_1
	mov	w0, w8
	add	sp, sp, #32
	ret
```

**What to look for.** The loop now needs four values (`p`, `n`, `i`, `acc`) plus a temporary, but only two registers exist. `n` and `p` are spilled once before the loop, then reloaded at each use. This is the cheapest way to make a small test exercise your spill hooks while bringing up a backend ([checklist](#backend-checklist)).

## 6. A Loop Containing a Call

```llvm
declare void @g()
define i32 @lc(ptr %p, i32 %n, i32 %k) {
entry:
  br label %loop
loop:
  %i = phi i32 [0, %entry], [%i.next, %latch]
  %acc = phi i32 [0, %entry], [%acc.next, %latch]
  ...                                   ; load %v = p[i]; acc += v
  %c0 = icmp eq i32 %v, %k
  br i1 %c0, label %cold, label %latch
cold:
  call void @g()
  br label %latch
latch:
  ...                                   ; i++; loop while i < n
exit:
  ret i32 %acc.next
}
```

Assembly:

```
lc:
	str	x30, [sp, #-64]!                // 8-byte Folded Spill
	stp	x24, x23, [sp, #16]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	mov	w19, w2
	mov	w20, w1
	mov	x21, x0
	mov	x23, xzr
	mov	w22, wzr
	b	.LBB0_2
.LBB0_1:                                // %latch
	add	x23, x23, #1
	add	w22, w22, w24
	cmp	w23, w20
	b.hs	.LBB0_4
.LBB0_2:                                // %loop
	ldr	w24, [x21, x23, lsl #2]
	cmp	w24, w19
	b.ne	.LBB0_1
	bl	g
	b	.LBB0_1
.LBB0_4:                                // %exit
	mov	w0, w22
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	...
	ret
```

**What to look for.** Every value live in the loop (`k`, `n`, `p`, `i`, `acc`, `v`) is also live across `bl g`, so none of them can sit in a caller-saved register. Greedy put all six in callee-saved `w19`–`x24`. That costs four save/restore pairs, once per call of `lc`, and **no** memory traffic inside the loop. Splitting around the call would add copies or reloads on every iteration that takes the call. With callee-saved registers free, the cost model ([Greedy: callee-saved registers](#regalloc-greedy)) prefers them. A loop with more live values than callee-saved registers would force splitting or spilling.

## 7. The Same Code at -O0

Example 1 at `-O0`. Before the Fast allocator:

```
%0:gpr32 = COPY $w0
%1:gpr32 = COPY $w1
%2:gpr32 = COPY $w2
%3:gpr32 = MADDWrrr %0, %1, $wzr
%4:gpr32 = ADDWrr %3, %2
$w0 = COPY %4
RET_ReallyLR implicit $w0
```

After `regallocfast`:

```
renamable $w8 = MADDWrrr killed renamable $w0, killed renamable $w1, $wzr
renamable $w0 = ADDWrr killed renamable $w8, killed renamable $w2
RET_ReallyLR implicit killed $w0
```

**What to look for.** No combiner ran, so `mul` and `add` stay separate (the `mul` is a `madd` with `wzr`). [Fast](#regalloc-fast) followed the copy chains and removed every copy. There is one block, so no slots were needed. With a branch, values crossing the block boundary would be stored and reloaded.

## Reproducing These

```
llc -mtriple=aarch64 -O2 file.ll -stop-before=greedy -o -
llc -mtriple=aarch64 -O2 file.ll -stop-after=virtregrewriter -o -
llc -mtriple=aarch64 -O2 file.ll -o -
llc -mtriple=aarch64 -O2 file.ll -o /dev/null -pass-remarks-missed=regalloc
llc -mtriple=aarch64 -O2 -stress-regalloc=2 file.ll -o -
llc -mtriple=aarch64 -O0 file.ll -stop-after=regallocfast -o -
```

See [Tooling and Debugging](#tooling) for more.