# Spilling and Splitting

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/InlineSpiller.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/InlineSpiller.cpp)
- [llvm/lib/CodeGen/SplitKit.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/SplitKit.cpp)
- [llvm/lib/CodeGen/CalcSpillWeights.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CalcSpillWeights.cpp)
- [llvm/lib/CodeGen/LiveRangeEdit.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/LiveRangeEdit.cpp)

</details>
When a value cannot stay in a register for its whole life, the allocator has three tools. It can **spill** it (keep it in a stack slot and load it before each use), **rematerialise** it (recompute it instead of loading it), or **split** it (cut its live range into pieces, so that only the pieces that do not fit go to memory).

## Purpose and Scope

This page introduces the three tools and the vocabulary. The details are on [Spill Weights](#spill-weights), [The Inline Spiller](#inline-spiller) and [Live Range Splitting](#splitkit).

## Spilling

Spilling interval `%v` means:

1. give `%v` a **stack slot** (a frame index, printed `%stack.N`);
2. after every definition of `%v`, insert a **store** to the slot;
3. before every use, insert a **load** from the slot into a brand-new, tiny virtual register;
4. delete `%v`. The tiny registers live for one instruction each, so they almost always fit.

Real output from the 24-load test (`-stop-after=virtregrewriter`, excerpt):

```
STRWui killed renamable $w8, %stack.11, 0 :: (store (s32) into %stack.11)
STRWui killed renamable $w8, %stack.2, 0 :: (store (s32) into %stack.2)
...
BL @g, csr_aarch64_aapcs, implicit-def dead $lr, implicit $sp, implicit-def $sp
renamable $w9 = LDRWui %stack.11, 0 :: (load (s32) from %stack.11)
renamable $w12 = LDRWui %stack.12, 0 :: (load (s32) from %stack.12)
```

Each loaded value was stored right after its load from `%p`, and is reloaded after the call just before the `add` that uses it. The stack section lists the slots as `type: spill-slot` with `offset: 0`. Real offsets are assigned later by prologue/epilogue insertion.

## Allocator Spills Versus Callee-saved Saves

Both show up as stores and loads around `sp`, and the assembly comments can say "Spill" for both. Tell them apart like this:

| | Allocator spill | Callee-saved save |
| --- | --- | --- |
| Inserted by | `InlineSpiller` (Greedy, Basic, PBQP) or Fast | Prologue/epilogue insertion |
| Where | Next to the definition and the uses of a value | Function entry and every return |
| In MIR after the rewriter | `STRWui ... %stack.N` (type `spill-slot`) | Not there yet; appears after `prologepilog` |
| Assembly comment (AArch64) | `4-byte Spill`, `4-byte Reload` (or `Folded` when the load/store optimiser pairs them) | `16-byte Folded Spill` on `stp x.., x..` at entry |
| Reported by `-pass-remarks-missed=regalloc` | Yes | No |

In the 24-load test, the remark says 13 spills and 13 reloads, which matches exactly the 13 `STRWui`/`LDRWui` pairs. The six `stp`/`ldp` pairs of `x19`–`x30` are callee-saved saves.

## Rematerialisation

If a value is cheap to recompute and its inputs are always available, for example a constant `mov w24, #11`, the spiller recomputes it before each use instead of storing and loading it. No stack slot is needed. That is what happened in the first spill experiment on the [walkthroughs](#aarch64-walkthroughs) page: constants stayed as `MOVi32imm` and nothing went to memory. Rematerialisation needs the target to mark such instructions `isReMaterializable` (see [TargetInstrInfo Hooks](#tii-hooks)).

## Folding

Some instructions can read an operand directly from memory (x86 `add eax, [rsp+8]`). Instead of a load plus the instruction, the spiller asks the target to **fold** the stack slot into the instruction (`foldMemoryOperandImpl`). AArch64 is a load/store architecture and folds very little; x86 folds a lot.

## Splitting

Spilling a long interval everywhere is wasteful if it only conflicts in one place, such as across one call or inside one hot loop. **Splitting** replaces `%v` with several smaller registers connected by `COPY`s:

```
before:   %v  live from A to Z
after:    %v1 live A..M,  %v2 = COPY %v1 at M,  %v2 live M..Z
```

Each piece is allocated separately. One piece may get a register, another may get a different register, and only a piece that still does not fit is spilled. Copies between pieces that end up in the same register are removed by the rewriter. Greedy is the only allocator that splits.

## How the Pieces Fit Together

```mermaid
flowchart TD
  G["Greedy selectOrSplit"] -->|"split"| SK["SplitAnalysis + SplitEditor<br/>(SplitKit.cpp)"]
  G -->|"spill"| IS["InlineSpiller"]
  SK --> LRE["LiveRangeEdit<br/>creates vregs, updates LiveIntervals"]
  IS --> LRE
  IS -->|"remat?"| RM["LiveRangeEdit::rematerializeAt"]
  IS -->|"fold?"| FO["TII::foldMemoryOperand"]
  IS -->|"store/load"| TII["TII::storeRegToStackSlot<br/>TII::loadRegFromStackSlot"]
  W["VirtRegAuxInfo<br/>spill weights + hints"] --> G
```

`LiveRangeEdit` is the shared helper. It creates new virtual registers derived from an original (`createFrom`), keeps `LiveIntervals` correct, deletes dead definitions, and tells the allocator about changes through callbacks (`LRE_CanEraseVirtReg`, `LRE_WillShrinkVirtReg`, `LRE_DidCloneVirtReg`).

**Sources:** [llvm/lib/CodeGen/LiveRangeEdit.cpp:55-426](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/LiveRangeEdit.cpp#L55-L426), [llvm/lib/CodeGen/RegAllocGreedy.cpp:370-412](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegAllocGreedy.cpp#L370-L412)