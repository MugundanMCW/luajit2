# Writing Register Allocation Support for a Custom Backend

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/Target/Target.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/Target.td)
- [llvm/include/llvm/CodeGen/TargetRegisterInfo.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetRegisterInfo.h)
- [llvm/include/llvm/CodeGen/TargetInstrInfo.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetInstrInfo.h)
- [llvm/lib/CodeGen/TargetPassConfig.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/TargetPassConfig.cpp)
- [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp)
- [llvm/lib/Target/AArch64/AArch64InstrInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.cpp)

</details>
You do **not** write a register allocator for a new backend. LLVM's allocators are target-independent and work for every target. What you write is the **description of your machine** that they consume: which registers exist, how they overlap, which are reserved or preserved across calls, and how to copy, save and restore a register. This section is the practical guide to that description.

## Purpose and Scope

This page is the roadmap. The sub-pages go through each part with AArch64 as the real reference and a small made-up "Toy" target for illustrative snippets (marked as such; Toy is not in LLVM).

| Page | You write |
| --- | --- |
| [9.1 Register Definitions in TableGen](#tablegen-registers) | `<Target>RegisterInfo.td`: registers, sub-registers, classes, allocation order; callee-saved lists in `<Target>CallingConv.td` |
| [9.2 TargetRegisterInfo Hooks](#tri-hooks) | `<Target>RegisterInfo.cpp`: reserved registers, callee-saved registers and masks, frame index elimination, hints |
| [9.3 TargetInstrInfo Hooks](#tii-hooks) | `<Target>InstrInfo.cpp`: copy, spill, reload, rematerialisation, folding |
| [9.4 Pass Pipeline Hooks](#pass-config-hooks) | `<Target>TargetMachine.cpp`: passes around allocation, allocator choice |
| [9.5 Bring-up Checklist and Common Failures](#backend-checklist) | Order of work, tests, and what each error means |

## What the Allocator Asks Your Target

Every question the allocator asks maps to one piece of your backend:

| Question | Answered by | Required for |
| --- | --- | --- |
| Which physical registers exist and how do they overlap? | TableGen `Register`, `SubRegIndex`, register units (generated) | Everything |
| Which registers may hold a value of this type / operand? | TableGen `RegisterClass`, instruction operand classes | Everything |
| Which order should I try them in? | Class member order, `AltOrders`, `AltOrderSelect` | Quality |
| Which registers may I never use? | `getReservedRegs` | Correctness |
| Which registers does a call destroy? | `getCallPreservedMask` (from `CalleeSavedRegs`) | Correctness |
| Which registers must this function save if it uses them? | `getCalleeSavedRegs` | Correctness |
| How do I copy register A to B? | `copyPhysReg` | Correctness |
| How do I store / load a register to a stack slot? | `storeRegToStackSlot`, `loadRegFromStackSlot` | Correctness at any register pressure |
| How do I turn a stack slot into an address? | `eliminateFrameIndex`, `getFrameRegister` (with frame lowering) | Correctness |
| Is this instruction cheap to recompute? | `isReMaterializable` (TableGen), `isReMaterializableImpl` | Quality |
| Can this instruction read from memory directly? | `foldMemoryOperandImpl` | Quality |
| Which register would this value like? | `getRegAllocationHints` | Quality |

The "correctness" rows are the minimum. With them, Fast works at `-O0` and Greedy works at `-O2`. The "quality" rows make the code good.

## The Data Flow

```mermaid
flowchart LR
  TD["Target.td + <Target>RegisterInfo.td<br/>+ <Target>CallingConv.td"] -->|"llvm-tblgen -gen-register-info"| GEN["<Target>GenRegisterInfo.inc<br/>register enums, classes, units,<br/>sub-reg tables, CSR save lists / masks"]
  GEN --> TRI["<Target>RegisterInfo<br/>(derives from <Target>GenRegisterInfo)"]
  TRI --> RA["Allocators, coalescer,<br/>LiveIntervals, rewriter"]
  TII["<Target>InstrInfo<br/>copy / spill / reload / remat"] --> RA
  PC["<Target>PassConfig<br/>pipeline hooks"] --> RA
  RA --> PEI["Prologue/Epilogue insertion<br/>+ <Target>FrameLowering"]
  TRI --> PEI
```

## Minimal Skeleton (Illustrative)

For a made-up target "Toy" with sixteen 32-bit registers `R0`–`R15`, `R15` the stack pointer and `R14` the link register. **This is an illustrative sketch, not LLVM source.**

```tablegen
// ToyRegisterInfo.td (illustrative)
class ToyReg<bits<16> Enc, string n> : Register<n> {
  let HWEncoding = Enc;
  let Namespace = "Toy";
}
foreach i = 0-15 in
  def R#i : ToyReg<i, "r"#i>, DwarfRegNum<[i]>;

def GPR : RegisterClass<"Toy", [i32], 32, (sequence "R%u", 0, 15)>;
```

```cpp
// ToyRegisterInfo.cpp (illustrative)
BitVector ToyRegisterInfo::getReservedRegs(const MachineFunction &MF) const {
  BitVector Reserved(getNumRegs());
  Reserved.set(Toy::R15);                 // stack pointer
  if (getFrameLowering(MF)->hasFP(MF))
    Reserved.set(Toy::R13);               // frame pointer
  return Reserved;
}
const MCPhysReg *
ToyRegisterInfo::getCalleeSavedRegs(const MachineFunction *) const {
  return CSR_Toy_SaveList;                // generated from ToyCallingConv.td
}
const uint32_t *
ToyRegisterInfo::getCallPreservedMask(const MachineFunction &,
                                      CallingConv::ID) const {
  return CSR_Toy_RegMask;                 // generated from ToyCallingConv.td
}
```

```cpp
// ToyInstrInfo.cpp (illustrative)
void ToyInstrInfo::copyPhysReg(MachineBasicBlock &MBB,
                               MachineBasicBlock::iterator I,
                               const DebugLoc &DL, Register Dst, Register Src,
                               bool KillSrc, bool RenamableDest,
                               bool RenamableSrc) const {
  BuildMI(MBB, I, DL, get(Toy::MOVrr), Dst)
      .addReg(Src, getKillRegState(KillSrc));
}
```

That is enough for straight-line `-O0` code with no spills. Spilling needs `storeRegToStackSlot`, `loadRegFromStackSlot` and `eliminateFrameIndex`; the sub-pages show each one. Check the exact current signatures in `TargetRegisterInfo.h` and `TargetInstrInfo.h` at your LLVM version: they change from release to release (for example, at the pinned commit `storeRegToStackSlot` takes a trailing `MachineInstr::MIFlag`).

## Where AArch64 Implements Each Piece

| Piece | AArch64 file and line |
| --- | --- |
| Register and class definitions | `AArch64RegisterInfo.td:13-261` |
| Callee-saved lists | `AArch64CallingConvention.td:594` (`CSR_AArch64_AAPCS`) |
| `getCalleeSavedRegs` | `AArch64RegisterInfo.cpp:72` |
| `getCallPreservedMask` | `AArch64RegisterInfo.cpp:271` |
| `getStrictlyReservedRegs`, `getReservedRegs` | `AArch64RegisterInfo.cpp:419`, `535` |
| `getFrameRegister`, `requiresRegisterScavenging`, `requiresFrameIndexScavenging` | `AArch64RegisterInfo.cpp:753-790` |
| `eliminateFrameIndex` | `AArch64RegisterInfo.cpp:978` |
| `getRegAllocationHints`, `shouldCoalesce` | `AArch64RegisterInfo.cpp:1191`, `1459` |
| `copyPhysReg` | `AArch64InstrInfo.cpp:6365` |
| `storeRegToStackSlot`, `loadRegFromStackSlot` | `AArch64InstrInfo.cpp:6400`, `6580` |
| `isLoadFromStackSlot`, `isStoreToStackSlot` | `AArch64InstrInfo.cpp:2852`, `2881` |
| `foldMemoryOperandImpl` | `AArch64InstrInfo.cpp:7154` |
| Pass config hooks | `AArch64TargetMachine.cpp:852-973` |

**Sources:** [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:72-1459](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L72-L1459), [llvm/lib/Target/AArch64/AArch64InstrInfo.cpp:2852-7154](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.cpp#L2852-L7154), [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:852-973](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L852-L973)