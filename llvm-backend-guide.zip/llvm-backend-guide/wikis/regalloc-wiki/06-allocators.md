# The Register Allocators

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/RegAllocFast.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegAllocFast.cpp)
- [llvm/lib/CodeGen/RegAllocBasic.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegAllocBasic.cpp)
- [llvm/lib/CodeGen/RegAllocGreedy.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegAllocGreedy.cpp)
- [llvm/lib/CodeGen/RegAllocPBQP.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegAllocPBQP.cpp)
- [llvm/lib/CodeGen/TargetPassConfig.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/TargetPassConfig.cpp)

</details>
LLVM ships four register allocators. They all produce the same kind of result (every virtual register in a physical register or a stack slot), but they differ in how much they look at before deciding, and so in compile time and code quality.

## Purpose and Scope

This page compares the four and explains how one is chosen. Each has its own page.

## Side by Side

| | [Fast](#regalloc-fast) | [Basic](#regalloc-basic) | [Greedy](#regalloc-greedy) | [PBQP](#regalloc-pbqp) |
| --- | --- | --- | --- | --- |
| `-regalloc=` | `fast` | `basic` | `greedy` | `pbqp` |
| Default for | `-O0` | nothing | `-O1` and above | nothing |
| Unit of work | One instruction, one block at a time | One whole live interval | One live interval, or a piece of one | The whole function at once |
| Uses `LiveIntervals` | No | Yes | Yes | Yes |
| Uses `LiveRegMatrix`, `VirtRegMap` | No | Yes | Yes | `VirtRegMap` only |
| Pipeline | Unoptimised (no coalescer, no scheduler) | Optimised | Optimised | Optimised |
| On conflict | Spill a value currently in a register | Spill lighter interference, else spill itself | Evict, split, then spill | Solver picks "spill" for some nodes |
| Splitting | No | No | Yes (region, block, local, instruction) | No |
| Writes physical registers into instructions | Itself | `VirtRegRewriter` | `VirtRegRewriter` | `VirtRegRewriter` |
| Compile time | Lowest | Low | Medium | Highest |

## Measured on One Example

The 24-load spill test from the [walkthroughs](#aarch64-walkthroughs), compiled with `llc -mtriple=aarch64 -O2 -regalloc=X` (counts from the assembly; "save/spill/reload lines" includes the 12 prologue/epilogue lines that save callee-saved registers):

| Allocator | Instructions | Save/spill/reload lines |
| --- | --- | --- |
| `fast` | 86 | 35 |
| `basic` | 83 | 32 |
| `greedy` | 83 | 32 |
| `pbqp` | 82 | 31 |

This is a straight-line function, so there is nothing to split and the optimising allocators are almost the same. `-regalloc=fast` at `-O2` also runs the unoptimised pipeline, which is part of why it is slightly worse. Differences become large in code with loops and calls, where Greedy's splitting keeps hot paths in registers.

## How the Allocator Is Chosen

```mermaid
flowchart TD
  A{"-regalloc= given?"} -->|"yes"| B["use it;<br/>optimised pipeline unless it is fast"]
  A -->|"no"| C{"opt level -O0?"}
  C -->|"yes"| D["createTargetRegisterAllocator(false)<br/>default: Fast"]
  C -->|"no"| E["createTargetRegisterAllocator(true)<br/>default: Greedy"]
```

A target can override `createTargetRegisterAllocator` to pick a different default, or override `addRegAssignAndRewriteOptimized` / `addRegAssignAndRewriteFast` to run several allocators in sequence (AMDGPU does this with register filters). See [Pass Pipeline Hooks](#pass-config-hooks).

**Sources:** [llvm/lib/CodeGen/TargetPassConfig.cpp:1393-1473](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/TargetPassConfig.cpp#L1393-L1473)

## Reading Order

1. [Fast](#regalloc-fast): see the problem in its simplest form.
2. [Basic](#regalloc-basic): see the shared framework used for real.
3. [Greedy](#regalloc-greedy): the allocator you will actually debug.
4. [PBQP](#regalloc-pbqp): an alternative model, if your target has unusual constraints.