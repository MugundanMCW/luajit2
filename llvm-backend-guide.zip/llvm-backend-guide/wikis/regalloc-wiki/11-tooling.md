# Tooling and Debugging

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/RegAllocGreedy.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegAllocGreedy.cpp)
- [llvm/lib/CodeGen/RegisterCoalescer.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegisterCoalescer.cpp)
- [llvm/lib/CodeGen/RegisterClassInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegisterClassInfo.cpp)
- [llvm/lib/CodeGen/TargetPassConfig.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/TargetPassConfig.cpp)

</details>
Most register allocation questions can be answered with a release `llc` by looking at MIR before and after each pass. The detailed allocator trace (`-debug-only=regalloc`) needs a build with assertions.

## Purpose and Scope

Which options exist, which work in which kind of build, and a workflow for the common questions: why did this spill, why is this copy still here, and why did allocation fail.

## Release Build or Assertions Build

Every option below was tried with the release `llc` built from the pinned commit (LLVM 24.0.0git, "Optimized build"):

| Option | Release `llc` | Notes |
| --- | --- | --- |
| `-stop-before=P`, `-stop-after=P` | Works | Print MIR as a `.mir` file and stop |
| `-print-before=P`, `-print-after=P` | Works | Print MIR with slot indexes (`32B`, `48B`, ...) and keep going |
| `-run-pass=P1,P2` | Works | Run only these passes on a `.mir` input |
| `-verify-machineinstrs` | Works | Run the machine verifier after every pass |
| `-verify-regalloc` | Works | Extra verification inside the allocator |
| `-pass-remarks-missed=regalloc` | Works | Greedy's spill and reload counts per function and loop |
| `-regalloc=fast\|basic\|greedy\|pbqp` | Works | Choose the allocator ([which pipeline](#pipeline)) |
| `-stress-regalloc=N` | Works | Limit every class to `N` registers |
| `-join-liveintervals=false` | Works | Disable the coalescer |
| `-split-spill-mode=default\|size\|speed`, `-lcr-max-depth=N` | Work | Greedy tuning ([Greedy options](#regalloc-greedy)) |
| `-enable-subreg-liveness` | Accepted | Force sub-register liveness on |
| `-time-passes` | Works | Time spent in each pass, including the allocator |
| `-stats` | Accepted | Statistics are only collected in builds with statistics enabled |
| `-debug-pass=Structure` | Works | List the passes that run |
| `-debug-only=regalloc` (and `-debug-only=regalloc,register-coalescer,...`) | **Not available** ("Unknown command line argument") | Needs an assertions build: configure with `-DLLVM_ENABLE_ASSERTIONS=ON` |

## Workflow 1: Why Was This Value Spilled?

1. Count spills: `llc ... -pass-remarks-missed=regalloc -o /dev/null`. No remark means Greedy did not spill. Any `Spill` comments in the assembly are then callee-saved saves ([how to tell](#spilling-splitting)).
2. Look at the input to the allocator: `-stop-before=greedy`. How many values are live at the hot point? Do they cross calls?
3. Look at its output: `-stop-after=virtregrewriter`. Find the `STR...ui %stack.N` and `LDR...ui %stack.N` instructions and the registers involved.
4. In an assertions build: `-debug-only=regalloc`. It prints every `selectOrSplit` decision, with the interval, its weight, the stage, and whether it was assigned, evicted, split or spilled.
5. Experiments: `-regalloc=basic` (no splitting) and `-split-spill-mode=...`. Also compare `-O2` with and without the scheduler's pressure tracking, by changing the input.

## Workflow 2: Why Is This Copy Still Here?

1. `-stop-after=register-coalescer`: is the copy still there? If yes, the coalescer refused it. Usual reasons are physical-register copies (kept as hints), no common sub-class, or a `shouldCoalesce` veto ([coalescer](#coalescer)).
2. `-stop-after=virtregrewriter`: does the copy now have different registers on each side? Then the hint was broken, usually because the hinted register is busy (example: `mov w0, w8` in [the loop walkthrough](#aarch64-walkthroughs)).
3. If the copy came from splitting, it sits at a split boundary: a block edge or around a call.

## Workflow 3: Why Did Allocation Fail?

`error: ran out of registers during register allocation` or `error: inline assembly requires more registers than available`:

1. Find the instruction: the error names the function; with an assertions build `-debug-only=regalloc` shows the last interval.
2. Check that instruction's operand constraints. Do too many operands need the same small class at once? Is there an early-clobber definition plus many uses?
3. Check `getReservedRegs`: did a recent change reserve too much ([checklist](#backend-checklist))?
4. Try `-regalloc=basic` and `-regalloc=pbqp`. If every allocator fails, the constraints are impossible. If only Greedy fails, see the last-chance recoloring limits (`-lcr-max-depth`, `-lcr-max-interf`).

## Workflow 4: Reduce a Bug to a MIR Test

```
llc -mtriple=aarch64 -O2 bug.ll -stop-before=greedy -o bug.mir
# edit bug.mir down to the smallest function that still fails
llc -mtriple=aarch64 -run-pass=greedy,virtregrewriter -verify-machineinstrs bug.mir -o -
```

Tried at the pinned commit on the loop example: the `.mir` round trip produced the same allocation as the full pipeline (`renamable $w10 = LDRWroX renamable $x0, renamable $x9, 0, 1`). Running just `-run-pass=greedy` leaves virtual registers in the output, assigned in `VirtRegMap` but not yet rewritten. Add `virtregrewriter` to see physical registers.

Turn it into a regression test with `llvm/utils/update_mir_test_checks.py`.

## Reading MIR Quickly

| You see | It means |
| --- | --- |
| `%5:gpr32` | Virtual register 5, class `gpr32` |
| `%15.sub_32` | The `sub_32` part of `%15` |
| `$w0`, `$x19` | Physical registers |
| `renamable $w8` | Assigned by the allocator; may be renamed later |
| `killed`, `dead`, `undef` | Last use; never-read definition; value does not matter ([flags](#registers-basics)) |
| `csr_aarch64_aapcs` on a call | Register mask: registers outside it are clobbered |
| `%stack.3` | Frame index; `type: spill-slot` in the `stack:` section means an allocator spill slot |
| `32B` before an instruction | Slot index (only in `-print-*` output; [liveness](#liveness)) |
| `liveins: $w1, $x0` | Physical registers live into the block (after the rewriter) |
| `TiedOpsRewritten`, `NoPHIs`, `NoVRegs` | Function properties: which preparation steps have happened |