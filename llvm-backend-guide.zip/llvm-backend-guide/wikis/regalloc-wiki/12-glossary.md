# Glossary and Where Do I Look

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/CodeGen/Register.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/Register.h)
- [llvm/include/llvm/CodeGen/SlotIndexes.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/SlotIndexes.h)
- [llvm/include/llvm/CodeGen/RegAllocEvictionAdvisor.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/RegAllocEvictionAdvisor.h)

</details>
Short definitions of every term used in this wiki, with a link to the page that explains it, followed by a table that maps common questions to the code to read.

## Purpose and Scope

A reference page. Terms are in alphabetical order.

## Glossary

| Term | Meaning | Page |
| --- | --- | --- |
| **Allocation order** | The order in which an allocator tries physical registers for a class: hints first, then the class order with reserved registers removed and callee-saved registers last | [Framework](#framework) |
| **AllocationPriority** | TableGen field (0–31) that pushes a register class earlier in Greedy's queue | [TableGen](#tablegen-registers) |
| **Callee-saved register** | Preserved across calls; a function that uses it must save and restore it | [Registers](#registers-basics) |
| **Caller-saved (clobbered) register** | Destroyed by calls; values live across a call cannot stay in one | [Registers](#registers-basics) |
| **Cascade number** | Greedy's counter that prevents eviction loops | [Greedy](#regalloc-greedy) |
| **Coalescing** | Merging the source and destination of a `COPY` into one register so the copy disappears | [Coalescer](#coalescer) |
| **Complement** | Interval 0 in `SplitEditor`: everything not given to a new split interval | [Splitting](#splitkit) |
| **Copy hint** | A preferred register derived from a copy to or from it | [Spill weights](#spill-weights) |
| **Early-clobber** | A definition that is written before the instruction's uses are read, so it cannot share a register with them | [Liveness](#liveness) |
| **Edge bundle** | A set of block boundaries that must agree on register-or-memory for a value; used by region splitting | [Splitting](#splitkit) |
| **Eviction** | Unassigning a lower-priority interval so the current one can take its register; the evicted interval is requeued | [Greedy](#regalloc-greedy) |
| **Frame index** | Abstract stack slot number (`%stack.N`) replaced by an address in prologue/epilogue insertion | [Rewriting](#rewriting-post-ra) |
| **Identity copy** | `$r = COPY $r`; deleted by the rewriter | [Rewriting](#rewriting-post-ra) |
| **Interference** | Two registers live at the same point with different values; they cannot share a physical register | [Liveness](#liveness) |
| **Lane mask** | Bit set describing which parts of a register a sub-register index covers | [Registers](#registers-basics) |
| **Live interval** | `LiveInterval`: the set of program points where a virtual register is live, as segments plus value numbers | [Liveness](#liveness) |
| **LiveRegMatrix** | Per-register-unit record of which virtual registers are assigned where; answers interference queries | [Framework](#framework) |
| **Local interval** | An interval contained in one basic block | [Greedy](#regalloc-greedy) |
| **MIR** | Machine IR: `MachineInstr`s in `MachineBasicBlock`s | [Overview](#overview) |
| **PHI-def** | A value number defined at a block start where several incoming values merge | [Liveness](#liveness) |
| **Physical register** | A real hardware register (`$w0`) | [Registers](#registers-basics) |
| **Region split** | Greedy split that keeps a value in one register over a set of blocks | [Splitting](#splitkit) |
| **Register class** | Set of interchangeable physical registers a virtual register may use | [Registers](#registers-basics) |
| **Register mask (regmask)** | Call operand listing preserved registers; all others are clobbered | [Registers](#registers-basics) |
| **Register scavenger** | Finds a free physical register after allocation, spilling to an emergency slot if needed | [TRI hooks](#tri-hooks) |
| **Register unit** | Smallest piece of register state never shared in part; physical liveness and interference are tracked per unit | [Registers](#registers-basics) |
| **Rematerialisation** | Recomputing a cheap value instead of storing and reloading it | [Inline spiller](#inline-spiller) |
| **Reserved register** | Never allocated (`sp`, `wzr`, frame pointer when used, ...) | [TRI hooks](#tri-hooks) |
| **Rewriter** | `VirtRegRewriter`: replaces virtual registers with their assigned physical registers | [Rewriting](#rewriting-post-ra) |
| **Slot index** | Position number of an instruction; four slots per instruction (B, e, r, d), 16 apart | [Liveness](#liveness) |
| **Snippet** | A tiny split piece connected only by copies, spilled together with its sibling | [Inline spiller](#inline-spiller) |
| **Spill** | Keeping a value in a stack slot, with a store after each definition and a load before each use | [Spilling](#spilling-splitting) |
| **Spill weight** | Estimated cost of spilling an interval: weighted uses divided by length | [Spill weights](#spill-weights) |
| **Split** | Cutting an interval into pieces joined by copies | [Splitting](#splitkit) |
| **Stage** | Greedy's per-interval progress: `RS_New`, `RS_Assign`, `RS_Split`, `RS_Split2`, `RS_Spill`, `RS_Done` | [Greedy](#regalloc-greedy) |
| **Sub-register** | Named part of a register (`sub_32` of `x0` is `w0`) | [Registers](#registers-basics) |
| **Tied operand** | A use that must be in the same register as a definition; handled by two-address lowering | [Two-address](#phi-two-address) |
| **Value number** | `VNInfo`: one definition of a register; lets liveness distinguish values | [Liveness](#liveness) |
| **Virtual register** | Unlimited register name created by instruction selection (`%5`) | [Registers](#registers-basics) |
| **VirtRegMap** | Records the physical register or stack slot chosen for each virtual register | [Framework](#framework) |

## Where Do I Look?

| Question | Look at |
| --- | --- |
| Which passes run around allocation, and in what order? | `TargetPassConfig::addOptimizedRegAlloc`, `addFastRegAlloc` ([Pipeline](#pipeline)) |
| Why does this value use `w19` instead of `w8`? | It is live across a call; regmask on the call ([Walkthrough 2](#aarch64-walkthroughs)) |
| Why is a copy still there after allocation? | Coalescer output, then hints ([Tooling](#tooling)) |
| Why was this spilled? | `-pass-remarks-missed=regalloc`, then `-stop-after=virtregrewriter` ([Tooling](#tooling)) |
| Why are these `stp`/`ldp` at entry? | Callee-saved saves from prologue insertion, not spills ([Spilling](#spilling-splitting)) |
| How does Greedy decide what to do? | `RAGreedy::selectOrSplitImpl` ([Greedy](#regalloc-greedy)) |
| How is spill code inserted? | `InlineSpiller::spillAroundUses` and your `storeRegToStackSlot` ([Inline spiller](#inline-spiller)) |
| What must my new backend implement? | [Custom backend](#custom-backend) and its [checklist](#backend-checklist) |
| "ran out of registers" | Operand constraints, reserved set, class sizes ([Checklist](#backend-checklist)) |
| `Target didn't implement ...` | The named `TargetInstrInfo` hook ([TII hooks](#tii-hooks)) |
| Liveness verifier errors after my pass | Update `LiveIntervals` ([Liveness](#liveness)) |