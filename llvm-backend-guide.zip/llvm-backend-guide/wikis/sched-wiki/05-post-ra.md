# Post-RA Scheduling

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/MachineScheduler.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp)
- [llvm/lib/CodeGen/PostRASchedulerList.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PostRASchedulerList.cpp)
- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)

</details>
After register allocation and frame lowering, the code contains spill code, prologue and epilogue, and expanded pseudos that the pre-RA scheduler never saw. A second scheduling pass can reorder this final code. Register pressure no longer matters (all registers are physical), so the post-RA scheduler cares about latency and execution resources only, and it must respect the extra anti and output dependencies that physical registers create.

## Purpose and Scope

The two post-RA schedulers, how a target picks one, and what AArch64 does.

## Two Implementations

| | Post-RA machine scheduler | Old post-RA list scheduler |
| --- | --- | --- |
| Pass | `postmisched` | `post-RA-sched` |
| Code | `PostMachineSchedulerImpl::run` (`MachineScheduler.cpp:588`), `ScheduleDAGMI`, `PostGenericScheduler` | `SchedulePostRATDList` (`PostRASchedulerList.cpp`) |
| Direction | Configurable (`-misched-postra-direction`, line 190) | Top-down only (`ListScheduleTopDown`, line 544) |
| Enabled by | `enablePostRAMachineScheduler()` / `-enable-post-misched` (line 479) | `enablePostRAScheduler()` and opt level, or `-post-RA-scheduler` (line 56) |
| Strategy hooks | `createPostMachineScheduler`, `overridePostRASchedPolicy` | Hazard recognizer, anti-dependence breaker |

`PostGenericScheduler::tryCandidate` (line 4375) uses a shorter heuristic list than the pre-RA version: no pressure checks, but stall cycles, clustering, resources and latency.

**Sources:** [llvm/lib/CodeGen/MachineScheduler.cpp:479-483](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L479-L483), [llvm/lib/CodeGen/MachineScheduler.cpp:588-610](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L588-L610), [llvm/lib/CodeGen/MachineScheduler.cpp:190-191](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L190-L191), [llvm/lib/CodeGen/MachineScheduler.cpp:4375-4523](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L4375-L4523), [llvm/lib/CodeGen/PostRASchedulerList.cpp:53-56](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PostRASchedulerList.cpp#L53-L56), [llvm/lib/CodeGen/PostRASchedulerList.cpp:270-283](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PostRASchedulerList.cpp#L270-L283), [llvm/lib/CodeGen/PostRASchedulerList.cpp:544](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PostRASchedulerList.cpp#L544)

## How the Old Scheduler Is Enabled

```cpp
static bool enablePostRAScheduler(const TargetSubtargetInfo &ST,
                                  CodeGenOptLevel OptLevel) {
  // Check for explicit enable/disable of post-ra scheduling.
  if (EnablePostRAScheduler.getPosition() > 0)
    return EnablePostRAScheduler;

  return ST.enablePostRAScheduler() &&
         OptLevel >= ST.getOptLevelToEnablePostRAScheduler();
}
```

## AArch64's Choice

AArch64 replaces the old pass with the machine-scheduler version in its pass config constructor:

```cpp
  AArch64PassConfig(AArch64TargetMachine &TM, PassManagerBase &PM)
      : TargetPassConfig(TM, PM) {
    if (TM.getOptLevel() != CodeGenOptLevel::None)
      substitutePass(&PostRASchedulerID, &PostMachineSchedulerID);
```

and provides its own post-RA strategy, plus macro fusion again because some fusible pairs only appear after pseudo expansion:

```cpp
ScheduleDAGInstrs *
AArch64TargetMachine::createPostMachineScheduler(MachineSchedContext *C) const {
  const AArch64Subtarget &ST = C->MF->getSubtarget<AArch64Subtarget>();
  ScheduleDAGMI *DAG = createSchedPostRA<AArch64PostRASchedStrategy>(C);
  if (ST.hasFusion()) {
    // Run the Macro Fusion after RA again since literals are expanded from
    // pseudos then (v. addPreSched2()).
    DAG->addMutation(createAArch64MacroFusionDAGMutation());
    return DAG;
  }
```

Whether the old list scheduler would run for a CPU depends on the subtarget's `enablePostRAScheduler()`, which AArch64 forwards to `usePostRAScheduler()`. That accessor is not written by hand in `AArch64Subtarget.h`/`.cpp`; it comes from the TableGen-generated subtarget (a feature bit), and this page does not trace which CPUs set it. The `SchedMachineModel` record also has a `PostRAScheduler` bit (see [The Scheduling Model](#sched-model)).

**Sources:** [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:538-550](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L538-L550), [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:582-587](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L582-L587), [llvm/lib/Target/AArch64/AArch64Subtarget.h:161](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Subtarget.h#L161), [llvm/include/llvm/Target/TargetSchedule.td:88](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetSchedule.td#L88)

## Effect

In the [walkthrough](#aarch64-walkthroughs), `-mcpu=cortex-a57`: with both schedulers off the two loads `ldr x11, [x0, #16]` and `ldr x12, [x1, #16]` stay next to each other after the `mul`; with only the post-RA scheduler on, `ldr x12` is hoisted above the second `ldp` so its 4-cycle latency overlaps the other loads.