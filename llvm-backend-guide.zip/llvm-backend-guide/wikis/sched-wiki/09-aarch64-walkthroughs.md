# AArch64 Walkthroughs

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)
- [llvm/lib/Target/AArch64/AArch64SchedA57.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64SchedA57.td)

</details>
One small function compiled with the real `llc` (LLVM 24.0.0git release build at `a2171756`) using `-O2 -mtriple=aarch64-linux-gnu -mcpu=cortex-a57`, under four scheduler settings. The point is to show which pass changed what, and also that later passes can hide a scheduler's effect.

## Purpose and Scope

The pre-RA scheduler's effect on MIR, the post-RA scheduler's effect on assembly, and why the final code with only the pre-RA scheduler switched off is the same as the default.

## The Function

```llvm
define i64 @dot(ptr %a, ptr %b) {
  ; loads a[0..2], b[0..2]; returns a0*b0 + a1*b1 + a2*b2
  ...
}
```

## 1. Pre-RA Scheduler: MIR Before and After

`-stop-before=machine-scheduler`:

```text
    %2:gpr64 = LDRXui %0, 0 :: (load (s64) from %ir.a)
    %3:gpr64 = LDRXui %1, 0 :: (load (s64) from %ir.b)
    %5:gpr64 = LDRXui %0, 1 :: (load (s64) from %ir.pa1)
    %6:gpr64 = LDRXui %1, 1 :: (load (s64) from %ir.pb1)
    %7:gpr64 = MADDXrrr %5, %6, $xzr
    %8:gpr64 = LDRXui %0, 2 :: (load (s64) from %ir.pa2)
    %9:gpr64 = LDRXui %1, 2 :: (load (s64) from %ir.pb2)
    %11:gpr64 = MADDXrrr %2, %3, %7
    %12:gpr64 = MADDXrrr %8, %9, %11
```

`-stop-after=machine-scheduler`:

```text
    %2:gpr64 = LDRXui %0, 0 :: (load (s64) from %ir.a)
    %5:gpr64 = LDRXui %0, 1 :: (load (s64) from %ir.pa1)
    %3:gpr64 = LDRXui %1, 0 :: (load (s64) from %ir.b)
    %6:gpr64 = LDRXui %1, 1 :: (load (s64) from %ir.pb1)
    %7:gpr64 = MADDXrrr %5, %6, $xzr
    %8:gpr64 = LDRXui %0, 2 :: (load (s64) from %ir.pa2)
    %9:gpr64 = LDRXui %1, 2 :: (load (s64) from %ir.pb2)
    %11:gpr64 = MADDXrrr %2, %3, %7
    %12:gpr64 = MADDXrrr %8, %9, %11
```

The only change: `a[1]` moved up next to `a[0]`, so the two adjacent loads from `%0` are together, and the two from `%1` likewise. That is the load-clustering mutation added in `createMachineScheduler` (Cluster edges win over latency in `tryCandidate`; see [MachineScheduler](#machine-scheduler)). The rest of the order already satisfied the model.

**Sources:** [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:524-536](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L524-L536)

## 2. Final Assembly Under Four Settings

| Setting | Assembly body |
| --- | --- |
| Default (both schedulers) | `ldp x8, x9, [x0]` / `ldr x12, [x1, #16]` / `ldp x10, x11, [x1]` / `mul x9, x9, x11` / `ldr x11, [x0, #16]` / `madd x8, x8, x10, x9` / `madd x0, x11, x12, x8` |
| `-enable-misched=false` | `ldp x8, x10, [x0]` / `ldr x12, [x1, #16]` / `ldp x9, x11, [x1]` / `mul x10, x10, x11` / `ldr x11, [x0, #16]` / `madd x8, x8, x9, x10` / `madd x0, x11, x12, x8` |
| `-enable-misched=false -enable-post-misched=false` | `ldp x8, x10, [x0]` / `ldp x9, x11, [x1]` / `mul x10, x10, x11` / `ldr x11, [x0, #16]` / `ldr x12, [x1, #16]` / `madd x8, x8, x9, x10` / `madd x0, x11, x12, x8` |

Observations:

- **Default vs. pre-RA off:** same instruction order, different register numbers. The pre-RA scheduler's clustering did not change the final code here, because the load/store optimizer (`aarch64-ldst-opt`, which runs after allocation) forms the `ldp` pairs either way. Its effect is visible in MIR and in register choice only.
- **Post-RA on vs. off:** with `postmisched` disabled, `ldr x12, [x1, #16]` stays after the `mul`; with it enabled, that load is hoisted above the second `ldp` so its 4-cycle latency (`WriteLD` → `A57Write_4cyc_1L`) overlaps the other loads before the final `madd` needs it.

**Sources:** [llvm/lib/Target/AArch64/AArch64SchedA57.td:87](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64SchedA57.td#L87), [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:538-550](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L538-L550)

## Lesson

To see what a scheduler did, compare the MIR right before and right after that pass, not just the final assembly: later passes (load/store pairing, the other scheduler, register allocation) can make a scheduler's change invisible or even undo it.

## Reproducing

```text
llc -O2 -mtriple=aarch64-linux-gnu -mcpu=cortex-a57 sched.ll -o -
llc ... -enable-misched=false sched.ll -o -
llc ... -enable-misched=false -enable-post-misched=false sched.ll -o -
llc ... -stop-before=machine-scheduler sched.ll -o before.mir
llc ... -stop-after=machine-scheduler sched.ll -o after.mir
```

The regalloc wiki's [AArch64 walkthroughs](../regalloc-wiki/regalloc-wiki.html#aarch64-walkthroughs) show what allocation does with scheduled MIR.