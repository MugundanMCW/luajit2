# Instruction Scheduling Overview

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/MachineScheduler.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp)
- [llvm/lib/CodeGen/PostRASchedulerList.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PostRASchedulerList.cpp)
- [llvm/include/llvm/Target/TargetSchedule.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetSchedule.td)
- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)

</details>
Instruction scheduling reorders instructions inside a region (usually a basic block) without changing what the program computes. Its goals are to hide latency (start long operations early), to keep execution units busy, and to keep register pressure low enough that the allocator does not have to spill. LLVM schedules up to three times, and all of them read the same per-CPU **scheduling model** written in TableGen.

## Purpose and Scope

This wiki covers the scheduling DAG, the machine scheduler (before register allocation), register pressure tracking, post-RA scheduling, the scheduling model language, how a target wires a model to its CPUs, a custom-backend guide and real AArch64 output. Where scheduling fits in a whole backend is on the [bring-up wiki](../bringup-wiki/bringup-wiki.html#scheduling).

## Where Scheduling Runs

```mermaid
flowchart LR
    ISEL["SelectionDAG scheduler<br/>(orders DAG nodes into MachineInstrs)"] --> SSA["SSA machine passes"]
    SSA --> MS["machine-scheduler<br/>pre-RA, ScheduleDAGMILive"]
    MS --> RA["register allocation"]
    RA --> PEI["prolog-epilog"]
    PEI --> PMS["postmisched<br/>post-RA, ScheduleDAGMI"]
```

| Scheduler | Pass | When | Main concern | Page |
| --- | --- | --- | --- | --- |
| SelectionDAG scheduler | part of instruction selection | Linearizing the selected DAG | A legal order; little else on targets using the machine scheduler | SelectionDAG [scheduling and emission](../selectiondag-wiki.html#scheduling-emission) |
| Machine scheduler | `machine-scheduler` | After coalescing, before allocation | Latency and register pressure together | [MachineScheduler](#machine-scheduler) |
| Post-RA machine scheduler | `postmisched` | After PEI | Latency and resources with physical registers | [Post-RA Scheduling](#post-ra) |
| Old post-RA list scheduler | `post-RA-sched` | Same slot | Replaced by `postmisched` on AArch64 | [Post-RA Scheduling](#post-ra) |

From the AArch64 pipeline (`llc -O2 -mtriple=aarch64-linux-gnu -mcpu=cortex-a57 -debug-pass=Structure`): `... -register-coalescer -rename-independent-subregs -machine-scheduler -aarch64-post-coalescer ... -greedy ...` and later `... -aarch64-ldst-opt ... -postmisched ...`. The regalloc wiki's [pipeline](../regalloc-wiki/regalloc-wiki.html#pipeline) and [preparation](../regalloc-wiki/regalloc-wiki.html#preparation) pages show the passes around the pre-RA scheduler.

The two machine-scheduler passes are entered at `MachineSchedulerImpl::run` and `PostMachineSchedulerImpl::run`; both build a scheduler with the target's factory and call `scheduleRegions`.

**Sources:** [llvm/lib/CodeGen/MachineScheduler.cpp:540-610](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L540-L610), [llvm/lib/CodeGen/MachineScheduler.cpp:810](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L810), [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:582-587](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L582-L587)

## The Pieces

```mermaid
flowchart TD
    TD["SchedMachineModel (.td)<br/>ProcResource, WriteRes, ReadAdvance, InstRW"] -->|"-gen-subtarget"| MCS["MCSchedModel tables"]
    MCS --> TSM["TargetSchedModel<br/>latency / resource queries"]
    SDI["ScheduleDAGInstrs<br/>SUnits + SDep edges"] --> MS["ScheduleDAGMI(Live)"]
    TSM --> SDI
    MS --> STRAT["MachineSchedStrategy<br/>GenericScheduler / PostGenericScheduler"]
    RP["RegPressureTracker"] --> STRAT
    MUT["DAG mutations<br/>(clustering, macro fusion)"] --> MS
```

## Pages

1. [The Scheduling DAG](#schedule-dag)
2. [MachineScheduler and GenericScheduler](#machine-scheduler)
3. [Register Pressure Tracking](#register-pressure)
4. [Post-RA Scheduling](#post-ra)
5. [The Scheduling Model](#sched-model)
6. [Wiring a Model to a Target](#wiring)
7. [Custom Backend Guide](#custom-backend)
8. [AArch64 Walkthroughs](#aarch64-walkthroughs)
9. [Tooling and Glossary](#tooling-glossary)