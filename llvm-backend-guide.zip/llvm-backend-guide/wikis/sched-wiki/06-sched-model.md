# The Scheduling Model

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/Target/TargetSchedule.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetSchedule.td)
- [llvm/include/llvm/MC/MCSchedule.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCSchedule.h)
- [llvm/lib/CodeGen/TargetSchedule.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/TargetSchedule.cpp)
- [llvm/lib/Target/AArch64/AArch64SchedA57.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64SchedA57.td)

</details>
A scheduling model describes one CPU: how many micro-ops it issues per cycle, which execution units (processor resources) it has, and for each kind of instruction which units it uses and how long its result takes. It is written in TableGen with the classes from `TargetSchedule.td`; `-gen-subtarget` turns it into `MCSchedModel` tables, and `TargetSchedModel` answers latency and resource questions from them.

## Purpose and Scope

The per-operand model (the one all current AArch64 CPUs use): machine parameters, resources, `SchedWrite`/`SchedRead` types, `WriteRes`, `ReadAdvance`, `InstRW`, `SchedAlias`, and variants. Itineraries, the older model, are mentioned at the end.

## Two Levels

```mermaid
flowchart LR
    I["Instruction record<br/>Sched&lt;[WriteI, ReadI, ReadI]&gt;"] --> T["target-wide types<br/>SchedWrite / SchedRead"]
    T -->|"per CPU: WriteRes / SchedAlias / ReadAdvance"| R["ProcResources + latency"]
    I -->|"per CPU override: InstRW"| R
```

Instructions name abstract types once; each CPU model maps the types to costs. An `InstRW` overrides the mapping for specific instructions on one CPU.

## Machine Parameters

```tablegen
class SchedMachineModel {
  int IssueWidth = -1; // Max micro-ops that may be scheduled per cycle.
  int MicroOpBufferSize = -1; // Max micro-ops that can be buffered.
  int LoopMicroOpBufferSize = -1; // Max micro-ops that can be buffered for
  ...
  int LoadLatency = -1; // Cycles for loads to access the cache.
  int HighLatency = -1; // Approximation of cycles for "high latency" ops.
  int MispredictPenalty = -1; // Extra cycles for a mispredicted branch.
  ...
  bit PostRAScheduler = false; // Enable Post RegAlloc Scheduler pass.
  ...
  bit CompleteModel = true;
```

`-1` means "use the default". `MicroOpBufferSize = 0` models an in-order core (the scheduler must avoid stalls), a large value an out-of-order core. `CompleteModel` makes TableGen check that every instruction has scheduling information. `NoSchedModel` (line 127) is the empty default. The generated fields appear in `MCSchedModel` (`MCSchedule.h:273`: `IssueWidth` 285, `MicroOpBufferSize` 302, `LoadLatency` 314, `CompleteModel` 331).

**Sources:** [llvm/include/llvm/Target/TargetSchedule.td:76-127](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetSchedule.td#L76-L127), [llvm/include/llvm/MC/MCSchedule.h:273-331](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCSchedule.h#L273-L331)

## The Classes

| Class | Line in `TargetSchedule.td` | Purpose |
| --- | --- | --- |
| `ProcResource<N>` | 197 | An execution unit with N copies |
| `ProcResGroup<[...]>` | 200 | A set of units any of which can be used |
| `SchedWrite` / `SchedRead` | 225 / 229 | Target-wide abstract operand types |
| `WriteRes<Write, [units]>` | 310 | Map a `SchedWrite` to units and `Latency` for this model |
| `SchedWriteRes<[units]>` | 318 | An anonymous write type, used with `InstRW` |
| `ReadAdvance<Read, N, [writes]>` | 347 | Operand read N cycles late (forwarding), optionally only from given writes |
| `SchedReadAdvance` | 355 | Anonymous read type |
| `SchedVar` / `SchedVariant` / `SchedWriteVariant` | 426 / 434 / 447 | Choose a write type by a predicate on the instruction |
| `InstRW<[rw...], (instrs ...)>` | 464 | Override types for specific instructions |
| `ItinRW` | 477 | Map itinerary classes to types |
| `SchedAlias<Match, Alias>` | 490 | Make a type an alias of another for this model |

**Sources:** [llvm/include/llvm/Target/TargetSchedule.td:134-490](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetSchedule.td#L134-L490)

## Cortex-A57 Example

```tablegen
def CortexA57Model : SchedMachineModel {
  let IssueWidth        =   3; // 3-way decode and dispatch
  let MicroOpBufferSize = 128; // 128 micro-op re-order buffer
  let LoadLatency       =   4; // Optimistic load latency
  let MispredictPenalty =  14; // Fetch + Decode/Rename/Dispatch + Branch
  ...
  let LoopMicroOpBufferSize = 16;
  let CompleteModel = 1;
  ...
def A57UnitI : ProcResource<2>;  // Type I micro-ops
def A57UnitM : ProcResource<1>;  // Type M micro-ops
def A57UnitL : ProcResource<1>;  // Type L micro-ops
...
  def A57UnitV : ProcResGroup<[A57UnitX, A57UnitW]>;    // Type V micro-ops
...
def : SchedAlias<WriteLD,    A57Write_4cyc_1L>;
...
def : WriteRes<WriteFMul, [A57UnitV]> { let Latency = 5;}
...
// Forwarding logic is only modeled for multiply and accumulate
def : ReadAdvance<ReadI,       0>;
...
def : ReadAdvance<ReadIMA,     2, [WriteIM32, WriteIM64]>;
...
def : InstRW<[A57Write_6cyc_1M], (instrs SMULHrr, UMULHrr)>;
```

Reading it: a plain load is a 4-cycle use of the load unit; the accumulator input of a multiply-accumulate (`ReadIMA`) is read 2 cycles late when it comes from another multiply, which is why chains of `madd` are cheap; `SMULH`/`UMULH` get a specific 6-cycle cost. Records are wrapped in `let SchedModel = CortexA57Model in { ... }` so they apply only to this model.

**Sources:** [llvm/lib/Target/AArch64/AArch64SchedA57.td:23-61](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64SchedA57.td#L23-L61), [llvm/lib/Target/AArch64/AArch64SchedA57.td:85-120](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64SchedA57.td#L85-L120), [llvm/lib/Target/AArch64/AArch64SchedA57.td:157](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64SchedA57.td#L157)

## How the Scheduler Reads It

`TargetSchedModel` (initialized in `init`, `TargetSchedule.cpp:43`) wraps the generated tables. `hasInstrSchedModel` (35) tells whether a per-operand model exists; `getNumMicroOps` (91) and `computeOperandLatency` (169) are what the DAG builder and `SchedBoundary` call. The generated tables are arrays of `MCSchedClassDesc` (`MCSchedule.h:129`) pointing into `MCWriteProcResEntry` (74), `MCWriteLatencyEntry` (97) and `MCReadAdvanceEntry` (114) lists, plus one `MCProcResourceDesc` (42) per unit.

**Sources:** [llvm/lib/CodeGen/TargetSchedule.cpp:35-169](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/TargetSchedule.cpp#L35-L169), [llvm/include/llvm/MC/MCSchedule.h:42-129](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCSchedule.h#L42-L129)

## Itineraries

The older itinerary model (`InstrItinClass`, stage-by-stage pipeline tables) still exists and `ItinRW` can bridge it to `SchedWrite` types, but new models should use the per-operand form shown here. The same model also feeds `llvm-mca` (not available in this build).