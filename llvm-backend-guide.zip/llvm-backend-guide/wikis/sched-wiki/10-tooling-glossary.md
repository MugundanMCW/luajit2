# Tooling and Glossary

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/MachineScheduler.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp)
- [llvm/lib/CodeGen/PostRASchedulerList.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PostRASchedulerList.cpp)

</details>
Commands for inspecting scheduling, and the terms used in this wiki. General `llc` options are on the [bring-up tooling page](../bringup-wiki/bringup-wiki.html#tooling-glossary).

## Purpose and Scope

All output in this wiki comes from an LLVM 24.0.0git release `llc` (no assertions) at commit `a2171756`. `llvm-mca` was not available in this build.

## Commands

| Command | Shows | Needs assertions |
| --- | --- | --- |
| `llc ... -mcpu=<cpu>` | Select the CPU and its scheduling model | No |
| `llc ... -stop-before=machine-scheduler` / `-stop-after=machine-scheduler` | MIR on either side of the pre-RA scheduler | No |
| `llc ... -stop-before=postmisched` / `-stop-after=postmisched` | MIR on either side of the post-RA scheduler | No |
| `llc ... -enable-misched=false` | Disable the pre-RA scheduler (option at line 474) | No |
| `llc ... -enable-post-misched=false` | Disable the post-RA machine scheduler (line 479) | No |
| `llc ... -misched-prera-direction=topdown\|bottomup\|bidirectional` | Force direction (line 179) | No |
| `llc ... -misched-regpressure=false` | Disable pressure tracking (line 251) | No |
| `llc ... -misched-cluster=false` | Disable memory-op clustering (line 257) | No |
| `llc ... -misched-print-dags`, `-debug-only=machine-scheduler` | Print DAGs and every scheduling decision | Yes |
| `llc ... -view-misched-dags` | Draw the DAG (line 212) | Debug build + Graphviz |
| `llvm-mca -mcpu=<cpu> file.s` | Static throughput analysis from the same model | No (tool not built here) |

**Sources:** [llvm/lib/CodeGen/MachineScheduler.cpp:179-257](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L179-L257), [llvm/lib/CodeGen/MachineScheduler.cpp:474-483](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L474-L483), [llvm/lib/CodeGen/PostRASchedulerList.cpp:53-56](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PostRASchedulerList.cpp#L53-L56)

## Glossary

| Term | Meaning |
| --- | --- |
| Region | Instruction range scheduled as a unit; split at calls, terminators and barriers |
| `SUnit` | One scheduling node, wrapping a `MachineInstr` |
| `SDep` | DAG edge: Data, Anti, Output or Order (with sub-kinds such as Barrier, Cluster) |
| Latency | Cycles from a write until a dependent read can use it |
| `ScheduleDAGMILive` | Pre-RA scheduler with live intervals and pressure |
| `ScheduleDAGMI` | Scheduler without liveness, used post-RA |
| `GenericScheduler` | Default pre-RA strategy (bidirectional, ordered heuristics) |
| `PostGenericScheduler` | Default post-RA strategy |
| `SchedBoundary` | Per-direction state: current cycle, issued micro-ops, resource use |
| Pressure set | Group of register units that compete for the same registers |
| DAG mutation | Post-processing that adds edges (clustering, macro fusion) |
| `SchedMachineModel` | Per-CPU model: issue width, buffer size, latencies |
| `ProcResource` | An execution unit (with a count) |
| `SchedWrite` / `SchedRead` | Target-wide abstract operand types |
| `WriteRes` | Maps a `SchedWrite` to resources and latency for one model |
| `ReadAdvance` | Forwarding: operand read N cycles late |
| `InstRW` | Per-instruction override of scheduling types |
| `CompleteModel` | TableGen checks that every instruction has scheduling data |
| Macro fusion | Hardware executes an instruction pair as one; scheduler keeps them adjacent |