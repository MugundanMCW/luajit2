# Custom Backend Guide and Checklist

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/Target/TargetSchedule.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetSchedule.td)
- [llvm/lib/Target/AArch64/AArch64Schedule.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Schedule.td)

</details>
A first scheduling model for a new CPU can be small: a handful of `SchedWrite` types, one or two processor resources, and a `WriteRes` per type. It can be refined later with `InstRW` overrides and `ReadAdvance` forwarding once measurements show where the model is wrong. All code here is for the made-up "Toy" target and is **illustrative, not LLVM source**.

## Purpose and Scope

Steps to write a minimal model, and how to check that it is complete. The model language is on [The Scheduling Model](#sched-model); the hooks on [Wiring](#wiring).

## Steps

| Step | Write | Check |
| --- | --- | --- |
| 1 | `enableMachineScheduler()` returns `true` in the subtarget | `machine-scheduler` appears in `-debug-pass=Structure` and changes MIR |
| 2 | Target-wide `SchedWrite`/`SchedRead` types (`ToySchedule.td`), included before the instructions | `.td` parses |
| 3 | `Sched<[...]>` on every instruction class: one write per def, then one read per use | — |
| 4 | `SchedMachineModel` with `IssueWidth`, `MicroOpBufferSize`, `LoadLatency`, `CompleteModel = 1` | — |
| 5 | `ProcResource`s and a `WriteRes` (or `SchedAlias`) per `SchedWrite`, `ReadAdvance` per `SchedRead`, inside `let SchedModel = ... in` | `llvm-tblgen -gen-subtarget` reports no missing information |
| 6 | `ProcessorModel<"toy2", ToyModel, [...]>` | `llc -mcpu=toy2` uses it |
| 7 | Optional: mutations in `createMachineScheduler`, `overrideSchedPolicy` | Compare MIR before/after `machine-scheduler` |

## Minimal Model (Illustrative)

**Illustrative, not LLVM source.**

```tablegen
// ToySchedule.td: target-wide types, included from Toy.td before ToyInstrInfo.td
def WriteALU  : SchedWrite;
def WriteMul  : SchedWrite;
def WriteLoad : SchedWrite;
def WriteStore: SchedWrite;
def WriteBr   : SchedWrite;
def ReadALU   : SchedRead;

// In ToyInstrInfo.td
// def ADD : ToyInst<...>, Sched<[WriteALU, ReadALU, ReadALU]>;
// def LW  : ToyInst<...>, Sched<[WriteLoad, ReadALU]>;

// ToySchedToy2.td
def ToyModel : SchedMachineModel {
  let IssueWidth = 2;
  let MicroOpBufferSize = 0;     // in-order
  let LoadLatency = 3;
  let CompleteModel = 1;
}
let SchedModel = ToyModel in {
  def ToyALU : ProcResource<2>;
  def ToyMUL : ProcResource<1>;
  def ToyLSU : ProcResource<1>;
  def : WriteRes<WriteALU,  [ToyALU]> { let Latency = 1; }
  def : WriteRes<WriteMul,  [ToyMUL]> { let Latency = 3; }
  def : WriteRes<WriteLoad, [ToyLSU]> { let Latency = 3; }
  def : WriteRes<WriteStore,[ToyLSU]> { let Latency = 1; }
  def : WriteRes<WriteBr,   [ToyALU]> { let Latency = 1; }
  def : ReadAdvance<ReadALU, 0>;
}
```

## Checking Completeness

With `CompleteModel = 1`, TableGen reports instructions that have no scheduling information for the model. Pseudos that never reach the scheduler can be marked `hasNoSchedulingInfo`, or the model can list them as unsupported. AArch64 models exclude whole feature groups with `UnsupportedFeatures` lists built from records such as `SVEUnsupported` in `AArch64.td`.

**Sources:** [llvm/include/llvm/Target/TargetSchedule.td:76-97](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetSchedule.td#L76-L97), [llvm/lib/Target/AArch64/AArch64.td:68-123](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64.td#L68-L123), [llvm/lib/Target/AArch64/AArch64Schedule.td:24-44](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Schedule.td#L24-L44)

## Checklist

- [ ] Machine scheduler enabled for the subtarget
- [ ] Every instruction has `Sched<[...]>` with writes first, then reads
- [ ] Model compiles with `CompleteModel = 1`
- [ ] `MicroOpBufferSize` matches the core (0 for in-order)
- [ ] `ProcessorModel` attaches the model to a CPU name
- [ ] Same test compiled with `-enable-misched=false` and without, MIR compared
- [ ] Spill count checked: a model that ignores pressure can make code slower