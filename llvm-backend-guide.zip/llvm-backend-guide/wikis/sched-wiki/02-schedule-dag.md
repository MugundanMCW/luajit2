# The Scheduling DAG

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/CodeGen/ScheduleDAG.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/ScheduleDAG.h)
- [llvm/lib/CodeGen/ScheduleDAGInstrs.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ScheduleDAGInstrs.cpp)

</details>
Before a region can be reordered, the scheduler needs to know which instructions must stay in order. `ScheduleDAGInstrs::buildSchedGraph` creates one `SUnit` (scheduling unit) per instruction and adds an `SDep` edge for every ordering constraint: register data flow, register reuse, and memory ordering. Each edge carries a latency taken from the scheduling model.

## Purpose and Scope

The node and edge types, and how each kind of edge is found. How the DAG is used is on [MachineScheduler](#machine-scheduler). The SelectionDAG has a different DAG (of `SDNode`s); see the SelectionDAG [data structures page](../selectiondag-wiki.html#data-structures).

## Edge Kinds

```cpp
  enum Kind {
    Data,        ///< Regular data dependence (aka true-dependence).
    Anti,        ///< A register anti-dependence (aka WAR).
    Output,      ///< A register output-dependence (aka WAW).
    Order        ///< Any other ordering dependency.
  };
```

`Order` edges have a sub-kind:

```cpp
    Barrier,      ///< An unknown scheduling barrier.
    MayAliasMem,  ///< Nonvolatile load/Store instructions that may alias.
    MustAliasMem, ///< Nonvolatile load/Store instructions that must alias.
    Artificial,   ///< Arbitrary strong DAG edge (no real dependence).
    Weak,         ///< Arbitrary weak DAG edge.
    Cluster       ///< Weak DAG edge linking a chain of clustered instrs.
```

| Edge | Example | Latency |
| --- | --- | --- |
| Data (RAW) | `%2 = LDRXui ...` then `MADDXrrr %2, ...` | Producer's write latency (minus any `ReadAdvance`) |
| Anti (WAR) | read of `$x0`, then a later write of `$x0` | 0 |
| Output (WAW) | two writes of the same register | usually 1 |
| Memory order | store then a load that may alias | 0 or 1 |
| Barrier | call, `hasUnmodeledSideEffects`, volatile access | — |
| Weak / Cluster | added by mutations | may be violated |

Before allocation most values are virtual registers in SSA form, so Anti and Output edges come mostly from physical registers (arguments, return values, `$sp`). After allocation every register is physical, so post-RA DAGs have many more of them.

**Sources:** [llvm/include/llvm/CodeGen/ScheduleDAG.h:55-77](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/ScheduleDAG.h#L55-L77)

## Building the Graph

`buildSchedGraph` (line 710) walks the region **bottom to top**, keeping maps from each register and each memory object to the instructions that use or define it:

| Function | Line | Adds |
| --- | --- | --- |
| `addPhysRegDataDeps` | 247 | Data edges for physical register uses (`SDep(SU, SDep::Data, UseReg)`, line 286) |
| `addPhysRegDeps` | 303 | Anti/Output edges for physical registers (line 319) |
| `addVRegDefDeps` | 413 | Data edges from a virtual register def to its uses (463), Output edges (507) |
| `addVRegUseDeps` | 533 | Records virtual register uses |
| `addChainDependencies` | 683, 690 | Memory edges between possibly aliasing accesses |
| `addBarrierChain` | 699 | Edges to a barrier instruction from everything pending |

For memory, each access is mapped to its underlying IR objects; two accesses that depend only on different identified objects need no edge. Spill and reload instructions are in their own `NonAlias` domain because they never alias IR values.

**Sources:** [llvm/lib/CodeGen/ScheduleDAGInstrs.cpp:247-319](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ScheduleDAGInstrs.cpp#L247-L319), [llvm/lib/CodeGen/ScheduleDAGInstrs.cpp:413-533](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ScheduleDAGInstrs.cpp#L413-L533), [llvm/lib/CodeGen/ScheduleDAGInstrs.cpp:683-759](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ScheduleDAGInstrs.cpp#L683-L759)

## Example

The dot-product region from the [walkthroughs](#aarch64-walkthroughs), before the pre-RA scheduler:

```text
    %2:gpr64 = LDRXui %0, 0 :: (load (s64) from %ir.a)
    %3:gpr64 = LDRXui %1, 0 :: (load (s64) from %ir.b)
    %5:gpr64 = LDRXui %0, 1 :: (load (s64) from %ir.pa1)
    %6:gpr64 = LDRXui %1, 1 :: (load (s64) from %ir.pb1)
    %7:gpr64 = MADDXrrr %5, %6, $xzr
    %8:gpr64 = LDRXui %0, 2 :: (load (s64) from %ir.pa2)
    %9:gpr64 = LDRXui %1, 2 :: (load (s64) from %ir.pb2)
    %11:gpr64 = MADDXrrr %2, %3, %7
    %12:gpr64 = MADDXrrr %8, %9, %11
```

```mermaid
flowchart TD
    L2["%2 LDR a[0]"] --> M11["%11 MADD"]
    L3["%3 LDR b[0]"] --> M11
    L5["%5 LDR a[1]"] --> M7["%7 MUL"]
    L6["%6 LDR b[1]"] --> M7
    M7 --> M11
    L8["%8 LDR a[2]"] --> M12["%12 MADD"]
    L9["%9 LDR b[2]"] --> M12
    M11 --> M12
```

All edges are Data edges. The six loads only read memory, so there are no memory edges between them and the scheduler may put them in any order.

## Mutations

After the graph is built, target **DAG mutations** may add edges before scheduling starts. AArch64 adds load and store clustering (Cluster edges between memory operations on the same base, so they end up adjacent and can be paired) and, on CPUs that support it, macro fusion (instruction pairs the hardware fuses). See [Wiring](#wiring).