# Wiring a Model to a Target

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64Processors.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Processors.td)
- [llvm/lib/Target/AArch64/AArch64.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64.td)
- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)
- [llvm/lib/Target/AArch64/AArch64Subtarget.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Subtarget.cpp)
- [llvm/include/llvm/CodeGen/TargetSubtargetInfo.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetSubtargetInfo.h)

</details>
A model has no effect until a CPU name points to it and the scheduler is enabled for the subtarget. A target can then customize scheduling in three places: the scheduler factories on `TargetMachine`, the policy hooks on the subtarget, and DAG mutations.

## Purpose and Scope

The connections from `-mcpu=` to the model and from the target to the scheduler passes.

## From CPU Name to Model

```mermaid
flowchart LR
    MCPU["-mcpu=cortex-a57"] --> PM["ProcessorModel&lt;'cortex-a57', CortexA57Model, ...&gt;"]
    PM -->|"-gen-subtarget"| TAB["processor table in GenSubtargetInfo.inc"]
    TAB --> ST["Subtarget::getSchedModel()"]
    ST --> TSM["TargetSchedModel::init"]
```

```tablegen
def : ProcessorModel<"generic", CortexA510Model, ProcessorFeatures.Generic,
...
def : ProcessorModel<"cortex-a55", CortexA55Model, ProcessorFeatures.A55,
...
def : ProcessorModel<"cortex-a57", CortexA57Model, ProcessorFeatures.A53,
                     [TuneA57]>;
```

At this commit AArch64's `generic` CPU uses the Cortex-A510 model. The model files must be included in `AArch64.td` before `AArch64Processors.td` (lines 125-157), as shown on the [bring-up target .td page](../bringup-wiki/bringup-wiki.html#target-td).

**Sources:** [llvm/lib/Target/AArch64/AArch64Processors.td:1291-1313](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Processors.td#L1291-L1313), [llvm/lib/Target/AArch64/AArch64.td:125-157](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64.td#L125-L157)

## Hooks

| Hook | Class | Header line | AArch64 |
| --- | --- | --- | --- |
| `enableMachineScheduler()` | `TargetSubtargetInfo` | 225 | `true` (`AArch64Subtarget.h:160`) |
| `enablePostRAScheduler()` | `TargetSubtargetInfo` | 251 | `usePostRAScheduler()` (`AArch64Subtarget.h:161`) |
| `enablePostRAMachineScheduler()` | `TargetSubtargetInfo` | 255 | default |
| `overrideSchedPolicy(Policy, Region)` | `TargetSubtargetInfo` | 268 | bidirectional (`AArch64Subtarget.cpp:513`) |
| `overridePostRASchedPolicy` | `TargetSubtargetInfo` | 278 | default |
| `createMachineScheduler(C)` | `TargetMachine` | — | `AArch64TargetMachine.cpp:524` |
| `createPostMachineScheduler(C)` | `TargetMachine` | — | `AArch64TargetMachine.cpp:538` |
| `adjustSchedDependency` | `TargetSubtargetInfo` | — | Fixes latencies through `BUNDLE`s (`AArch64Subtarget.cpp:525`) |

**Sources:** [llvm/include/llvm/CodeGen/TargetSubtargetInfo.h:225-278](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetSubtargetInfo.h#L225-L278), [llvm/lib/Target/AArch64/AArch64Subtarget.cpp:513-562](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Subtarget.cpp#L513-L562), [llvm/lib/Target/AArch64/AArch64Subtarget.h:160-161](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Subtarget.h#L160-L161)

## DAG Mutations

AArch64's pre-RA factory starts from the generic live scheduler and adds mutations:

```cpp
ScheduleDAGInstrs *
AArch64TargetMachine::createMachineScheduler(MachineSchedContext *C) const {
  const AArch64Subtarget &ST = C->MF->getSubtarget<AArch64Subtarget>();
  ScheduleDAGMILive *DAG = createSchedLive(C);
  DAG->addMutation(createLoadClusterDAGMutation(DAG->TII, DAG->TRI));
  DAG->addMutation(createStoreClusterDAGMutation(DAG->TII, DAG->TRI));
  if (ST.hasFusion())
    DAG->addMutation(createAArch64MacroFusionDAGMutation());
  ...
  return DAG;
}
```

Load/store clustering asks `TargetInstrInfo` (`getMemOperandsWithOffsetWidth`, `shouldClusterMemOps`) which memory operations share a base and should stay adjacent; that is what keeps `[x0]` and `[x0, #8]` next to each other so `aarch64-ldst-opt` can form an `ldp`. Macro fusion adds edges for pairs the CPU fuses (such as compare + branch).

**Sources:** [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:524-536](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L524-L536)