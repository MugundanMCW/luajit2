# MachineScheduler and GenericScheduler

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/MachineScheduler.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp)
- [llvm/include/llvm/CodeGen/MachineScheduler.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineScheduler.h)
- [llvm/lib/Target/AArch64/AArch64Subtarget.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Subtarget.cpp)

</details>
The machine scheduler (`machine-scheduler`) is a framework: `ScheduleDAGMILive` splits each block into regions, builds the scheduling DAG for each, and repeatedly asks a **strategy** which ready instruction to place next. The default strategy, `GenericScheduler`, places instructions from both ends of the region and picks between candidates with an ordered list of heuristics.

## Purpose and Scope

Regions, scheduling direction, the policy hooks and the heuristic order of `GenericScheduler`. Register pressure is on [Register Pressure Tracking](#register-pressure); the post-RA version on [Post-RA Scheduling](#post-ra).

## Structure

```mermaid
flowchart TD
    RUN["MachineSchedulerImpl::run"] --> REG["scheduleRegions: split blocks at calls / terminators / barriers"]
    REG --> SCHED["ScheduleDAGMILive::schedule (per region)"]
    SCHED --> BUILD["buildDAGWithRegPressure"]
    BUILD --> MUT["postProcessDAG (mutations)"]
    MUT --> LOOP{"pickNode loop"}
    LOOP -->|"top or bottom"| STRAT["GenericScheduler::pickNode"]
    STRAT --> MOVE["move MI into place, update boundaries and pressure"]
    MOVE --> LOOP
```

| Function | Line |
| --- | --- |
| `MachineSchedulerImpl::run` | 540 |
| `MachineSchedulerBase::scheduleRegions` | 810 |
| `ScheduleDAGMI::schedule` (no liveness, used post-RA) | 1057 |
| `ScheduleDAGMILive::initRegPressure` | 1477 |
| `ScheduleDAGMILive::schedule` | 1691 |
| `SchedBoundary::getLatencyStallCycles` | 2579 |
| `SchedBoundary::bumpCycle` | 2848 |
| `GenericScheduler::initPolicy` | 3667 |
| `GenericScheduler::tryCandidate` | 3944 |
| `GenericScheduler::pickNodeBidirectional` / `pickNode` | 4081 / 4159 |
| `createConvergingSched` (default scheduler factory) | 4294 |

Each scheduling direction has a `SchedBoundary` (class at `MachineScheduler.h:861`) that tracks the current cycle, issued micro-ops and resource use, using the model's `IssueWidth` and `ProcResource` counts.

**Sources:** [llvm/lib/CodeGen/MachineScheduler.cpp:540](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L540), [llvm/lib/CodeGen/MachineScheduler.cpp:810](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L810), [llvm/lib/CodeGen/MachineScheduler.cpp:1057](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L1057), [llvm/lib/CodeGen/MachineScheduler.cpp:1477](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L1477), [llvm/lib/CodeGen/MachineScheduler.cpp:1691](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L1691), [llvm/lib/CodeGen/MachineScheduler.cpp:2579-2848](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L2579-L2848), [llvm/lib/CodeGen/MachineScheduler.cpp:4081-4294](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L4081-L4294), [llvm/include/llvm/CodeGen/MachineScheduler.h:861](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineScheduler.h#L861)

## Policy

`initPolicy` runs per region. It turns on pressure tracking for regions larger than half the allocatable integer registers, defaults to bottom-up only, then lets the subtarget override:

```cpp
  // For generic targets, we default to bottom-up, because it's simpler and more
  // compile-time optimizations have been implemented in that direction.
  RegionPolicy.OnlyBottomUp = true;

  // Allow the subtarget to override default policy.
  SchedRegion Region(Begin, End, NumRegionInstrs);
  MF.getSubtarget().overrideSchedPolicy(RegionPolicy, Region);
```

Command-line options (`-misched-regpressure`, `-misched-prera-direction`) are applied after the override. AArch64 schedules in both directions:

```cpp
void AArch64Subtarget::overrideSchedPolicy(MachineSchedPolicy &Policy,
                                           const SchedRegion &Region) const {
  // LNT run (at least on Cyclone) showed reasonably significant gains for
  // bi-directional scheduling. 253.perlbmk.
  Policy.OnlyTopDown = false;
  Policy.OnlyBottomUp = false;
  ...
  Policy.DisableLatencyHeuristic = DisableLatencySchedHeuristic;
}
```

`MachineSchedPolicy` is declared at `MachineScheduler.h:200`.

**Sources:** [llvm/lib/CodeGen/MachineScheduler.cpp:3667-3715](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L3667-L3715), [llvm/lib/Target/AArch64/AArch64Subtarget.cpp:513-523](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Subtarget.cpp#L513-L523), [llvm/include/llvm/CodeGen/MachineScheduler.h:200](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineScheduler.h#L200)

## Heuristic Order

`tryCandidate` compares a new candidate against the best so far and stops at the first heuristic that prefers one of them. The reason is recorded as a `CandReason` (`NoCand`, `Only1`, `PhysReg`, `RegExcess`, ..., declared at `MachineScheduler.h:1099`).

| # | Heuristic | Lines | Prefers |
| --- | --- | --- | --- |
| 1 | `tryBiasPhysRegs` | 3953-3955 | Physical-register copies next to their uses/defs |
| 2 | Register excess | 3957-3962 | Not exceeding a pressure set's limit |
| 3 | Critical max pressure | 3964-3969 | Not raising pressure in the region's critical sets |
| 4 | Acyclic latency (loops) | 3978-3983 | Latency, when a loop is latency-bound |
| 5 | Stall cycles | 3985-3988 | Instructions that do not stall on unbuffered resources |
| 6 | Cluster | 3991-4006 | Keeping clustered instructions together |
| 7 | Weak edges | 4009-4013 | Fewer unscheduled weak predecessors |
| 8 | Current max pressure | 4016-4021 | Not raising the region's max pressure |
| 9 | Resources | 4024-4032 | Less critical resource use; more demanded resources |
| 10 | Latency | 4034-4038 | Not serializing long chains (`tryLatency`, 3470) |
| 11 | Node order | 4040-4044 | Original order, as a tie break |

Pressure comes before latency: before allocation, avoiding spills usually matters more than a few cycles. Clustering comes before latency too, which is why the loads in the [walkthrough](#aarch64-walkthroughs) are grouped by base register.

**Sources:** [llvm/lib/CodeGen/MachineScheduler.cpp:3944-4048](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L3944-L4048), [llvm/lib/CodeGen/MachineScheduler.cpp:3470](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L3470), [llvm/include/llvm/CodeGen/MachineScheduler.h:1095-1103](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineScheduler.h#L1095-L1103)

## Turning It On and Off

The pass only runs for a subtarget whose `enableMachineScheduler()` returns true (AArch64: always). `-enable-misched=false` (option at line 474) disables it; the [walkthroughs](#aarch64-walkthroughs) use that to show its effect.

**Sources:** [llvm/lib/CodeGen/MachineScheduler.cpp:474-483](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L474-L483), [llvm/lib/Target/AArch64/AArch64Subtarget.h:160](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Subtarget.h#L160)