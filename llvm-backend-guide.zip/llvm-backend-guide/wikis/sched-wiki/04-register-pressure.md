# Register Pressure Tracking

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/CodeGen/RegisterPressure.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/RegisterPressure.h)
- [llvm/lib/CodeGen/RegisterPressure.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegisterPressure.cpp)
- [llvm/lib/CodeGen/MachineScheduler.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp)

</details>
The pre-RA scheduler runs on virtual registers, so it can make register allocation easier or harder. Moving a definition earlier lengthens its live range; doing that to many values at once can push the number of simultaneously live values in a register class above what the hardware has, and the allocator then spills. The scheduler therefore tracks **register pressure** (live values per pressure set) while it schedules, and its first heuristics avoid raising it.

## Purpose and Scope

The pressure data structures, how they are updated, and how `GenericScheduler` uses them. Live intervals, which the tracker reads, are described on the regalloc [liveness page](../regalloc-wiki/regalloc-wiki.html#liveness).

## Data Structures

| Type | Line in `RegisterPressure.h` | Holds |
| --- | --- | --- |
| `RegisterPressure` | 48 | Max pressure per pressure set over a range, plus live-in/live-out registers |
| `PressureDiff` | 141 | Change in pressure caused by one instruction (per `SUnit`) |
| `PressureDiffs` | 214 | One `PressureDiff` per instruction in the region |
| `RegPressureTracker` | 375 | Current live set and pressure at a position; moved up or down instruction by instruction |

A **pressure set** is a group of register units that compete for the same physical registers (for example all 64-bit GPRs). TableGen computes the sets and their limits from the register classes; `TargetRegisterInfo::getRegPressureSetLimit` returns the limit.

**Sources:** [llvm/include/llvm/CodeGen/RegisterPressure.h:48](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/RegisterPressure.h#L48), [llvm/include/llvm/CodeGen/RegisterPressure.h:141](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/RegisterPressure.h#L141), [llvm/include/llvm/CodeGen/RegisterPressure.h:214](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/RegisterPressure.h#L214), [llvm/include/llvm/CodeGen/RegisterPressure.h:375](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/RegisterPressure.h#L375)

## Updating

```mermaid
flowchart LR
    BOT["bottom of region:<br/>live-outs"] -->|"recede() per instruction"| TOP["top of region:<br/>live-ins"]
    TOP -->|"advance() per instruction"| BOT
```

The tracker walks upward with `recede` (a use makes a register live, a def kills it going up) and downward with `advance`:

| Function | Line in `RegisterPressure.cpp` |
| --- | --- |
| `RegPressureTracker::recede(const RegisterOperands &, ...)` | 772 |
| `RegPressureTracker::recede(SmallVectorImpl<VRegMaskOrUnit> *)` | 880 |
| `RegPressureTracker::advance(const RegisterOperands &)` | 903 |
| `RegPressureTracker::advance()` | 954 |

`ScheduleDAGMILive::initRegPressure` (`MachineScheduler.cpp:1477`) sets up one tracker at each end of the region; as instructions are scheduled from the top or the bottom, the matching tracker moves.

**Sources:** [llvm/lib/CodeGen/RegisterPressure.cpp:772-954](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegisterPressure.cpp#L772-L954), [llvm/lib/CodeGen/MachineScheduler.cpp:1477](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L1477)

## Use in GenericScheduler

Three of the first heuristics in `tryCandidate` are pressure checks (see [MachineScheduler](#machine-scheduler)): register **excess** (would this candidate push any set over its limit), **critical max** (would it raise pressure in a set that is already the region's bottleneck) and **current max** (would it raise the region's maximum). `tryPressure` (`MachineScheduler.cpp:3784`) compares the two candidates' `PressureChange`s.

Tracking costs compile time, so `initPolicy` only enables it when the region has more instructions than half the allocatable registers of the widest legal integer class. `-misched-regpressure=false` (line 251) turns it off completely.

**Sources:** [llvm/lib/CodeGen/MachineScheduler.cpp:3673-3686](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L3673-L3686), [llvm/lib/CodeGen/MachineScheduler.cpp:3784](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L3784), [llvm/lib/CodeGen/MachineScheduler.cpp:3957-3969](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L3957-L3969), [llvm/lib/CodeGen/MachineScheduler.cpp:251](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/MachineScheduler.cpp#L251)

## Why the Order Matters

Where the pre-RA scheduler runs (after the coalescer, before greedy allocation) is shown on the regalloc [pipeline page](../regalloc-wiki/regalloc-wiki.html#pipeline). Because allocation comes later, a schedule that minimizes cycles but raises pressure can be slower overall once spills are added; the scheduler favors pressure first and latency second for that reason. After allocation there are no virtual registers left, so the post-RA scheduler does not track pressure.