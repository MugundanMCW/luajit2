# Streamers

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/MC/MCStreamer.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCStreamer.cpp)
- [llvm/lib/MC/MCAsmStreamer.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAsmStreamer.cpp)
- [llvm/lib/MC/MCObjectStreamer.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCObjectStreamer.cpp)
- [llvm/lib/MC/MCELFStreamer.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCELFStreamer.cpp)
- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp)

</details>
`MCStreamer` is an abstract interface with one method per thing an assembly file can say: switch section, define a label, emit an instruction, emit some bytes, set a symbol attribute, align. Code producers only ever call this interface. Different subclasses turn the calls into text or into an object file.

## Purpose and Scope

The streamer interface, its main subclasses, and target streamers for target-specific directives.

## The Interface

| Call | Assembly equivalent |
| --- | --- |
| `switchSection(Sec)` | `.section .text` |
| `emitLabel(Sym)` | `h:` |
| `emitSymbolAttribute(Sym, MCSA_Global)` | `.globl h` |
| `emitInstruction(Inst, STI)` | one instruction |
| `emitBytes(Data)`, `emitValue(Expr, Size)` | `.byte`, `.xword sym` |
| `emitValueToAlignment(...)` | `.p2align 2` |
| `emitCFI...`, `emitDwarfLocDirective` | `.cfi_*`, `.loc` |

`MCStreamer::emitInstruction` itself does nothing but sanity-check operands. The subclass decides what an instruction becomes.

**Sources:** [llvm/lib/MC/MCStreamer.cpp:401](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCStreamer.cpp#L401), [llvm/lib/MC/MCStreamer.cpp:1402](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCStreamer.cpp#L1402), [llvm/lib/MC/MCStreamer.cpp:1586-1597](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCStreamer.cpp#L1586-L1597)

## The Subclasses

```mermaid
flowchart TD
  S["MCStreamer"] --> A["MCAsmStreamer<br/>prints text"]
  S --> O["MCObjectStreamer<br/>builds fragments for MCAssembler"]
  S --> N["null streamer<br/>discards everything"]
  O --> E["MCELFStreamer"]
  O --> M["MCMachOStreamer"]
  O --> C["MCWinCOFFStreamer"]
  E --> AE["AArch64ELFStreamer<br/>mapping symbols $x / $d"]
```

### MCAsmStreamer (text)

`MCAsmStreamer::emitInstruction` asks the target's `MCInstPrinter` to print the `MCInst`. If asked (`-show-mc-encoding`), it also runs the code emitter and writes the bytes and fixups as a comment (`AddEncodingComment`). That is why `llc -show-mc-encoding` can show encodings without writing an object file. With `-asm-show-inst` it dumps the `MCInst` itself.

**Sources:** [llvm/lib/MC/MCAsmStreamer.cpp:708](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAsmStreamer.cpp#L708), [llvm/lib/MC/MCAsmStreamer.cpp:2627](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAsmStreamer.cpp#L2627)

### MCObjectStreamer (objects)

`MCObjectStreamer` owns an `MCAssembler`. Each call appends to the current fragment of the current section. An instruction is either encoded straight into the current data fragment or, if it might need relaxing, given its own relaxable fragment:

```cpp
  if (!(Backend.mayNeedRelaxation(Inst.getOpcode(), Inst.getOperands(), STI) ||
        Backend.allowEnhancedRelaxation())) {
    emitInstToData(Inst, STI);
    return;
  }

  // Otherwise, relax and emit it as data if RelaxAll is specified.
  if (Assembler.getRelaxAll()) {
    emitInstToData(relaxToFixpoint(Inst), STI);
    return;
  }

  emitInstToFragment(Inst, STI);
```

`emitInstToData` calls the code emitter and appends the bytes and fixups:

```cpp
  getAssembler().getEmitter().encodeInstruction(Inst, Content, Fixups, STI);
  appendContents(Content);
  ...
  for (auto &Fixup : Fixups) {
    Fixup.setOffset(Fixup.getOffset() + CodeOffset);
    ...
  }
  F->appendFixups(Fixups);
```

Fixup offsets come back from the emitter relative to the instruction; the streamer shifts them to be relative to the fragment. `finishImpl` (called at the end) runs `MCAssembler::Finish`, which lays out and writes the object.

**Sources:** [llvm/lib/MC/MCObjectStreamer.cpp:402-488](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCObjectStreamer.cpp#L402-L488), [llvm/lib/MC/MCObjectStreamer.cpp:803](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCObjectStreamer.cpp#L803)

### MCELFStreamer

Adds the ELF meaning of symbol attributes (`emitSymbolAttribute`: binding, type, visibility), ELF section switching and the creation of standard sections (`initSections`). Targets can subclass it; AArch64's `AArch64ELFStreamer` adds the ELF mapping symbols that mark code and data.

**Sources:** [llvm/lib/MC/MCELFStreamer.cpp:53-136](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCELFStreamer.cpp#L53-L136), [llvm/lib/MC/MCELFStreamer.cpp:451](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCELFStreamer.cpp#L451)

## Target Streamers

Directives that exist only on one target (AArch64 `.variant_pcs`, `.inst`, Windows SEH opcodes) go through a **target streamer**, an object attached to the streamer. Each target provides three: one for text (prints the directive), one for objects (does the work), one null. AArch64 registers all three:

```cpp
    TargetRegistry::RegisterObjectTargetStreamer(
        *T, createAArch64ObjectTargetStreamer);
    TargetRegistry::RegisterAsmTargetStreamer(*T,
                                              createAArch64AsmTargetStreamer);
    TargetRegistry::RegisterNullTargetStreamer(*T,
                                               createAArch64NullTargetStreamer);
```

Both the `AsmPrinter` and the target `AsmParser` call the target streamer, so a directive parsed from a `.s` file and one produced by the compiler take the same path.

**Sources:** [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp:546-555](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp#L546-L555)