# AsmBackend and Object Writer

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/MC/MCAsmBackend.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCAsmBackend.h)
- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp)
- [llvm/include/llvm/MC/MCELFObjectWriter.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCELFObjectWriter.h)
- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp)

</details>
The asm backend is the target's part of the assembler. It describes its fixup kinds, patches resolved fixups into bytes, decides which instructions can be relaxed, writes NOP padding, and creates the target object writer. The object writer's only essential job is to map a fixup to a relocation number.

## Purpose and Scope

The virtuals a backend implements, with AArch64's versions as the reference. How fixups flow is on [Fixups and Relocations](#fixups-relocations).

## MCAsmBackend Virtuals

| Virtual (`MCAsmBackend.h`) | Line | Required? | Job |
| --- | --- | --- | --- |
| `createObjectTargetWriter()` | 102 | Yes (pure) | Create the format-specific target writer |
| `getFixupKindInfo(Kind)` | 111 | Yes for any target fixup | Name, bit offset, bit size, flags of each kind |
| `applyFixup(F, Fixup, Target, Data, Value, IsResolved)` | 128 | Yes | Patch the value into the bytes; record a relocation if not resolved |
| `mayNeedRelaxation(Opcode, Operands, STI)` | 139 | Only if you relax | Can this instruction grow? |
| `relaxInstruction(Inst, STI)` | 155 | Only if you relax | Replace it with the longer form |
| `writeNopData(OS, Count, STI)` | 194 | Yes | Fill `Count` bytes with NOPs (for alignment in code) |

**Sources:** [llvm/include/llvm/MC/MCAsmBackend.h:93-194](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCAsmBackend.h#L93-L194)

## AArch64's Backend

- **Fixup info:** `getFixupKindInfo` holds a table of the `fixup_aarch64_*` kinds and falls back to `MCAsmBackend::getFixupKindInfo` for generic ones.
- **Applying fixups:** `applyFixup` forces a relocation where needed (`shouldForceRelocation`), calls `maybeAddReloc`, then converts the value with `adjustFixupValue` (range checks, scaling: branch offsets `>> 2`), shifts it to the field's bit offset and ORs it into the bytes (code on [Fixups and Relocations](#fixups-relocations)).
- **Relaxation:** none. There is no `mayNeedRelaxation` override, because AArch64 instructions are fixed size ([Assembler and Layout](#assembler-layout)).
- **NOPs:** `writeNopData` writes 4-byte `nop` words.
- **Object writer:** the ELF backend's `createObjectTargetWriter` returns `createAArch64ELFObjectWriter(OSABI, IsILP32)`. Separate backend classes cover Mach-O and COFF.
- **Endianness:** separate factories, `createAArch64leAsmBackend` and `createAArch64beAsmBackend`.

**Sources:** [llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp:44-73](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp#L44-L73), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp:404-498](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp#L404-L498), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp:762-802](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp#L762-L802)

## The ELF Target Writer

```cpp
virtual unsigned getRelocType(const MCFixup &Fixup, const MCValue &Target,
                              bool IsPCRel) const = 0;
virtual bool needsRelocateWithSymbol(const MCValue &, unsigned Type) const {
```

`getRelocType` returns an `R_<ARCH>_*` number for every fixup that reaches the object file. Use the fixup kind, the specifier in `Target` (`:got:`, `:lo12:`, TLS forms) and `IsPCRel`. Report unsupported combinations with `reportError` and return `R_<ARCH>_NONE` rather than crashing. The constructor passes the ELF `e_machine` value and whether relocations carry explicit addends (RELA).

**Sources:** [llvm/include/llvm/MC/MCELFObjectWriter.h:88-91](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCELFObjectWriter.h#L88-L91), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp:85-130](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp#L85-L130), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp:537](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp#L537)

## A Minimal Backend (Illustrative)

```cpp
// ToyAsmBackend.cpp (illustrative, not LLVM source)
namespace Toy { enum { fixup_toy_branch24 = FirstTargetFixupKind }; }

MCFixupKindInfo ToyAsmBackend::getFixupKindInfo(MCFixupKind K) const {
  static const MCFixupKindInfo Infos[] = {
      // name                 offset bits flags
      {"fixup_toy_branch24",  0,     24,  0},
  };
  if (K < FirstTargetFixupKind)
    return MCAsmBackend::getFixupKindInfo(K);
  return Infos[K - FirstTargetFixupKind];
}

void ToyAsmBackend::applyFixup(const MCFragment &F, const MCFixup &Fixup,
                               const MCValue &Target, uint8_t *Data,
                               uint64_t Value, bool IsResolved) {
  maybeAddReloc(F, Fixup, Target, Value, IsResolved);
  if (!Value) return;
  if (Fixup.getKind() == Toy::fixup_toy_branch24)
    Value = (Value >> 2) & 0xffffff;     // word offset, 24 bits
  unsigned N = getFixupKindInfo(Fixup.getKind()).TargetSize / 8;
  for (unsigned I = 0; I != N; ++I)
    Data[I] |= uint8_t(Value >> (I * 8));
}

std::unique_ptr<MCObjectTargetWriter>
ToyAsmBackend::createObjectTargetWriter() const {
  return std::make_unique<ToyELFObjectWriter>(OSABI);
}

// ToyELFObjectWriter.cpp
unsigned ToyELFObjectWriter::getRelocType(const MCFixup &Fixup,
    const MCValue &Target, bool IsPCRel) const {
  switch (Fixup.getKind()) {
  case Toy::fixup_toy_branch24: return ELF::R_TOY_BRANCH24;
  case FK_Data_4:               return ELF::R_TOY_32;
  default:
    reportError(Fixup.getLoc(), "unsupported relocation");
    return ELF::R_TOY_NONE;
  }
}
```

The field names in `MCFixupKindInfo` and the exact `applyFixup` signature change between releases. Copy them from `MCAsmBackend.h` and `MCFixup.h` at your commit.