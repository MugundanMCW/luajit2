# Tooling and Glossary

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/MC/MCAsmStreamer.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAsmStreamer.cpp)
- [llvm/lib/CodeGen/CodeGenTargetMachineImpl.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CodeGenTargetMachineImpl.cpp)

</details>
Which tools show which part of the MC layer, and short definitions of the terms used in this wiki.

## Purpose and Scope

A reference page. Options marked "tried" were run with the release `llc` built from the pinned commit.

## llc Options

| Option | Shows | Status |
| --- | --- | --- |
| `-filetype=asm` (default) | Text through `MCAsmStreamer` and the printer | Tried |
| `-show-mc-encoding` | Bytes from the code emitter, plus fixups (`fixup A - offset ... kind ...`) | Tried |
| `-asm-show-inst` | The `MCInst` and its `MCOperand`s for each line | Tried |
| `-filetype=obj` | Writes an object through `MCObjectStreamer`, `MCAssembler` and the object writer | Tried (1128-byte AArch64 object) |
| `-mtriple=...` | Selects the target, and with it the object format (ELF, Mach-O, COFF) | Tried (`aarch64-linux-gnu`) |

## Tools This Build Does Not Have

| Tool | Use |
| --- | --- |
| `llvm-mc -show-encoding` / `-show-inst` | Assemble `.s` files with the target asm parser |
| `llvm-mc -filetype=obj` | Assemble straight to an object |
| `llvm-mc --disassemble` | Decode bytes given as text |
| `llvm-objdump -d -r` | Disassemble an object, with relocations |
| `llvm-readelf -r -s -S` | Read relocations, symbols and sections |

Build them with `cmake --build <build> --target llvm-mc llvm-objdump llvm-readelf`. MC regression tests in `llvm/test/MC/<Target>/` use them, usually with `FileCheck`.

## Glossary

| Term | Meaning | Page |
| --- | --- | --- |
| **AsmBackend** | Target part of the assembler: fixup info, applying fixups, relaxation, NOPs | [AsmBackend](#asm-backend) |
| **AsmPrinter** | CodeGen pass that lowers `MachineInstr`s to `MCInst`s and drives the streamer | [Overview](#overview) |
| **Code emitter** | Turns an `MCInst` into bytes and fixups | [Code Emitter](#code-emitter) |
| **Fixup** | A note that some bits depend on an expression not known yet | [Fixups](#fixups-relocations) |
| **Fixup kind** | Which bits and how: generic (`FK_Data_4`) or target (`fixup_aarch64_pcrel_call26`) | [Fixups](#fixups-relocations) |
| **Fragment** | A piece of a section: data, relaxable instruction, alignment, fill, ... | [Assembler](#assembler-layout) |
| **Layout** | Assigning offsets to all fragments, repeated until relaxation stops | [Assembler](#assembler-layout) |
| **MCAsmInfo** | Syntax and object-format facts of a target | [Printer](#asminfo-printer) |
| **MCContext** | Owner of all symbols, sections and expressions | [Data Structures](#data-structures) |
| **MCExpr** | A value computed at assembly or link time | [Data Structures](#data-structures) |
| **MCInst** | Opcode plus operands; the unit everything in MC works on | [Data Structures](#data-structures) |
| **MCInstPrinter** | Turns an `MCInst` into text | [Printer](#asminfo-printer) |
| **MCStreamer** | Interface for "emit label / instruction / bytes / directive" | [Streamers](#streamers) |
| **MCValue** | An evaluated expression: `SymA - SymB + Constant` plus specifier | [Data Structures](#data-structures) |
| **Object writer** | Writes the file format; the target part picks relocation types | [AsmBackend](#asm-backend) |
| **Relaxation** | Replacing an instruction with a longer form when its operand does not fit | [Assembler](#assembler-layout) |
| **Relocation** | An entry in the object asking the linker to patch bytes | [Fixups](#fixups-relocations) |
| **Specifier** | Target modifier on an expression, e.g. AArch64 `:got:`, `:lo12:` | [Fixups](#fixups-relocations) |
| **Target streamer** | Per-target object for directives only that target has | [Streamers](#streamers) |
| **TargetRegistry** | Where each target registers factory functions for its MC objects | [Custom backend](#custom-backend) |

## Where Do I Look?

| Question | Look at |
| --- | --- |
| Why is this instruction printed this way? | `<T>InstPrinter::printInst`, `InstAlias` records |
| Why are these the bytes? | `-show-mc-encoding`; `Inst` field layout; encoder methods |
| Why is there a relocation here? | Fixup kind and specifier; `<T>ELFObjectWriter::getRelocType` |
| Why is the value wrong after linking? | `adjustFixupValue` in `<T>AsmBackend.cpp` |
| What does my backend need to implement? | [Custom backend](#custom-backend), [checklist](#mc-checklist) |