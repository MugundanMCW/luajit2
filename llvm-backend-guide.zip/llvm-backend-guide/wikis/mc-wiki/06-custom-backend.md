# Writing an MC Layer for a Custom Backend

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp)
- [llvm/include/llvm/MC/TargetRegistry.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/TargetRegistry.h)
- [llvm/lib/CodeGen/CodeGenTargetMachineImpl.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CodeGenTargetMachineImpl.cpp)

</details>
The generic MC code (streamers, assembler, ELF writer) is shared by every target. A backend supplies a set of small target objects and registers a factory function for each with `TargetRegistry`. Tools such as `llc`, `llvm-mc` and `llvm-objdump` then find them by target triple.

## Purpose and Scope

The list of pieces, how they are registered, and the order to write them. Each piece has its own page.

## The Pieces

| Piece | Base class | Needed for | Page |
| --- | --- | --- | --- |
| Instruction, register, subtarget tables | `MCInstrInfo`, `MCRegisterInfo`, `MCSubtargetInfo` | Everything (mostly TableGen output) | [Data Structures](#data-structures) |
| Syntax facts | `MCAsmInfo` | Everything | [MCAsmInfo and Printer](#asminfo-printer) |
| Instruction printer | `MCInstPrinter` | `.s` output, disassembler output | [MCAsmInfo and Printer](#asminfo-printer) |
| Code emitter | `MCCodeEmitter` | `.o` output | [Code Emitter](#code-emitter) |
| Asm backend | `MCAsmBackend` | `.o` output: fixups, relaxation, NOPs | [AsmBackend and Object Writer](#asm-backend) |
| ELF object writer | `MCELFObjectTargetWriter` | `.o` output: relocation types | [AsmBackend and Object Writer](#asm-backend) |
| Target streamer (optional) | `MCTargetStreamer` | Target-only directives | [Streamers](#streamers) |
| Asm parser | `MCTargetAsmParser` | `.s` input, inline asm | [Parser and Disassembler](#parser-disassembler) |
| Disassembler | `MCDisassembler` | `llvm-objdump`, `llvm-mc --disassemble` | [Parser and Disassembler](#parser-disassembler) |

## Directory Layout

| Directory | Contents | Library |
| --- | --- | --- |
| `lib/Target/<T>/MCTargetDesc/` | `<T>MCTargetDesc.cpp` (registration), `MCAsmInfo`, `InstPrinter`, `MCCodeEmitter`, `AsmBackend`, `ELFObjectWriter`, `FixupKinds.h` | `LLVM<T>Desc` |
| `lib/Target/<T>/AsmParser/` | `<T>AsmParser.cpp` | `LLVM<T>AsmParser` |
| `lib/Target/<T>/Disassembler/` | `<T>Disassembler.cpp` | `LLVM<T>Disassembler` |
| `lib/Target/<T>/TargetInfo/` | `getThe<T>Target()` | `LLVM<T>Info` |

The MC libraries must not depend on CodeGen: `llvm-mc` links them without the compiler. AArch64 follows exactly this layout (see the file list of `AArch64/MCTargetDesc`).

## Registration

AArch64 registers everything in `LLVMInitializeAArch64TargetMC`:

```cpp
LLVMInitializeAArch64TargetMC() {
  for (Target *T : {&getTheAArch64leTarget(), &getTheAArch64beTarget(),
                    &getTheAArch64_32Target(), &getTheARM64Target(),
                    &getTheARM64_32Target()}) {
    // Register the MC asm info.
    RegisterMCAsmInfoFn X(*T, createAArch64MCAsmInfo);
    // Register the MC instruction info.
    TargetRegistry::RegisterMCInstrInfo(*T, createAArch64MCInstrInfo);
    // Register the MC register info.
    TargetRegistry::RegisterMCRegInfo(*T, createAArch64MCRegisterInfo);
    // Register the MC subtarget info.
    TargetRegistry::RegisterMCSubtargetInfo(*T, createAArch64MCSubtargetInfo);
    ...
    // Register the MC Code Emitter
    TargetRegistry::RegisterMCCodeEmitter(*T, createAArch64MCCodeEmitter);
    // Register the obj streamers.
    TargetRegistry::RegisterELFStreamer(*T, createAArch64ELFStreamer);
    ...
    // Register the MCInstPrinter.
    TargetRegistry::RegisterMCInstPrinter(*T, createAArch64MCInstPrinter);
  }

  // Register the asm backend.
  for (Target *T : {&getTheAArch64leTarget(), &getTheAArch64_32Target(),
                    &getTheARM64Target(), &getTheARM64_32Target()})
    TargetRegistry::RegisterMCAsmBackend(*T, createAArch64leAsmBackend);
  TargetRegistry::RegisterMCAsmBackend(getTheAArch64beTarget(),
                                       createAArch64beAsmBackend);
}
```

The asm parser and disassembler register themselves in their own libraries (`LLVMInitializeAArch64AsmParser`, `LLVMInitializeAArch64Disassembler`). The ELF object writer is not registered: the asm backend creates it in `createObjectTargetWriter`.

When `llc` writes an object, `CodeGenTargetMachineImpl::createMCStreamer` asks the registry for the code emitter and asm backend and calls `createMCObjectStreamer` with them.

**Sources:** [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp:516-567](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp#L516-L567), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp:48](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp#L48), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp:339-370](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp#L339-L370), [llvm/lib/CodeGen/CodeGenTargetMachineImpl.cpp:168-215](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CodeGenTargetMachineImpl.cpp#L168-L215)

## Minimal Registration for a New Target (Illustrative)

For a made-up "Toy" target. **Illustrative, not LLVM source**; check the exact factory signatures in `TargetRegistry.h` at your LLVM version.

```cpp
// ToyMCTargetDesc.cpp (illustrative)
#define GET_INSTRINFO_MC_DESC
#include "ToyGenInstrInfo.inc"
#define GET_REGINFO_MC_DESC
#include "ToyGenRegisterInfo.inc"
#define GET_SUBTARGETINFO_MC_DESC
#include "ToyGenSubtargetInfo.inc"

static MCInstrInfo *createToyMCInstrInfo() {
  auto *X = new MCInstrInfo();
  InitToyMCInstrInfo(X);                // generated
  return X;
}
static MCRegisterInfo *createToyMCRegisterInfo(const Triple &) {
  auto *X = new MCRegisterInfo();
  InitToyMCRegisterInfo(X, Toy::R14);   // return-address register
  return X;
}

extern "C" LLVM_EXTERNAL_VISIBILITY void LLVMInitializeToyTargetMC() {
  Target &T = getTheToyTarget();
  RegisterMCAsmInfo<ToyMCAsmInfo> X(T);
  TargetRegistry::RegisterMCInstrInfo(T, createToyMCInstrInfo);
  TargetRegistry::RegisterMCRegInfo(T, createToyMCRegisterInfo);
  TargetRegistry::RegisterMCSubtargetInfo(T, createToyMCSubtargetInfo);
  TargetRegistry::RegisterMCInstPrinter(T, createToyMCInstPrinter);
  TargetRegistry::RegisterMCCodeEmitter(T, createToyMCCodeEmitter);
  TargetRegistry::RegisterMCAsmBackend(T, createToyAsmBackend);
}
```

## Order of Work

1. TableGen: registers, instructions with **encodings** (`bits<32> Inst` and operand fields), assembly strings. One description drives the printer, the code emitter, the parser matcher and the decoder.
2. `MCAsmInfo` and `InstPrinter`: `llc -filetype=asm` works.
3. `MCCodeEmitter`: `llc -show-mc-encoding` shows bytes.
4. Fixup kinds, `AsmBackend`, `ELFObjectWriter`: `llc -filetype=obj` works.
5. `AsmParser`: `llvm-mc` assembles `.s` files; inline asm works.
6. `Disassembler`: `llvm-objdump -d` works.

The [checklist](#mc-checklist) gives tests for each step.