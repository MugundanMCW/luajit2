# Assembly Parser and Disassembler

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/MC/MCParser/MCTargetAsmParser.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCParser/MCTargetAsmParser.h)
- [llvm/lib/Target/AArch64/AsmParser/AArch64AsmParser.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AsmParser/AArch64AsmParser.cpp)
- [llvm/include/llvm/MC/MCDisassembler/MCDisassembler.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCDisassembler/MCDisassembler.h)
- [llvm/lib/Target/AArch64/Disassembler/AArch64Disassembler.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/Disassembler/AArch64Disassembler.cpp)

</details>
These are the two input directions. The asm parser turns assembly text into `MCInst`s and streamer calls. The disassembler turns bytes into `MCInst`s, which the [printer](#asminfo-printer) then prints. Both are generated mostly from the same TableGen instruction descriptions as the printer and the encoder.

## Purpose and Scope

What a target writes for each, and what TableGen generates. The build used for this wiki has no `llvm-mc` or `llvm-objdump`, so this page has no tool output. In `llc`, the asm parser is only exercised through inline assembly.

## The Asm Parser

The generic `AsmParser` (in `lib/MC/MCParser`) lexes the file, handles generic directives (`.text`, `.globl`, `.byte`, ...) and calls the target parser for everything else:

| Virtual (`MCTargetAsmParser.h`) | Line | Job |
| --- | --- | --- |
| `parseRegister(Reg, StartLoc, EndLoc)` | 408 | Parse one register name |
| `parseInstruction(Info, Name, NameLoc, Operands)` | 432 | Split an instruction into a mnemonic token plus target operands |
| `ParseDirective` / `parseDirective` | 450 / 462 | Target-specific directives; return "not mine" for the rest |
| `matchAndEmitInstruction(IDLoc, Opcode, Operands, Out, ErrorInfo, ...)` | 470 | Choose the opcode, build the `MCInst`, emit it |

Matching is generated. `-gen-asm-matcher` (`AArch64GenAsmMatcher.inc`) produces `MatchInstructionImpl`, which compares the operand list against every instruction's `AsmString` and operand classes. AArch64's `matchAndEmitInstruction` first rewrites some aliases by hand (for example `lsl` with an immediate), then calls `MatchInstructionImpl`, and on success emits the result with `Out.emitInstruction`.

**What you write per operand kind:** an operand class (`AArch64Operand` in AArch64) with `isXxx()` predicates and `addXxxOperands()` methods. TableGen `AsmOperandClass` records name them through `PredicateMethod` and `RenderMethod`. AArch64's `GPR64spPlus0Operand` (`AArch64RegisterInfo.td:231-236`) is a small real example: `PredicateMethod = "isGPR64<AArch64::GPR64spRegClassID>"`, `RenderMethod = "addRegOperands"`, `ParserMethod = "tryParseGPR64sp0Operand"`.

**Sources:** [llvm/include/llvm/MC/MCParser/MCTargetAsmParser.h:408-470](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCParser/MCTargetAsmParser.h#L408-L470), [llvm/lib/Target/AArch64/AsmParser/AArch64AsmParser.cpp:2925](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AsmParser/AArch64AsmParser.cpp#L2925), [llvm/lib/Target/AArch64/AsmParser/AArch64AsmParser.cpp:5255](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AsmParser/AArch64AsmParser.cpp#L5255), [llvm/lib/Target/AArch64/AsmParser/AArch64AsmParser.cpp:6451-6470](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AsmParser/AArch64AsmParser.cpp#L6451-L6470), [llvm/lib/Target/AArch64/AsmParser/AArch64AsmParser.cpp:6744](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AsmParser/AArch64AsmParser.cpp#L6744), [llvm/lib/Target/AArch64/AsmParser/AArch64AsmParser.cpp:7064](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AsmParser/AArch64AsmParser.cpp#L7064), [llvm/lib/Target/AArch64/CMakeLists.txt:5](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt#L5)

## The Disassembler

There is one virtual to provide:

```cpp
virtual DecodeStatus getInstruction(MCInst &Instr, uint64_t &Size,
                                    ArrayRef<uint8_t> Bytes, uint64_t Address,
                                    raw_ostream &CStream) const = 0;
```

AArch64's version is short because decoding is generated (`-gen-disassembler`, `AArch64GenDisassemblerTables.inc`):

```cpp
  Size = 0;
  // We want to read exactly 4 bytes of data.
  if (Bytes.size() < 4)
    return Fail;
  Size = 4;

  // Encoded as a small-endian 32-bit word in the stream.
  uint32_t Insn =
      (Bytes[3] << 24) | (Bytes[2] << 16) | (Bytes[1] << 8) | (Bytes[0] << 0);

  const uint8_t *Tables[] = {DecoderTable32, DecoderTableFallback32};

  for (const auto *Table : Tables) {
    DecodeStatus Result =
        decodeInstruction(Table, MI, Insn, Address, this, STI);
    if (Result != MCDisassembler::Fail)
      return Result;
  }

  return MCDisassembler::Fail;
```

The generated decoder table walks the instruction's fixed bits to pick an opcode, then calls **decoder functions** for each operand field, named in TableGen with `DecoderMethod`. AArch64's GPR classes use a shared template, for example `let DecoderMethod = "DecodeSimpleRegisterClass<AArch64::GPR64RegClassID, 0, 32>";` (`AArch64RegisterInfo.td:210`). You write decoders for every register class and for any operand whose encoding is not a plain field.

The disassembler registers itself (with a symbolizer that names branch targets) in `LLVMInitializeAArch64Disassembler`.

**Sources:** [llvm/include/llvm/MC/MCDisassembler/MCDisassembler.h:135](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCDisassembler/MCDisassembler.h#L135), [llvm/lib/Target/AArch64/Disassembler/AArch64Disassembler.cpp:1637-1663](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/Disassembler/AArch64Disassembler.cpp#L1637-L1663), [llvm/lib/Target/AArch64/Disassembler/AArch64Disassembler.cpp:1683-1703](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/Disassembler/AArch64Disassembler.cpp#L1683-L1703), [llvm/lib/Target/AArch64/CMakeLists.txt:10](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt#L10)

## One Description, Four Tools

| TableGen field | Printer | Encoder | Parser | Decoder |
| --- | --- | --- | --- | --- |
| `AsmString` | Text to print | | Text to match | |
| `bits<32> Inst` + operand fields | | Bit layout | | Bit layout |
| Operand `PrintMethod` | Yes | | | |
| Operand `EncoderMethod` | | Yes | | |
| Operand `ParserMatchClass` | | | Yes | |
| Operand `DecoderMethod` | | | | Yes |
| `InstAlias` | Prints the alias | | Accepts the alias | |

If one instruction encodes, prints, parses and decodes consistently, the round trip "assemble, then disassemble" gives back the same text. In a build that has the tools, that is the standard test: `llvm-mc -show-encoding` and `llvm-mc --disassemble` on the same lines.