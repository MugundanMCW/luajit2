# MC Layer Overview

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/CodeGenTargetMachineImpl.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CodeGenTargetMachineImpl.cpp)
- [llvm/lib/CodeGen/AsmPrinter/AsmPrinter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/AsmPrinter/AsmPrinter.cpp)
- [llvm/lib/MC/MCStreamer.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCStreamer.cpp)
- [llvm/lib/MC/MCObjectStreamer.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCObjectStreamer.cpp)
- [llvm/lib/MC/MCAssembler.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp)
- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp)

</details>
The MC ("Machine Code") layer is the bottom of LLVM's code generator and the core of its assembler and disassembler. It knows about instructions as opcodes plus operands (`MCInst`), not as `MachineInstr`s. It can print them as assembly text, encode them to bytes, write object files, parse assembly back into `MCInst`s, and decode bytes into `MCInst`s.

## Purpose and Scope

This wiki explains `llvm/lib/MC/` and the per-target `MCTargetDesc`, `AsmParser` and `Disassembler` directories, using AArch64 as the worked example. It runs from the basic data structures to everything a new backend has to write: see [Writing an MC Layer for a Custom Backend](#custom-backend).

It does not cover instruction selection or register allocation (see the other two wikis), or the linker.

All tool output on these pages was produced by the release `llc` built from the pinned commit. That build has no `llvm-mc`, `llvm-objdump` or `llvm-readelf`, so assembling `.s` files, disassembly and reading relocation tables back from objects are explained from the source code only, without listings.

## Where MC Fits

```mermaid
flowchart LR
  MI["MachineInstr<br/>after register allocation"] --> AP["AsmPrinter<br/>lowers each MI to an MCInst"]
  AP --> S{"MCStreamer"}
  S -->|"-filetype=asm"| AS["MCAsmStreamer<br/>MCInstPrinter prints text"]
  S -->|"-filetype=obj"| OS["MCELFStreamer / MCObjectStreamer<br/>MCCodeEmitter encodes bytes"]
  OS --> ASM["MCAssembler<br/>layout, relaxation, fixups"]
  ASM --> OW["ELFObjectWriter<br/>sections, symbols, relocations"]
  P[".s file"] --> PARSER["AsmParser<br/>MCTargetAsmParser"] --> S
  BYTES["bytes"] --> DIS["MCDisassembler"] --> MCI["MCInst"] --> PR["MCInstPrinter"]
```

The `MCStreamer` is the hub. Everything that produces code (the compiler's `AsmPrinter`, the assembly parser) talks to a streamer, and the kind of streamer decides whether text or an object file comes out. The same `MCInst` can be printed or encoded, which is why `llc` can emit both from one pipeline.

## How llc Builds It

`CodeGenTargetMachineImpl::addAsmPrinter` creates the streamer, then the `AsmPrinter` pass. `createMCStreamer` chooses by file type: `getTarget().createAsmStreamer(...)` for text, `getTarget().createMCObjectStreamer(...)` for objects.

`AsmPrinter` lowers each `MachineInstr` to an `MCInst` (AArch64: `AArch64AsmPrinter::emitInstruction`, using `AArch64MCInstLower::lowerOperand`) and hands it to the streamer through `EmitToStreamer`.

**Sources:** [llvm/lib/CodeGen/CodeGenTargetMachineImpl.cpp:145-215](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CodeGenTargetMachineImpl.cpp#L145-L215), [llvm/lib/CodeGen/AsmPrinter/AsmPrinter.cpp:505](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/AsmPrinter/AsmPrinter.cpp#L505), [llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp:3258-3265](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp#L3258-L3265), [llvm/lib/Target/AArch64/AArch64MCInstLower.cpp:332](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64MCInstLower.cpp#L332)

## A First Look

```llvm
@gv = global i32 0
declare i32 @g(i32)
define i32 @h(i32 %a) {
  %v = load i32, ptr @gv
  %x = call i32 @g(i32 %v)
  %y = add i32 %x, %a
  ret i32 %y
}
```

`llc -mtriple=aarch64-linux-gnu -O2 -show-mc-encoding` prints the assembly, the bytes the code emitter produced, and any fixups (excerpt):

```
	adrp	x8, :got:gv                     // encoding: [0x08'A',A,A,0x90'A']
                                        //   fixup A - offset: 0, value: :got:gv, kind: fixup_aarch64_pcrel_adrp_imm21
	mov	w19, w0                         // encoding: [0xf3,0x03,0x00,0x2a]
	bl	g                               // encoding: [A,A,A,0b100101AA]
                                        //   fixup A - offset: 0, value: g, kind: fixup_aarch64_pcrel_call26
	add	w0, w0, w19                     // encoding: [0x00,0x00,0x13,0x0b]
	ret                                     // encoding: [0xc0,0x03,0x5f,0xd6]
```

`mov w19, w0` is fully known: four bytes. `bl g` is not: the address of `g` is unknown when the instruction is encoded. The emitter writes the opcode bits it knows and records a **fixup** (bits marked `A`), which is resolved later by the assembler or turned into a **relocation** for the linker. That distinction runs through the whole MC layer; see [Fixups and Relocations](#fixups-relocations).

## Component Map

| Component | Class | Role | Page |
| --- | --- | --- | --- |
| Instruction | `MCInst`, `MCOperand` | Opcode + operands, target-independent container | [Data Structures](#data-structures) |
| Expressions, symbols, sections | `MCExpr`, `MCSymbol`, `MCSection`, `MCContext` | Values not known yet, names, output sections | [Data Structures](#data-structures) |
| Streamer | `MCStreamer`, `MCAsmStreamer`, `MCObjectStreamer`, `MCELFStreamer` | The interface code producers call | [Streamers](#streamers) |
| Assembler | `MCAssembler`, fragments | Layout, relaxation, fixup evaluation | [Assembler and Layout](#assembler-layout) |
| Object writer | `ELFObjectWriter` | Writes the ELF file and relocations | [Fixups and Relocations](#fixups-relocations) |
| Target: description | `MCInstrInfo`, `MCRegisterInfo`, `MCSubtargetInfo`, `MCAsmInfo` | Tables and syntax facts | [Custom backend](#custom-backend) |
| Target: printer | `<T>InstPrinter` | `MCInst` to text | [MCAsmInfo and Printer](#asminfo-printer) |
| Target: encoder | `<T>MCCodeEmitter` | `MCInst` to bytes + fixups | [Code Emitter](#code-emitter) |
| Target: backend | `<T>AsmBackend`, `<T>ELFObjectWriter` | Apply fixups, relax, choose relocation types | [AsmBackend and Object Writer](#asm-backend) |
| Target: parser, decoder | `<T>AsmParser`, `<T>Disassembler` | Text to `MCInst`, bytes to `MCInst` | [Parser and Disassembler](#parser-disassembler) |

## Reading Guide

- New to MC: [Data Structures](#data-structures), [Streamers](#streamers), [Assembler and Layout](#assembler-layout), [Fixups and Relocations](#fixups-relocations).
- Writing a backend: [Custom backend](#custom-backend) and its [checklist](#mc-checklist).
- Debugging output: [Tooling and Glossary](#tooling-glossary).