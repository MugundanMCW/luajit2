# Fixups and Relocations

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/MC/MCAssembler.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp)
- [llvm/lib/MC/ELFObjectWriter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/ELFObjectWriter.cpp)
- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64FixupKinds.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64FixupKinds.h)
- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp)
- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp)

</details>
A **fixup** is a note left by the code emitter: "these bits of this instruction depend on this expression, fill them in later". After layout, each fixup is either **resolved** (the assembler knows the value and patches the bytes) or turned into a **relocation** (the object file asks the linker to patch it).

## Purpose and Scope

The life of a fixup from the code emitter to the object file, with AArch64's fixup kinds and relocation choice.

## What a Fixup Holds

| Field | Meaning |
| --- | --- |
| Offset | Byte offset in the fragment (the streamer shifts it from instruction-relative to fragment-relative) |
| Value | The `MCExpr` to compute |
| Kind | `MCFixupKind`: generic (`FK_Data_4`, `FK_Data_8`) or a target kind |

`-show-mc-encoding` prints them. Bits that depend on a fixup are shown as `A`:

```
	adrp	x8, :got:gv                     // encoding: [0x08'A',A,A,0x90'A']
                                        //   fixup A - offset: 0, value: :got:gv, kind: fixup_aarch64_pcrel_adrp_imm21
	ldr	x8, [x8, :got_lo12:gv]          // encoding: [0x08,0bAAAAAA01,0b01AAAAAA,0xf9]
                                        //   fixup A - offset: 0, value: :got_lo12:gv, kind: fixup_aarch64_ldst_imm12_scale8
	bl	g                               // encoding: [A,A,A,0b100101AA]
                                        //   fixup A - offset: 0, value: g, kind: fixup_aarch64_pcrel_call26
```

Read `bl g`: the top six bits `100101` are the `BL` opcode; the low 26 bits are the branch offset, unknown yet.

## Target Fixup Kinds

A target declares one kind per way an expression can be placed into an instruction. AArch64 (excerpt):

```cpp
  fixup_aarch64_pcrel_adr_imm21 = FirstTargetFixupKind,
  fixup_aarch64_pcrel_adrp_imm21,
  fixup_aarch64_add_imm12,
  fixup_aarch64_ldst_imm12_scale1,
  ...
  fixup_aarch64_ldst_imm12_scale8,
  ...
  fixup_aarch64_pcrel_branch19,
  fixup_aarch64_pcrel_branch26,
  fixup_aarch64_pcrel_call26,
```

`getFixupKindInfo` describes each one: bit offset, bit size, and whether it is PC-relative. The generic code uses that to know which bits to touch.

**Sources:** [llvm/lib/Target/AArch64/MCTargetDesc/AArch64FixupKinds.h:19-64](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64FixupKinds.h#L19-L64), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp:44-73](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp#L44-L73)

## Resolved or Relocated?

```mermaid
flowchart TD
  F["fixup after layout"] --> E["MCAssembler::evaluateFixup<br/>expression to MCValue"]
  E --> Q{"value fully known?<br/>(local symbol, same section,<br/>no forced relocation)"}
  Q -->|"yes"| A["AsmBackend::applyFixup<br/>patch bits"]
  Q -->|"no"| R["ELFObjectWriter::recordRelocation<br/>target getRelocType picks R_* type"]
  R --> A2["applyFixup patches any addend bits"]
```

AArch64's `applyFixup` shows both paths in a few lines:

```cpp
  if (shouldForceRelocation(Fixup))
    IsResolved = false;
  maybeAddReloc(F, Fixup, Target, Value, IsResolved);
  ...
  if (!Value)
    return; // Doesn't change encoding.
  ...
  // Apply any target-specific value adjustments.
  Value = adjustFixupValue(Fixup, Target, Value, Ctx, TheTriple, IsResolved);

  // Shift the value into position.
  Value <<= Info.TargetOffset;
  ...
      Data[i] |= uint8_t((Value >> (i * 8)) & 0xff);
```

`adjustFixupValue` converts a raw value into the field's encoding and checks its range. For branches, the byte offset is divided by 4 (`return Value >> 2;`), because AArch64 branch offsets count instructions.

**Sources:** [llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp:138-191](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp#L138-L191), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp:404-470](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64AsmBackend.cpp#L404-L470), [llvm/lib/MC/MCAssembler.cpp:144](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp#L144)

## Choosing the Relocation Type

The target's ELF writer maps fixup kind + specifier + PC-relativity to an ELF relocation number in `getRelocType`. For the fixups above, the mapping in `AArch64ELFObjectWriter.cpp` is:

| Fixup (from the listing) | Relocation | Source line |
| --- | --- | --- |
| `fixup_aarch64_pcrel_adrp_imm21` with `:got:` | `R_AARCH64_ADR_GOT_PAGE` | 168 |
| `fixup_aarch64_pcrel_adrp_imm21` with `:gottprel:` | `R_AARCH64_TLSIE_ADR_GOTTPREL_PAGE21` | 178 |
| `fixup_aarch64_pcrel_branch26` | `R_AARCH64_JUMP26` | 192 |
| `fixup_aarch64_pcrel_call26` | `R_AARCH64_CALL26` | 194 |
| `fixup_aarch64_pcrel_branch19` | `R_AARCH64_CONDBR19` | 221 |

The table is read from the source, not from an object file: this build has no `llvm-readelf` to print the relocation section.

The specifier matters as much as the kind: the same `adrp` fixup becomes a different relocation for `:got:`, `:gottprel:` or a plain symbol. `getRelocType` also reports impossible combinations (for example a `:plt:` specifier anywhere other than a `.word`).

**Sources:** [llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp:85-221](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp#L85-L221)

## The Generic ELF Writer

`ELFObjectWriter` (in `lib/MC`) does the format work so targets do not have to: `recordRelocation` collects relocations per section, `executePostLayoutBinding` resolves symbol aliases, and `ELFWriter::writeObject` writes the header, sections, symbol table, string tables and `.rela` sections. The target only supplies `getRelocType` and a few policy hooks (`needsRelocateWithSymbol`: relocate against the symbol or against its section).

**Sources:** [llvm/lib/MC/ELFObjectWriter.cpp:722-991](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/ELFObjectWriter.cpp#L722-L991), [llvm/lib/MC/ELFObjectWriter.cpp:1171-1403](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/ELFObjectWriter.cpp#L1171-L1403), [llvm/include/llvm/MC/MCELFObjectWriter.h:88-91](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCELFObjectWriter.h#L88-L91)