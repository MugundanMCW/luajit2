# Bring-up Checklist and Common Failures

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp)
- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp)
- [llvm/lib/Target/AArch64/MCTargetDesc/CMakeLists.txt](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/CMakeLists.txt)

</details>
This page orders the work of the previous pages into stages, each with a test you can run, followed by a table of common symptoms and their usual causes.

## Purpose and Scope

A step-by-step plan for a new target's MC layer. The tests use `llc`; where `llvm-mc` or `llvm-objdump` is needed, that is noted (this wiki's build does not have them).

## Stage 1: Text Output

- [ ] TableGen: every instruction has an `AsmString`; every operand that is not a plain register or immediate has a `PrintMethod`.
- [ ] `<T>MCAsmInfo` with at least `CommentString` set ([page](#asminfo-printer)).
- [ ] `<T>InstPrinter` including the generated `printInstruction` and `getRegisterName`.
- [ ] `LLVMInitialize<T>TargetMC` registers asm info, instr info, register info, subtarget info and the printer ([page](#custom-backend)).
- [ ] The `MCTargetDesc` library links only MC-level libraries (AArch64's links `MC`, `CodeGenTypes`, `Support`, ... but not `CodeGen`).

**Test:** `llc -mtriple=<t> -filetype=asm`. Add `-asm-show-inst` to see the `MCInst` behind each line and check that operands are in the order you expect.

## Stage 2: Encodings

- [ ] TableGen: `bits<N> Inst` with operand fields for every instruction; `EncoderMethod` for any operand that needs one.
- [ ] `<T>MCCodeEmitter::encodeInstruction` calling the generated `getBinaryCodeForInstr` ([page](#code-emitter)).
- [ ] Fixup kinds for every way an expression can be placed in an instruction ([page](#fixups-relocations)).

**Test:** `llc -show-mc-encoding`. Check the bytes for a few instructions of each format against the ISA manual, and check that symbol operands produce `fixup A - ... kind: fixup_<t>_...` lines.

## Stage 3: Object Files

- [ ] `<T>AsmBackend`: `getFixupKindInfo`, `applyFixup`, `writeNopData`, `createObjectTargetWriter` ([page](#asm-backend)).
- [ ] `<T>ELFObjectWriter::getRelocType` covering every fixup kind and specifier, reporting errors for the rest.
- [ ] Relaxation only if your ISA has variable-size forms: `mayNeedRelaxation`, `relaxInstruction`.

**Test:** `llc -filetype=obj` must succeed without assertions; this wiki's build produced a 1128-byte AArch64 object this way. To inspect it you need `llvm-readelf -r -s` and `llvm-objdump -d -r`.

## Stage 4: Assembler and Disassembler

- [ ] `<T>AsmParser`: `parseRegister`, `parseInstruction`, `matchAndEmitInstruction` with the generated `MatchInstructionImpl`; operand classes with predicates and render methods ([page](#parser-disassembler)).
- [ ] `<T>Disassembler::getInstruction` with the generated decoder tables, and a `DecoderMethod` for every register class.

**Test (needs `llvm-mc`):** `llvm-mc -triple=<t> -show-encoding` on a file of instructions, then `llvm-mc --disassemble` on the bytes. The text must survive the round trip. Write these as `llvm/test/MC/<T>/` tests.

## Symptoms and Causes

| Symptom | Usual cause |
| --- | --- |
| `llc` reports that it cannot create an object streamer or code emitter for the target | Code emitter or asm backend not registered in `LLVMInitialize<T>TargetMC` |
| Wrong operand order in `-asm-show-inst` | ISel or `MCInstLower` builds operands in a different order from the TableGen `(outs)` + `(ins)` list |
| Encodings off by a few bits | `Inst` field ranges wrong in TableGen, or a missing `PostEncoderMethod` |
| Fixup kind missing from the listing | Encoder method returns a value for an expression operand instead of adding a fixup |
| Assertion in `applyFixup` about the fixup offset | `getFixupKindInfo` size does not match the instruction size |
| Linker reports out-of-range or wrong relocation | `getRelocType` mapping wrong; check against your psABI. AArch64's mapping starts at `AArch64ELFObjectWriter.cpp:85` |
| Alias printed where the canonical form was wanted (or the reverse) | `InstAlias` priority, or `PrintAliases` setting |
| Assembler accepts the text but the disassembly differs | `AsmString`, `ParserMatchClass` and `DecoderMethod` disagree for that operand |
| Alignment padding is not executable | `writeNopData` writes the wrong bytes or the wrong unit size |

**Sources:** [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp:516-567](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp#L516-L567), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp:85-130](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64ELFObjectWriter.cpp#L85-L130)