# Assembler and Layout

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/MC/MCAssembler.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp)
- [llvm/lib/MC/MCObjectStreamer.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCObjectStreamer.cpp)
- [llvm/include/llvm/MC/MCSection.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCSection.h)
- [llvm/include/llvm/MC/MCAsmBackend.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCAsmBackend.h)

</details>
While the object streamer runs, nothing has an address yet: sections are just lists of fragments. When the streamer finishes, `MCAssembler` gives every fragment an offset, grows instructions that turn out to be too short (**relaxation**), and then resolves fixups and writes the bytes.

## Purpose and Scope

How `MCAssembler::Finish` turns fragments into final section contents. What happens to each fixup is on [Fixups and Relocations](#fixups-relocations).

## Fragments

A section is a chain of fragments. Each kind knows how to compute its own size (`MCAssembler::computeFragmentSize`):

| Kind | Contents | Size |
| --- | --- | --- |
| `FT_Data` | Encoded bytes plus fixups | Fixed |
| `FT_Relaxable` | One instruction that may need a longer form | Depends on the current encoding |
| `FT_Align` | Padding to an alignment | Depends on the offset |
| `FT_Fill`, `FT_Nops`, `FT_Org` | Repeated bytes, NOPs, move to an offset | Depends on expressions or offset |
| `FT_LEB`, `FT_Dwarf`, `FT_DwarfFrame` | Variable-length encodings | Depends on symbol differences |

**Sources:** [llvm/include/llvm/MC/MCSection.h:53-67](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCSection.h#L53-L67), [llvm/lib/MC/MCAssembler.cpp:208](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp#L208)

## Finish

```mermaid
flowchart TD
  A["MCObjectStreamer::finishImpl"] --> B["MCAssembler::Finish"]
  B --> C["layout()"]
  C --> D["layoutSection: assign offsets"]
  D --> E["relaxOnce until stable"]
  E --> F["backend finishLayout (optional extra pass)"]
  F --> G["object writer: executePostLayoutBinding"]
  B --> H["evaluate every fixup:<br/>apply value or record relocation"]
  H --> I["writeObject: sections, symbols, relocations"]
```

## layout

```cpp
  // Layout until everything fits.
  this->HasLayout = true;
  for (MCSection &Sec : *this)
    layoutSection(Sec);
  unsigned FirstStable = Sections.size();
  while ((FirstStable = relaxOnce(FirstStable)) > 0)
    if (getContext().hadError())
      return;

  // Some targets might want to adjust fragment offsets. If so, perform another
  // layout iteration.
  if (getBackend().finishLayout())
    for (MCSection &Sec : *this)
      layoutSection(Sec);
```

First every section gets ordinals and an initial layout. Then `relaxOnce` repeats until no fragment changes size.

**Sources:** [llvm/lib/MC/MCAssembler.cpp:668-720](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp#L668-L720), [llvm/lib/MC/MCAssembler.cpp:1121](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp#L1121)

## Relaxation

```cpp
      for (MCFragment &F : Sec) {
        if (F.Offset != Offset)
          Changed = true;
        Stretch = Offset - F.Offset;
        F.Offset = Offset;
        if (F.getKind() != MCFragment::FT_Data)
          relaxFragment(F);
        Offset += computeFragmentSize(F);
      }
```

Each pass walks the fragments in order, sets their offsets, and lets every non-data fragment re-check itself. For an `FT_Relaxable` instruction, `relaxInstruction` asks the backend whether the fixup's value still fits the current encoding (`fixupNeedsRelaxation`). If not, the backend replaces the instruction with a larger one (`MCAsmBackend::relaxInstruction`), which moves everything after it, so another pass runs. If anything changed, all sections are re-checked, because cross-section differences can change too.

The classic example is x86: a short `jmp` with an 8-bit displacement grows to a 32-bit one when the target is too far away.

**AArch64 hardly relaxes.** Every instruction is 4 bytes, and branches have fixed ranges. Branches out of range are handled by the linker (veneers) or reported as errors, so `AArch64AsmBackend` does not override `mayNeedRelaxation` and its instructions go straight into data fragments (`emitInstToData`).

**Sources:** [llvm/lib/MC/MCAssembler.cpp:1134-1160](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp#L1134-L1160), [llvm/lib/MC/MCAssembler.cpp:876](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp#L876), [llvm/lib/MC/MCAssembler.cpp:1078](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp#L1078), [llvm/include/llvm/MC/MCAsmBackend.h:139-155](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCAsmBackend.h#L139-L155)

## After Layout

With every fragment placed, every label has an address. `MCAssembler::evaluateFixup` computes each fixup's value. If it is fully known (same section, no symbol the linker might move) the backend's `applyFixup` patches it into the bytes. Otherwise the object writer records a relocation. Finally `writeSectionData` produces each section's bytes and the object writer writes the file.

**Sources:** [llvm/lib/MC/MCAssembler.cpp:144](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp#L144), [llvm/lib/MC/MCAssembler.cpp:603](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp#L603), [llvm/lib/MC/MCAssembler.cpp:801](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/MC/MCAssembler.cpp#L801)