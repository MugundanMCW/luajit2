# MCAsmInfo and the Instruction Printer

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCAsmInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCAsmInfo.cpp)
- [llvm/lib/Target/AArch64/MCTargetDesc/AArch64InstPrinter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64InstPrinter.cpp)
- [llvm/include/llvm/MC/MCInstPrinter.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCInstPrinter.h)
- [llvm/lib/Target/AArch64/CMakeLists.txt](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt)

</details>
`MCAsmInfo` holds the facts about the assembly syntax and object format that generic code needs: the comment string, directive spellings, label prefixes, alignment rules and the exception-handling model. `MCInstPrinter` turns one `MCInst` into text. These two pieces are enough to make `llc -filetype=asm` work.

## Purpose and Scope

What to set in `MCAsmInfo`, and how a printer is built from TableGen output plus a few hand-written operand printers.

## MCAsmInfo

`MCAsmInfo` has no virtual "do it" method. A target subclasses it and sets fields in its constructor. AArch64 has one subclass per object format. The ELF one sets, among other things:

| Field | AArch64 ELF value | Effect |
| --- | --- | --- |
| `CommentString` | `"//"` | The `// encoding: ...` comments in every listing |
| `Data64bitsDirective` | `"\t.xword\t"` | How 8-byte data is printed |
| `SupportsDebugInformation` | `true` | DWARF emission allowed |
| `ExceptionsType` | `ExceptionHandling::DwarfCFI` | `.cfi_*` unwind directives |

The Darwin subclass uses `";"` as its comment string, and the Microsoft COFF one uses `ExceptionHandling::WinEH`. `createAArch64MCAsmInfo` chooses the subclass from the triple.

```cpp
// ToyMCAsmInfo.cpp (illustrative, not LLVM source)
ToyMCAsmInfo::ToyMCAsmInfo(const Triple &TT) {
  CommentString = "#";
  SupportsDebugInformation = true;
  ExceptionsType = ExceptionHandling::DwarfCFI;
  Data64bitsDirective = "\t.quad\t";
}
```

**Sources:** [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCAsmInfo.cpp:146-163](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCAsmInfo.cpp#L146-L163), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCAsmInfo.cpp:211-240](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCAsmInfo.cpp#L211-L240), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCAsmInfo.cpp:266-280](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCAsmInfo.cpp#L266-L280), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp:346](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64MCTargetDesc.cpp#L346)

## The Instruction Printer

There are two virtuals to provide:

```cpp
virtual void printInst(const MCInst *MI, uint64_t Address, StringRef Annot,
                       const MCSubtargetInfo &STI, raw_ostream &OS) = 0;
virtual void printRegName(raw_ostream &OS, MCRegister Reg);
```

Most of the work is generated. `-gen-asm-writer` reads each instruction's `AsmString` (for example `"add $Rd, $Rn, $Rm"`) and generates `printInstruction`, which prints the literal text and calls an operand printer for each `$operand`. It also generates `printAliasInstr` from `InstAlias` records. AArch64 runs the generator twice, once per syntax variant (`AArch64GenAsmWriter.inc`, `AArch64GenAsmWriter1.inc`).

The hand-written `printInst` deals with special cases, then falls back to the generated code:

```cpp
  if (!PrintAliases || !printAliasInstr(MI, Address, STI, O))
    printInstruction(MI, Address, STI, O);
```

This is why the `MCInst` `ORRWrs W19, WZR, W0` prints as `mov w19, w0`: an `InstAlias` matched first. Operand printers such as `printOperand` print registers, immediates and expressions. A target adds its own (for example `printShifter`) and names them in the operand definitions in TableGen with `PrintMethod = "..."`.

**Sources:** [llvm/include/llvm/MC/MCInstPrinter.h:145-153](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/MC/MCInstPrinter.h#L145-L153), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64InstPrinter.cpp:38-90](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64InstPrinter.cpp#L38-L90), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64InstPrinter.cpp:374-375](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64InstPrinter.cpp#L374-L375), [llvm/lib/Target/AArch64/MCTargetDesc/AArch64InstPrinter.cpp:1243](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/MCTargetDesc/AArch64InstPrinter.cpp#L1243), [llvm/lib/Target/AArch64/CMakeLists.txt:6-7](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt#L6-L7)

## A Minimal Printer (Illustrative)

```cpp
// ToyInstPrinter.cpp (illustrative, not LLVM source)
#include "ToyGenAsmWriter.inc"          // printInstruction, getRegisterName

void ToyInstPrinter::printInst(const MCInst *MI, uint64_t Address,
                               StringRef Annot, const MCSubtargetInfo &STI,
                               raw_ostream &O) {
  printInstruction(MI, Address, O);
  printAnnotation(O, Annot);
}
void ToyInstPrinter::printOperand(const MCInst *MI, unsigned OpNo,
                                  raw_ostream &O) {
  const MCOperand &Op = MI->getOperand(OpNo);
  if (Op.isReg())      O << getRegisterName(Op.getReg());
  else if (Op.isImm()) O << Op.getImm();
  else                 MAI.printExpr(O, *Op.getExpr());
}
```

The printer serves both `llc` output and disassembler output, so print exactly what your assembler accepts.