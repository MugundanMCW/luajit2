# Instructions and Instruction Selection

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64InstrInfo.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.td)
- [llvm/lib/Target/AArch64/AArch64InstrFormats.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrFormats.td)
- [llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp)
- [llvm/lib/Target/AArch64/AArch64InstrInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.cpp)

</details>
Instructions are TableGen records derived from `Instruction`. Each record gives the operands, the assembly string, the encoding, scheduling information and, optionally, a DAG pattern. `-gen-instr-info` turns them into opcode enums and descriptor tables; `-gen-dag-isel` turns the patterns into a matcher table that the target's `SelectionDAGISel` subclass runs node by node.

## Purpose and Scope

What a target writes to get instruction selection working: instruction records, target DAG nodes, the selector class, and the `TargetInstrInfo` hooks that later passes need. The pattern syntax is covered by the SelectionDAG [pattern language page](../selectiondag-wiki.html#pattern-language), the matcher by the [matcher interpreter page](../selectiondag-wiki.html#matcher-interpreter), and AArch64's hand-written selection by the [AArch64 selection page](../selectiondag-wiki.html#aarch64-selection).

## Instruction Records

AArch64 builds most instructions from multiclasses in `AArch64InstrFormats.td`, which share operand lists and encoding layouts. Integer add and subtract are one line in `AArch64InstrInfo.td`:

```tablegen
defm ADD : AddSub<0, "add", "sub", add>;
```

`AddSub` (defined in `AArch64InstrFormats.td`) expands into the register, immediate, shifted-register and extended-register forms for 32 and 64 bits (`ADDWrr`, `ADDXri`, ...), and the last argument, the generic `add` node, becomes the selection pattern. That is why the first-milestone MIR shows `ADDWrr`:

```text
    %1:gpr32 = COPY $w1
    %0:gpr32 = COPY $w0
    %2:gpr32 = ADDWrr %0, %1
    $w0 = COPY %2
    RET_ReallyLR implicit $w0
```

(`llc -O2 -mtriple=aarch64-linux-gnu -stop-after=finalize-isel` on the `add` function from the [overview](#overview).)

**Sources:** [llvm/lib/Target/AArch64/AArch64InstrInfo.td:2811](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.td#L2811), [llvm/lib/Target/AArch64/AArch64InstrFormats.td:3096](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrFormats.td#L3096)

## Target DAG Nodes

Custom lowering (for calls, returns, globals) creates target-specific nodes. Each needs an `SDNode` record so patterns can match it:

```tablegen
def AArch64call          : SDNode<"AArch64ISD::CALL",
...
def AArch64retglue       : SDNode<"AArch64ISD::RET_GLUE", SDTNone,
```

The string is the C++ enum value; `-gen-sd-node-info` (`AArch64GenSDNodeInfo.inc` in AArch64's CMake file) generates the enum and the node names used in debug output.

**Sources:** [llvm/lib/Target/AArch64/AArch64InstrInfo.td:820](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.td#L820), [llvm/lib/Target/AArch64/AArch64InstrInfo.td:895](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.td#L895), [llvm/lib/Target/AArch64/CMakeLists.txt:26](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt#L26)

## The Selector Class

```mermaid
flowchart LR
    N["SDNode"] --> S["ToyDAGToDAGISel::Select(N)"]
    S -->|special cases| H["hand-written C++ (frame index, constants)"]
    S -->|everything else| SC["SelectCode(N)<br/>(generated matcher table)"]
    SC --> M["MachineSDNode"]
```

`AArch64DAGToDAGISel` derives from `SelectionDAGISel`, includes the generated matcher inside the class, and overrides `Select`. `Select` handles nodes that patterns cannot express and ends with a call to the generated `SelectCode(Node)`. `createAArch64ISelDag` wraps it in a legacy pass for `addInstSelector`.

| Location | Line |
| --- | --- |
| `class AArch64DAGToDAGISel : public SelectionDAGISel` | 49 |
| `#include "AArch64GenDAGISel.inc"` (inside the class) | 460 |
| `void AArch64DAGToDAGISel::Select(SDNode *Node)` | 5157 |
| `SelectCode(Node);` at the end of `Select` | 7820 |
| `createAArch64ISelDag` | 7825 |

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp:49](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp#L49), [llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp:460](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp#L460), [llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp:5157](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp#L5157), [llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp:7820-7825](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp#L7820-L7825)

## TargetInstrInfo Hooks Needed Early

Selection alone is not enough: later generic passes ask `TargetInstrInfo` to create copies, spills and branches.

| Hook | Called by | AArch64 line | Needed for |
| --- | --- | --- | --- |
| `copyPhysReg` | Copy expansion after allocation | 6365 | Any function with a `COPY` that survives |
| `storeRegToStackSlot` / `loadRegFromStackSlot` | Spiller, callee-saved spills | 6400 / 6580 | Any spill |
| `analyzeBranch`, `insertBranch`, `removeBranch` | Branch folding, block placement | 523 / 839 / 772 | Correct `-O2` with control flow |
| `expandPostRAPseudo` | `postrapseudos` pass | 2559 | Pseudos like `RET_ReallyLR` that expand late |

`analyzeBranch` may return `true` ("can't analyze") at first; passes then leave the branches alone. The regalloc wiki's [TII hooks page](../regalloc-wiki/regalloc-wiki.html#tii-hooks) shows the copy and spill hooks in detail.

**Sources:** [llvm/lib/Target/AArch64/AArch64InstrInfo.cpp:523](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.cpp#L523), [llvm/lib/Target/AArch64/AArch64InstrInfo.cpp:772](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.cpp#L772), [llvm/lib/Target/AArch64/AArch64InstrInfo.cpp:839](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.cpp#L839), [llvm/lib/Target/AArch64/AArch64InstrInfo.cpp:2559](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.cpp#L2559), [llvm/lib/Target/AArch64/AArch64InstrInfo.cpp:6365-6580](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.cpp#L6365-L6580)

## Minimal Toy Instructions (Illustrative)

**Illustrative, not LLVM source.**

```tablegen
// ToyInstrInfo.td
def SDT_ToyCall : SDTypeProfile<0, -1, [SDTCisVT<0, i32>]>;
def ToyCall   : SDNode<"ToyISD::CALL", SDT_ToyCall,
                       [SDNPHasChain, SDNPOptInGlue, SDNPOutGlue, SDNPVariadic]>;
def ToyRet    : SDNode<"ToyISD::RET", SDTNone,
                       [SDNPHasChain, SDNPOptInGlue, SDNPVariadic]>;

class ToyInst<dag outs, dag ins, string asm, list<dag> pat>
    : Instruction {
  let Namespace = "Toy";
  let OutOperandList = outs;
  let InOperandList = ins;
  let AsmString = asm;
  let Pattern = pat;
  let Size = 4;
  field bits<32> Inst;
}

def simm16 : Operand<i32>, ImmLeaf<i32, [{ return isInt<16>(Imm); }]>;

def ADD  : ToyInst<(outs GPR:$rd), (ins GPR:$rs, GPR:$rt),
                   "add $rd, $rs, $rt", [(set GPR:$rd, (add GPR:$rs, GPR:$rt))]>;
def ADDI : ToyInst<(outs GPR:$rd), (ins GPR:$rs, simm16:$imm),
                   "addi $rd, $rs, $imm", [(set GPR:$rd, (add GPR:$rs, simm16:$imm))]>;
def LW   : ToyInst<(outs GPR:$rd), (ins GPR:$base, simm16:$off),
                   "lw $rd, ${off}(${base})", []> { let mayLoad = 1; }
def SW   : ToyInst<(outs), (ins GPR:$rs, GPR:$base, simm16:$off),
                   "sw $rs, ${off}(${base})", []> { let mayStore = 1; }

let isReturn = 1, isTerminator = 1, isBarrier = 1, Uses = [LR] in
def RET  : ToyInst<(outs), (ins), "ret", [(ToyRet)]>;

let isCall = 1, Defs = [LR] in
def CALL : ToyInst<(outs), (ins i32imm:$target), "call $target", []>;
def : Pat<(ToyCall tglobaladdr:$dst), (CALL tglobaladdr:$dst)>;

// load/store patterns using a ComplexPattern for base+offset
def AddrFI : ComplexPattern<iPTR, 2, "SelectAddr", [frameindex], []>;
def : Pat<(load AddrFI:$addr), (LW AddrFI:$addr)>;
def : Pat<(store GPR:$v, AddrFI:$addr), (SW GPR:$v, AddrFI:$addr)>;
```

```cpp
// ToyISelDAGToDAG.cpp (illustrative)
class ToyDAGToDAGISel : public SelectionDAGISel {
public:
  explicit ToyDAGToDAGISel(ToyTargetMachine &TM, CodeGenOptLevel OL)
      : SelectionDAGISel(TM, OL) {}
  void Select(SDNode *N) override {
    if (N->isMachineOpcode()) { N->setNodeId(-1); return; }
    if (N->getOpcode() == ISD::FrameIndex) {
      int FI = cast<FrameIndexSDNode>(N)->getIndex();
      SDValue TFI = CurDAG->getTargetFrameIndex(FI, MVT::i32);
      ReplaceNode(N, CurDAG->getMachineNode(Toy::ADDI, SDLoc(N), MVT::i32, TFI,
                         CurDAG->getTargetConstant(0, SDLoc(N), MVT::i32)));
      return;
    }
    SelectCode(N);
  }
  bool SelectAddr(SDValue Addr, SDValue &Base, SDValue &Off);
#include "ToyGenDAGISel.inc"
};
```

Frame-index operands produced here are rewritten to real offsets by `eliminateFrameIndex`; see [Frame Lowering](#frame-lowering).