# Scheduling

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/Target/TargetSchedule.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetSchedule.td)
- [llvm/lib/Target/AArch64/AArch64SchedA57.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64SchedA57.td)
- [llvm/lib/Target/AArch64/AArch64Schedule.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Schedule.td)
- [llvm/lib/Target/AArch64/AArch64Subtarget.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Subtarget.cpp)
- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)

</details>
A backend produces correct code without any scheduling model: the schedulers fall back to default latencies. A model becomes necessary when performance matters. It tells the machine scheduler how many micro-ops issue per cycle, which execution units each instruction uses, and how long results take.

## Purpose and Scope

What a new target needs for scheduling: enabling the machine scheduler, `SchedWrite` types on instructions, and a per-CPU `SchedMachineModel`. The [instruction scheduling wiki](../sched-wiki/sched-wiki.html#overview) covers the [scheduling DAG](../sched-wiki/sched-wiki.html#schedule-dag), the [machine scheduler](../sched-wiki/sched-wiki.html#machine-scheduler), [register pressure](../sched-wiki/sched-wiki.html#register-pressure), [post-RA scheduling](../sched-wiki/sched-wiki.html#post-ra), the [model language](../sched-wiki/sched-wiki.html#sched-model) and [how a target wires it up](../sched-wiki/sched-wiki.html#wiring). Where the pre-RA scheduler sits relative to register allocation is on the regalloc [pipeline page](../regalloc-wiki/regalloc-wiki.html#pipeline); the older SelectionDAG scheduler is on the SelectionDAG [scheduling and emission page](../selectiondag-wiki.html#scheduling-emission).

## Three Steps

```mermaid
flowchart TD
    A["1. Subtarget: enableMachineScheduler() returns true"] --> B["2. ToySchedule.td: SchedWrite types; instructions list them with Sched<[...]>"]
    B --> C["3. ToySchedModel.td: SchedMachineModel + ProcResource + WriteRes per SchedWrite"]
    C --> D["ProcessorModel<'toy2', ToyModel, ...>"]
```

### 1. Turn the machine scheduler on

AArch64's subtarget header has `bool enableMachineScheduler() const override { return true; }`. Without it the pre-RA `machine-scheduler` pass does nothing for the target.

**Sources:** [llvm/lib/Target/AArch64/AArch64Subtarget.h:160-161](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Subtarget.h#L160-L161)

### 2. Abstract scheduling types

`AArch64Schedule.td` defines target-wide types, one per kind of operation:

```tablegen
def WriteI         : SchedWrite; // ALU
def WriteISReg     : SchedWrite; // ALU of Shifted-Reg
def ReadI          : SchedRead;  // ALU
...
def WriteIM64      : SchedWrite; // 64-bit Multiply
def WriteBr        : SchedWrite; // Branch
def WriteLD        : SchedWrite; // Load from base addr plus immediate offset
def WriteST        : SchedWrite; // Store to base addr plus immediate offset
```

Instructions list these in `Sched<[...]>`, one entry per defined operand followed by one per read operand. They say nothing about any particular CPU.

**Sources:** [llvm/lib/Target/AArch64/AArch64Schedule.td:24-44](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Schedule.td#L24-L44)

### 3. A per-CPU model

The Cortex-A57 model sets machine-wide parameters, declares execution units, and maps each `SchedWrite` to units and a latency:

```tablegen
def CortexA57Model : SchedMachineModel {
  let IssueWidth        =   3; // 3-way decode and dispatch
  let MicroOpBufferSize = 128; // 128 micro-op re-order buffer
  let LoadLatency       =   4; // Optimistic load latency
  let MispredictPenalty =  14; // Fetch + Decode/Rename/Dispatch + Branch
  ...
  let CompleteModel = 1;
  ...
}
...
def A57UnitB : ProcResource<1>;  // Type B micro-ops
def A57UnitI : ProcResource<2>;  // Type I micro-ops
def A57UnitM : ProcResource<1>;  // Type M micro-ops
def A57UnitL : ProcResource<1>;  // Type L micro-ops
...
def : SchedAlias<WriteLD,    A57Write_4cyc_1L>;
...
def : WriteRes<WriteFMul, [A57UnitV]> { let Latency = 5;}
```

`ProcessorModel<"cortex-a57", CortexA57Model, ...>` in `AArch64Processors.td` attaches the model to the CPU name (see [The Target .td File](#target-td)). `CompleteModel = 1` makes TableGen report every instruction that has no scheduling information.

**Sources:** [llvm/lib/Target/AArch64/AArch64SchedA57.td:23-51](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64SchedA57.td#L23-L51), [llvm/lib/Target/AArch64/AArch64SchedA57.td:85-98](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64SchedA57.td#L85-L98), [llvm/include/llvm/Target/TargetSchedule.td:76-97](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetSchedule.td#L76-L97)

## Target Hooks Around the Scheduler

| Hook | Where | AArch64 does |
| --- | --- | --- |
| `createMachineScheduler` | `TargetMachine` | Adds load and store clustering mutations, and macro fusion when the CPU supports it |
| `createPostMachineScheduler` | `TargetMachine` | Uses its own post-RA strategy; macro fusion again |
| `overrideSchedPolicy` | Subtarget | Schedules both top-down and bottom-up (`OnlyTopDown = OnlyBottomUp = false`) |
| `substitutePass(&PostRASchedulerID, &PostMachineSchedulerID)` | Pass config constructor | Uses the post-RA machine scheduler instead of the old list scheduler |

**Sources:** [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:524-550](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L524-L550), [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:582-587](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L582-L587), [llvm/lib/Target/AArch64/AArch64Subtarget.cpp:513-523](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Subtarget.cpp#L513-L523)

## What It Changes

For a small dot-product function (three pairs of loads, multiplies, adds), with `llc -O2 -mtriple=aarch64-linux-gnu -mcpu=cortex-a57`, the pre-RA scheduler moves the second load from `%0` next to the first, because the load-clustering mutation keeps same-base loads together (MIR just before and just after `machine-scheduler`):

```text
before:                                   after:
%2:gpr64 = LDRXui %0, 0                   %2:gpr64 = LDRXui %0, 0
%3:gpr64 = LDRXui %1, 0                   %5:gpr64 = LDRXui %0, 1
%5:gpr64 = LDRXui %0, 1                   %3:gpr64 = LDRXui %1, 0
%6:gpr64 = LDRXui %1, 1                   %6:gpr64 = LDRXui %1, 1
```

The full comparison, including what the post-RA scheduler changes, is on the [scheduling walkthroughs page](../sched-wiki/sched-wiki.html#aarch64-walkthroughs).

## Minimal Toy Model (Illustrative)

**Illustrative, not LLVM source.**

```tablegen
// ToySchedule.td: target-wide types
def WriteALU : SchedWrite;
def WriteLoad : SchedWrite;
def WriteStore : SchedWrite;
def WriteBranch : SchedWrite;
def ReadALU : SchedRead;

// ToySchedToy2.td: one CPU
def ToyModel : SchedMachineModel {
  let IssueWidth = 1;
  let MicroOpBufferSize = 0;   // in-order
  let LoadLatency = 2;
  let CompleteModel = 1;
}
let SchedModel = ToyModel in {
  def ToyALU : ProcResource<1>;
  def ToyLSU : ProcResource<1>;
  def : WriteRes<WriteALU, [ToyALU]>    { let Latency = 1; }
  def : WriteRes<WriteLoad, [ToyLSU]>   { let Latency = 2; }
  def : WriteRes<WriteStore, [ToyLSU]>  { let Latency = 1; }
  def : WriteRes<WriteBranch, [ToyALU]> { let Latency = 1; }
  def : ReadAdvance<ReadALU, 0>;
}
```

Instructions then carry `Sched<[WriteALU, ReadALU, ReadALU]>` and so on. The [scheduling custom backend page](../sched-wiki/sched-wiki.html#custom-backend) explains how to check that the model is complete.