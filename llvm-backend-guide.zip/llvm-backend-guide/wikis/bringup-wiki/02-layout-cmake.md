# Directory Layout, CMake and Registration

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/CMakeLists.txt](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/CMakeLists.txt)
- [llvm/lib/Target/AArch64/CMakeLists.txt](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt)
- [llvm/lib/Target/AArch64/TargetInfo/AArch64TargetInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/TargetInfo/AArch64TargetInfo.cpp)
- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)
- [llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp)

</details>
A target lives in `llvm/lib/Target/<T>/` and is built as several small libraries. Each library exports an `LLVMInitialize<T>...` function that registers its part with `TargetRegistry`. Tools such as `llc` call all of these functions at startup and then look the target up by name (`-march=toy`) or by triple (`-mtriple=toy-unknown-elf`).

## Purpose and Scope

The files and directories a target needs, how CMake builds them, how `LLVM_TARGETS_TO_BUILD` selects targets, and the registration functions. Instruction and register TableGen are on [The Target .td File](#target-td).

## Directory Layout

| Directory | Contents | Library | Init function |
| --- | --- | --- | --- |
| `lib/Target/<T>/` | `<T>.td`, `<T>TargetMachine`, `<T>Subtarget`, `<T>ISelLowering`, `<T>ISelDAGToDAG`, `<T>InstrInfo`, `<T>RegisterInfo`, `<T>FrameLowering`, `<T>AsmPrinter`, `<T>MCInstLower` | `LLVM<T>CodeGen` | `LLVMInitialize<T>Target`, `LLVMInitialize<T>AsmPrinter` |
| `lib/Target/<T>/TargetInfo/` | `getThe<T>Target()` | `LLVM<T>Info` | `LLVMInitialize<T>TargetInfo` |
| `lib/Target/<T>/MCTargetDesc/` | MC objects (asm info, printer, code emitter, asm backend) | `LLVM<T>Desc` | `LLVMInitialize<T>TargetMC` |
| `lib/Target/<T>/AsmParser/` | Assembly parser | `LLVM<T>AsmParser` | `LLVMInitialize<T>AsmParser` |
| `lib/Target/<T>/Disassembler/` | Disassembler | `LLVM<T>Disassembler` | `LLVMInitialize<T>Disassembler` |

The `TargetInfo` library is tiny and depends on nothing else in the target, so tools that only need the target's name can link it alone. The MC libraries must not depend on CodeGen (see the [MC custom backend page](../mc-wiki/mc-wiki.html#custom-backend)).

## Choosing Targets to Build

`llvm/CMakeLists.txt` lists the core targets in `LLVM_ALL_TARGETS` and the experimental ones in `LLVM_ALL_EXPERIMENTAL_TARGETS`. `LLVM_TARGETS_TO_BUILD` defaults to all core targets; a new target starts as experimental and is enabled with `LLVM_EXPERIMENTAL_TARGETS_TO_BUILD`.

```cmake
set(LLVM_ALL_TARGETS
  AArch64
  AMDGPU
  ...
  X86
  XCore
  )

set(LLVM_ALL_EXPERIMENTAL_TARGETS
  ARC
  CSKY
  M68k
  Xtensa
)
```

For a new target, configure with `-DLLVM_EXPERIMENTAL_TARGETS_TO_BUILD=Toy` (and, to save build time, `-DLLVM_TARGETS_TO_BUILD=AArch64` or similar). CMake checks every requested name against these lists and stops with an error listing the valid names if one is unknown.

**Sources:** [llvm/CMakeLists.txt:578-607](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/CMakeLists.txt#L578-L607), [llvm/CMakeLists.txt:716](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/CMakeLists.txt#L716), [llvm/CMakeLists.txt:1157-1165](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/CMakeLists.txt#L1157-L1165)

## The Target's CMakeLists.txt

AArch64's file does three things:

1. Names the root TableGen file: `set(LLVM_TARGET_DEFINITIONS AArch64.td)`.
2. Runs `llvm-tblgen` once per backend, each producing one `.inc` file:

```cmake
tablegen(LLVM AArch64GenAsmMatcher.inc -gen-asm-matcher)
tablegen(LLVM AArch64GenAsmWriter.inc -gen-asm-writer)
tablegen(LLVM AArch64GenCallingConv.inc -gen-callingconv)
tablegen(LLVM AArch64GenDAGISel.inc -gen-dag-isel)
tablegen(LLVM AArch64GenDisassemblerTables.inc -gen-disassembler)
tablegen(LLVM AArch64GenInstrInfo.inc -gen-instr-info)
tablegen(LLVM AArch64GenMCCodeEmitter.inc -gen-emitter)
tablegen(LLVM AArch64GenRegisterInfo.inc -gen-register-info)
tablegen(LLVM AArch64GenSubtargetInfo.inc -gen-subtarget)
...
add_public_tablegen_target(AArch64CommonTableGen)
```

3. Declares the CodeGen library with `add_llvm_target(AArch64CodeGen ...)` listing the `.cpp` files and `LINK_COMPONENTS`, then adds the subdirectories (`TargetInfo`, `MCTargetDesc`, `AsmParser`, `Disassembler`, `Utils`).

The first line, `add_llvm_component_group(AArch64 HAS_JIT)`, creates the `AArch64` component name used by `llvm-config` and by other components' `LINK_COMPONENTS`.

| `tablegen` backend | Output used by | Needed for first milestone |
| --- | --- | --- |
| `-gen-register-info` | `<T>RegisterInfo`, MC register info | Yes |
| `-gen-instr-info` | `<T>InstrInfo`, MC instr info | Yes |
| `-gen-subtarget` | `<T>Subtarget`, scheduling model | Yes |
| `-gen-callingconv` | `<T>ISelLowering.cpp` | Yes |
| `-gen-dag-isel` | `<T>ISelDAGToDAG.cpp` | Yes |
| `-gen-asm-writer` | `<T>InstPrinter` | Yes |
| `-gen-emitter` | `<T>MCCodeEmitter` | For `.o` |
| `-gen-asm-matcher` | `<T>AsmParser` | For `.s` input |
| `-gen-disassembler` | `<T>Disassembler` | For `llvm-objdump` |

**Sources:** [llvm/lib/Target/AArch64/CMakeLists.txt:1-33](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt#L1-L33)

## Registration

```mermaid
sequenceDiagram
    participant llc
    participant Info as LLVMInitializeToyTargetInfo
    participant TM as LLVMInitializeToyTarget
    participant MC as LLVMInitializeToyTargetMC
    participant AP as LLVMInitializeToyAsmPrinter
    llc->>Info: RegisterTarget (name, description, triple arch)
    llc->>TM: RegisterTargetMachine, initialize passes
    llc->>MC: Register MCAsmInfo, InstrInfo, RegInfo, ...
    llc->>AP: RegisterAsmPrinter
    llc->>llc: TargetRegistry::lookupTarget(triple)
```

### TargetInfo

Each target is a single static `Target` object returned by a function. `RegisterTarget<Arch, HasJIT>` binds it to a `Triple::ArchType`, a short name for `-march`, and a description:

```cpp
Target &llvm::getTheAArch64leTarget() {
  static Target TheAArch64leTarget;
  return TheAArch64leTarget;
}
...
extern "C" LLVM_ABI LLVM_EXTERNAL_VISIBILITY void
LLVMInitializeAArch64TargetInfo() {
  ...
  RegisterTarget<Triple::aarch64, /*HasJIT=*/true> Z(
      getTheAArch64leTarget(), "aarch64", "AArch64 (little endian)", "AArch64");
  ...
}
```

A new architecture also needs an entry in `Triple::ArchType` and the triple parser (`llvm/lib/TargetParser/Triple.cpp`), so that `toy-unknown-elf` parses to `Triple::toy`. The data layout for the triple is computed in `llvm/lib/TargetParser/TargetDataLayout.cpp` (see [TargetMachine and Subtarget](#targetmachine-subtarget)).

**Sources:** [llvm/lib/Target/AArch64/TargetInfo/AArch64TargetInfo.cpp:14-52](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/TargetInfo/AArch64TargetInfo.cpp#L14-L52)

### Target machine, MC and AsmPrinter

`LLVMInitializeAArch64Target` registers the target machine class for each `Target` object and initializes the target's own machine passes so they can be named on the command line:

```cpp
extern "C" LLVM_ABI LLVM_EXTERNAL_VISIBILITY void
LLVMInitializeAArch64Target() {
  // Register the target.
  RegisterTargetMachine<AArch64leTargetMachine> X(getTheAArch64leTarget());
  RegisterTargetMachine<AArch64beTargetMachine> Y(getTheAArch64beTarget());
  ...
  auto &PR = *PassRegistry::getPassRegistry();
  initializeGlobalISel(PR);
  initializeAArch64A53Fix835769LegacyPass(PR);
  ...
}
```

The AsmPrinter is registered from the CodeGen library too:

```cpp
LLVMInitializeAArch64AsmPrinter() {
  RegisterAsmPrinter<AArch64AsmPrinter> X(getTheAArch64leTarget());
  RegisterAsmPrinter<AArch64AsmPrinter> Y(getTheAArch64beTarget());
  ...
}
```

MC registration (`LLVMInitializeAArch64TargetMC`) is shown on the [MC custom backend page](../mc-wiki/mc-wiki.html#custom-backend).

**Sources:** [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:234-287](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L234-L287), [llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp:4187-4192](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp#L4187-L4192)

## Minimal Files for Toy (Illustrative)

**Illustrative, not LLVM source.**

```cmake
# lib/Target/Toy/CMakeLists.txt (illustrative)
add_llvm_component_group(Toy)
set(LLVM_TARGET_DEFINITIONS Toy.td)
tablegen(LLVM ToyGenRegisterInfo.inc -gen-register-info)
tablegen(LLVM ToyGenInstrInfo.inc -gen-instr-info)
tablegen(LLVM ToyGenSubtargetInfo.inc -gen-subtarget)
tablegen(LLVM ToyGenCallingConv.inc -gen-callingconv)
tablegen(LLVM ToyGenDAGISel.inc -gen-dag-isel)
tablegen(LLVM ToyGenAsmWriter.inc -gen-asm-writer)
tablegen(LLVM ToyGenMCCodeEmitter.inc -gen-emitter)
add_public_tablegen_target(ToyCommonTableGen)

add_llvm_target(ToyCodeGen
  ToyAsmPrinter.cpp ToyFrameLowering.cpp ToyInstrInfo.cpp
  ToyISelDAGToDAG.cpp ToyISelLowering.cpp ToyMCInstLower.cpp
  ToyRegisterInfo.cpp ToySubtarget.cpp ToyTargetMachine.cpp
  LINK_COMPONENTS
  AsmPrinter CodeGen CodeGenTypes Core MC SelectionDAG Support Target
  TargetParser ToyDesc ToyInfo
  ADD_TO_COMPONENT Toy)

add_subdirectory(MCTargetDesc)
add_subdirectory(TargetInfo)
```

```cpp
// TargetInfo/ToyTargetInfo.cpp (illustrative)
Target &llvm::getTheToyTarget() {
  static Target TheToyTarget;
  return TheToyTarget;
}
extern "C" LLVM_EXTERNAL_VISIBILITY void LLVMInitializeToyTargetInfo() {
  RegisterTarget<Triple::toy> X(getTheToyTarget(), "toy", "Toy example", "Toy");
}
```

After this step `llc --version` lists `toy` under "Registered Targets", even before the target machine exists.