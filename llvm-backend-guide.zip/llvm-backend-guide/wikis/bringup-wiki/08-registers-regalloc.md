# Registers and Allocation Hooks

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp)
- [llvm/lib/Target/AArch64/AArch64CallingConvention.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td)
- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)

</details>
Registers are described once in TableGen (`Register`, `RegisterClass`, sub-register indices). `-gen-register-info` produces the register enum, class tables and a `<T>GenRegisterInfo` base class. The target's `<T>RegisterInfo` derives from it and answers the questions the register allocator and frame lowering ask: which registers are reserved, which are callee-saved, what a call clobbers, and how to turn a frame index into a register plus offset.

## Purpose and Scope

The minimum register description and `TargetRegisterInfo` hooks for a new target. The [register allocation wiki](../regalloc-wiki/regalloc-wiki.html#custom-backend) covers this in depth: [TableGen registers](../regalloc-wiki/regalloc-wiki.html#tablegen-registers), [TRI hooks](../regalloc-wiki/regalloc-wiki.html#tri-hooks), [TII hooks](../regalloc-wiki/regalloc-wiki.html#tii-hooks), [pass config hooks](../regalloc-wiki/regalloc-wiki.html#pass-config-hooks) and its [backend checklist](../regalloc-wiki/regalloc-wiki.html#backend-checklist).

## How the Pieces Connect

```mermaid
flowchart LR
    RTD["ToyRegisterInfo.td<br/>registers, classes"] -->|-gen-register-info| GEN["ToyGenRegisterInfo.inc"]
    CTD["ToyCallingConv.td<br/>CSR_Toy"] -->|-gen-register-info| GEN
    GEN --> TRI["ToyRegisterInfo"]
    TRI -->|getReservedRegs| RA["Register allocator"]
    TRI -->|getCalleeSavedRegs| PEI["Prologue/epilogue insertion"]
    TRI -->|getCallPreservedMask| LC["LowerCall regmask operand"]
    TRI -->|eliminateFrameIndex| PEI
    TL["TargetLowering::addRegisterClass"] --> RA
```

A register class becomes usable for a value type only when `TargetLowering` adds it with `addRegisterClass` ([TargetLowering Setup](#targetlowering)). AArch64's `addRegisterClass(MVT::i64, &AArch64::GPR64allRegClass)` is where the generated `GPR64allRegClass` object is first used.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:486-487](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L486-L487)

## The Hooks a New Target Writes

| Hook | Question it answers | AArch64 line | Required |
| --- | --- | --- | --- |
| `getCalleeSavedRegs(MF)` | Which registers must a function preserve? Returns the generated `CSR_*_SaveList` | 72 | Yes (pure virtual) |
| `getCallPreservedMask(MF, CC)` | Which registers survive a call? Returns `CSR_*_RegMask`, attached to every call | 270-271 | Yes, for calls |
| `getReservedRegs(MF)` | Which registers the allocator must never use (SP, zero register, FP when used) | 534-535 | Yes (pure virtual) |
| `getFrameRegister(MF)` | Base register for frame references (FP or SP) | 752-753 | Yes (pure virtual) |
| `eliminateFrameIndex(...)` | Rewrite a frame-index operand into register + offset | 978 | Yes (pure virtual) |
| `requiresRegisterScavenging(MF)` | Can frame-index elimination need a scratch register? | 758 | Usually |
| `requiresFrameIndexScavenging(MF)` | Scavenge virtual registers created during elimination | 787 | Optional |
| `hasBasePointer(MF)` | Need a third frame base register (realigned stack plus variable-sized objects)? | 623 | Optional |

AArch64 splits reserved registers into two functions: `getStrictlyReservedRegs` (never allocatable, such as SP and the zero register) at line 418-419 and `getReservedRegs` at 534-535, which adds registers the user asked to reserve.

The callee-saved list comes straight from the calling convention file:

```tablegen
def CSR_AArch64_AAPCS : CalleeSavedRegs<(add X19, X20, X21, X22, X23, X24,
```

**Sources:** [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:72](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L72), [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:270-271](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L270-L271), [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:418-419](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L418-L419), [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:534-535](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L534-L535), [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:623](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L623), [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:752-787](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L752-L787), [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:978](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L978), [llvm/lib/Target/AArch64/AArch64CallingConvention.td:594](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L594)

## What the Allocator Does with Them

With these hooks in place the generic allocators work without further target code. In the AArch64 `notail` function (from the [calling conventions walkthroughs](../callconv-wiki/callconv-wiki.html#aarch64-walkthroughs)), the value of `x0` must survive a call, so the allocator picks the callee-saved `x19`, and frame lowering then saves and restores it because it is in the `CSR_AArch64_AAPCS` list:

```asm
	stp	x30, x19, [sp, #-16]!           // 16-byte Folded Spill
	...
	mov	x19, x0
	bl	g
	add	x0, x0, x19
	ldp	x30, x19, [sp], #16             // 16-byte Folded Reload
	ret
```

(`llc -O2 -mtriple=aarch64-linux-gnu`.) The regmask on the `BL` instruction is what told the allocator that `x0`-`x18` do not survive the call.

## Minimal Toy Registers (Illustrative)

**Illustrative, not LLVM source.**

```tablegen
// ToyRegisterInfo.td
class ToyReg<bits<5> num, string n> : Register<n> {
  let HWEncoding{4-0} = num;
  let Namespace = "Toy";
}
foreach i = 0-15 in
  def R#i : ToyReg<i, "r"#i>, DwarfRegNum<[i]>;
def SP : ToyReg<16, "sp">, DwarfRegNum<[16]>;
def LR : ToyReg<17, "lr">, DwarfRegNum<[17]>;

def GPR : RegisterClass<"Toy", [i32], 32,
                        (add (sequence "R%u", 0, 15), SP, LR)>;
```

```cpp
// ToyRegisterInfo.cpp (illustrative)
ToyRegisterInfo::ToyRegisterInfo() : ToyGenRegisterInfo(Toy::LR) {}

const MCPhysReg *ToyRegisterInfo::getCalleeSavedRegs(const MachineFunction *) const {
  return CSR_Toy_SaveList;
}
const uint32_t *ToyRegisterInfo::getCallPreservedMask(const MachineFunction &,
                                                      CallingConv::ID) const {
  return CSR_Toy_RegMask;
}
BitVector ToyRegisterInfo::getReservedRegs(const MachineFunction &MF) const {
  BitVector R(getNumRegs());
  R.set(Toy::SP);
  if (getFrameLowering(MF)->hasFP(MF))
    R.set(Toy::R11);                       // frame pointer
  return R;
}
Register ToyRegisterInfo::getFrameRegister(const MachineFunction &MF) const {
  return getFrameLowering(MF)->hasFP(MF) ? Toy::R11 : Toy::SP;
}
```

`eliminateFrameIndex` for Toy is on the [Frame Lowering](#frame-lowering) page.