# Calling Conventions

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64CallingConvention.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td)
- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)
- [llvm/include/llvm/CodeGen/CallingConvLower.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/CallingConvLower.h)

</details>
A calling convention says where each argument and return value lives: which register, or which stack offset. In LLVM the rules are written in TableGen (`CallingConv` records), compiled by `-gen-callingconv` into C++ functions, and used by three `TargetLowering` hooks that every target must implement: `LowerFormalArguments`, `LowerCall` and `LowerReturn`.

## Purpose and Scope

The minimum a new target needs for calls to work, with AArch64 as reference. The [calling conventions wiki](../callconv-wiki/callconv-wiki.html#overview) covers each part in depth: the [TableGen language](../callconv-wiki/callconv-wiki.html#cc-td), [`CCState`](../callconv-wiki/callconv-wiki.html#ccstate), the three hooks, varargs and tail calls. Where call lowering happens during DAG building is on the SelectionDAG [DAG construction page](../selectiondag-wiki.html#dag-construction).

## The Three Pieces

```mermaid
flowchart LR
    TD["ToyCallingConv.td<br/>CC_Toy, RetCC_Toy, CSR_Toy"] -->|-gen-callingconv| INC["ToyGenCallingConv.inc"]
    INC --> LFA["LowerFormalArguments<br/>(incoming args)"]
    INC --> LC["LowerCall<br/>(outgoing args, call node, results)"]
    INC --> LR["LowerReturn<br/>(return values)"]
    TD -->|-gen-register-info| CSR["CSR_Toy_SaveList / RegMask"]
    CSR --> TRI["ToyRegisterInfo::getCalleeSavedRegs,<br/>getCallPreservedMask"]
```

### TableGen rules

AArch64's AAPCS rules are one list of actions tried in order for each value. Integer rules from that list:

```tablegen
  CCIfType<[i1, i8, i16], CCPromoteToType<i32>>,
  CCIfType<[i32], CCAssignToReg<[W0, W1, W2, W3, W4, W5, W6, W7]>>,
  ...
  CCIfType<[i64], CCAssignToReg<[X0, X1, X2, X3, X4, X5, X6, X7]>>,
  ...
  // If more than will fit in registers, pass them on the stack instead.
  CCIfType<[i1, i8, i16, f16, bf16], CCAssignToStack<8, 8>>,
  CCIfType<[i32, f32], CCAssignToStack<8, 8>>,
```

`let Entry = 1 in def CC_AArch64_AAPCS : CallingConv<AArch64_Common>;` makes the generated function visible to C++. The callee-saved set is a separate record:

```tablegen
def CSR_AArch64_AAPCS : CalleeSavedRegs<(add X19, X20, X21, X22, X23, X24,
```

`-gen-register-info` turns it into `CSR_AArch64_AAPCS_SaveList` and `CSR_AArch64_AAPCS_RegMask`, returned by `getCalleeSavedRegs` and `getCallPreservedMask` (see the regalloc [registers page](../regalloc-wiki/regalloc-wiki.html#registers-basics)).

**Sources:** [llvm/lib/Target/AArch64/AArch64CallingConvention.td:95-126](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L95-L126), [llvm/lib/Target/AArch64/AArch64CallingConvention.td:594](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L594)

### Choosing the rules per call

AArch64 picks a generated function by calling convention and OS:

```cpp
CCAssignFn *AArch64TargetLowering::CCAssignFnForCall(CallingConv::ID CC,
                                                     bool IsVarArg) const {
  switch (CC) {
  ...
  case CallingConv::C:
  case CallingConv::Fast:
  ...
    if (!Subtarget->isTargetDarwin())
      return CC_AArch64_AAPCS;
```

A new target with one convention just names `CC_Toy` directly.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9197-9257](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9197-L9257)

### The hooks

| Hook | Runs for | Builds |
| --- | --- | --- |
| `LowerFormalArguments` | Function entry | `CopyFromReg` from live-in registers; loads from fixed stack objects |
| `LowerCall` | Each call site | `CALLSEQ_START`, copies to argument registers, stores to the stack, target call node with a register mask, `CALLSEQ_END`, `CopyFromReg` of results |
| `LowerReturn` | Each `ret` | Copies to return registers and a target return node |
| `CanLowerReturn` | Optional | Says whether the return fits in registers; if not, LLVM adds an `sret` pointer |

Each hook follows the same pattern: make a `CCState`, call `Analyze*` with the generated function, then walk the resulting `CCValAssign` list.

```cpp
  SmallVector<CCValAssign, 16> ArgLocs;
  CCState CCInfo(CallConv, isVarArg, MF, ArgLocs, *DAG.getContext());
```

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9314-9335](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9314-L9335), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10442](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10442), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:11172-11194](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L11172-L11194), [llvm/include/llvm/CodeGen/CallingConvLower.h:171](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/CallingConvLower.h#L171)

## What the Result Looks Like

For a call with ten `i64` arguments, `llc -O2 -mtriple=aarch64-linux-gnu` puts arguments 1–8 in `x0`–`x7` and the last two on the stack (abridged):

```asm
	mov	w8, #9                          // =0x9
	mov	w9, #8                          // =0x8
	mov	w1, #1                          // =0x1
	...
	stp	x8, x30, [sp, #8]               // 8-byte Folded Spill
	str	x9, [sp]
	bl	callee
```

The [calling conventions walkthroughs](../callconv-wiki/callconv-wiki.html#aarch64-walkthroughs) show the full output and the MIR after instruction selection.

## Minimal Toy Version (Illustrative)

**Illustrative, not LLVM source.**

```tablegen
// ToyCallingConv.td
def CC_Toy : CallingConv<[
  CCIfType<[i1, i8, i16], CCPromoteToType<i32>>,
  CCIfType<[i32], CCAssignToReg<[R0, R1, R2, R3]>>,
  CCIfType<[i32], CCAssignToStack<4, 4>>
]>;
def RetCC_Toy : CallingConv<[
  CCIfType<[i32], CCAssignToReg<[R0, R1]>>
]>;
def CSR_Toy : CalleeSavedRegs<(add R8, R9, R10, R11, LR)>;
```

A full `LowerFormalArguments`, `LowerCall` and `LowerReturn` for this convention is on the [calling conventions custom backend page](../callconv-wiki/callconv-wiki.html#custom-backend).

## Order of Implementation

Every function goes through `LowerFormalArguments` and `LowerReturn`, so those two are needed before even the first function compiles. `LowerCall` is only reached when the function contains a call, so it can come second. The defaults in `TargetLowering` do not report a useful error:

```cpp
  virtual SDValue
    LowerCall(CallLoweringInfo &/*CLI*/,
              SmallVectorImpl<SDValue> &/*InVals*/) const {
    llvm_unreachable("Not Implemented");
  }
```

With assertions enabled this prints `Not Implemented` and aborts; in a release build `llvm_unreachable` is undefined behaviour, so a missing hook can crash anywhere. Build LLVM with `-DLLVM_ENABLE_ASSERTIONS=ON` while bringing up a target.

**Sources:** [llvm/include/llvm/CodeGen/TargetLowering.h:4893-4898](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetLowering.h#L4893-L4898), [llvm/include/llvm/CodeGen/TargetLowering.h:5187-5191](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetLowering.h#L5187-L5191), [llvm/include/llvm/CodeGen/TargetLowering.h:5215-5222](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetLowering.h#L5215-L5222)
