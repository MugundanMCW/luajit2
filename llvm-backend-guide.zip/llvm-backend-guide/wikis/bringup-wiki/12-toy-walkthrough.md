# A Minimal Toy Target

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/CMakeLists.txt](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt)
- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)
- [llvm/lib/TargetParser/TargetDataLayout.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/TargetParser/TargetDataLayout.cpp)

</details>
This page collects the Toy pieces from the earlier pages into one ordered build-up, from an empty directory to `llc -march=toy` printing assembly for a function with a call. Every code block on this page is **illustrative, not LLVM source**; Toy is not an LLVM target and none of this output was produced by a tool. Each step lists what to test before moving on.

## Purpose and Scope

The order of work and the test after each step. The code itself is on the pages linked from each step. For object-file output, continue with the [MC checklist](../mc-wiki/mc-wiki.html#mc-checklist).

## The Toy Machine

| Property | Choice |
| --- | --- |
| Word size | 32-bit, little endian |
| Registers | `r0`–`r15`, `sp`, `lr`; `r11` is the frame pointer when one is needed |
| Calling convention | Arguments in `r0`–`r3`, then the stack; return in `r0`/`r1`; `r8`–`r11` and `lr` callee-saved |
| Instructions | `add`, `addi`, `lw`, `sw`, `call`, `ret`, a compare and a branch |
| Data layout | `e-m:e-p:32:32-i64:64-n32-S64` |

## Files

```text
llvm/lib/Target/Toy/
  CMakeLists.txt
  Toy.td  ToyRegisterInfo.td  ToyCallingConv.td  ToySchedule.td  ToyInstrInfo.td
  ToyTargetMachine.{h,cpp}  ToySubtarget.{h,cpp}
  ToyISelLowering.{h,cpp}   ToyISelDAGToDAG.cpp
  ToyInstrInfo.{h,cpp}      ToyRegisterInfo.{h,cpp}  ToyFrameLowering.{h,cpp}
  ToyAsmPrinter.cpp         ToyMCInstLower.{h,cpp}
  TargetInfo/{CMakeLists.txt, ToyTargetInfo.cpp}
  MCTargetDesc/{CMakeLists.txt, ToyMCTargetDesc.cpp, ToyMCAsmInfo.cpp, ToyInstPrinter.cpp}
```

Outside the directory: `Triple::toy` in `llvm/include/llvm/TargetParser/Triple.h` and its parser, a `case Triple::toy:` in `llvm/lib/TargetParser/TargetDataLayout.cpp` (the file where AArch64's string is built, lines 81–97), and `Toy` added to `LLVM_ALL_EXPERIMENTAL_TARGETS` in `llvm/CMakeLists.txt`.

**Sources:** [llvm/lib/TargetParser/TargetDataLayout.cpp:81-97](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/TargetParser/TargetDataLayout.cpp#L81-L97), [llvm/CMakeLists.txt:602-607](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/CMakeLists.txt#L602-L607)

## Steps

```mermaid
flowchart TD
    S1["1. Triple + TargetInfo"] --> S2["2. Toy.td: registers, empty instr set"]
    S2 --> S3["3. MC glue: MCAsmInfo, generated infos, InstPrinter"]
    S3 --> S4["4. TargetMachine + Subtarget + PassConfig"]
    S4 --> S5["5. TargetLowering, LowerFormalArguments, LowerReturn"]
    S5 --> S6["6. ADD, RET + selector"]
    S6 --> S7["7. FrameLowering + eliminateFrameIndex + AsmPrinter"]
    S7 --> S8["8. Loads, stores, branches, LowerCall"]
    S8 --> S9["9. -O2: analyzeBranch, copyPhysReg, spills"]
```

| Step | Write | Page | Test |
| --- | --- | --- | --- |
| 1 | `Triple::toy`, `ToyTargetInfo.cpp`, CMake for `TargetInfo/` | [Layout and CMake](#layout-cmake) | `llc --version` lists `toy` |
| 2 | `Toy.td`, `ToyRegisterInfo.td`, empty `ToyInstrInfo.td` | [The Target .td File](#target-td), [Registers](#registers-regalloc) | `llvm-tblgen -gen-register-info` succeeds |
| 3 | `ToyMCTargetDesc.cpp`, `ToyMCAsmInfo`, `ToyInstPrinter` | [AsmPrinter and MC](#asmprinter-mc) | Library links |
| 4 | `ToyTargetMachine`, `ToySubtarget`, `ToyPassConfig::addInstSelector` | [TargetMachine and Subtarget](#targetmachine-subtarget) | `llc -march=toy` on an empty module succeeds |
| 5 | `ToyTargetLowering` constructor, `CC_Toy`, `RetCC_Toy`, `LowerFormalArguments`, `LowerReturn` | [TargetLowering](#targetlowering), [Calling Conventions](#calling-conventions) | `define void @f() { ret void }` reaches instruction selection |
| 6 | `ADD`, `RET` records, `ToyDAGToDAGISel` | [Instructions and ISel](#instructions-isel) | `llc -march=toy -stop-after=finalize-isel` prints `ADD` |
| 7 | `ToyFrameLowering`, `getReservedRegs`, `eliminateFrameIndex`, `ToyAsmPrinter`, `ToyMCInstLower` | [Frame Lowering](#frame-lowering), [AsmPrinter and MC](#asmprinter-mc) | `llc -march=toy -O0` prints `add r0, r0, r1` / `ret` |
| 8 | `LW`, `SW`, branch, `LowerCall`, `CALL` pattern, `getCallPreservedMask` | [Calling Conventions](#calling-conventions) | A function that calls another compiles at `-O0` |
| 9 | `copyPhysReg`, `storeRegToStackSlot`, `loadRegFromStackSlot`, `analyzeBranch` | [Instructions and ISel](#instructions-isel) | The same tests at `-O2`; `-verify-machineinstrs` passes |

## Expected Output After Step 7

For the same `add` function as on the [overview](#overview), the Toy target should print something like this (**illustrative**: Toy does not exist, so this was not produced by `llc`):

```asm
add:
	add	r0, r0, r1
	ret
```

Compare it with the real AArch64 output from the overview (`add w0, w0, w1` / `ret`): the same shape, with Toy's register names and mnemonics.

## Common First Failures

| Symptom | Usual cause |
| --- | --- |
| `No available targets are compatible with triple` | Triple parser does not know `toy`, or `RegisterTarget` uses a different `ArchType` |
| Crash in `initAsmInfo` | An MC factory (asm info, register info, instr info, subtarget info) is not registered |
| `Cannot select: ...` | Missing pattern or missing `setOperationAction` ([TargetLowering](#targetlowering)) |
| `Not Implemented` (assertions build) | A required call-lowering hook is missing ([Calling Conventions](#calling-conventions)) |
| `Call Frame Pseudo Instructions do not exist on this target!` | `ADJCALLSTACKDOWN/UP` used but `eliminateCallFramePseudoInstr` not overridden ([Frame Lowering](#frame-lowering)) |
| Bad machine code from `-verify-machineinstrs` | Wrong register class in a pattern, missing `Defs`/`Uses` on calls and returns |
| `Unknown operand type` in `MCInstLower` | An operand kind not handled (often `MO_RegisterMask` or an implicit register) |

Always test with `-verify-machineinstrs`: it catches most mistakes right after the pass that made them. The regalloc wiki's [backend checklist](../regalloc-wiki/regalloc-wiki.html#backend-checklist) has more checks for the allocation-related steps.