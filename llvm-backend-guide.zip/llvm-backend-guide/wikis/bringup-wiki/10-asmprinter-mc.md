# AsmPrinter and the MC Layer

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp)
- [llvm/lib/Target/AArch64/AArch64MCInstLower.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64MCInstLower.cpp)
- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)

</details>
The last CodeGen pass is the target's `AsmPrinter`. It walks every `MachineInstr`, converts it to an `MCInst` (a flat opcode plus operands, with no links to the function), and hands it to an `MCStreamer`. From there on everything is MC layer: the streamer either prints text through the `MCInstPrinter` or encodes bytes through the `MCCodeEmitter` and `MCAsmBackend`.

## Purpose and Scope

The `AsmPrinter` subclass, `MCInstLower`, and the minimum MC objects needed for `.s` output. The MC layer itself is covered by the [MC wiki](../mc-wiki/mc-wiki.html#overview): [streamers](../mc-wiki/mc-wiki.html#streamers), [MCAsmInfo and the printer](../mc-wiki/mc-wiki.html#asminfo-printer), [code emitter](../mc-wiki/mc-wiki.html#code-emitter), [asm backend](../mc-wiki/mc-wiki.html#asm-backend), [fixups and relocations](../mc-wiki/mc-wiki.html#fixups-relocations) and its [checklist](../mc-wiki/mc-wiki.html#mc-checklist).

## From MachineInstr to Output

```mermaid
flowchart LR
    MI["MachineInstr"] --> AP["ToyAsmPrinter::emitInstruction"]
    AP -->|"pseudo expansion (generated)"| MCI["MCInst"]
    AP -->|"ToyMCInstLower::Lower"| MCI
    MCI --> S["MCStreamer"]
    S -->|.s| IP["ToyInstPrinter (-gen-asm-writer)"]
    S -->|.o| CE["ToyMCCodeEmitter (-gen-emitter)"]
    CE --> AB["ToyAsmBackend: fixups"]
    AB --> OW["ToyELFObjectWriter: relocations"]
```

## The AsmPrinter Subclass

`AArch64AsmPrinter` (declared at line 98) derives from `AsmPrinter`. Its `emitInstruction` first tries the TableGen-generated pseudo lowering (`-gen-pseudo-lowering`, included just above it), then handles special opcodes, and finally falls back to the generic path:

```cpp
#include "AArch64GenMCPseudoLowering.inc"

void AArch64AsmPrinter::EmitToStreamer(MCStreamer &S, const MCInst &Inst) {
  S.emitInstruction(Inst, *STI);
  ...
}

void AArch64AsmPrinter::emitInstruction(const MachineInstr *MI) {
  ...
  // Do any auto-generated pseudo lowerings.
  if (MCInst OutInst; lowerPseudoInstExpansion(MI, OutInst)) {
    EmitToStreamer(*OutStreamer, OutInst);
    return;
  }
  ...
```

At the end of the function, ordinary instructions go through `MCInstLowering.Lower(MI, TmpInst)` and `EmitToStreamer(*OutStreamer, TmpInst)`.

The printer is registered with `RegisterAsmPrinter<AArch64AsmPrinter>` in `LLVMInitializeAArch64AsmPrinter` (see [Layout and CMake](#layout-cmake)).

**Sources:** [llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp:98](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp#L98), [llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp:3256-3279](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp#L3256-L3279), [llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp:3969-3970](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp#L3969-L3970), [llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp:4187-4192](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64AsmPrinter.cpp#L4187-L4192)

## MCInstLower

`AArch64MCInstLower` copies the opcode and converts each `MachineOperand` to an `MCOperand`:

| Function | Line | Job |
| --- | --- | --- |
| `LowerSymbolOperand` | 321 | Global, external symbol, block address, constant pool, jump table → `MCSymbolRefExpr`, with the target flag (`:lo12:`, `:got:` ...) turned into a specifier |
| `lowerOperand` | 332 | Register → `MCOperand::createReg`, immediate → `createImm`, symbols → `LowerSymbolOperand`; implicit operands and register masks are dropped |
| `Lower` | 376 | `OutMI.setOpcode(MI->getOpcode())`, then each operand |

A new target's version is short: a switch over `MachineOperand` kinds. Operand target flags are the bridge between instruction selection (which marks `MO_LO`/`MO_HI` style flags) and the MC fixups that become relocations.

**Sources:** [llvm/lib/Target/AArch64/AArch64MCInstLower.cpp:321-376](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64MCInstLower.cpp#L321-L376)

## Minimum MC Objects for .s Output

`initAsmInfo()` in the target machine constructor ([TargetMachine and Subtarget](#targetmachine-subtarget)) fails unless these are registered in `LLVMInitialize<T>TargetMC`:

| Object | Source | Needed for |
| --- | --- | --- |
| `MCAsmInfo` | Hand-written (comment string, directives, alignment) | Everything |
| `MCInstrInfo`, `MCRegisterInfo`, `MCSubtargetInfo` | Generated, a few lines of glue | Everything |
| `MCInstPrinter` | Generated `printInstruction` + hand-written `printOperand` | `.s` |
| `MCCodeEmitter` | Generated `getBinaryCodeForInstr` + operand encoders | `.o` |
| `MCAsmBackend`, `MCELFObjectTargetWriter` | Hand-written | `.o` |

The registration code is on the [MC custom backend page](../mc-wiki/mc-wiki.html#custom-backend).

## Minimal Toy Versions (Illustrative)

**Illustrative, not LLVM source.**

```cpp
// ToyMCInstLower.cpp
void ToyMCInstLower::Lower(const MachineInstr *MI, MCInst &Out) const {
  Out.setOpcode(MI->getOpcode());
  for (const MachineOperand &MO : MI->operands()) {
    switch (MO.getType()) {
    case MachineOperand::MO_Register:
      if (MO.isImplicit()) continue;
      Out.addOperand(MCOperand::createReg(MO.getReg()));
      break;
    case MachineOperand::MO_Immediate:
      Out.addOperand(MCOperand::createImm(MO.getImm()));
      break;
    case MachineOperand::MO_GlobalAddress:
      Out.addOperand(MCOperand::createExpr(MCSymbolRefExpr::create(
          Printer.getSymbol(MO.getGlobal()), Ctx)));
      break;
    case MachineOperand::MO_MachineBasicBlock:
      Out.addOperand(MCOperand::createExpr(
          MCSymbolRefExpr::create(MO.getMBB()->getSymbol(), Ctx)));
      break;
    case MachineOperand::MO_RegisterMask:
      continue;
    default:
      llvm_unreachable("unknown operand type");
    }
  }
}

// ToyAsmPrinter.cpp
class ToyAsmPrinter : public AsmPrinter {
  ToyMCInstLower MCInstLowering;
public:
  ToyAsmPrinter(TargetMachine &TM, std::unique_ptr<MCStreamer> S)
      : AsmPrinter(TM, std::move(S)), MCInstLowering(OutContext, *this) {}
  StringRef getPassName() const override { return "Toy Assembly Printer"; }
  void emitInstruction(const MachineInstr *MI) override {
    MCInst I;
    MCInstLowering.Lower(MI, I);
    EmitToStreamer(*OutStreamer, I);
  }
};
extern "C" LLVM_EXTERNAL_VISIBILITY void LLVMInitializeToyAsmPrinter() {
  RegisterAsmPrinter<ToyAsmPrinter> X(getTheToyTarget());
}
```

Pseudo instructions that survive to this point (for example a `RET` pseudo with implicit operands) must either be expanded in `expandPostRAPseudo` or given a `PseudoInstExpansion` in TableGen so `lowerPseudoInstExpansion` handles them.