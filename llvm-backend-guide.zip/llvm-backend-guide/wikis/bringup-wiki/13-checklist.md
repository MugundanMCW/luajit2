# Bring-up Checklist and AArch64 File Map

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/CMakeLists.txt](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt)
- [llvm/lib/Target/AArch64/AArch64.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64.td)

</details>
A list of milestones from "empty target" to `-O2` object files, each with a test, followed by a map of where each piece lives in the AArch64 backend so you can read the real version.

## Purpose and Scope

A checklist to track progress. Each item links to the page that explains it. The MC-specific steps (encoding, fixups, relocations, parser, disassembler) are listed in detail on the [MC checklist](../mc-wiki/mc-wiki.html#mc-checklist), and the allocation-specific ones on the [regalloc backend checklist](../regalloc-wiki/regalloc-wiki.html#backend-checklist).

## Milestones

### A. The target exists

- [ ] `Triple::toy` parses; data layout case added ([TargetMachine and Subtarget](#targetmachine-subtarget))
- [ ] `ToyTargetInfo` registered; `llc --version` lists it ([Layout and CMake](#layout-cmake))
- [ ] CMake builds `LLVMToyInfo`, `LLVMToyDesc`, `LLVMToyCodeGen` with `LLVM_EXPERIMENTAL_TARGETS_TO_BUILD=Toy`
- [ ] `Toy.td` parses with `llvm-tblgen -print-records` ([The Target .td File](#target-td))

### B. A function compiles to assembly at -O0

- [ ] Registers and one register class ([Registers and Allocation](#registers-regalloc))
- [ ] MC glue: asm info, instr/reg/subtarget info, instruction printer ([AsmPrinter and MC](#asmprinter-mc))
- [ ] `ToyTargetMachine`, `ToySubtarget`, `ToyPassConfig::addInstSelector`
- [ ] `ToyTargetLowering` constructor: `addRegisterClass`, `computeRegisterProperties` ([TargetLowering Setup](#targetlowering))
- [ ] `LowerFormalArguments`, `LowerReturn`, `CC_Toy`, `RetCC_Toy` ([Calling Conventions](#calling-conventions))
- [ ] `ADD`, `RET` and a selector ([Instructions and ISel](#instructions-isel))
- [ ] `ToyFrameLowering`, `getReservedRegs`, `getFrameRegister`, `eliminateFrameIndex` ([Frame Lowering](#frame-lowering))
- [ ] `ToyAsmPrinter`, `ToyMCInstLower`
- [ ] Test: `llc -march=toy -O0 -verify-machineinstrs add.ll`

### C. Real programs at -O0

- [ ] Loads, stores, constants, globals (custom `GlobalAddress` lowering)
- [ ] Compares and branches (`BR_CC` expanded or custom)
- [ ] `LowerCall`, `CALL` pattern, `getCallPreservedMask`, call-frame pseudos ([calling conventions wiki](../callconv-wiki/callconv-wiki.html#lower-call))
- [ ] `copyPhysReg`, `storeRegToStackSlot`, `loadRegFromStackSlot` ([regalloc TII hooks](../regalloc-wiki/regalloc-wiki.html#tii-hooks))
- [ ] Operation actions for everything the hardware lacks (division, wide multiplies, rotates)
- [ ] Test: a small C program compiled by `clang --target=toy -O0 -S`, every function verified

### D. -O2

- [ ] `analyzeBranch`, `insertBranch`, `removeBranch` so branch folding and block placement work
- [ ] Callee-saved spills appear and are correct ([frame wiki: callee saves](../frame-wiki/frame-wiki.html#callee-saves))
- [ ] Large frames: `eliminateFrameIndex` with the register scavenger ([frame wiki: frame index](../frame-wiki/frame-wiki.html#frame-index))
- [ ] Frame pointer and variable-sized objects (`hasFPImpl`)
- [ ] Varargs and tail calls ([calling conventions wiki](../callconv-wiki/callconv-wiki.html#special-args), [tail calls](../callconv-wiki/callconv-wiki.html#tail-calls))
- [ ] `enableMachineScheduler`, a scheduling model ([scheduling wiki](../sched-wiki/sched-wiki.html#custom-backend))
- [ ] Test: the same programs at `-O2 -verify-machineinstrs`; run them on hardware or a simulator

### E. Object files and tools

- [ ] Encodings in TableGen, `MCCodeEmitter`, fixup kinds, `MCAsmBackend`, ELF object writer ([MC checklist](../mc-wiki/mc-wiki.html#mc-checklist))
- [ ] CFI from frame lowering so debuggers and unwinders work ([frame wiki: CFI](../frame-wiki/frame-wiki.html#cfi))
- [ ] Asm parser (`llvm-mc`, inline asm) and disassembler (`llvm-objdump`)
- [ ] `lit` tests under `llvm/test/CodeGen/Toy` and `llvm/test/MC/Toy`

## AArch64 File Map

Where to look in `llvm/lib/Target/AArch64/` for the real version of each piece:

| Piece | AArch64 file | Wiki page |
| --- | --- | --- |
| Root TableGen | `AArch64.td` | [The Target .td File](#target-td) |
| Features, processors | `AArch64Features.td`, `AArch64Processors.td` | [The Target .td File](#target-td) |
| Registers | `AArch64RegisterInfo.td`, `AArch64RegisterInfo.cpp` | [Registers and Allocation](#registers-regalloc) |
| Calling conventions | `AArch64CallingConvention.td`, `AArch64CallingConvention.cpp` | [Calling Conventions](#calling-conventions) |
| Instructions | `AArch64InstrFormats.td`, `AArch64InstrInfo.td`, `AArch64InstrInfo.cpp` | [Instructions and ISel](#instructions-isel) |
| Lowering | `AArch64ISelLowering.cpp` | [TargetLowering Setup](#targetlowering) |
| Selector | `AArch64ISelDAGToDAG.cpp` | [Instructions and ISel](#instructions-isel) |
| Target machine, pass config | `AArch64TargetMachine.cpp` | [TargetMachine and Subtarget](#targetmachine-subtarget) |
| Subtarget | `AArch64Subtarget.cpp`, `AArch64Subtarget.h` | [TargetMachine and Subtarget](#targetmachine-subtarget) |
| Frame | `AArch64FrameLowering.cpp`, `AArch64PrologueEpilogue.cpp` | [Frame Lowering](#frame-lowering) |
| Scheduling | `AArch64Schedule.td`, `AArch64Sched*.td` | [Scheduling](#scheduling) |
| Printer | `AArch64AsmPrinter.cpp`, `AArch64MCInstLower.cpp` | [AsmPrinter and MC](#asmprinter-mc) |
| MC | `MCTargetDesc/` | [MC wiki](../mc-wiki/mc-wiki.html#custom-backend) |
| Target info | `TargetInfo/AArch64TargetInfo.cpp` | [Layout and CMake](#layout-cmake) |
| Build | `CMakeLists.txt` | [Layout and CMake](#layout-cmake) |

**Sources:** [llvm/lib/Target/AArch64/CMakeLists.txt:1-33](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt#L1-L33), [llvm/lib/Target/AArch64/AArch64.td:16-58](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64.td#L16-L58)