# The Target .td File

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64.td)
- [llvm/lib/Target/AArch64/AArch64Processors.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Processors.td)
- [llvm/lib/Target/AArch64/CMakeLists.txt](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt)

</details>
`<T>.td` is the root TableGen file of a target. `llvm-tblgen` reads it, follows its `include` lines, and every `-gen-*` backend listed in the target's `CMakeLists.txt` produces one `.inc` file from the same set of records. The file itself is short: it includes the generic `Target.td`, includes the target's own `.td` files in dependency order, and ends with one `def <T> : Target` record.

## Purpose and Scope

What goes in `<T>.td`, the order of includes, how processors and features are declared, and the `Target` record. Registers are covered by the [regalloc TableGen page](../regalloc-wiki/regalloc-wiki.html#tablegen-registers), instructions and patterns by the [SelectionDAG pattern language page](../selectiondag-wiki.html#pattern-language), calling conventions by the [calling conventions wiki](../callconv-wiki/callconv-wiki.html#cc-td) and scheduling models by the [scheduling wiki](../sched-wiki/sched-wiki.html#sched-model).

## Include Order

TableGen is single pass: a record can only refer to records defined earlier. AArch64's root file therefore includes, in order:

| Line | Include | Defines |
| --- | --- | --- |
| 16 | `llvm/Target/Target.td` | Generic classes: `Register`, `RegisterClass`, `Instruction`, `Target`, `Processor`, `CallingConv`, `SchedMachineModel`, ... |
| 21-22 | `AArch64Features.td`, `AArch64FMV.td` | `SubtargetFeature` records and predicates |
| 28-30 | `AArch64RegisterInfo.td`, `AArch64RegisterBanks.td`, `AArch64CallingConvention.td` | Registers, classes, banks, calling conventions (which name registers) |
| 36-41 | `AArch64Schedule.td`, `AArch64InstrInfo.td`, scheduling predicates, `AArch64Combine.td` | `SchedWrite` types first, then instructions that use them |
| 45 | `def AArch64InstrInfo : InstrInfo;` | The instruction set record |
| 125-155 | `AArch64Sched*.td` | One `SchedMachineModel` per CPU family |
| 157 | `AArch64Processors.td` | `ProcessorModel` records tying CPU names to models and features |
| 163-194 | Parser and writer variants | `AsmParserVariant`, `AsmWriter` |
| 200-205 | `def AArch64 : Target` | The root record |

`AArch64Schedule.td` comes before `AArch64InstrInfo.td` because instruction definitions list `SchedWrite`/`SchedRead` types (`Sched<[WriteI, ReadI, ReadI]>`). The per-CPU models come after the instructions because `InstRW` refers to instruction names.

**Sources:** [llvm/lib/Target/AArch64/AArch64.td:16-58](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64.td#L16-L58), [llvm/lib/Target/AArch64/AArch64.td:125-157](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64.td#L125-L157)

## The Target Record

```tablegen
def GenericAsmWriter : AsmWriter {
  string AsmWriterClassName  = "InstPrinter";
  int PassSubtarget = 1;
  int Variant = 0;
  bit isMCAsmWriter = 1;
}
...
def AArch64 : Target {
  let InstructionSet = AArch64InstrInfo;
  let AssemblyParserVariants = [GenericAsmParserVariant, AppleAsmParserVariant];
  let AssemblyWriters = [GenericAsmWriter, AppleAsmWriter];
  let AllowRegisterRenaming = 1;
}
```

| Field | Meaning |
| --- | --- |
| `InstructionSet` | The `InstrInfo` record; required |
| `AssemblyWriters` | Printer variants; `AsmWriterClassName` gives the generated class name `<T><Name>` (here `AArch64InstPrinter`) |
| `AssemblyParserVariants` | Parser variants for `-gen-asm-matcher` |
| `AllowRegisterRenaming` | Lets post-RA passes rename registers (only safe if the target has no hidden register constraints) |

The record's name (`AArch64`) is the target name TableGen uses for generated identifiers: `AArch64GenInstrInfo`, `AArch64GenRegisterInfo`, the `AArch64::` namespace for opcodes and registers.

**Sources:** [llvm/lib/Target/AArch64/AArch64.td:163-205](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64.td#L163-L205)

## Processors and Features

A `SubtargetFeature` becomes a boolean field of the generated subtarget (`HasSVE` and so on) and a `-mattr=` name. A `ProcessorModel` names a CPU for `-mcpu=`, its scheduling model and its features:

```tablegen
def : ProcessorModel<"cortex-a57", CortexA57Model, ProcessorFeatures.A53,
                     [TuneA57]>;
```

`-gen-subtarget` turns these into tables in `<T>GenSubtargetInfo.inc`, and the generated `ParseSubtargetFeatures(CPU, TuneCPU, FS)` sets the feature fields from them. The [TargetMachine and Subtarget page](#targetmachine-subtarget) shows where that function is called; the [scheduling wiki](../sched-wiki/sched-wiki.html#wiring) covers the scheduling model argument.

**Sources:** [llvm/lib/Target/AArch64/AArch64Processors.td:1312-1313](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Processors.td#L1312-L1313)

## Minimal Toy.td (Illustrative)

**Illustrative, not LLVM source.** Each included file is sketched on the page named in the comment.

```tablegen
include "llvm/Target/Target.td"

// Features and processors
def FeatureMul : SubtargetFeature<"mul", "HasMul", "true", "Has MUL">;

include "ToyRegisterInfo.td"       // Registers and Allocation
include "ToyCallingConv.td"        // Calling Conventions
include "ToySchedule.td"           // Scheduling (SchedWrite types)
include "ToyInstrInfo.td"          // Instructions and ISel

def ToyInstrInfo : InstrInfo;

def : ProcessorModel<"generic", NoSchedModel, []>;
def : ProcessorModel<"toy2", ToyModel, [FeatureMul]>;

def Toy : Target {
  let InstructionSet = ToyInstrInfo;
}
```

`NoSchedModel` (from `TargetSchedule.td`) is fine at first; add a real model when you care about performance.

## Checking the Records

`llvm-tblgen` can print every record after parsing, which is the fastest way to find TableGen errors before CMake runs all the backends:

```text
llvm-tblgen -print-records -I llvm/include -I llvm/lib/Target/Toy llvm/lib/Target/Toy/Toy.td
```

Each backend can also be run by hand, for example `-gen-register-info` to look at the generated register enum.