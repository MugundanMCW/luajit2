# Target Bring-up Overview

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)
- [llvm/lib/Target/AArch64/AArch64Subtarget.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64Subtarget.cpp)
- [llvm/lib/Target/AArch64/AArch64.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64.td)
- [llvm/lib/Target/AArch64/CMakeLists.txt](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt)

</details>
An LLVM backend is a set of C++ classes and TableGen files under `llvm/lib/Target/<T>/`. The generic code generator calls them through a few interfaces: `TargetMachine`, `TargetSubtargetInfo`, `TargetLowering`, `TargetInstrInfo`, `TargetRegisterInfo`, `TargetFrameLowering`, and the MC layer objects. This wiki walks through writing each piece for a new target, in the order you would write them, using AArch64 as the real reference and a made-up "Toy" target for minimal examples.

## Purpose and Scope

This wiki covers the whole path from an empty directory to a target that compiles a function to assembly and then to object files. It ties together six other wikis:

| Wiki | What it covers in depth |
| --- | --- |
| [SelectionDAG](../selectiondag-wiki.html#overview) | Turning LLVM IR into machine instructions |
| [Register allocation](../regalloc-wiki/regalloc-wiki.html#overview) | Assigning physical registers, spilling |
| [MC layer](../mc-wiki/mc-wiki.html#overview) | Printing assembly, encoding, object files |
| [Calling conventions](../callconv-wiki/callconv-wiki.html#overview) | Arguments, returns, calls |
| [Frame lowering](../frame-wiki/frame-wiki.html#overview) | Prologue, epilogue, stack layout |
| [Instruction scheduling](../sched-wiki/sched-wiki.html#overview) | Machine scheduler and scheduling models |

Each page here explains what the piece is, shows what AArch64 does, gives a minimal Toy version, and links to the wiki that goes deeper.

## The Pieces of a Backend

```mermaid
flowchart TD
    TI["TargetInfo: getTheToyTarget()"] --> TM["ToyTargetMachine"]
    TD["Toy.td + included .td files"] -->|llvm-tblgen| GEN["ToyGen*.inc"]
    TM --> ST["ToySubtarget"]
    ST --> TL["ToyTargetLowering"]
    ST --> TII["ToyInstrInfo"]
    ST --> TRI["ToyRegisterInfo"]
    ST --> TFL["ToyFrameLowering"]
    TM --> PC["ToyPassConfig"]
    PC --> ISEL["ToyDAGToDAGISel"]
    TM --> AP["ToyAsmPrinter"]
    AP --> MC["MC layer: MCAsmInfo, InstPrinter, CodeEmitter, AsmBackend"]
    GEN --> TL
    GEN --> TII
    GEN --> TRI
    GEN --> ISEL
    GEN --> MC
```

| Piece | Base class | Job | Page |
| --- | --- | --- | --- |
| Target registration | `Target`, `TargetRegistry` | Lets tools find the target by name or triple | [Layout and CMake](#layout-cmake) |
| Target description | TableGen `Target` | Registers, instructions, calling conventions, processors | [The Target .td File](#target-td) |
| Target machine | `CodeGenTargetMachineImpl` | Data layout, pass pipeline, subtarget cache | [TargetMachine and Subtarget](#targetmachine-subtarget) |
| Subtarget | `TargetSubtargetInfo` | Owns the per-CPU objects listed below | [TargetMachine and Subtarget](#targetmachine-subtarget) |
| Lowering | `TargetLowering` | Legal types, operation actions, custom lowering | [TargetLowering Setup](#targetlowering) |
| Calling convention | TableGen `CallingConv`, `LowerCall` etc. | Arguments and returns | [Calling Conventions](#calling-conventions) |
| Instructions and selection | `TargetInstrInfo`, `SelectionDAGISel` | Instruction definitions and patterns | [Instructions and ISel](#instructions-isel) |
| Registers | `TargetRegisterInfo` | Register classes, reserved registers, allocation hooks | [Registers and Allocation](#registers-regalloc) |
| Frame | `TargetFrameLowering` | Prologue, epilogue, stack offsets | [Frame Lowering](#frame-lowering) |
| Printing and encoding | `AsmPrinter`, MC classes | `.s` and `.o` output | [AsmPrinter and MC](#asmprinter-mc) |
| Scheduling model | TableGen `SchedMachineModel` | Latencies and resources | [Scheduling](#scheduling) |

## Order the Pieces Run In

For each function, `llc` runs the pass pipeline built by the target's `TargetPassConfig`. The order below is from `llc -O2 -debug-pass=Structure` for `aarch64-linux-gnu` (`-mcpu=cortex-a57`), shortened:

```text
... -codegenprepare ... -aarch64-isel -finalize-isel ...
-machine-cse -machine-sink -peephole-opt ...
-phi-node-elimination -twoaddressinstruction -liveintervals -register-coalescer
-machine-scheduler ... -greedy -virtregrewriter ...
-shrink-wrap -prolog-epilog ... -postrapseudos -aarch64-expand-pseudo
-aarch64-ldst-opt ... -postmisched ... -block-placement ...
-branch-relaxation ... -aarch64-asm-printer
```

```mermaid
flowchart LR
    IR["LLVM IR"] --> ISEL["Instruction selection<br/>(TargetLowering, CC, patterns)"]
    ISEL --> PRE["SSA machine opts"]
    PRE --> MS["MachineScheduler<br/>(sched model)"]
    MS --> RA["Register allocation<br/>(TargetRegisterInfo)"]
    RA --> PEI["Shrink wrap + PEI<br/>(TargetFrameLowering)"]
    PEI --> POST["Post-RA passes,<br/>post-RA scheduler"]
    POST --> AP["AsmPrinter -> MC"]
```

Instruction selection is where `TargetLowering` and the calling convention are used. The scheduling model is consulted by the machine scheduler before allocation and again after it. Frame lowering runs after allocation, because only then is it known which callee-saved registers are used and how many spill slots exist.

**Sources:** [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:580-615](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L580-L615), [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:760-770](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L760-L770)

## A First Milestone

The first useful goal is one function compiled to assembly. For AArch64 this IR:

```llvm
define i32 @add(i32 %a, i32 %b) {
  %s = add i32 %a, %b
  ret i32 %s
}
```

gives, with `llc -O2 -mtriple=aarch64-linux-gnu`:

```asm
add:                                    // @add
	.cfi_startproc
	add	w0, w0, w1
	ret
.Lfunc_end0:
	.cfi_endproc
```

To get this far a target needs every piece in the table above except the code emitter, asm backend and scheduling model. [A Minimal Toy Target](#toy-walkthrough) shows the smallest version of each, and the [checklist](#checklist) lists the milestones after it.

## How to Read This Wiki

1. [Layout and CMake](#layout-cmake): files, libraries, registration.
2. [The Target .td File](#target-td): the TableGen root.
3. [TargetMachine and Subtarget](#targetmachine-subtarget).
4. [TargetLowering Setup](#targetlowering).
5. [Calling Conventions](#calling-conventions).
6. [Instructions and ISel](#instructions-isel).
7. [Registers and Allocation](#registers-regalloc).
8. [Frame Lowering](#frame-lowering).
9. [AsmPrinter and MC](#asmprinter-mc).
10. [Scheduling](#scheduling).
11. [A Minimal Toy Target](#toy-walkthrough).
12. [Bring-up Checklist](#checklist).
13. [Tooling and Glossary](#tooling-glossary).