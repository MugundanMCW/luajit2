# TargetLowering Setup

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)

</details>
`<T>TargetLowering` tells SelectionDAG what the target can do natively. Its constructor runs once per subtarget and fills in tables: which value types live in which register class, and for each (operation, type) pair whether the operation is `Legal`, should be `Promote`d, `Expand`ed into other operations, turned into a library call, or handled by target code (`Custom`). The legalizer and DAG combiner read those tables; the target only writes code for the `Custom` cases.

## Purpose and Scope

The constructor of `TargetLowering`: register classes, `computeRegisterProperties`, operation actions, and the `LowerOperation` hook for `Custom`. How the legalizer uses these tables is covered by the SelectionDAG wiki's [legalization](../selectiondag-wiki.html#legalization), [type legalization](../selectiondag-wiki.html#type-legalization) and [operation and vector legalization](../selectiondag-wiki.html#op-vector-legalization) pages. The call-lowering hooks on the same class are covered on [Calling Conventions](#calling-conventions).

## The Constructor in Three Steps

```mermaid
flowchart TD
    A["addRegisterClass(VT, RC) for each legal type"] --> B["computeRegisterProperties(TRI)"]
    B --> C["setOperationAction / setLoadExtAction / setTruncStoreAction / setCondCodeAction"]
    C --> D["other settings: boolean contents, stack pointer register, alignment, libcalls"]
```

### 1. Register classes make types legal

A type is legal exactly when a register class has been added for it:

```cpp
AArch64TargetLowering::AArch64TargetLowering(const TargetMachine &TM,
                                             const AArch64Subtarget &STI)
    : TargetLowering(TM, STI), Subtarget(&STI) {
  // AArch64 doesn't have comparisons which set GPRs or setcc instructions, so
  // we have to make something up. Arbitrarily, choose ZeroOrOne.
  setBooleanContents(ZeroOrOneBooleanContent);
  ...
  // Set up the register classes.
  addRegisterClass(MVT::i32, &AArch64::GPR32allRegClass);
  addRegisterClass(MVT::i64, &AArch64::GPR64allRegClass);
  ...
  if (Subtarget->hasFPARMv8()) {
    ...
    addRegisterClass(MVT::f32, &AArch64::FPR32RegClass);
    addRegisterClass(MVT::f64, &AArch64::FPR64RegClass);
```

Feature checks (`hasFPARMv8()`, `hasLS64()`) mean the set of legal types depends on the subtarget. `i8` and `i16` get no class on AArch64, so the type legalizer promotes them to `i32`.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:475-500](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L475-L500)

### 2. computeRegisterProperties

After all classes are added, one call derives the rest of the type tables (how each illegal type is promoted, expanded or split, the number of registers per type):

```cpp
  // Compute derived properties from the register classes
  computeRegisterProperties(Subtarget->getRegisterInfo());
```

It must come after the last `addRegisterClass` and before code that queries `isTypeLegal`.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:566-567](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L566-L567)

### 3. Operation actions

Every operation on a legal type defaults to `Legal`. The target lists the exceptions:

```cpp
  // Provide all sorts of operation actions
  setOperationAction(ISD::GlobalAddress, MVT::i64, Custom);
  setOperationAction(ISD::GlobalTLSAddress, MVT::i64, Custom);
  setOperationAction(ISD::SETCC, MVT::i32, Custom);
  setOperationAction(ISD::SETCC, MVT::i64, Custom);
  ...
  setOperationAction(ISD::SDIVREM, MVT::i32, Expand);
  setOperationAction(ISD::SDIVREM, MVT::i64, Expand);
  ...
  setOperationAction(ISD::SREM, MVT::i32, Expand);
  setOperationAction(ISD::SREM, MVT::i64, Expand);
```

| Action | Meaning | Who does the work |
| --- | --- | --- |
| `Legal` | A pattern selects it directly | TableGen patterns |
| `Promote` | Do it in a wider type | Legalizer |
| `Expand` | Rewrite into other nodes (for `SREM`: divide, multiply, subtract) or a libcall | Legalizer |
| `LibCall` | Call a runtime function | Legalizer |
| `Custom` | Call `LowerOperation` | Target code |

AArch64 marks `GlobalAddress` `Custom` because the address needs a target-specific sequence (`adrp` + `add :lo12:`) that depends on the code model. `SREM` is `Expand` because there is no remainder instruction.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:569-575](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L569-L575), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:783-790](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L783-L790)

## Custom Lowering

For every `Custom` entry the legalizer calls `LowerOperation(SDValue Op, SelectionDAG &DAG)`. The usual form is a switch on the opcode that dispatches to one function per node:

```cpp
// ToyISelLowering.cpp (illustrative, not LLVM source)
SDValue ToyTargetLowering::LowerOperation(SDValue Op, SelectionDAG &DAG) const {
  switch (Op.getOpcode()) {
  case ISD::GlobalAddress: return LowerGlobalAddress(Op, DAG);
  case ISD::BR_CC:         return LowerBR_CC(Op, DAG);
  default: llvm_unreachable("unexpected custom lowering");
  }
}
```

Custom lowering usually produces target-specific nodes (`ToyISD::HI`, `ToyISD::LO`, `ToyISD::CALL`). Their opcodes and type profiles are declared in TableGen (`SDNode` records) and matched by patterns; see [Instructions and ISel](#instructions-isel).

## Minimal Toy Constructor (Illustrative)

**Illustrative, not LLVM source.** A 32-bit target with one GPR class and no floating point:

```cpp
ToyTargetLowering::ToyTargetLowering(const TargetMachine &TM,
                                     const ToySubtarget &STI)
    : TargetLowering(TM, STI) {
  addRegisterClass(MVT::i32, &Toy::GPRRegClass);
  computeRegisterProperties(STI.getRegisterInfo());

  setStackPointerRegisterToSaveRestore(Toy::SP);
  setBooleanContents(ZeroOrOneBooleanContent);

  setOperationAction(ISD::GlobalAddress, MVT::i32, Custom);
  setOperationAction(ISD::BR_CC, MVT::i32, Expand);   // use SETCC + BRCOND
  setOperationAction(ISD::SELECT_CC, MVT::i32, Expand);
  for (unsigned Op : {ISD::SDIV, ISD::UDIV, ISD::SREM, ISD::UREM,
                      ISD::SDIVREM, ISD::UDIVREM})
    setOperationAction(Op, MVT::i32, Expand);         // libcalls
  if (!STI.hasMul())
    setOperationAction(ISD::MUL, MVT::i32, Expand);    // __mulsi3
  for (unsigned Op : {ISD::MULHS, ISD::MULHU, ISD::SMUL_LOHI, ISD::UMUL_LOHI,
                      ISD::ROTL, ISD::ROTR, ISD::CTPOP, ISD::CTLZ, ISD::CTTZ})
    setOperationAction(Op, MVT::i32, Expand);
  for (MVT VT : {MVT::i1, MVT::i8, MVT::i16}) {
    setLoadExtAction(ISD::EXTLOAD, MVT::i32, VT, Promote);
  }
  setOperationAction(ISD::DYNAMIC_STACKALLOC, MVT::i32, Expand);
  setOperationAction(ISD::STACKSAVE, MVT::Other, Expand);
  setOperationAction(ISD::STACKRESTORE, MVT::Other, Expand);
  setOperationAction(ISD::VASTART, MVT::Other, Custom);
  setOperationAction(ISD::VAARG, MVT::Other, Expand);
  setOperationAction(ISD::VACOPY, MVT::Other, Expand);
  setOperationAction(ISD::VAEND, MVT::Other, Expand);

  setMinFunctionAlignment(Align(4));
}
```

## Finding Missing Actions

If an operation has no pattern and no action, instruction selection fails with `LLVM ERROR: Cannot select: ...` and prints the node. The fix is either a pattern (if the instruction exists) or an action. `llc -debug-only=isel` prints each DAG stage and `-view-legalize-dags` draws it, but both need an assertions (or debug) build of LLVM. With a release build like the one used for this wiki, reduce the input IR (for example with `llvm-reduce`) until the failing node is obvious. The SelectionDAG wiki's [tooling page](../selectiondag-wiki.html#tooling) lists the options.
