# Frame Lowering

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/CodeGen/TargetFrameLowering.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h)
- [llvm/lib/CodeGen/PrologEpilogInserter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp)
- [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp)
- [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp)

</details>
Until register allocation is finished, stack slots are abstract frame indices and there is no prologue or epilogue. The generic prologue/epilogue insertion pass (PEI, `-prolog-epilog`) decides the final stack layout and then calls the target's `TargetFrameLowering` to emit the code that builds and tears down the frame, and `TargetRegisterInfo::eliminateFrameIndex` to turn each frame index into a register plus offset.

## Purpose and Scope

The minimum frame lowering a new target needs. The [frame lowering wiki](../frame-wiki/frame-wiki.html#overview) covers [`MachineFrameInfo`](../frame-wiki/frame-wiki.html#frame-info), [all the hooks](../frame-wiki/frame-wiki.html#tfl-hooks), [the PEI pass step by step](../frame-wiki/frame-wiki.html#pei-pass), [callee-saved spilling](../frame-wiki/frame-wiki.html#callee-saves), [frame index elimination](../frame-wiki/frame-wiki.html#frame-index), [shrink wrapping](../frame-wiki/frame-wiki.html#shrink-wrap) and [CFI](../frame-wiki/frame-wiki.html#cfi).

## What PEI Calls, in Order

```mermaid
flowchart TD
    A["calculateCallFrameInfo<br/>(eliminateCallFramePseudoInstr)"] --> B["calculateSaveRestoreBlocks"]
    B --> C["spillCalleeSavedRegs<br/>(determineCalleeSaves, spill/restoreCalleeSavedRegisters)"]
    C --> D["processFunctionBeforeFrameFinalized"]
    D --> E["calculateFrameObjectOffsets"]
    E --> F["insertPrologEpilogCode<br/>(emitPrologue, emitEpilogue)"]
    F --> G["replaceFrameIndices<br/>(eliminateFrameIndex)"]
    G --> H["scavengeFrameVirtualRegs"]
```

This is the order in `PEIImpl::run`. Target hooks are in parentheses.

**Sources:** [llvm/lib/CodeGen/PrologEpilogInserter.cpp:211-283](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp#L211-L283)

## Required Hooks

| Hook | Class | Declared at | Purpose |
| --- | --- | --- | --- |
| Constructor `(StackDirection, StackAlign, LocalAreaOffset)` | `TargetFrameLowering` | `TargetFrameLowering.h:86` | Stack grows down, alignment, offset of local area |
| `emitPrologue`, `emitEpilogue` | `TargetFrameLowering` | 211, 213 | Pure virtual: build and remove the frame |
| `hasFPImpl` | `TargetFrameLowering` | 520 | Pure virtual: does this function need a frame pointer? (`hasFP` at 306 calls it) |
| `hasReservedCallFrame` | `TargetFrameLowering` | 315 | Whether outgoing argument space is part of the fixed frame |
| `eliminateCallFramePseudoInstr` | `TargetFrameLowering` | 431 | Removes `ADJCALLSTACKDOWN/UP`; the default is `llvm_unreachable`, so any target that uses call-frame pseudos must override it |
| `eliminateFrameIndex` | `TargetRegisterInfo` | `TargetRegisterInfo.h:1020` | Pure virtual: rewrites frame-index operands |

AArch64's versions are short wrappers at this commit: `emitPrologue` and `emitEpilogue` construct an `AArch64PrologueEmitter` / `AArch64EpilogueEmitter` (in `AArch64PrologueEpilogue.cpp`) and call it:

```cpp
void AArch64FrameLowering::emitPrologue(MachineFunction &MF,
                                        MachineBasicBlock &MBB) const {
  AArch64PrologueEmitter PrologueEmitter(MF, MBB, *this);
  PrologueEmitter.emitPrologue();
}
```

The default for call-frame pseudos:

```cpp
  eliminateCallFramePseudoInstr(MachineFunction &MF,
                                MachineBasicBlock &MBB,
                                MachineBasicBlock::iterator MI) const {
    llvm_unreachable("Call Frame Pseudo Instructions do not exist on this "
                     "target!");
  }
```

**Sources:** [llvm/include/llvm/CodeGen/TargetFrameLowering.h:86](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L86), [llvm/include/llvm/CodeGen/TargetFrameLowering.h:211-213](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L211-L213), [llvm/include/llvm/CodeGen/TargetFrameLowering.h:306-315](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L306-L315), [llvm/include/llvm/CodeGen/TargetFrameLowering.h:431-436](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L431-L436), [llvm/include/llvm/CodeGen/TargetFrameLowering.h:520](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L520), [llvm/include/llvm/CodeGen/TargetRegisterInfo.h:1020](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetRegisterInfo.h#L1020), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:1236-1246](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L1236-L1246)

## What It Produces

Two AArch64 functions from `llc -O2 -mtriple=aarch64-linux-gnu`. A leaf function gets no frame at all:

```asm
leaf:                                   // @leaf
	.cfi_startproc
	mul	x0, x0, x1
	ret
```

A function with a call saves the return address and the callee-saved register it uses in one paired store, and emits CFI for the unwinder:

```asm
withcall:                               // @withcall
	.cfi_startproc
	stp	x30, x19, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w19, -8
	.cfi_offset w30, -16
	mov	x19, x0
	bl	h
	add	x0, x0, x19
	ldp	x30, x19, [sp], #16             // 16-byte Folded Reload
	ret
```

The [frame lowering walkthroughs](../frame-wiki/frame-wiki.html#aarch64-walkthroughs) show the MIR before and after PEI and the large-frame and `alloca` cases.

## Minimal Toy Frame Lowering (Illustrative)

**Illustrative, not LLVM source.** Fixed-size frames only, no frame pointer, outgoing arguments in the reserved call frame:

```cpp
class ToyFrameLowering : public TargetFrameLowering {
public:
  ToyFrameLowering()
      : TargetFrameLowering(StackGrowsDown, Align(8), /*LocalAreaOffset=*/0) {}

  void emitPrologue(MachineFunction &MF, MachineBasicBlock &MBB) const override {
    uint64_t Size = MF.getFrameInfo().getStackSize();
    if (!Size) return;
    const auto &TII = *MF.getSubtarget<ToySubtarget>().getInstrInfo();
    auto MBBI = MBB.begin();
    BuildMI(MBB, MBBI, DebugLoc(), TII.get(Toy::ADDI), Toy::SP)
        .addReg(Toy::SP).addImm(-(int64_t)Size)
        .setMIFlag(MachineInstr::FrameSetup);
  }
  void emitEpilogue(MachineFunction &MF, MachineBasicBlock &MBB) const override {
    uint64_t Size = MF.getFrameInfo().getStackSize();
    if (!Size) return;
    const auto &TII = *MF.getSubtarget<ToySubtarget>().getInstrInfo();
    auto MBBI = MBB.getFirstTerminator();
    BuildMI(MBB, MBBI, DebugLoc(), TII.get(Toy::ADDI), Toy::SP)
        .addReg(Toy::SP).addImm(Size)
        .setMIFlag(MachineInstr::FrameDestroy);
  }
  MachineBasicBlock::iterator
  eliminateCallFramePseudoInstr(MachineFunction &, MachineBasicBlock &MBB,
                                MachineBasicBlock::iterator I) const override {
    return MBB.erase(I);          // valid because hasReservedCallFrame() is true
  }
protected:
  bool hasFPImpl(const MachineFunction &) const override { return false; }
};
```

```cpp
// ToyRegisterInfo.cpp (illustrative)
bool ToyRegisterInfo::eliminateFrameIndex(MachineBasicBlock::iterator II,
                                          int SPAdj, unsigned FIOp,
                                          RegScavenger *RS) const {
  MachineInstr &MI = *II;
  MachineFunction &MF = *MI.getMF();
  int FI = MI.getOperand(FIOp).getIndex();
  int64_t Off = MF.getFrameInfo().getObjectOffset(FI) +
                MF.getFrameInfo().getStackSize() +
                MI.getOperand(FIOp + 1).getImm();
  assert(isInt<16>(Off) && "large frames need a scratch register");
  MI.getOperand(FIOp).ChangeToRegister(Toy::SP, false);
  MI.getOperand(FIOp + 1).ChangeToImmediate(Off);
  return false;                   // MI was not erased
}
```

This assumes every frame-index user has the operand pair `(base, offset)` as in the `LW`/`SW`/`ADDI` records on [Instructions and ISel](#instructions-isel). Callee-saved registers need no extra code: the default `spillCalleeSavedRegisters` returns `false`, so PEI calls `TargetFrameLowering::spillCalleeSavedRegister` for each register, which uses `ToyInstrInfo::storeRegToStackSlot` (restores go through `loadRegFromStackSlot`). See the frame wiki's [PEI page](../frame-wiki/frame-wiki.html#pei-pass).
