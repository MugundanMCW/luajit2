# Tooling and Glossary

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)
- [llvm/lib/CodeGen/PrologEpilogInserter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp)

</details>
The commands used while bringing up a target, and the terms used across this wiki. Each of the other wikis has its own tooling page with more detail: [SelectionDAG](../selectiondag-wiki.html#tooling), [register allocation](../regalloc-wiki/regalloc-wiki.html#tooling), [MC](../mc-wiki/mc-wiki.html#tooling-glossary), [calling conventions](../callconv-wiki/callconv-wiki.html#tooling-glossary), [frame lowering](../frame-wiki/frame-wiki.html#tooling-glossary) and [scheduling](../sched-wiki/sched-wiki.html#tooling-glossary).

## Purpose and Scope

`llc` and `llvm-tblgen` options useful during bring-up, and a glossary. All tool output in this wiki comes from an LLVM 24.0.0git release build of `llc` (no assertions) at commit `a2171756`; options that need an assertions build are marked.

## llc Options

| Option | Use | Used in this wiki |
| --- | --- | --- |
| `-mtriple=<triple>`, `-march=<name>` | Choose the target | Yes |
| `-mcpu=<cpu>`, `-mattr=+f,-g` | Choose CPU (and scheduling model) and features | Yes (`cortex-a57`, `cortex-a55`) |
| `-O0` ... `-O3` | Optimization level; `-O0` is the easiest first target | Yes |
| `-stop-after=<pass>`, `-stop-before=<pass>` | Print MIR at a point in the pipeline | Yes (`finalize-isel`, `prolog-epilog`, `machine-scheduler`) |
| `-run-pass=<pass>` | Run one pass on a `.mir` file | — |
| `-debug-pass=Structure` | Print the pass pipeline and pass names | Yes |
| `-verify-machineinstrs` | Run the machine verifier after each pass | — |
| `-filetype=obj` | Write an object file (needs the MC code emitter and asm backend) | — |
| `-debug-only=<type>`, `-view-*-dags` | Debug output, DAG graphs | Needs an assertions build |

Pass names for `-stop-after` are the `DEBUG_TYPE` strings, which can differ from the class name. For example the prologue/epilogue pass is `prolog-epilog`:

```cpp
#define DEBUG_TYPE "prolog-epilog"
```

`-debug-pass=Structure` prints every pass name in order (`... -shrink-wrap -prolog-epilog ...`), which is the quickest way to find the right one.

**Sources:** [llvm/lib/CodeGen/PrologEpilogInserter.cpp:69](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp#L69)

## llvm-tblgen

| Command | Use |
| --- | --- |
| `llvm-tblgen -print-records -I llvm/include -I lib/Target/Toy Toy.td` | Check the `.td` files parse; see every record |
| `llvm-tblgen -gen-register-info ...` (and other `-gen-*`) | Run one backend by hand to inspect its output |

## Glossary

| Term | Meaning |
| --- | --- |
| Target | The `Target` object returned by `getThe<T>Target()`, registered with `TargetRegistry` |
| Triple | `arch-vendor-os-env` string such as `aarch64-unknown-linux-gnu` |
| Data layout | String giving endianness, type sizes and alignments, stack alignment |
| TargetMachine | Per-compilation object: data layout, reloc and code model, pass pipeline |
| Subtarget | Per CPU-and-features object owning lowering, instr, register and frame info |
| TargetLowering | Legal types and operation actions; custom lowering; call lowering |
| Operation action | `Legal`, `Promote`, `Expand`, `LibCall` or `Custom` for an (operation, type) pair |
| Calling convention | Rules for placing arguments and return values; `CallingConv` records |
| Register mask | Bit set of registers preserved by a call, attached to call instructions |
| Callee-saved register | Register a function must restore before returning |
| Frame index | Abstract stack slot used before frame layout is final |
| PEI | Prologue/epilogue insertion pass (`prolog-epilog`) |
| Scheduling model | `SchedMachineModel` with resources and latencies for one CPU |
| `SchedWrite` / `SchedRead` | Abstract per-operand scheduling types attached to instructions |
| MCInst | Flat instruction used by the MC layer |
| AsmPrinter | Last CodeGen pass; turns `MachineInstr` into `MCInst` and streams it |
| Pseudo instruction | Instruction with no encoding, expanded before or during emission |
| Toy | The made-up target used for illustrative examples in these wikis |