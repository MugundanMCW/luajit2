# Core Data Structures

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/CodeGen/SelectionDAG.h](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/SelectionDAG.h)
- [llvm/include/llvm/CodeGen/SelectionDAGNodes.h](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/SelectionDAGNodes.h)
- [llvm/include/llvm/CodeGen/ISDOpcodes.h](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/ISDOpcodes.h)
- [llvm/lib/CodeGen/SelectionDAG/SelectionDAG.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAG.cpp)
- [llvm/include/llvm/CodeGen/TargetLowering.h](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/TargetLowering.h)

</details>
A SelectionDAG is a graph of `SDNode`s where an edge is an `SDValue` (a node plus which of its results is used). Edges come in three kinds: data, chain (ordering of side effects) and glue (must stay adjacent).

## Purpose and Scope

This page defines the vocabulary used by every later page: `SelectionDAG`, `SDNode`, `SDValue`, `SDUse`, value types, opcode ranges, chains, glue, uniquing and node numbering. It ends with a first DAG, `(a * b) + c`, printed in the format of `-debug-only=isel`.

## Class Relationships

```mermaid
classDiagram
  class SelectionDAG {
    AllNodes
    EntryNode
    Root
    getNode()
    AssignTopologicalOrder()
    ReplaceAllUsesWith()
  }
  class SDNode {
    NodeId
    NodeType
    ValueList
    OperandList
  }
  class SDValue {
    Node
    ResNo
  }
  class SDUse {
    Val
    User
  }
  SelectionDAG "1" o-- "*" SDNode : owns
  SDNode "1" *-- "*" SDUse : operands
  SDUse --> SDValue : holds
  SDValue --> SDNode : points to
```

| Type | Meaning | Key facts |
| --- | --- | --- |
| `SelectionDAG` | The graph for one block | Owns every node in an intrusive list (`AllNodes`), keeps a `FoldingSet` for uniquing, has an `EntryNode` and a `Root` (the last chain) |
| `SDNode` | One operation | An opcode (`NodeType`), result types (`ValueList`), operands (`OperandList`, an array of `SDUse`), flags (`nsw`, `nuw`, fast-math), a debug location and a `NodeId` |
| `SDValue` | One result of a node | A pair `(SDNode*, ResNo)`; printed `t5` for result 0 and `t5:1` for result 1 |
| `SDUse` | One operand slot | Records the user and the used value and links into the definition's use list, so `ReplaceAllUsesWith` is cheap |
| `EVT` / `MVT` | Value type | `MVT` is a simple type (`i32`, `v4i32`, `MVT::Other`, `MVT::Glue`); `EVT` also covers extended types such as `i7`, `i128`, `v3i16` |

**Sources:** [llvm/include/llvm/CodeGen/SelectionDAG.h:231-273](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/SelectionDAG.h#L231-L273), [llvm/include/llvm/CodeGen/SelectionDAGNodes.h:147](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/SelectionDAGNodes.h#L147), [llvm/include/llvm/CodeGen/SelectionDAGNodes.h:279](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/SelectionDAGNodes.h#L279), [llvm/include/llvm/CodeGen/SelectionDAGNodes.h:510](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/SelectionDAGNodes.h#L510), [llvm/include/llvm/CodeGen/SelectionDAGNodes.h:656-663](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/SelectionDAGNodes.h#L656-L663)

## Opcode Ranges

The value of a node's opcode tells you how far the node has come in the pipeline.

| Range | Name | Example | Created by |
| --- | --- | --- | --- |
| `0 .. ISD::BUILTIN_OP_END-1` | Target-independent `ISD::` | `ISD::ADD`, `ISD::LOAD`, `ISD::SETCC` | `SelectionDAGBuilder`, combiner, legalizer |
| `>= ISD::BUILTIN_OP_END` | Target-specific DAG nodes | `AArch64ISD::CSEL`, `AArch64ISD::ADRP`, `AArch64ISD::CALL` | Target `LowerOperation` and `PerformDAGCombine` |
| negative (`~MachineOpc`) | Machine nodes (already selected) | `AArch64::ADDWrr` | `AArch64DAGToDAGISel` and the generated matcher |

`SDNode::isTargetOpcode()` tests `NodeType >= ISD::BUILTIN_OP_END`; `isMachineOpcode()` tests `NodeType < 0` and `getMachineOpcode()` returns the instruction number. After selection the DAG holds only machine nodes plus a few structural kinds (`CopyToReg`, `CopyFromReg`, `TokenFactor`, `EntryToken`).

**Sources:** [llvm/include/llvm/CodeGen/SelectionDAGNodes.h:709](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/SelectionDAGNodes.h#L709), [llvm/include/llvm/CodeGen/SelectionDAGNodes.h:758-765](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/SelectionDAGNodes.h#L758-L765), [llvm/include/llvm/CodeGen/ISDOpcodes.h:1666-1668](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/ISDOpcodes.h#L1666-L1668)

## The Three Kinds of Edge

- **Data edges** carry values such as `i32` or `v4f32`. Independent data-only nodes have no order between them.
- **Chain edges** have type `MVT::Other`, printed `ch`. They serialise anything with a side effect (loads, stores, calls, `CopyToReg`, barriers). A node takes a chain in and produces a chain out; independent chains are merged with `ISD::TokenFactor`. The chain starts at `ISD::EntryToken` and ends at the DAG's `Root`.
- **Glue edges** have type `MVT::Glue`, printed `glue`. Glue says the producer and consumer must be scheduled back to back. It is used where hardware has an implicit register dependency, such as the `CopyToReg` of outgoing arguments right before a call.

AArch64 models condition flags as an explicit `i32` value instead of glue: `AArch64ISD::SUBS` returns `(i32, i32)` where result 1 is `NZCV`.

A load shows all three ideas: `t9: i32,ch = load<(load (s32) from %ir.p)> t0, t4, undef:i64` has results *(value, chain)* and operands *(chain, base pointer, offset)*; the trailing `<...>` is its `MachineMemOperand`.

**Sources:** [llvm/include/llvm/CodeGen/ISDOpcodes.h:48-53](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/ISDOpcodes.h#L48-L53), [llvm/include/llvm/CodeGen/ISDOpcodes.h:224-230](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/ISDOpcodes.h#L224-L230)

## Uniquing: Free Common-Subexpression Elimination

`SelectionDAG::getNode` builds a `FoldingSetNodeID` from opcode, result types, operands and flags and looks it up. If an identical node exists, it is returned instead of creating a new one, so the same `add t2, t4` built twice is one node with two users. Nodes whose last result is `MVT::Glue` are not uniqued, and loads and stores are only equal if their chain operand is equal.

**Sources:** [llvm/lib/CodeGen/SelectionDAG/SelectionDAG.cpp:1018-1043](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAG.cpp#L1018-L1043), [llvm/lib/CodeGen/SelectionDAG/SelectionDAG.cpp:7458](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAG.cpp#L7458)

## Special Nodes in Dumps

| Dump text | Opcode | Meaning |
| --- | --- | --- |
| `t0: ch,glue = EntryToken` | `ISD::EntryToken` | Start of the chain |
| `t2: i32,ch = CopyFromReg t0, Register:i32 %0` | `ISD::CopyFromReg` | Read a virtual or physical register: how arguments and cross-block values enter a block's DAG |
| `t9: ch,glue = CopyToReg t0, Register:i32 $w0, t7` | `ISD::CopyToReg` | Write a register: return values, outgoing arguments and live-out values leave this way |
| `Constant:i32<3>` | `ISD::Constant` | A constant that combine and legalization may change |
| `TargetConstant:i32<3>` | `ISD::TargetConstant` | A final immediate; selection places it in the instruction as is |
| `GlobalAddress:i64<ptr @g> 0` | `ISD::GlobalAddress` | Address of a symbol; the target lowers it (`ADRP` + `ADD :lo12:`) |
| `FrameIndex:i64<0>` | `ISD::FrameIndex` | Address of a stack slot |
| `t6: ch = TokenFactor t3:1, t5:1` | `ISD::TokenFactor` | Joins independent chains |

## Node Numbering

Every node has an integer `NodeId`. `SelectionDAG::AssignTopologicalOrder()` runs a Kahn-style sort and renumbers `AllNodes` so every node appears after all its operands (`EntryToken` first, `Root` last). Instruction selection uses this order backwards, and the node ids double as a cycle-safety check during folding. See [Pipeline, Phases and Traversal Orders](#pipeline).

**Sources:** [llvm/lib/CodeGen/SelectionDAG/SelectionDAG.cpp:13469-13551](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAG.cpp#L13469-L13551)

## Example: `(a * b) + c`

For `i32 madd(i32 a, i32 b, i32 c)` the initial DAG is shown below. The text dump follows the `-debug-only=isel` format; node numbers are illustrative.

```text
t0: ch,glue = EntryToken
t2: i32,ch = CopyFromReg t0, Register:i32 %0      ; a (live-in $w0 copied to vreg %0)
t4: i32,ch = CopyFromReg t0, Register:i32 %1      ; b
t6: i32,ch = CopyFromReg t0, Register:i32 %2      ; c
t7: i32 = mul t2, t4
t8: i32 = add t7, t6
t10: ch,glue = CopyToReg t0, Register:i32 $w0, t8  ; return value into $w0
t11: ch = AArch64ISD::RET_GLUE t10, Register:i32 $w0, t10:1
```

```mermaid
flowchart LR
  n0["t0 EntryToken"]
  n2["t2 CopyFromReg %0"]
  n4["t4 CopyFromReg %1"]
  n6["t6 CopyFromReg %2"]
  n7["t7 mul"]
  n8["t8 add"]
  n10["t10 CopyToReg $w0"]
  n11["t11 RET_GLUE"]
  n0 -.-> n2
  n0 -.-> n4
  n0 -.-> n6
  n2 --> n7
  n4 --> n7
  n7 --> n8
  n6 --> n8
  n8 --> n10
  n0 -.-> n10
  n10 -.-> n11
```

Solid arrows are data edges and dashed arrows are chain edges. The chain `t0 -> t10 -> t11` is the only ordering; the glue operand `t10:1` makes the return sit directly after the copy into `$w0`.
