# CFI and Unwind Information

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp)
- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)

</details>
Debuggers, profilers and C++ exception unwinding need to know, at every instruction, how to find the caller's frame: where the canonical frame address (CFA) is, and where each saved register is stored. On ELF this is DWARF call frame information (CFI). Frame lowering produces it: while emitting the prologue, the target inserts `CFI_INSTRUCTION` pseudo instructions, which the AsmPrinter turns into `.cfi_*` directives and the MC layer turns into the `.eh_frame` section.

## Purpose and Scope

Which CFI the prologue emits, how it looks in MIR and assembly, and how shrink wrapping interacts with it. How MC encodes `.eh_frame` is on the MC wiki's [streamers page](../mc-wiki/mc-wiki.html#streamers).

## From Prologue to Directive

```mermaid
flowchart LR
    P["emitPrologue"] -->|"BuildMI CFI_INSTRUCTION<br/>(MCCFIInstruction)"| MIR["frame-setup CFI_INSTRUCTION ..."]
    MIR --> AP["AsmPrinter"]
    AP --> S[".cfi_def_cfa_offset / .cfi_offset"]
    S --> EH[".eh_frame (MC)"]
```

## What AArch64 Emits

After PEI (`-stop-after=prolog-epilog`), `withcall`:

```text
    early-clobber $sp = frame-setup STPXpre killed $lr, killed $x19, $sp, -2 :: (store (s64) into %stack.1), (store (s64) into %stack.0)
    frame-setup CFI_INSTRUCTION def_cfa_offset 16
    frame-setup CFI_INSTRUCTION offset $w19, -8
    frame-setup CFI_INSTRUCTION offset $w30, -16
```

and the assembly:

```asm
	stp	x30, x19, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w19, -8
	.cfi_offset w30, -16
```

| Directive | Meaning |
| --- | --- |
| `.cfi_startproc` / `.cfi_endproc` | Function boundaries (emitted by the AsmPrinter, not frame lowering) |
| `.cfi_def_cfa_offset N` | CFA is `sp + N` after this instruction |
| `.cfi_def_cfa w29, N` | CFA is `x29 + N` (used once a frame pointer is set up) |
| `.cfi_offset wR, -K` | Register R is saved at `CFA - K` |

With a frame pointer (`-frame-pointer=all`) the CFA is rebased on `x29` so later SP changes need no more CFI:

```asm
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	str	x19, [sp, #16]                  // 8-byte Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
```

Without a frame pointer, every SP change needs a new `.cfi_def_cfa_offset`; the 70000-byte `bigframe` emits `.cfi_def_cfa_offset 70016` once, after both `sub sp` instructions.

`AArch64PrologueEmitter::emitCalleeSavedGPRLocations` is the function that emits the `offset` entries for saved general-purpose registers.

**Sources:** [llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp:1253](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp#L1253), [llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp:1017](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp#L1017)

## Shrink Wrapping and the CFI Fixup Pass

CFI describes the state at each instruction in address order. When shrink wrapping puts the prologue in a non-entry block, the fall-through and the taken path disagree about the frame. AArch64 turns on the generic CFI fixup pass (`-cfi-fixup`, near the end of the pipeline) which inserts `.cfi_remember_state`/`.cfi_restore_state` style corrections where needed:

```cpp
  // AArch64 supports fixing up the DWARF unwind information.
  if (!getMCAsmInfo().usesWindowsCFI())
    setCFIFixup(true);
```

Windows on Arm uses SEH unwind codes instead (`usesWindowsCFI`), which is also why shrink wrapping is disabled there.

**Sources:** [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:426-428](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L426-L428), [llvm/lib/CodeGen/ShrinkWrap.cpp:1044-1047](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ShrinkWrap.cpp#L1044-L1047)

## For a New Target

1. In `MCAsmInfo`, enable DWARF CFI (`ExceptionsType = ExceptionHandling::DwarfCFI`) and give the initial frame state (CFA = SP + 0 at entry) in the MC asm info factory. See the MC wiki's [MCAsmInfo page](../mc-wiki/mc-wiki.html#asminfo-printer).
2. In `emitPrologue`, after each SP change emit `MCCFIInstruction::cfiDefCfaOffset`; after each callee-saved store emit `MCCFIInstruction::createOffset`; after setting up the frame pointer emit `cfiDefCfa(FP, ...)`. Use `TII.get(TargetOpcode::CFI_INSTRUCTION)` with `MF.addFrameInst(...)` and mark them `FrameSetup`.
3. Give every register a `DwarfRegNum` in TableGen so the directives can name it.
4. If you enable shrink wrapping, either enable CFI fixup or make sure the epilogue path is described correctly.

(Step details are illustrative; check the `MCCFIInstruction` factory names in `llvm/include/llvm/MC/MCDwarf.h` at your LLVM version.)