# TargetFrameLowering Hooks

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/CodeGen/TargetFrameLowering.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h)
- [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp)
- [llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp)

</details>
`TargetFrameLowering` is the interface PEI and shrink wrapping call to learn about the target's stack and to emit target code. A few hooks are pure virtual; the rest have defaults that work for a simple target. The subtarget owns one instance and returns it from `getFrameLowering()`.

## Purpose and Scope

Every hook a backend usually touches, its default, and what AArch64 does. The order in which PEI calls them is on [The PEI Pass](#pei-pass).

## Constructor

```cpp
  TargetFrameLowering(StackDirection D, Align StackAl, int LAO,
```

`StackDirection` (`StackGrowsDown` or `StackGrowsUp`, enum at line 51), the stack alignment (must match the `S` part of the data layout), and the local area offset (where locals start relative to the incoming SP, usually 0).

**Sources:** [llvm/include/llvm/CodeGen/TargetFrameLowering.h:51](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L51), [llvm/include/llvm/CodeGen/TargetFrameLowering.h:86](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L86)

## The Hooks

| Hook | Header line | Default | AArch64 (line in `AArch64FrameLowering.cpp`) |
| --- | --- | --- | --- |
| `emitPrologue(MF, MBB)` | 211 | pure virtual | 1236: delegates to `AArch64PrologueEmitter` |
| `emitEpilogue(MF, MBB)` | 213 | pure virtual | 1242: delegates to `AArch64EpilogueEmitter` |
| `hasFPImpl(MF)` | 520 | pure virtual | 568 |
| `hasReservedCallFrame(MF)` | 315 | `!hasFP(MF)` | 659: no variable-sized objects |
| `eliminateCallFramePseudoInstr` | 431 | `llvm_unreachable` | 669 |
| `determineCalleeSaves(MF, SavedRegs, RS)` | 401 | callee-saved registers that are modified | 2521 |
| `assignCalleeSavedSpillSlots` | 165 | return `false` (let PEI choose) | 2800 |
| `spillCalleeSavedRegisters` | 263 | return `false` (PEI uses `storeRegToStackSlot`) | 1975: paired `stp` |
| `restoreCalleeSavedRegisters` | 285 | return `false` (PEI uses `loadRegFromStackSlot`) | 2194: paired `ldp` |
| `processFunctionBeforeFrameFinalized` | 409 | nothing | 3014 |
| `getFrameIndexReference(MF, FI, FrameReg)` | 338 | offset from `getFrameRegister` | via `resolveFrameIndexReference` (1372) |
| `enableShrinkWrapping(MF)` | 194 | `false` | overridden in `AArch64FrameLowering.h:110` |
| `canUseAsPrologue` / `canUseAsEpilogue` | 458 / 470 | `true` | 955 |

The declarations of `assignCalleeSavedSpillSlots` and `restoreCalleeSavedRegisters` are at [TargetFrameLowering.h:165](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L165) and [TargetFrameLowering.h:285](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L285); the default `hasReservedCallFrame` (`return !hasFP(MF);`) is at [TargetFrameLowering.h:315-317](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L315-L317); AArch64's shrink-wrapping override is at [AArch64FrameLowering.h:110](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.h#L110).

**Sources:** [llvm/include/llvm/CodeGen/TargetFrameLowering.h:194-520](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L194-L520), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:568](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L568), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:955](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L955), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:1236-1246](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L1236-L1246), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:1372](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L1372), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:1975](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L1975), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:2194](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L2194), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:2521](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L2521), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:2800](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L2800), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:3014](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L3014)

## hasFP

`hasFP` (line 306 of the header) is the public entry and calls the target's `hasFPImpl`. AArch64 needs a frame pointer when the user asked for one, or when SP-relative addressing would not work:

```cpp
  // Retain behavior of always omitting the FP for leaf functions when possible.
  if (MF.getTarget().Options.DisableFramePointerElim(MF))
    return true;
  if (MFI.hasVarSizedObjects() || MFI.isFrameAddressTaken() ||
      MFI.hasStackMap() || MFI.hasPatchPoint() ||
      RegInfo->hasStackRealignment(MF))
    return true;
```

With a variable-sized object, SP moves by an unknown amount, so locals must be addressed from `x29`; that is why the `dynalloca` walkthrough sets up `mov x29, sp`.

**Sources:** [llvm/include/llvm/CodeGen/TargetFrameLowering.h:306](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L306), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:588-594](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L588-L594)

## Call-Frame Pseudos

If the call frame is reserved (part of the fixed frame), `ADJCALLSTACKDOWN/UP` can just be deleted. Otherwise they become real SP adjustments around each call:

```cpp
bool AArch64FrameLowering::hasReservedCallFrame(
    const MachineFunction &MF) const {
  ...
  return !MF.getFrameInfo().hasVarSizedObjects();
}

MachineBasicBlock::iterator AArch64FrameLowering::eliminateCallFramePseudoInstr(
    MachineFunction &MF, MachineBasicBlock &MBB,
    MachineBasicBlock::iterator I) const {
  ...
  if (!hasReservedCallFrame(MF)) {
    int64_t Amount = I->getOperand(0).getImm();
    Amount = alignTo(Amount, getStackAlign());
    if (!IsDestroy)
      Amount = -Amount;
```

The outgoing argument area of a call is covered on the [calling conventions LowerCall page](../callconv-wiki/callconv-wiki.html#lower-call).

**Sources:** [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:659-686](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L659-L686)

## Prologue and Epilogue Emitters

At this commit AArch64 moved the prologue and epilogue bodies out of `AArch64FrameLowering.cpp` into helper classes:

| Function | Line in `AArch64PrologueEpilogue.cpp` |
| --- | --- |
| `AArch64PrologueEmitter::emitPrologue` | 638 |
| `AArch64PrologueEmitter::emitFramePointerSetup` | 1017 |
| `AArch64PrologueEmitter::emitCalleeSavedGPRLocations` (CFI) | 1253 |
| `AArch64EpilogueEmitter::emitEpilogue` | 1355 |
| `shouldCombineCSRLocalStackBump` | 308 |

`shouldCombineCSRLocalStackBump` decides whether the callee-saved store and the local-area `sub sp` can be merged into one pre-indexed `stp` (as in `stp x30, x19, [sp, #-16]!`).

**Sources:** [llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp:308](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp#L308), [llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp:638](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp#L638), [llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp:1017](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp#L1017), [llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp:1253](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp#L1253), [llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp:1355](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64PrologueEpilogue.cpp#L1355)

## Related Hooks Elsewhere

`TargetRegisterInfo` provides `eliminateFrameIndex`, `getFrameRegister`, `requiresRegisterScavenging` and `hasBasePointer` (see [Frame Index Elimination](#frame-index) and the regalloc [TRI hooks page](../regalloc-wiki/regalloc-wiki.html#tri-hooks)). `TargetInstrInfo` provides `storeRegToStackSlot` and `loadRegFromStackSlot`, used for default callee-saved spills (regalloc [TII hooks](../regalloc-wiki/regalloc-wiki.html#tii-hooks)).