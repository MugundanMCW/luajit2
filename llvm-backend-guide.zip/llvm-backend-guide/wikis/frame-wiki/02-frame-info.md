# MachineFrameInfo

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/CodeGen/MachineFrameInfo.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineFrameInfo.h)
- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)

</details>
`MachineFrameInfo` is the per-function table of stack objects. Each object has an index (the **frame index**), a size, an alignment, and, once PEI has run, an offset. Code refers to objects only by index (`%stack.0`, `%fixed-stack.1` in MIR) until frame index elimination replaces the index with a register and an offset.

## Purpose and Scope

The kinds of objects, how they are created, and the function-wide flags frame lowering reads. The pass that assigns offsets is on [The PEI Pass](#pei-pass).

## Object Kinds

| Kind | Created with | Index | Offset known when created? | Example |
| --- | --- | --- | --- | --- |
| Fixed object | `CreateFixedObject(Size, SPOffset, IsImmutable)` (line 723) | Negative | Yes, relative to SP at function entry | Incoming stack argument |
| Fixed spill object | `CreateFixedSpillStackObject` (728) | Negative | Yes | Some callee-saved slots |
| Stack object | `CreateStackObject(Size, Align, IsSpillSlot)` (831) | ≥ 0 | No, PEI assigns it | `alloca`, spill slot |
| Variable-sized object | `CreateVariableSizedObject(Align, Alloca)` (851) | ≥ 0 | No; sets `HasVarSizedObjects` | `alloca i8, i64 %n` |

`isFixedObjectIndex` (732) tells them apart. Each object also has a stack ID (`getStackID`, 794): `Default` for normal memory, others (such as scalable vectors on AArch64) for objects laid out separately.

**Sources:** [llvm/include/llvm/CodeGen/MachineFrameInfo.h:112-129](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineFrameInfo.h#L112-L129), [llvm/include/llvm/CodeGen/MachineFrameInfo.h:723-732](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineFrameInfo.h#L723-L732), [llvm/include/llvm/CodeGen/MachineFrameInfo.h:794](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineFrameInfo.h#L794), [llvm/include/llvm/CodeGen/MachineFrameInfo.h:831-851](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineFrameInfo.h#L831-L851)

## Where Objects Come From

```mermaid
flowchart TD
    LFA["LowerFormalArguments"] -->|"CreateFixedObject"| F["fixed objects (negative indices)"]
    FLI["FunctionLoweringInfo (static allocas)"] -->|"CreateStackObject"| S["stack objects"]
    DYN["dynamic alloca"] -->|"CreateVariableSizedObject"| V["variable-sized"]
    RA["spiller"] -->|"CreateSpillStackObject"| S
    PEI["PEI: assignCalleeSavedSpillSlots"] --> S
```

AArch64's `LowerFormalArguments` creates one fixed object per stack argument:

```cpp
        int FI = MFI.CreateFixedObject(ArgSize, ArgOffset + BEAlign, true);
```

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9515](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9515)

## Function-Wide Information

| Accessor | Line | Meaning |
| --- | --- | --- |
| `hasVarSizedObjects()` | 371 | Any dynamic `alloca`; usually forces a frame pointer |
| `getObjectOffset(FI)` | 553 | Offset from the incoming SP (valid after PEI) |
| `getStackSize()` / `setStackSize()` | 612 / 615 | Total frame size, set by PEI |
| `getMaxAlign()` | 627 | Largest object alignment; may force stack realignment |
| `adjustsStack()` | 644 | Function calls something or otherwise moves SP |
| `getMaxCallFrameSize()` | 698 | Largest outgoing argument area of any call |
| `setCalleeSavedInfo()` | 863 | List of callee-saved registers and their slots (`CalleeSavedInfo`, line 36) |

These appear in the `frameInfo:` section of MIR. For the AArch64 `withcall` function after PEI:

```text
  stackSize:       16
  adjustsStack:    true
  hasCalls:        true
  maxCallFrameSize: 0
  - { id: 0, name: '', type: spill-slot, offset: -8, size: 8, alignment: 8,
      stack-id: default, callee-saved-register: '$x19', callee-saved-restored: true,
  - { id: 1, name: '', type: spill-slot, offset: -16, size: 8, alignment: 8,
      stack-id: default, callee-saved-register: '$lr', callee-saved-restored: true,
```

Before PEI the same function had `stackSize: 0` and an empty `stack:` list; the two callee-saved slots were added by PEI.

**Sources:** [llvm/include/llvm/CodeGen/MachineFrameInfo.h:36](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineFrameInfo.h#L36), [llvm/include/llvm/CodeGen/MachineFrameInfo.h:371](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineFrameInfo.h#L371), [llvm/include/llvm/CodeGen/MachineFrameInfo.h:553-698](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineFrameInfo.h#L553-L698), [llvm/include/llvm/CodeGen/MachineFrameInfo.h:863](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineFrameInfo.h#L863)