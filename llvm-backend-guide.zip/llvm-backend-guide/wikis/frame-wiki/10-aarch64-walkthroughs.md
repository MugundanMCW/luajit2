# AArch64 Walkthroughs

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp)
- [llvm/lib/CodeGen/PrologEpilogInserter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp)

</details>
Five functions compiled with the real `llc` (LLVM 24.0.0git release build at `a2171756`) using `-O2 -mtriple=aarch64-linux-gnu`. MIR is from `-stop-before=prolog-epilog` and `-stop-after=prolog-epilog`.

## Purpose and Scope

Concrete evidence for each frame shape: leaf, call, large frame, dynamic `alloca`, and shrink wrapping. Each case links back to the page that explains it.

## 1. Leaf Function

```llvm
define i64 @leaf(i64 %a, i64 %b) {
  %s = mul i64 %a, %b
  ret i64 %s
}
```

```asm
leaf:                                   // @leaf
	.cfi_startproc
	mul	x0, x0, x1
	ret
```

No callee-saved registers used, no stack objects, `stackSize` 0: `emitPrologue` emits nothing. With `-frame-pointer=all` the same function gets a frame record (`stp x29, x30, [sp, #-16]!`, `mov x29, sp`), because `hasFPImpl` returns true when frame-pointer elimination is disabled.

## 2. Function With a Call

```llvm
declare i64 @h(i64)
define i64 @withcall(i64 %a) {
  %r = call i64 @h(i64 %a)
  %s = add i64 %r, %a
  ret i64 %s
}
```

Before PEI:

```text
    renamable $x19 = COPY $x0
    ADJCALLSTACKDOWN 0, 0, implicit-def dead $sp, implicit $sp
    BL @h, csr_aarch64_aapcs, implicit-def dead $lr, implicit $sp, implicit $x0, implicit-def $sp, implicit-def $x0
    ADJCALLSTACKUP 0, 0, implicit-def dead $sp, implicit $sp
    $x0 = ADDXrr killed renamable $x0, killed renamable $x19
    RET_ReallyLR implicit $x0
```

After PEI:

```text
    early-clobber $sp = frame-setup STPXpre killed $lr, killed $x19, $sp, -2 :: (store (s64) into %stack.1), (store (s64) into %stack.0)
    frame-setup CFI_INSTRUCTION def_cfa_offset 16
    frame-setup CFI_INSTRUCTION offset $w19, -8
    frame-setup CFI_INSTRUCTION offset $w30, -16
    renamable $x19 = COPY $x0
    BL @h, csr_aarch64_aapcs, implicit-def dead $lr, implicit $sp, implicit $x0, implicit-def $sp, implicit-def $x0
    $x0 = ADDXrr killed renamable $x0, killed renamable $x19
    early-clobber $sp, $lr, $x19 = frame-destroy LDPXpost $sp, 2 :: (load (s64) from %stack.1), (load (s64) from %stack.0)
    RET_ReallyLR implicit $x0
```

| Change | Step |
| --- | --- |
| `ADJCALLSTACKDOWN/UP` gone | `calculateCallFrameInfo` (reserved call frame) |
| `x19` and `lr` saved | `determineCalleeSaves` + pairing in `spillCalleeSavedRegisters` |
| Pre-indexed `STPXpre` also allocates the frame | Prologue combined the CSR store with the SP decrement |
| `CFI_INSTRUCTION`s | Prologue CFI ([CFI](#cfi)) |
| `stackSize: 16`, slots at −8 and −16 | `calculateFrameObjectOffsets` |

**Sources:** [llvm/lib/CodeGen/PrologEpilogInserter.cpp:211-283](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp#L211-L283)

## 3. Large Frame

```llvm
declare void @ext(ptr)
define void @bigframe() {
  %buf = alloca [70000 x i8], align 16
  call void @ext(ptr %buf)
  ret void
}
```

Before PEI: `$x0 = ADDXri %stack.0.buf, 0, 0`. After PEI:

```text
    early-clobber $sp = frame-setup STPXpre killed $fp, killed $lr, $sp, -2 :: (store (s64) into %stack.2), (store (s64) into %stack.1)
    $sp = frame-setup SUBXri $sp, 17, 12
    $sp = frame-setup SUBXri $sp, 368, 0
    frame-setup CFI_INSTRUCTION def_cfa_offset 70016
    frame-setup CFI_INSTRUCTION offset $w30, -8
    frame-setup CFI_INSTRUCTION offset $w29, -16
    $x0 = ADDXri $sp, 0, 0
    BL @ext, csr_aarch64_aapcs, implicit-def dead $lr, implicit $sp, implicit killed $x0, implicit-def $sp
    $sp = frame-destroy ADDXri $sp, 17, 12
    $sp = frame-destroy ADDXri $sp, 368, 0
    early-clobber $sp, $fp, $lr = frame-destroy LDPXpost $sp, 2 :: (load (s64) from %stack.2), (load (s64) from %stack.1)
    RET_ReallyLR
```

- The 70000-byte local (rounded to 70000 + 16 for the frame record = 70016) needs two `sub` instructions: 17 × 4096 = 69632 plus 368.
- `x29` is saved and restored even though `mov x29, sp` never appears: `determineCalleeSaves` added it to the saved set for this large frame (it is not used as a frame pointer here). The exact rule is in `AArch64FrameLowering::determineCalleeSaves` (line 2521 onwards); this page does not trace which condition triggered it.
- `%stack.0.buf` became `$sp + 0` in `eliminateFrameIndex` ([Frame Index Elimination](#frame-index)).

## 4. Variable-Sized alloca

```llvm
define void @dynalloca(i64 %n) {
  %p = alloca i8, i64 %n, align 16
  call void @ext(ptr %p)
  ret void
}
```

```asm
dynalloca:                              // @dynalloca
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x9, x0, #15
	mov	x8, sp
	and	x9, x9, #0xfffffffffffffff0
	sub	x0, x8, x9
	mov	sp, x0
	bl	ext
	mov	sp, x29
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	ret
```

`hasVarSizedObjects()` makes `hasFPImpl` true, so `x29` is set up and the CFA is based on it (`.cfi_def_cfa w29, 16`). The allocation rounds `%n` up to 16 and moves SP; the epilogue restores SP from `x29` (`mov sp, x29`) instead of adding a known size. See [TargetFrameLowering Hooks](#tfl-hooks).

**Sources:** [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:588-594](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L588-L594), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:659-667](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L659-L667)

## 5. Shrink Wrapping

The `shrink` function's prologue is placed after the `tbz` so the fast path has no frame; with `-enable-shrink-wrap=false` it is back in the entry block. Both outputs are on [Shrink Wrapping](#shrink-wrap).

## Reproducing

```text
llc -O2 -mtriple=aarch64-linux-gnu frame.ll -o -
llc -O2 -mtriple=aarch64-linux-gnu -stop-before=prolog-epilog frame.ll -o before.mir
llc -O2 -mtriple=aarch64-linux-gnu -stop-after=prolog-epilog frame.ll -o after.mir
llc -O2 -mtriple=aarch64-linux-gnu -frame-pointer=all frame.ll -o -
llc -O2 -mtriple=aarch64-linux-gnu -enable-shrink-wrap=false frame.ll -o -
```

The register allocation that chose `x19` for the value kept across the call is traced in the regalloc wiki's [AArch64 walkthroughs](../regalloc-wiki/regalloc-wiki.html#aarch64-walkthroughs); the stack-argument side of calls is on the calling conventions [walkthroughs](../callconv-wiki/callconv-wiki.html#aarch64-walkthroughs).