# Shrink Wrapping

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/ShrinkWrap.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ShrinkWrap.cpp)
- [llvm/lib/CodeGen/PrologEpilogInserter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp)
- [llvm/include/llvm/CodeGen/TargetFrameLowering.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h)

</details>
By default the prologue goes in the entry block and the epilogue in every return block, so even a fast path that never touches the stack pays for the frame. Shrink wrapping (`-shrink-wrap`, run just before PEI) moves the save point down and the restore point up, to the smallest region that contains every use of callee-saved registers and stack objects.

## Purpose and Scope

What the pass computes, how PEI uses it, and what a target must provide. The PEI side is on [The PEI Pass](#pei-pass).

## What It Computes

```mermaid
flowchart LR
    A["find blocks that use CSRs or frame indices<br/>(useOrDefCSROrFI)"] --> B["Save = common dominator of those blocks"]
    B --> C["Restore = common post-dominator"]
    C --> D["move out of loops; ask target canUseAsPrologue / canUseAsEpilogue"]
    D --> E["MFI.setSavePoints / setRestorePoints"]
```

| Function | Line | Job |
| --- | --- | --- |
| `useOrDefCSROrFI` | 304 | Does an instruction need the frame (CSR use, frame index, SP use)? |
| `postShrinkWrapping` | 584 | Second chance to move the points when the first attempt fails |
| `updateSaveRestorePoints` | 701 | Fold a new user block into the current points |
| `performShrinkWrapping` | 836 | Walk blocks in RPO and build the points |
| `ShrinkWrapImpl::run` | 945 | Driver; gives up on irreducible CFGs |
| `isShrinkWrapEnabled` | 1039 | Command line, target hook, Windows CFI and sanitizers |

The result is just two blocks stored in `MachineFrameInfo`:

```cpp
  SaveRestorePoints SavePoints({{Save, {}}});
  SaveRestorePoints RestorePoints({{Restore, {}}});

  MFI.setSavePoints(SavePoints);
  MFI.setRestorePoints(RestorePoints);
```

PEI's `calculateSaveRestoreBlocks` then uses them instead of the entry and return blocks (only one save and one restore point are supported).

**Sources:** [llvm/lib/CodeGen/ShrinkWrap.cpp:304](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ShrinkWrap.cpp#L304), [llvm/lib/CodeGen/ShrinkWrap.cpp:584](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ShrinkWrap.cpp#L584), [llvm/lib/CodeGen/ShrinkWrap.cpp:701](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ShrinkWrap.cpp#L701), [llvm/lib/CodeGen/ShrinkWrap.cpp:836](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ShrinkWrap.cpp#L836), [llvm/lib/CodeGen/ShrinkWrap.cpp:945-996](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ShrinkWrap.cpp#L945-L996), [llvm/lib/CodeGen/PrologEpilogInserter.cpp:411-433](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp#L411-L433)

## When It Runs

```cpp
  switch (EnableShrinkWrapOpt) {
  case cl::boolOrDefault::BOU_UNSET:
    return TFI->enableShrinkWrapping(MF) &&
           // Windows with CFI has some limitations that make it impossible
           // to use shrink-wrapping.
           !MF.getTarget().getMCAsmInfo().usesWindowsCFI() &&
           ...
  case cl::boolOrDefault::BOU_TRUE:
    return true;
  case cl::boolOrDefault::BOU_FALSE:
    return false;
  }
```

So a target opts in with `enableShrinkWrapping` (default `false`, `TargetFrameLowering.h:194`), and `-enable-shrink-wrap=true/false` (option at line 99) overrides it. Sanitizer builds turn it off.

**Sources:** [llvm/lib/CodeGen/ShrinkWrap.cpp:99](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ShrinkWrap.cpp#L99), [llvm/lib/CodeGen/ShrinkWrap.cpp:1039-1066](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ShrinkWrap.cpp#L1039-L1066), [llvm/include/llvm/CodeGen/TargetFrameLowering.h:194-196](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h#L194-L196)

## Example

```llvm
define i64 @shrink(i64 %a, i1 %c) {
entry:
  br i1 %c, label %slow, label %fast
fast:
  ret i64 %a
slow:
  %r = call i64 @h(i64 %a)
  %s = add i64 %r, %a
  ret i64 %s
}
```

`llc -O2 -mtriple=aarch64-linux-gnu` (shrink wrapping on, the AArch64 default):

```asm
shrink:                                 // @shrink
	.cfi_startproc
	tbz	w1, #0, .LBB4_2
	stp	x30, x19, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w19, -8
	.cfi_offset w30, -16
	mov	x19, x0
	bl	h
	add	x0, x0, x19
	ldp	x30, x19, [sp], #16             // 16-byte Folded Reload
.LBB4_2:                                // %common.ret
	ret
```

With `-enable-shrink-wrap=false`:

```asm
shrink:                                 // @shrink
	.cfi_startproc
	stp	x30, x19, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w19, -8
	.cfi_offset w30, -16
	tbz	w1, #0, .LBB4_2
	mov	x19, x0
	bl	h
	add	x0, x0, x19
.LBB4_2:                                // %common.ret
	ldp	x30, x19, [sp], #16             // 16-byte Folded Reload
	ret
```

With shrink wrapping, the fast path (`tbz` taken) runs two instructions and never touches memory.

## Target Requirements

- `enableShrinkWrapping` returns `true`.
- `emitPrologue`/`emitEpilogue` must work in any block, not just entry/return (for example, they must not assume no live registers).
- `canUseAsPrologue`/`canUseAsEpilogue` (default `true`) must reject blocks where the prologue/epilogue would clobber a live register, if it needs a scratch register.
- CFI must be correct at both points; AArch64 enables the CFI fixup pass (`setCFIFixup(true)`) so unwind info stays valid on paths that skip the prologue (see [CFI](#cfi)).