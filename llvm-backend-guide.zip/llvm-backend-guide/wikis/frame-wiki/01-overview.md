# Frame Lowering Overview

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/PrologEpilogInserter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp)
- [llvm/include/llvm/CodeGen/TargetFrameLowering.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h)
- [llvm/include/llvm/CodeGen/MachineFrameInfo.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/MachineFrameInfo.h)
- [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp)

</details>
A function's stack frame holds everything that does not fit in registers: incoming stack arguments, callee-saved registers, spill slots, local variables (`alloca`), and the outgoing argument area for calls. During most of code generation these are abstract **frame indices** in `MachineFrameInfo`. After register allocation, the prologue/epilogue insertion pass (PEI) gives every object an offset, asks the target to emit the prologue and epilogue, and rewrites every frame index into a real register plus offset.

## Purpose and Scope

This wiki explains how a backend builds stack frames, using AArch64 as the real example and a made-up "Toy" target for minimal code. For the place of frame lowering in a whole backend see the [bring-up wiki](../bringup-wiki/bringup-wiki.html#frame-lowering).

## Who Builds the Frame

```mermaid
flowchart LR
    ISEL["Instruction selection<br/>CreateFixedObject (stack args)<br/>CreateStackObject (allocas)"] --> RA["Register allocation<br/>CreateSpillStackObject"]
    RA --> SW["ShrinkWrap<br/>(save/restore points)"]
    SW --> PEI["PEI (prolog-epilog)<br/>layout, prologue, epilogue,<br/>frame index elimination"]
    PEI --> MC["AsmPrinter: CFI directives"]
```

| Stage | Adds to the frame | Page |
| --- | --- | --- |
| Call lowering | Fixed objects for incoming stack arguments, outgoing area size | [calling conventions wiki](../callconv-wiki/callconv-wiki.html#formal-arguments) |
| Instruction selection | Stack objects for `alloca`, variable-sized objects | [MachineFrameInfo](#frame-info) |
| Register allocation | Spill slots | [regalloc spilling](../regalloc-wiki/regalloc-wiki.html#spilling-splitting) |
| Shrink wrapping | Where the prologue and epilogue go | [Shrink Wrapping](#shrink-wrap) |
| PEI | Callee-saved slots, offsets, prologue/epilogue, real addresses | [The PEI Pass](#pei-pass) |

In the pipeline (`llc -O2 -debug-pass=Structure`, AArch64): `... -greedy -virtregrewriter ... -shrink-wrap -prolog-epilog -machine-latecleanup ...`.

**Sources:** [llvm/lib/CodeGen/PrologEpilogInserter.cpp:211-283](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp#L211-L283)

## AArch64 Frame Shapes

Real output from `llc -O2 -mtriple=aarch64-linux-gnu`:

| Function | Frame |
| --- | --- |
| Leaf, no spills | None: `mul x0, x0, x1` / `ret` |
| One call, one value kept | `stp x30, x19, [sp, #-16]!` ... `ldp x30, x19, [sp], #16` |
| 70000-byte `alloca` | `stp x29, x30` then `sub sp, sp, #17, lsl #12` and `sub sp, sp, #368` |
| Variable-sized `alloca` | Frame pointer: `mov x29, sp` ... `mov sp, x29` |
| Call only on a slow path | Prologue moved after the branch (shrink wrapping) |

The [walkthroughs](#aarch64-walkthroughs) show each in full with the MIR before and after PEI.

## Pages

1. [MachineFrameInfo](#frame-info)
2. [TargetFrameLowering Hooks](#tfl-hooks)
3. [The PEI Pass](#pei-pass)
4. [Callee-Saved Registers and Stack Layout](#callee-saves)
5. [Frame Index Elimination and the Register Scavenger](#frame-index)
6. [Shrink Wrapping](#shrink-wrap)
7. [CFI and Unwind Information](#cfi)
8. [Custom Backend Guide](#custom-backend)
9. [AArch64 Walkthroughs](#aarch64-walkthroughs)
10. [Tooling and Glossary](#tooling-glossary)