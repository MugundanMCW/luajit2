# Tooling and Glossary

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/PrologEpilogInserter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp)
- [llvm/lib/CodeGen/ShrinkWrap.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ShrinkWrap.cpp)

</details>
Commands for inspecting frame lowering, and the terms used in this wiki. General `llc` options are on the [bring-up tooling page](../bringup-wiki/bringup-wiki.html#tooling-glossary).

## Purpose and Scope

All output in this wiki comes from an LLVM 24.0.0git release `llc` (no assertions) at commit `a2171756`.

## Commands

| Command | Shows |
| --- | --- |
| `llc ... -stop-before=prolog-epilog` | Frame indices, call-frame pseudos, empty prologue; `frameInfo:` and `stack:` sections |
| `llc ... -stop-after=prolog-epilog` | Prologue/epilogue, CFI pseudos, final `stackSize` and object offsets |
| `llc ... -stop-before=shrink-wrap` / `-stop-after=shrink-wrap` | `savePoint`/`restorePoint` in `frameInfo:` |
| `llc ... -enable-shrink-wrap=false` | Frame without shrink wrapping |
| `llc ... -frame-pointer=all` (or `none`, `non-leaf`) | Force or omit the frame pointer |
| `llc ... -verify-machineinstrs` | Machine verifier after each pass |
| `llc ... -debug-only=prolog-epilog,shrink-wrap` | Pass debug output (assertions build only) |

The pass names come from `#define DEBUG_TYPE "prolog-epilog"` and `#define DEBUG_TYPE "shrink-wrap"`.

**Sources:** [llvm/lib/CodeGen/PrologEpilogInserter.cpp:69](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp#L69), [llvm/lib/CodeGen/ShrinkWrap.cpp:91](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/ShrinkWrap.cpp#L91)

## Glossary

| Term | Meaning |
| --- | --- |
| Frame index | Abstract stack slot number; negative for fixed objects |
| Fixed object | Stack object at a known offset from the incoming SP (incoming arguments) |
| `MachineFrameInfo` | Per-function table of stack objects and frame flags |
| PEI | Prologue/epilogue insertion pass (`prolog-epilog`) |
| Prologue / epilogue | Code that builds / removes the frame |
| Callee-saved register (CSR) | Register a function must restore before returning |
| Frame pointer (FP) | Register (`x29` on AArch64) pointing to a fixed place in the frame |
| Frame record | Saved FP and LR pair, forming the frame-pointer chain |
| Base pointer | Third base register used with both realignment and dynamic allocas |
| Reserved call frame | Outgoing argument area allocated once in the prologue |
| Call-frame pseudos | `ADJCALLSTACKDOWN` / `ADJCALLSTACKUP` |
| `eliminateFrameIndex` | Replaces a frame-index operand with base register + offset |
| Register scavenger | Finds a free physical register after allocation |
| Emergency spill slot | Slot reserved so the scavenger can always free a register |
| Shrink wrapping | Moving prologue/epilogue to the smallest region that needs them |
| CFA | Canonical frame address, the reference point for unwinding |
| CFI | `.cfi_*` directives describing the CFA and saved registers |
| Red zone | Area below SP a leaf function may use without adjusting SP (`canUseRedZone`) |