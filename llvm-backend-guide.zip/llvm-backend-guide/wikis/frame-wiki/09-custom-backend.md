# Custom Backend Guide and Checklist

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/CodeGen/TargetFrameLowering.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetFrameLowering.h)
- [llvm/lib/CodeGen/PrologEpilogInserter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp)

</details>
Frame lowering for a new target is best built in stages: fixed frames first, then callee-saved registers, then a frame pointer, then large frames and dynamic allocation, then shrink wrapping and CFI. Each stage has a small test. All code here is for the made-up "Toy" target and is **illustrative, not LLVM source**.

## Purpose and Scope

The order of work and a checklist. The minimal `ToyFrameLowering` and `eliminateFrameIndex` are on the [bring-up frame page](../bringup-wiki/bringup-wiki.html#frame-lowering); the hooks are described on [TargetFrameLowering Hooks](#tfl-hooks).

## Stages

| Stage | Write | Test |
| --- | --- | --- |
| 1. Fixed frame | Constructor, `emitPrologue`/`emitEpilogue` (one SP add/sub), `hasFPImpl` returning `false`, `eliminateFrameIndex` for small offsets, `eliminateCallFramePseudoInstr` that erases | A function with a local array compiles; `stackSize` in MIR matches the `sub sp` |
| 2. Callee saves | `storeRegToStackSlot`/`loadRegFromStackSlot` in `ToyInstrInfo` (PEI uses them through the default `spillCalleeSavedRegister`) | A value live across a call: saved and restored around the body |
| 3. Frame pointer | `hasFPImpl` true for `hasVarSizedObjects()` and `DisableFramePointerElim`; set up FP in the prologue, restore SP from FP in the epilogue; reserve FP in `getReservedRegs` | `-frame-pointer=all`; a dynamic `alloca` |
| 4. Non-reserved call frame | `hasReservedCallFrame` false with variable-sized objects; `eliminateCallFramePseudoInstr` emits SP adjustments | Call inside a function with a dynamic `alloca` |
| 5. Large frames | `requiresRegisterScavenging`, scratch register in `eliminateFrameIndex`, emergency slot in `processFunctionBeforeFrameFinalized` | 100 KB `alloca` |
| 6. Shrink wrapping | `enableShrinkWrapping`, check `canUseAsPrologue` | Early-return function as on [Shrink Wrapping](#shrink-wrap) |
| 7. CFI | `CFI_INSTRUCTION`s in the prologue | `.cfi_*` directives present; unwinding works in a debugger |

## Prologue With Callee Saves and FP (Illustrative)

**Illustrative, not LLVM source.**

```cpp
void ToyFrameLowering::emitPrologue(MachineFunction &MF,
                                    MachineBasicBlock &MBB) const {
  MachineFrameInfo &MFI = MF.getFrameInfo();
  const auto &TII = *MF.getSubtarget<ToySubtarget>().getInstrInfo();
  auto MBBI = MBB.begin();
  DebugLoc DL;
  uint64_t Size = MFI.getStackSize();

  // PEI already inserted the callee-saved stores (FrameSetup flag) at the
  // top of the block; this sub must come before them, so insert at begin().
  BuildMI(MBB, MBBI, DL, TII.get(Toy::ADDI), Toy::SP)
      .addReg(Toy::SP).addImm(-(int64_t)Size)
      .setMIFlag(MachineInstr::FrameSetup);
  unsigned CFI = MF.addFrameInst(
      MCCFIInstruction::cfiDefCfaOffset(nullptr, Size));
  BuildMI(MBB, MBBI, DL, TII.get(TargetOpcode::CFI_INSTRUCTION))
      .addCFIIndex(CFI).setMIFlag(MachineInstr::FrameSetup);

  // Skip the callee-saved stores, then set up FP if needed.
  while (MBBI != MBB.end() && MBBI->getFlag(MachineInstr::FrameSetup))
    ++MBBI;
  if (hasFP(MF))
    BuildMI(MBB, MBBI, DL, TII.get(Toy::ADDI), Toy::R11)
        .addReg(Toy::SP).addImm(0)
        .setMIFlag(MachineInstr::FrameSetup);
}
```

Callee-saved slots get their offsets from `calculateFrameObjectOffsets`, so the stores PEI inserted address them through frame indices that `eliminateFrameIndex` resolves later; the prologue does not need to know the offsets.

**Sources:** [llvm/lib/CodeGen/PrologEpilogInserter.cpp:211-283](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp#L211-L283), [llvm/lib/CodeGen/PrologEpilogInserter.cpp:618-650](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp#L618-L650)

## Checklist

- [ ] Stack alignment in the constructor equals the data layout `S` value
- [ ] `getStackSize()` is used, never recomputed, in `emitPrologue`/`emitEpilogue`
- [ ] Prologue and epilogue instructions carry `FrameSetup`/`FrameDestroy`
- [ ] Epilogue is inserted before the first terminator, including `TCRETURN` tail calls
- [ ] `eliminateCallFramePseudoInstr` is overridden if `ADJCALLSTACKDOWN/UP` exist
- [ ] `getFrameRegister` agrees with `hasFP`
- [ ] FP (and base pointer, if any) are reserved when used
- [ ] Offsets out of immediate range are handled, or asserted
- [ ] `-verify-machineinstrs` passes after `prolog-epilog`
- [ ] MIR before/after `prolog-epilog` compared for each test (see [Tooling](#tooling-glossary))