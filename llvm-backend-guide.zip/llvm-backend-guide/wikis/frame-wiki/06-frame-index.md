# Frame Index Elimination and the Register Scavenger

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp)
- [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp)
- [llvm/lib/CodeGen/RegisterScavenging.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegisterScavenging.cpp)
- [llvm/include/llvm/CodeGen/RegisterScavenging.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/RegisterScavenging.h)

</details>
After PEI has laid out the frame, every instruction operand that names a frame index (`%stack.0`, `%fixed-stack.1`) must become a real base register plus an offset. PEI calls `TargetRegisterInfo::eliminateFrameIndex` once per such operand. If the offset does not fit the instruction's immediate field, the target must build the address in a scratch register; because register allocation is over, that register comes from the **register scavenger**.

## Purpose and Scope

What `eliminateFrameIndex` must do, how AArch64 does it, and when the scavenger is needed. The PEI step that calls it is on [The PEI Pass](#pei-pass). The register allocator's own rewriting of virtual registers (before PEI) is on the regalloc [rewriting page](../regalloc-wiki/regalloc-wiki.html#rewriting-post-ra).

## The Hook

```cpp
bool AArch64RegisterInfo::eliminateFrameIndex(MachineBasicBlock::iterator II,
                                              int SPAdj, unsigned FIOperandNum,
                                              RegScavenger *RS) const {
```

| Parameter | Meaning |
| --- | --- |
| `II` | The instruction |
| `SPAdj` | SP adjustment in effect here (non-zero only between un-eliminated call-frame pseudos) |
| `FIOperandNum` | Index of the frame-index operand |
| `RS` | Scavenger, if `requiresRegisterScavenging` returned true |
| return value | `true` if the instruction was erased |

**Sources:** [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:978-980](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L978-L980)

## AArch64's Steps

```mermaid
flowchart TD
    A["frame index FI"] --> B["resolveFrameIndexReference:<br/>choose FP or SP (or base pointer), compute StackOffset"]
    B --> C["rewriteAArch64FrameIndex:<br/>fold offset into the immediate if legal"]
    C -->|fits| D["done"]
    C -->|does not fit| E["create virtual scratch register,<br/>emitFrameOffset base+offset into it"]
    E --> F["scavengeFrameVirtualRegs<br/>gives it a physical register later"]
```

```cpp
  } else {
    Offset = TFI->resolveFrameIndexReference(
        MF, FrameIndex, FrameReg, /*PreferFP=*/false, /*ForSimm=*/true);
  }

  // Modify MI as necessary to handle as much of 'Offset' as possible
  if (rewriteAArch64FrameIndex(MI, FIOperandNum, FrameReg, Offset, TII))
    return true;

  assert((!RS || !RS->isScavengingFrameIndex(FrameIndex)) &&
         "Emergency spill slot is out of reach");
```

Before that, special cases are handled: `STACKMAP`/`PATCHPOINT`/`STATEPOINT` (operand becomes register + immediate directly), `LOCAL_ESCAPE`, and memory-tagging instructions. `resolveFrameIndexReference` (in `AArch64FrameLowering.cpp`, line 1372, with the work in `resolveFrameOffsetReference` at 1383) decides whether to address from SP or FP: SP when the offset is small and SP is stable, FP when there are variable-sized objects.

**Sources:** [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:995-1060](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L995-L1060), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:1372-1383](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L1372-L1383)

## Example

In the `bigframe` function (one 70000-byte `alloca` passed to a call), before PEI the address is a frame index:

```text
    $x0 = ADDXri %stack.0.buf, 0, 0
```

After PEI the buffer is at the bottom of the frame, so the index became `$sp` with offset 0:

```text
    $x0 = ADDXri $sp, 0, 0
```

The 70000-byte SP adjustment itself does not fit one `add`/`sub` immediate (12 bits, optionally shifted by 12), so the prologue splits it into `sub sp, sp, #17, lsl #12` (69632) and `sub sp, sp, #368`.

## The Register Scavenger

`RegScavenger` (class at `RegisterScavenging.h:35`) tracks which physical registers are free at a point after allocation. A target that may need scratch registers during elimination:

1. Returns `true` from `requiresRegisterScavenging` (AArch64: `AArch64RegisterInfo.cpp:758`) and usually `requiresFrameIndexScavenging` (787), so PEI creates the scavenger and runs `scavengeFrameVirtualRegs` afterwards.
2. In `eliminateFrameIndex`, creates a *virtual* register for the scratch value, as AArch64 does with `createVirtualRegister(&AArch64::GPR64RegClass)`.
3. Reserves an emergency spill slot in `processFunctionBeforeFrameFinalized` with `RS->addScavengingFrameIndex(FI)` (`RegisterScavenging.h:113`) when a frame is large, so the scavenger can spill a register if none is free.

| Function | Line in `RegisterScavenging.cpp` | Job |
| --- | --- | --- |
| `RegScavenger::spill` | 233 | Save a register to the emergency slot |
| `RegScavenger::scavengeRegisterBackwards` | 306 | Find a free register of a class, walking backwards |
| `scavengeFrameVirtualRegsInBlock` | 401 | Replace virtual registers in one block |
| `llvm::scavengeFrameVirtualRegs` | 473 | Do it for the whole function |

**Sources:** [llvm/include/llvm/CodeGen/RegisterScavenging.h:35](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/RegisterScavenging.h#L35), [llvm/include/llvm/CodeGen/RegisterScavenging.h:113](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/RegisterScavenging.h#L113), [llvm/lib/CodeGen/RegisterScavenging.cpp:233-473](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/RegisterScavenging.cpp#L233-L473), [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:758-787](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L758-L787), [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:1031-1045](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L1031-L1045)

## For a New Target

Start with frames small enough that every offset fits (assert on overflow, as the Toy example on the [bring-up frame page](../bringup-wiki/bringup-wiki.html#frame-lowering) does). Then add: `requiresRegisterScavenging` and `requiresFrameIndexScavenging` returning `true`, a virtual scratch register plus a "load immediate + add" sequence for large offsets, and an emergency slot when the frame size estimate exceeds the immediate range.