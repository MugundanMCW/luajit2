# Callee-Saved Registers and Stack Layout

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/PrologEpilogInserter.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp)
- [llvm/lib/CodeGen/TargetFrameLoweringImpl.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/TargetFrameLoweringImpl.cpp)
- [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp)

</details>
A callee-saved register must hold the same value on return as on entry. If the register allocator used one, the function has to save it in the prologue and restore it in the epilogue. PEI decides which registers need saving, gives each a stack slot, and inserts the saves and restores, with three target hooks that can each take over one part.

## Purpose and Scope

The three steps (decide, assign slots, emit code), the defaults, and how AArch64 pairs saves into `stp`/`ldp`. Where the callee-saved list comes from is on the calling conventions wiki's [TableGen page](../callconv-wiki/callconv-wiki.html#cc-td); how the allocator chooses to use them is on the regalloc [registers page](../regalloc-wiki/regalloc-wiki.html#registers-basics).

## Three Steps

```mermaid
flowchart LR
    D["determineCalleeSaves<br/>which registers"] --> A["assignCalleeSavedSpillSlots<br/>which slots"]
    A --> S["spillCalleeSavedRegisters / restoreCalleeSavedRegisters<br/>which instructions"]
```

| Step | Default | AArch64 (`AArch64FrameLowering.cpp`) |
| --- | --- | --- |
| Decide | `TargetFrameLowering::determineCalleeSaves`: every callee-saved register that is modified in the function | 2521: calls the default, then adds LR/FP when a frame record is needed, pairs registers, may add one extra register for the scavenger |
| Slots | PEI's static `assignCalleeSavedSpillSlots` (`PrologEpilogInserter.cpp:445`) creates one spill slot per register, unless the target hook returns `true` | 2800: assigns slots so pairs are adjacent |
| Emit | `insertCSRSaves`/`insertCSRRestores` → per-register `spillCalleeSavedRegister` → `storeRegToStackSlot` | 1975 / 2194: one `stp`/`ldp` per pair |

AArch64's override starts by calling the generic version:

```cpp
void AArch64FrameLowering::determineCalleeSaves(MachineFunction &MF,
                                                BitVector &SavedRegs,
                                                RegScavenger *RS) const {
  // All calls are tail calls in GHC calling conv, and functions have no
  // prologue/epilogue.
  if (MF.getFunction().getCallingConv() == CallingConv::GHC)
    return;
  ...
  TargetFrameLowering::determineCalleeSaves(MF, SavedRegs, RS);
```

**Sources:** [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:2521-2545](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L2521-L2545), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:1975](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L1975), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:2194](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L2194), [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:2800](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L2800), [llvm/lib/CodeGen/PrologEpilogInserter.cpp:445](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp#L445), [llvm/lib/CodeGen/TargetFrameLoweringImpl.cpp:211-240](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/TargetFrameLoweringImpl.cpp#L211-L240)

## AArch64 Pairing

AArch64 can store two 64-bit registers with one `stp`, and the pre-indexed form also moves SP. So instead of the default one-store-per-register, `spillCalleeSavedRegisters` groups the saved registers into pairs and emits one store per pair. `producePairRegisters` (line 454) decides whether pairing is allowed for the function.

Real output (`llc -O2 -mtriple=aarch64-linux-gnu`), `withcall`, which keeps one value (`x19`) live across a call:

```asm
	stp	x30, x19, [sp, #-16]!           // 16-byte Folded Spill
	...
	ldp	x30, x19, [sp], #16             // 16-byte Folded Reload
```

The MIR after PEI shows the two slots behind that one instruction:

```text
    early-clobber $sp = frame-setup STPXpre killed $lr, killed $x19, $sp, -2 :: (store (s64) into %stack.1), (store (s64) into %stack.0)
    ...
    early-clobber $sp, $lr, $x19 = frame-destroy LDPXpost $sp, 2 :: (load (s64) from %stack.1), (load (s64) from %stack.0)
```

`%stack.0` (`x19`, offset −8) and `%stack.1` (`lr`, offset −16) are the two callee-saved slots; the `-2` is the pre-decrement in 8-byte units.

**Sources:** [llvm/lib/Target/AArch64/AArch64FrameLowering.cpp:454](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64FrameLowering.cpp#L454)

## With a Frame Pointer

With `-frame-pointer=all`, `x29` and `x30` form the frame record and are always the first pair; the remaining callee-saved register is stored alone:

```asm
withcall:                               // @withcall
	.cfi_startproc
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	str	x19, [sp, #16]                  // 8-byte Spill
	mov	x29, sp
	...
	ldr	x19, [sp, #16]                  // 8-byte Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	ret
```

The frame grows to 32 bytes because AArch64 keeps SP 16-byte aligned; the odd register gets a 16-byte area of its own.

## Layout Order

`calculateFrameObjectOffsets` places, from the incoming SP downwards: fixed objects (incoming arguments are above SP), callee-saved slots, the local block, protected objects (stack protector), the remaining locals and spill slots, and finally the reserved outgoing call frame at the bottom (see [The PEI Pass](#pei-pass)). On AArch64 this means callee-saved registers sit right below the incoming SP, which is why the prologue can combine the save and the SP decrement.

**Sources:** [llvm/lib/CodeGen/PrologEpilogInserter.cpp:854-1158](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/PrologEpilogInserter.cpp#L854-L1158)