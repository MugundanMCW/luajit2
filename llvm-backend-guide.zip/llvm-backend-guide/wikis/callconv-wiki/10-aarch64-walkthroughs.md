# AArch64 Walkthroughs

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64CallingConvention.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td)
- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)

</details>
Four small functions compiled with the real `llc` (LLVM 24.0.0git release build at `a2171756`), each traced back to the rules and hooks on the earlier pages. All commands use `-O2 -mtriple=aarch64-linux-gnu`; MIR is from `-stop-after=finalize-isel`.

## Purpose and Scope

Concrete evidence for each rule: incoming arguments, an outgoing call with stack arguments, mixed integer and floating-point arguments, and a tail call. Varargs, `sret` and `byval` output is on [Varargs, byval, sret](#special-args).

## 1. Ten Incoming Arguments

```llvm
define i64 @many(i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7, i64 %a8, i64 %a9) {
  %s = add i64 %a0, %a9
  %t = add i64 %s, %a8
  ret i64 %t
}
```

```asm
many:                                   // @many
	.cfi_startproc
	ldp	x9, x8, [sp]
	add	x8, x0, x8
	add	x0, x8, x9
	ret
```

| Argument | Rule | Location |
| --- | --- | --- |
| `%a0`–`%a7` | `CCIfType<[i64], CCAssignToReg<[X0, ..., X7]>>` | `x0`–`x7` |
| `%a8` | `CCIfType<[i64, ...], CCAssignToStack<8, 8>>` | `[sp]` (offset 0) |
| `%a9` | same | `[sp, #8]` |

`LowerFormalArguments` made two fixed frame objects at offsets 0 and 8 and loaded them; the load/store optimizer later merged the two loads into one `ldp`. The function has no frame of its own, so the fixed objects are addressed directly from `sp` at entry.

**Sources:** [llvm/lib/Target/AArch64/AArch64CallingConvention.td:106](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L106), [llvm/lib/Target/AArch64/AArch64CallingConvention.td:119-120](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L119-L120), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9487-9552](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9487-L9552)

## 2. An Outgoing Call with Stack Arguments

```llvm
declare i64 @callee(i64, i64, i64, i64, i64, i64, i64, i64, i64, i64)
define i64 @caller(i64 %x) {
  %r = call i64 @callee(i64 %x, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7, i64 8, i64 9)
  %s = add i64 %r, 1
  ret i64 %s
}
```

MIR after selection (abridged in the middle):

```text
    %0:gpr64 = COPY $x0
    ADJCALLSTACKDOWN 16, 0, implicit-def dead $sp, implicit $sp
    %1:gpr64sp = COPY $sp
    %2:gpr32 = MOVi32imm 9
    %3:gpr64 = SUBREG_TO_REG killed %2, %subreg.sub_32
    STRXui killed %3, %1, 1 :: (store (s64) into stack + 8)
    %4:gpr32 = MOVi32imm 8
    %5:gpr64 = SUBREG_TO_REG killed %4, %subreg.sub_32
    STRXui killed %5, %1, 0 :: (store (s64) into stack)
    ...
    $x0 = COPY %0
    $x1 = COPY %7
    ...
    $x7 = COPY %19
    BL @callee, csr_aarch64_aapcs, implicit-def dead $lr, implicit $sp, implicit $x0, implicit $x1, implicit $x2, implicit $x3, implicit $x4, implicit $x5, implicit $x6, implicit $x7, implicit-def $sp, implicit-def $x0
    ADJCALLSTACKUP 16, 0, implicit-def dead $sp, implicit $sp
    %20:gpr64sp = COPY $x0
    %21:gpr64sp = ADDXri %20, 1, 0
    $x0 = COPY %21
    RET_ReallyLR implicit $x0
```

| MIR | Comes from |
| --- | --- |
| `ADJCALLSTACKDOWN 16` / `ADJCALLSTACKUP 16` | `CALLSEQ_START` / `CALLSEQ_END` with `CCInfo.getStackSize()` = 16 |
| Two `STRXui` to `stack` and `stack + 8` | Stack locations for arguments 9 and 10, `MemOpChains` |
| `$x0 = COPY ...` ... `$x7 = COPY ...` | `RegsToPass` → glued `CopyToReg` |
| `csr_aarch64_aapcs` on `BL` | Register mask from `getCallPreservedMask` |
| `implicit $x0` ... `implicit $x7` | Argument register operands on the call node |
| `implicit-def $x0` | The result register, from `RetCC_AArch64_AAPCS` |
| `%20 = COPY $x0` | `LowerCallResult` |

Final assembly:

```asm
caller:                                 // @caller
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -16
	mov	w8, #9                          // =0x9
	mov	w9, #8                          // =0x8
	mov	w1, #1                          // =0x1
	mov	w2, #2                          // =0x2
	mov	w3, #3                          // =0x3
	mov	w4, #4                          // =0x4
	mov	w5, #5                          // =0x5
	mov	w6, #6                          // =0x6
	mov	w7, #7                          // =0x7
	stp	x8, x30, [sp, #8]               // 8-byte Folded Spill
	str	x9, [sp]
	bl	callee
	ldr	x30, [sp, #16]                  // 8-byte Reload
	add	x0, x0, #1
	add	sp, sp, #32
	ret
```

The 16-byte outgoing area sits at the bottom of the 32-byte frame (AArch64 reserves the call frame, so `ADJCALLSTACKDOWN/UP` became no SP change). Frame lowering put the saved `x30` at `[sp, #16]`, right after argument 10 at `[sp, #8]`, and the store of argument 10 merged with the `x30` save into one `stp`. `x0` (`%x`) needed no copy because it was already in place.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10535-10541](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10535-L10541), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:11063-11129](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L11063-L11129)

## 3. Mixed Integer and Floating-Point Arguments

```llvm
define double @mixed(i32 %i, double %d, i8 %c, float %f) {
  %e = sext i8 %c to i32
  %x = add i32 %i, %e
  %y = sitofp i32 %x to double
  %fe = fpext float %f to double
  %z = fadd double %y, %d
  %w = fadd double %z, %fe
  ret double %w
}
```

```asm
mixed:                                  // @mixed
	.cfi_startproc
	add	w8, w0, w1, sxtb
	fcvt	d1, s1
	scvtf	d2, w8
	fadd	d0, d2, d0
	fadd	d0, d0, d1
	ret
```

| Argument | Rule | Location |
| --- | --- | --- |
| `i32 %i` | `CCIfType<[i32], CCAssignToReg<[W0, ...]>>` | `w0` |
| `double %d` | `CCIfType<[f64], CCAssignToReg<[D0, ...]>>` | `d0` |
| `i8 %c` | `CCPromoteToType<i32>`, then the `i32` rule | `w1` |
| `float %f` | `CCIfType<[f32], CCAssignToReg<[S0, ...]>>` | `s1` |
| return `double` | `RetCC_AArch64_AAPCS` `f64` rule | `d0` |

Integer and FP registers are allocated independently, so `%c` takes `w1` even though `%d` came between. `S1` and `D0` are different registers from `CCState`'s point of view (only aliases are marked used), so `%f` gets `s1`.

**Sources:** [llvm/lib/Target/AArch64/AArch64CallingConvention.td:97-110](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L97-L110), [llvm/lib/Target/AArch64/AArch64CallingConvention.td:150](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L150)

## 4. Sibling Call

```text
    %0:gpr64 = COPY $x0
    $x0 = COPY %0
    TCRETURNdi @g, 0, csr_aarch64_aapcs, implicit $sp, implicit $x0
```

```asm
sib:                                    // @sib
	.cfi_startproc
	b	g
```

No `ADJCALLSTACKDOWN`, no result copy, no `RET_ReallyLR`: `LowerCall` returned the `TC_RETURN` node directly, which ends the block. See [Tail Calls](#tail-calls) for the eligibility checks, and the frame wiki's [walkthroughs](../frame-wiki/frame-wiki.html#aarch64-walkthroughs) for how the epilogue is placed before such jumps.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10516-10541](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10516-L10541), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:11091-11105](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L11091-L11105)

## Reproducing

```text
llc -O2 -mtriple=aarch64-linux-gnu args.ll -o -
llc -O2 -mtriple=aarch64-linux-gnu -stop-after=finalize-isel call.ll -o -
```

The SelectionDAG wiki's [AArch64 walkthroughs](../selectiondag-wiki.html#aarch64-walkthroughs) show the same kind of trace for instruction selection, and the MC wiki's [streamers page](../mc-wiki/mc-wiki.html#streamers) shows how the final `bl` and `b` become encoded instructions with relocations.