# LowerFormalArguments

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)
- [llvm/include/llvm/CodeGen/TargetLowering.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetLowering.h)
- [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp)

</details>
`LowerFormalArguments` runs once per function, at the start of DAG building. It receives the function's incoming arguments as a list of legal-typed `ISD::InputArg`s and must return one `SDValue` per entry in `InVals`. Register arguments become `CopyFromReg` nodes from virtual registers tied to live-in physical registers; stack arguments become loads from fixed frame objects.

## Purpose and Scope

The steps of AArch64's `LowerFormalArguments`, and the pattern a new target should copy. Line numbers for `AArch64ISelLowering.cpp` are from the committed file at `a2171756`.

## The Hook

```cpp
  virtual SDValue LowerFormalArguments(
      SDValue /*Chain*/, CallingConv::ID /*CallConv*/, bool /*isVarArg*/,
      const SmallVectorImpl<ISD::InputArg> & /*Ins*/, const SDLoc & /*dl*/,
      SelectionDAG & /*DAG*/, SmallVectorImpl<SDValue> & /*InVals*/) const {
    llvm_unreachable("Not Implemented");
  }
```

It is called from `SelectionDAGISel::LowerArguments`, which builds `Ins` from the IR arguments (splitting `i128` into two `i64`s, setting `sext`/`zext`/`byval` flags) and maps the returned values back to the IR arguments.

**Sources:** [llvm/include/llvm/CodeGen/TargetLowering.h:4893-4898](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetLowering.h#L4893-L4898), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp:11970](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp#L11970)

## Steps in AArch64

```mermaid
flowchart TD
    A["1. CCState + assign a location to every Ins[i]"] --> B{"for each CCValAssign"}
    B -->|byval| BV["fixed object at LocMemOffset, pass its frame index"]
    B -->|register| R["pick reg class, MF.addLiveIn, CopyFromReg, undo extension"]
    B -->|stack| S["CreateFixedObject, extending load"]
    R --> I["InVals.push_back"]
    S --> I
    BV --> I
    I --> V["2. varargs: save remaining registers, record stack offset"]
    V --> F["3. record stack argument size for tail calls"]
```

### 1. Assign locations

```cpp
  // Assign locations to all of the incoming arguments.
  SmallVector<CCValAssign, 16> ArgLocs;
  CCState CCInfo(CallConv, isVarArg, MF, ArgLocs, *DAG.getContext());
  ...
  CCAssignFn *AssignFn = CCAssignFnForCall(CallConv, UseVarArgCC);

  for (unsigned i = 0; i != NumArgs; ++i) {
    MVT ValVT = Ins[i].VT;
    if (Ins[i].isOrigArg()) {
      ...
      // If ActualMVT is i1/i8/i16, we should set LocVT to i8/i8/i16.
      if (ActualMVT == MVT::i1 || ActualMVT == MVT::i8)
        ValVT = MVT::i8;
      else if (ActualMVT == MVT::i16)
        ValVT = MVT::i16;
    }
    bool Res = AssignFn(i, ValVT, ValVT, CCValAssign::Full, Ins[i].Flags,
                        Ins[i].OrigTy, CCInfo);
    assert(!Res && "Call operand has unhandled type");
```

AArch64 runs the loop itself instead of calling `AnalyzeFormalArguments` so that an `i8` passed on the stack is treated as one byte (the stack rule `CCAssignToStack<8, 8>` keeps the slot 8 bytes, but the load is a byte load).

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9314-9372](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9314-L9372)

### 2. Register arguments

For each register location, choose a register class from the location type, make the physical register a live-in of the function (which creates a virtual register), and copy from it:

```cpp
    if (VA.isRegLoc()) {
      // Arguments stored in registers.
      EVT RegVT = VA.getLocVT();
      const TargetRegisterClass *RC;

      if (RegVT == MVT::i32)
        RC = &AArch64::GPR32RegClass;
      else if (RegVT == MVT::i64)
        RC = &AArch64::GPR64RegClass;
      ...
      // Transform the arguments in physical registers into virtual ones.
      Register Reg = MF.addLiveIn(VA.getLocReg(), RC);
      ...
        ArgValue = DAG.getCopyFromReg(Chain, DL, Reg, RegVT);
```

Then `LocInfo` decides the conversion back to the value type. `BCvt` adds a `BITCAST`; `SExt`/`ZExt`/`AExt` need nothing here on AArch64 (the truncation to the IR type is inserted by generic code).

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9405-9486](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9405-L9486)

### 3. Stack arguments

A stack location becomes a fixed frame object: its offset is relative to the stack pointer at the call, which frame lowering later turns into an offset from SP or FP (see the [frame wiki](../frame-wiki/frame-wiki.html#frame-info)).

```cpp
      } else {
        int FI = MFI.CreateFixedObject(ArgSize, ArgOffset + BEAlign, true);

        // Create load nodes to retrieve arguments from the stack.
        FIN = DAG.getFrameIndex(FI, getPointerTy(DAG.getDataLayout()));
        PtrInfo = MachinePointerInfo::getFixedStack(MF, FI);
      }
      ...
      ArgValue = DAG.getExtLoad(ExtType, DL, VA.getLocVT(), Chain, FIN, PtrInfo,
                                MemVT);
```

`ExtType` comes from `LocInfo` (`SExt` → `SEXTLOAD` ...). The last `true` marks the object immutable, which lets later passes treat the load as invariant.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9487-9552](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9487-L9552)

### 4. byval

A `byval` argument is already in the caller's outgoing area, so the callee just creates a fixed object over it and passes its address:

```cpp
    if (Ins[i].Flags.isByVal()) {
      ...
      unsigned FrameIdx =
        MFI.CreateFixedObject(8 * NumRegs, VA.getLocMemOffset(), false);
      SDValue FrameIdxN = DAG.getFrameIndex(FrameIdx, PtrVT);
      InVals.push_back(FrameIdxN);
      continue;
    }
```

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9384-9399](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9384-L9399)

### 5. Varargs and stack size

If the function calls `va_start`, the unused argument registers are spilled (`saveVarArgRegisters`) and the offset of the first variadic stack argument is recorded; see [Varargs, byval, sret](#special-args). Finally the size of the incoming stack argument area is saved, because [tail calls](#tail-calls) may reuse it:

```cpp
  unsigned StackArgSize = CCInfo.getStackSize();
  ...
  FuncInfo->setBytesInStackArgArea(StackArgSize);
```

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9640-9660](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9640-L9660), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9702-9720](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9702-L9720)

## Result

`llc -O2 -mtriple=aarch64-linux-gnu` on `double @mixed(i32 %i, double %d, i8 %c, float %f)` (body: `sext %c`, add to `%i`, convert, add `%d` and `fpext %f`):

```asm
mixed:                                  // @mixed
	.cfi_startproc
	add	w8, w0, w1, sxtb
	fcvt	d1, s1
	scvtf	d2, w8
	fadd	d0, d2, d0
	fadd	d0, d0, d1
	ret
```

`%i` is in `w0`, `%d` in `d0`, `%c` in `w1` (the next free GPR, not `w2`), `%f` in `s1`. The `sxtb` shows that the `i8` arrives with undefined upper bits and the callee extends it.

## Minimal Pattern (Illustrative)

**Illustrative, not LLVM source.** For a target with only `i32` arguments:

```cpp
SDValue ToyTargetLowering::LowerFormalArguments(
    SDValue Chain, CallingConv::ID CC, bool IsVarArg,
    const SmallVectorImpl<ISD::InputArg> &Ins, const SDLoc &DL,
    SelectionDAG &DAG, SmallVectorImpl<SDValue> &InVals) const {
  MachineFunction &MF = DAG.getMachineFunction();
  SmallVector<CCValAssign, 16> Locs;
  CCState CCInfo(CC, IsVarArg, MF, Locs, *DAG.getContext());
  CCInfo.AnalyzeFormalArguments(Ins, CC_Toy);

  for (CCValAssign &VA : Locs) {
    SDValue V;
    if (VA.isRegLoc()) {
      Register VReg = MF.addLiveIn(VA.getLocReg(), &Toy::GPRRegClass);
      V = DAG.getCopyFromReg(Chain, DL, VReg, VA.getLocVT());
    } else {
      int FI = MF.getFrameInfo().CreateFixedObject(4, VA.getLocMemOffset(), true);
      V = DAG.getLoad(VA.getLocVT(), DL, Chain, DAG.getFrameIndex(FI, MVT::i32),
                      MachinePointerInfo::getFixedStack(MF, FI));
    }
    if (VA.getLocInfo() == CCValAssign::SExt)
      V = DAG.getNode(ISD::AssertSext, DL, VA.getLocVT(), V,
                      DAG.getValueType(VA.getValVT()));
    if (VA.getLocInfo() != CCValAssign::Full)
      V = DAG.getNode(ISD::TRUNCATE, DL, VA.getValVT(), V);
    InVals.push_back(V);
  }
  return Chain;
}
```
