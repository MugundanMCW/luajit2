# LowerReturn and CanLowerReturn

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)
- [llvm/include/llvm/CodeGen/TargetLowering.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetLowering.h)
- [llvm/lib/CodeGen/CallingConvLower.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CallingConvLower.cpp)
- [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp)

</details>
`LowerReturn` is called for every `ret` instruction. It copies each return value into the register the `RetCC_*` rules choose, and ends the block with the target's return node. `CanLowerReturn` is asked first: if the return values do not fit in registers, generic code rewrites the function to return through a hidden pointer argument (`sret` demotion), and `LowerReturn` then only sees a `void` return.

## Purpose and Scope

Both hooks as implemented by AArch64, and the minimal version for a new target. Line numbers for `AArch64ISelLowering.cpp` are from the committed file at `a2171756`.

## CanLowerReturn

```cpp
bool AArch64TargetLowering::CanLowerReturn(
    CallingConv::ID CallConv, MachineFunction &MF, bool isVarArg,
    const SmallVectorImpl<ISD::OutputArg> &Outs, LLVMContext &Context,
    const Type *RetTy) const {
  CCAssignFn *RetCC = CCAssignFnForReturn(CallConv);
  SmallVector<CCValAssign, 16> RVLocs;
  CCState CCInfo(CallConv, isVarArg, MF, RVLocs, Context);
  return CCInfo.CheckReturn(Outs, RetCC);
}
```

`CheckReturn` runs the return rules and returns `false` as soon as one value cannot be placed. `RetCC_AArch64_AAPCS` has no stack rules, so anything beyond eight integer or eight FP/vector registers fails, and the function is demoted. The default `TargetLowering::CanLowerReturn` returns `true`, which is only safe if the return rules can place every value the target can return:

```cpp
  virtual bool CanLowerReturn(CallingConv::ID /*CallConv*/,
                              MachineFunction &/*MF*/, bool /*isVarArg*/,
               const SmallVectorImpl<ISD::OutputArg> &/*Outs*/,
               LLVMContext &/*Context*/, const Type *RetTy) const
  {
    // Return true by default to get preexisting behavior.
    return true;
  }
```

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:11172-11180](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L11172-L11180), [llvm/lib/CodeGen/CallingConvLower.cpp:99-109](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CallingConvLower.cpp#L99-L109), [llvm/lib/Target/AArch64/AArch64CallingConvention.td:128-162](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L128-L162), [llvm/include/llvm/CodeGen/TargetLowering.h:5199-5206](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetLowering.h#L5199-L5206)

## LowerReturn

```mermaid
flowchart LR
    A["AnalyzeReturn(Outs, RetCC)"] --> B["for each RVLoc: extend/bitcast, CopyToReg (glued)"]
    B --> C["RetOps: chain, one register operand per return reg"]
    C --> D["sret pointer in X0 (Win64), CSRs via copy"]
    D --> E["AArch64ISD::RET_GLUE"]
```

```cpp
AArch64TargetLowering::LowerReturn(SDValue Chain, CallingConv::ID CallConv,
                                   bool isVarArg,
                                   const SmallVectorImpl<ISD::OutputArg> &Outs,
                                   const SmallVectorImpl<SDValue> &OutVals,
                                   const SDLoc &DL, SelectionDAG &DAG) const {
  ...
  CCAssignFn *RetCC = CCAssignFnForReturn(CallConv);
  SmallVector<CCValAssign, 16> RVLocs;
  CCState CCInfo(CallConv, isVarArg, MF, RVLocs, *DAG.getContext());
  CCInfo.AnalyzeReturn(Outs, RetCC);

  // Copy the result values into the output registers.
  SDValue Glue;
  ...
```

Each copy is glued to the previous one so the copies and the return stay together. Every return register is also added to `RetOps` as a register operand: that makes the register live-out (used by the return instruction), so the copies are not deleted as dead. The function ends with:

```cpp
  RetOps[0] = Chain; // Update chain.

  // Add the glue if we have it.
  if (Glue.getNode())
    RetOps.push_back(Glue);
  ...
  return DAG.getNode(AArch64ISD::RET_GLUE, DL, MVT::Other, RetOps);
```

`RET_GLUE` is matched by the pattern on the `RET_ReallyLR` pseudo, `def RET_ReallyLR : Pseudo<(outs), (ins), [(AArch64retglue)]>`, seen in MIR as `RET_ReallyLR implicit $w0`; it becomes `ret` before emission.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:11182-11200](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L11182-L11200), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:11292-11326](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L11292-L11326), [llvm/lib/Target/AArch64/AArch64InstrInfo.td:895](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.td#L895), [llvm/lib/Target/AArch64/AArch64InstrInfo.td:3758](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64InstrInfo.td#L3758)

## In MIR

`llc -O2 -mtriple=aarch64-linux-gnu -stop-after=finalize-isel` on `i32 @add(i32 %a, i32 %b)`:

```text
    %1:gpr32 = COPY $w1
    %0:gpr32 = COPY $w0
    %2:gpr32 = ADDWrr %0, %1
    $w0 = COPY %2
    RET_ReallyLR implicit $w0
```

`$w0 = COPY %2` is the `CopyToReg` from `LowerReturn`; `implicit $w0` on the return is the register operand added to `RetOps`.

## Minimal Version (Illustrative)

**Illustrative, not LLVM source.**

```cpp
SDValue ToyTargetLowering::LowerReturn(SDValue Chain, CallingConv::ID CC,
    bool IsVarArg, const SmallVectorImpl<ISD::OutputArg> &Outs,
    const SmallVectorImpl<SDValue> &OutVals, const SDLoc &DL,
    SelectionDAG &DAG) const {
  SmallVector<CCValAssign, 4> RVLocs;
  CCState CCInfo(CC, IsVarArg, DAG.getMachineFunction(), RVLocs,
                 *DAG.getContext());
  CCInfo.AnalyzeReturn(Outs, RetCC_Toy);

  SDValue Glue;
  SmallVector<SDValue, 4> RetOps(1, Chain);
  for (unsigned i = 0; i != RVLocs.size(); ++i) {
    CCValAssign &VA = RVLocs[i];
    SDValue V = OutVals[i];
    if (VA.getLocInfo() == CCValAssign::SExt)
      V = DAG.getNode(ISD::SIGN_EXTEND, DL, VA.getLocVT(), V);
    else if (VA.getLocInfo() == CCValAssign::ZExt)
      V = DAG.getNode(ISD::ZERO_EXTEND, DL, VA.getLocVT(), V);
    else if (VA.getLocInfo() == CCValAssign::AExt)
      V = DAG.getNode(ISD::ANY_EXTEND, DL, VA.getLocVT(), V);
    Chain = DAG.getCopyToReg(Chain, DL, VA.getLocReg(), V, Glue);
    Glue = Chain.getValue(1);
    RetOps.push_back(DAG.getRegister(VA.getLocReg(), VA.getLocVT()));
  }
  RetOps[0] = Chain;
  if (Glue.getNode())
    RetOps.push_back(Glue);
  return DAG.getNode(ToyISD::RET, DL, MVT::Other, RetOps);
}

bool ToyTargetLowering::CanLowerReturn(CallingConv::ID CC, MachineFunction &MF,
    bool IsVarArg, const SmallVectorImpl<ISD::OutputArg> &Outs,
    LLVMContext &Ctx, const Type *RetTy) const {
  SmallVector<CCValAssign, 4> RVLocs;
  CCState CCInfo(CC, IsVarArg, MF, RVLocs, Ctx);
  return CCInfo.CheckReturn(Outs, RetCC_Toy);
}
```

With `CanLowerReturn` in place, an `i128` return on a 32-bit Toy (four `i32` parts, only `r0`/`r1` available) is demoted to a hidden `sret` pointer automatically.