# Calling Conventions Overview

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/Target/TargetCallingConv.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetCallingConv.td)
- [llvm/include/llvm/CodeGen/CallingConvLower.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/CallingConvLower.h)
- [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp)
- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)

</details>
A calling convention is the contract between a caller and a callee: which registers or stack slots hold each argument, where the return value goes, which registers the callee must preserve, and who cleans up the stack. In LLVM the placement rules are written once in TableGen, and three `TargetLowering` hooks use them while the SelectionDAG is being built from IR.

## Purpose and Scope

This wiki explains how a backend implements calling conventions, with AArch64 (AAPCS64) as the real example and a made-up "Toy" target for minimal code. It covers the TableGen language, `CCState`, the three lowering hooks, varargs and special arguments, tail calls, a custom-backend guide and real `llc` walkthroughs. For where this fits in a whole backend see the [bring-up wiki](../bringup-wiki/bringup-wiki.html#calling-conventions).

## What a Calling Convention Decides

| Question | Where LLVM answers it |
| --- | --- |
| Which register or stack offset holds argument N? | `CallingConv` record in `<T>CallingConv.td` (`CC_*`) |
| Where does the return value go? | `RetCC_*` record |
| Which registers survive a call? | `CalleeSavedRegs` record → register mask on each call |
| How are small integers extended? | `CCPromoteToType` and the `LocInfo` of each `CCValAssign` |
| Who removes stack arguments? | Target code in `LowerCall` (`CALLSEQ_END` bytes) |
| Can this call be a jump? | `isEligibleForTailCallOptimization` |

## Where Lowering Happens

```mermaid
flowchart TD
    IR["LLVM IR function"] --> SDB["SelectionDAGBuilder"]
    SDB -->|function entry| LA["SelectionDAGISel::LowerArguments"]
    LA --> LFA["Target::LowerFormalArguments"]
    SDB -->|each call| LCT["SelectionDAGBuilder::LowerCallTo"]
    LCT --> TLCT["TargetLowering::LowerCallTo"]
    TLCT --> LC["Target::LowerCall"]
    SDB -->|each ret| VR["SelectionDAGBuilder::visitRet"]
    VR --> LR["Target::LowerReturn"]
    LFA --> CC["CCState + generated CC_* function"]
    LC --> CC
    LR --> CC
```

Generic code splits every IR argument into legal-typed pieces (`ISD::InputArg` / `ISD::OutputArg`, each with flags such as `sext`, `byval`, `sret`) before calling the target. The target only sees legal value types.

| Generic entry point | Line | Calls |
| --- | --- | --- |
| `SelectionDAGBuilder::visitRet` | 2214 | `LowerReturn` |
| `SelectionDAGBuilder::LowerCallTo` | 9202 | `TargetLowering::LowerCallTo` |
| `TargetLowering::LowerCallTo` | 11333-11334 | `LowerCall` |
| `SelectionDAGISel::LowerArguments` | 11970 | `LowerFormalArguments` |

**Sources:** [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp:2214](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp#L2214), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp:9202](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp#L9202), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp:11333-11334](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp#L11333-L11334), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp:11970](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp#L11970)

The DAG-building side of this is described on the SelectionDAG wiki's [DAG construction page](../selectiondag-wiki.html#dag-construction).

## A First Example

`llc -O2 -mtriple=aarch64-linux-gnu` on a function with ten `i64` arguments that returns `a0 + a9 + a8`:

```asm
many:                                   // @many
	.cfi_startproc
	ldp	x9, x8, [sp]
	add	x8, x0, x8
	add	x0, x8, x9
	ret
```

`a0` arrives in `x0`; `a8` and `a9` did not fit in `x0`–`x7`, so they are at `[sp]` and `[sp, #8]` and are loaded with one `ldp`. The result goes back in `x0`. Every piece of that comes from the rules on the next pages.

## Pages

1. [The CallingConv.td Language](#cc-td)
2. [CCState and CCValAssign](#ccstate)
3. [LowerFormalArguments](#formal-arguments)
4. [LowerCall](#lower-call)
5. [LowerReturn and CanLowerReturn](#lower-return)
6. [Varargs, byval, sret, swifterror](#special-args)
7. [Tail Calls and Sibling Calls](#tail-calls)
8. [Custom Backend Guide](#custom-backend)
9. [AArch64 Walkthroughs](#aarch64-walkthroughs)
10. [Tooling and Glossary](#tooling-glossary)