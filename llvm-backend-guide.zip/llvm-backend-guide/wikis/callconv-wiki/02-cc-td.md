# The CallingConv.td Language

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/Target/TargetCallingConv.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetCallingConv.td)
- [llvm/lib/Target/AArch64/AArch64CallingConvention.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td)
- [llvm/lib/Target/AArch64/AArch64CallingConvention.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.cpp)

</details>
A `CallingConv` record is an ordered list of actions. For each value, the generated C++ function tries the actions from top to bottom. Predicate actions (`CCIfType`, `CCIf...`) wrap another action and only apply when their test passes. The first action that assigns a location ends the search. If no action matches, the function returns `true` ("not handled").

## Purpose and Scope

The action classes in `TargetCallingConv.td`, how AArch64 combines them, the `Entry` flag, `CCDelegateTo`, `CCCustom`, and `CalleeSavedRegs`. How the generated function is driven is on [CCState and CCValAssign](#ccstate).

## How a Rule List Is Evaluated

```mermaid
flowchart TD
    V["value: ValVT, LocVT, ArgFlags"] --> A1{"action 1 applies?"}
    A1 -->|"no"| A2{"action 2 applies?"}
    A1 -->|"yes: changes type (Promote/BitConvert)"| A2
    A1 -->|"yes: assigns location"| DONE["CCValAssign added, return false"]
    A2 --> AN["... action N"]
    AN -->|"nothing assigned"| FAIL["return true (unhandled)"]
```

Type-changing actions (`CCPromoteToType`, `CCBitConvertToType`) do not end the search: they change `LocVT` and `LocInfo`, and evaluation continues with the next action using the new type. That is why AArch64 can write `CCIfType<[i1, i8, i16], CCPromoteToType<i32>>` once and then handle all of them with the `i32` rules.

## Action Classes

| Class | Line | Effect |
| --- | --- | --- |
| `CCCustom<"fn">` | 18 | Call a hand-written C++ function |
| `CCIfType<[types], A>` | 30 | Apply `A` if `LocVT` is in the list |
| `CCIf<"cond", A>` | 35 | Apply `A` if the C++ expression is true |
| `CCIfByVal<A>` | 41 | Argument has the `byval` attribute |
| `CCIfSwiftSelf`, `CCIfSwiftAsync`, `CCIfSwiftError` | 51-61 | Swift ABI attributes |
| `CCIfConsecutiveRegs<A>` | 71 | Part of an aggregate split into consecutive registers (HFAs) |
| `CCIfCC<"CC", A>` | 75 | Current calling convention is `CC` |
| `CCIfInReg`, `CCIfNest`, `CCIfSplit`, `CCIfSRet` | 80-92 | Argument flags |
| `CCIfVarArg`, `CCIfNotVarArg` | 95-98 | Function or call is variadic |
| `CCIfArgFixed`, `CCIfArgVarArg` | 101-104 | This particular argument is a fixed or variadic one |
| `CCAssignToReg<[regs]>` | 118 | First free register in the list |
| `CCAssignToRegWithShadow<[regs], [shadows]>` | 131 | Same, but also marks the matching shadow register used |
| `CCAssignToStack<size, align>` | 141 | Next stack slot (size 0 means "size of the type") |
| `CCAssignToStackWithShadow<size, align, [regs]>` | 149 | Stack slot, and mark registers used |
| `CCPassByVal<size, align>` | 169 | Copy a `byval` aggregate to the stack |
| `CCPromoteToType<type>` | 176 | Extend to a wider type (sign/zero/any from the flags) |
| `CCBitConvertToType<type>` | 188 | Reinterpret as another type of the same size |
| `CCPassIndirect<type>` | 200 | Pass a pointer to a copy |
| `CCDelegateTo<CC>` | 206 | Run another `CallingConv`'s rules |
| `CallingConv<[actions]>` | 212 | The record itself |
| `CalleeSavedRegs<(add ...)>` | 235 | Registers a callee must preserve |

**Sources:** [llvm/include/llvm/Target/TargetCallingConv.td:14-235](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/Target/TargetCallingConv.td#L14-L235)

## AArch64's AAPCS Rules

AArch64 keeps the common rules in a `defvar` list and builds several conventions from it. The order matters:

1. Special-purpose arguments first: `nest` in `X15`, `sret` in `X8`, `byval` to the stack, Swift registers, HFA blocks via `CCCustom`.
2. Type normalization: pointers as `i64`, some vectors bit-converted, `i1`/`i8`/`i16` promoted to `i32`.
3. Registers: `W0`–`W7` / `X0`–`X7` for integers, `H`/`S`/`D`/`Q` 0–7 for floating point and vectors, `Z0`–`Z7` and `P0`–`P3` for SVE.
4. Stack, when the registers run out.

```tablegen
  // In AAPCS, an SRet is passed in X8, not X0 like a normal pointer parameter.
  ...
  CCIfSRet<CCIfType<[i64], CCAssignToReg<[X8]>>>,

  // Put ByVal arguments directly on the stack. Minimum size and alignment of a
  // slot is 64-bit.
  CCIfByVal<CCPassByVal<8, 8>>,
  ...
  CCIfConsecutiveRegs<CCCustom<"CC_AArch64_Custom_Block">>,
  ...
  CCIfType<[i1, i8, i16], CCPromoteToType<i32>>,
  CCIfType<[i32], CCAssignToReg<[W0, W1, W2, W3, W4, W5, W6, W7]>>,
  // i128 is split to two i64s, we can't fit half to register X7.
  CCIfType<[i64], CCIfSplit<CCAssignToRegWithShadow<[X0, X2, X4, X6],
                                                    [X0, X1, X3, X5]>>>,
  ...
  CCIfType<[i64], CCAssignToReg<[X0, X1, X2, X3, X4, X5, X6, X7]>>,
  ...
  CCIfType<[f64], CCAssignToReg<[D0, D1, D2, D3, D4, D5, D6, D7]>>,
  ...
  // If more than will fit in registers, pass them on the stack instead.
  CCIfType<[i1, i8, i16, f16, bf16], CCAssignToStack<8, 8>>,
  CCIfType<[i32, f32], CCAssignToStack<8, 8>>,
```

The `i128` rule shows `CCAssignToRegWithShadow`: the first half of an `i128` must go in an even register (`X0`, `X2`, ...), and assigning `X2` also uses up `X1`, so the pair never starts at an odd register.

Integer and floating-point registers are counted separately, because `CCAssignToReg` only looks at the listed registers. A function `(i32, double, i8, float)` gets `w0`, `d0`, `w1`, `s1`; see the [walkthroughs](#aarch64-walkthroughs).

**Sources:** [llvm/lib/Target/AArch64/AArch64CallingConvention.td:30-123](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L30-L123)

## Entry Points and Delegation

```tablegen
let Entry = 1 in
def CC_AArch64_AAPCS : CallingConv<AArch64_Common>;

let Entry = 1 in
def RetCC_AArch64_AAPCS : CallingConv<[
  ...
```

`Entry = 1` makes `-gen-callingconv` emit a non-static function that C++ can name. Conventions without it are only usable through `CCDelegateTo` from other records. The generated functions have the `CCAssignFn` signature and are included into `AArch64ISelLowering.cpp` (and the GlobalISel call lowering) from `AArch64GenCallingConv.inc`.

**Sources:** [llvm/lib/Target/AArch64/AArch64CallingConvention.td:125-162](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L125-L162), [llvm/lib/Target/AArch64/CMakeLists.txt:8](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/CMakeLists.txt#L8)

## CCCustom

When a rule cannot be written in TableGen, `CCCustom<"Name">` calls a C++ function with the `CCCustomFn`-like signature `(ValNo, ValVT, LocVT, LocInfo, ArgFlags, State)` returning `true` if it handled the value. AArch64 uses `CC_AArch64_Custom_Block` for homogeneous floating-point aggregates, which must go in consecutive registers or entirely on the stack; it collects the pieces in `State.getPendingLocs()` until the last one arrives, then allocates them together.

| Function | Line |
| --- | --- |
| `finishStackBlock` | 43 |
| `CC_AArch64_Custom_Stack_Block` | 116 |
| `CC_AArch64_Custom_Block` | 135 |

**Sources:** [llvm/lib/Target/AArch64/AArch64CallingConvention.cpp:43-135](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.cpp#L43-L135)

## Callee-Saved Registers

```tablegen
def CSR_AArch64_AAPCS : CalleeSavedRegs<(add X19, X20, X21, X22, X23, X24,
...
def CSR_AArch64_AAPCS_ThisReturn : CalleeSavedRegs<(add CSR_AArch64_AAPCS, X0)>;
...
def CSR_AArch64_NoRegs : CalleeSavedRegs<(add)>;
```

`-gen-register-info` produces `<Name>_SaveList` (a null-terminated list, for `getCalleeSavedRegs`) and `<Name>_RegMask` (a bit mask, for `getCallPreservedMask`). Variants are built with `add`: `ThisReturn` adds `X0` for calls whose result is known to equal the first argument. How register masks are used by the allocator is on the regalloc [registers page](../regalloc-wiki/regalloc-wiki.html#registers-basics).

**Sources:** [llvm/lib/Target/AArch64/AArch64CallingConvention.td:594](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L594), [llvm/lib/Target/AArch64/AArch64CallingConvention.td:702](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L702), [llvm/lib/Target/AArch64/AArch64CallingConvention.td:720](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L720)

## Target-Specific Predicates

A target can define its own predicate classes on top of `CCIf`. AArch64 defines three at the top of its file:

```tablegen
/// CCIfBigEndian - Match only if we're in big endian mode.
class CCIfBigEndian<CCAction A> :
  CCIf<"State.getMachineFunction().getDataLayout().isBigEndian()", A>;

class CCIfILP32<CCAction A> :
  CCIf<"State.getMachineFunction().getDataLayout().getPointerSize() == 4", A>;

/// CCIfSubtarget - Match if the current subtarget has a feature F.
class CCIfSubtarget<string F, CCAction A>
```

The string is pasted into the generated C++, where `State` is the `CCState&` argument.

**Sources:** [llvm/lib/Target/AArch64/AArch64CallingConvention.td:13-24](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L13-L24)