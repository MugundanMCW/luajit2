# Tooling and Glossary

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/include/llvm/CodeGen/CallingConvLower.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/CallingConvLower.h)
- [llvm/lib/CodeGen/CallingConvLower.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CallingConvLower.cpp)

</details>
Commands for inspecting calling-convention decisions, common errors, and the terms used in this wiki. The [bring-up tooling page](../bringup-wiki/bringup-wiki.html#tooling-glossary) covers the general `llc` options.

## Purpose and Scope

All output in this wiki comes from an LLVM 24.0.0git release `llc` (no assertions) at commit `a2171756`.

## Commands

| Command | Shows |
| --- | --- |
| `llc -O2 -mtriple=aarch64-linux-gnu f.ll -o -` | Final placement of arguments and results |
| `llc ... -stop-after=finalize-isel` | MIR after selection: live-in copies, `ADJCALLSTACKDOWN/UP`, argument copies, the call's register mask and implicit operands |
| `llc ... -stop-after=prolog-epilog` | How stack arguments and the outgoing area ended up in the frame |
| `llc ... -O0` | Same lowering without later optimizations hiding the copies |
| `llvm-tblgen -gen-callingconv -I llvm/include -I lib/Target/T T.td` | The generated `CC_*` C++ functions |
| `llc ... -debug-only=isel` | DAGs before and after each stage (assertions build only) |

## Common Errors

| Message | Source | Cause |
| --- | --- | --- |
| `unable to allocate function argument #N` | `CCState::AnalyzeFormalArguments` | No rule in `CC_*` matched the argument's type |
| `unable to allocate function return #N` | `CCState::AnalyzeReturn` | No rule in `RetCC_*`, and `CanLowerReturn` did not demote it |
| `Call operand #N has unhandled type` (debug) then unreachable | `CCState::AnalyzeCallOperands` | No rule for an outgoing argument type |
| `failed to perform tail call elimination on a call site marked musttail` | AArch64 `LowerCall` | `musttail` call failed the eligibility checks |
| `Not Implemented` | `TargetLowering` defaults | A call-lowering hook is missing |

**Sources:** [llvm/lib/CodeGen/CallingConvLower.cpp:85-141](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CallingConvLower.cpp#L85-L141), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10530-10532](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10530-L10532)

## Glossary

| Term | Meaning |
| --- | --- |
| Calling convention | Rules for where arguments and results live and which registers survive a call |
| AAPCS64 | The Arm 64-bit Procedure Call Standard, implemented by `CC_AArch64_AAPCS` |
| `CallingConv` record | TableGen list of actions; `Entry = 1` makes a callable C++ function |
| `CCAssignFn` | Signature of a generated (or hand-written) assignment function |
| `CCState` | Tracks allocated registers and stack size during analysis |
| `CCValAssign` | One result: value number, register or stack offset, `LocInfo` |
| `LocInfo` | How the value was converted for its location (`Full`, `SExt`, `ZExt`, `AExt`, `BCvt`, `Indirect`, ...) |
| `ISD::InputArg` / `OutputArg` | Legal-typed argument pieces with flags, built by generic code |
| Shadow register | Register marked used as a side effect of assigning another |
| `CALLSEQ_START` / `CALLSEQ_END` | DAG nodes bracketing a call; become `ADJCALLSTACKDOWN/UP` |
| Register mask | Bit set of registers preserved by a call, attached as an operand |
| `byval` | Aggregate passed as a copy in the argument area |
| `sret` | Hidden pointer to the caller's result buffer (`x8` on AArch64) |
| `sret` demotion | Rewriting a too-large return into an `sret` argument, triggered by `CanLowerReturn` |
| Sibling call | Tail call that needs no ABI change; `NumBytes = 0` |
| Guaranteed tail call | `tailcc`/`swifttailcc` (or `-tailcallopt`): callee pops arguments |
| `TC_RETURN` | AArch64 tail-call node; becomes `TCRETURNdi`/`TCRETURNri` then `b`/`br` |
| `va_list` | AAPCS64: five fields (`__stack`, `__gr_top`, `__vr_top`, `__gr_offs`, `__vr_offs`) |