# Varargs, byval, sret and swifterror

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)
- [llvm/lib/Target/AArch64/AArch64CallingConvention.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td)
- [llvm/lib/CodeGen/CallingConvLower.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CallingConvLower.cpp)

</details>
Most arguments are plain values in registers or stack slots. A few need extra work from the target: variadic functions must make the unnamed register arguments reachable through `va_list`; `byval` aggregates are copies placed in the argument area; `sret` pointers have a dedicated register on AArch64; Swift's special arguments have dedicated callee-saved registers. Each is a TableGen rule plus some C++ in the lowering hooks.

## Purpose and Scope

How AArch64 handles each of these, with real `llc -O2 -mtriple=aarch64-linux-gnu` output. Line numbers for `AArch64ISelLowering.cpp` are from the committed file at `a2171756`.

## Summary

| Kind | TableGen rule (AAPCS) | C++ work |
| --- | --- | --- |
| Varargs (callee) | Same rules as fixed arguments | `saveVarArgRegisters`, `LowerVASTART` fills `va_list` |
| Varargs (caller) | Same rules on Linux; Darwin and Windows use separate `*_VarArg` conventions | Chosen in `CCAssignFnForCall` |
| `byval` | `CCIfByVal<CCPassByVal<8, 8>>` | Caller copies with memcpy; callee uses a fixed object |
| `sret` | `CCIfSRet<CCIfType<[i64], CCAssignToReg<[X8]>>>` | None on Linux; Windows returns the pointer in `X0` |
| `swifterror` | `CCIfSwiftError<CCIfType<[i64], CCAssignToReg<[X21]>>>` | Special register handling in frame lowering |
| `swiftself` | `CCIfSwiftSelf<... [X20]>` | — |
| `nest` | `CCIfNest<CCAssignToReg<[X15]>>` | — |

**Sources:** [llvm/lib/Target/AArch64/AArch64CallingConvention.td:30-79](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L30-L79), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9197-9257](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9197-L9257)

## Varargs in the Callee

On AAPCS64 a variadic function receives its arguments exactly like a normal one: named and unnamed arguments share `x0`–`x7`, `q0`–`q7` and the stack. So if the function calls `va_start`, `LowerFormalArguments` must store the argument registers that the named arguments did not use, so that `va_arg` can find them later:

```cpp
  // varargs
  if (isVarArg) {
    if (DAG.getMachineFunction().getFrameInfo().hasVAStart()) {
      if (!Subtarget->isTargetDarwin() || IsWin64) {
        // The AAPCS variadic function ABI is identical to the non-variadic
        // one. As a result there may be more arguments in registers and we
        // should save them for future reference.
        ...
        saveVarArgRegisters(CCInfo, DAG, DL, Chain);
      }

      // This will point to the next argument passed via stack.
      unsigned VarArgsOffset = CCInfo.getStackSize();
      ...
      FuncInfo->setVarArgsStackIndex(
          MFI.CreateFixedObject(4, VarArgsOffset, true));
```

`saveVarArgRegisters` asks `CCState` for the first unallocated GPR and makes a stack object large enough for the rest:

```cpp
  unsigned FirstVariadicGPR = CCInfo.getFirstUnallocated(GPRArgRegs);

  unsigned GPRSaveSize = 8 * (NumGPRArgRegs - FirstVariadicGPR);
  int GPRIdx = 0;
  if (GPRSaveSize != 0) {
    if (IsWin64) {
      ...
    } else
      GPRIdx = MFI.CreateStackObject(GPRSaveSize, Align(8), false);
```

It does the same for the FP/SIMD registers.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9640-9660](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9640-L9660), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9777-9809](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9777-L9809)

### va_start

`va_start` is `Custom` lowered. On AAPCS it fills the five fields of the `va_list` structure from the frame indices recorded above:

```cpp
  // void *__stack at offset 0
  ...
  // void *__gr_top at offset 8 (4 on ILP32)
  ...
  // void *__vr_top at offset 16 (8 on ILP32)
  ...
  // int __gr_offs at offset 24 (12 on ILP32)
  ...
      DAG.getStore(Chain, DL, DAG.getSignedConstant(-GPRSize, DL, MVT::i32),
  ...
  // int __vr_offs at offset 28 (16 on ILP32)
```

`LowerVASTART` picks the Windows, Darwin (a single pointer) or AAPCS version.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:13594-13684](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L13594-L13684)

### Result

`define i32 @sum(i32 %n, ...)` with one `va_arg ptr %ap, i32`:

```asm
sum:                                    // @sum
	.cfi_startproc
	sub	sp, sp, #224
	.cfi_def_cfa_offset 224
	mov	x8, sp
	mov	x9, #-56                        // =0xffffffffffffffc8
	add	x10, sp, #136
	movk	x9, #65408, lsl #32
	add	x8, x8, #128
	ldr	w11, [sp, #224]
	stp	x8, x9, [sp, #208]
	add	x9, sp, #224
	add	x8, x10, #56
	orr	x9, x9, #0x8
	stp	x1, x2, [sp, #136]
	add	w0, w0, w11
	stp	x3, x4, [sp, #152]
	stp	x5, x6, [sp, #168]
	str	x7, [sp, #184]
	stp	q0, q1, [sp]
	stp	q2, q3, [sp, #32]
	stp	q4, q5, [sp, #64]
	stp	q6, q7, [sp, #96]
	stp	x9, x8, [sp, #192]
	add	sp, sp, #224
	ret
```

`%n` used `w0`, so `x1`–`x7` (56 bytes, hence `#-56` for `__gr_offs`) are saved at `[sp, #136]` and `q0`–`q7` (128 bytes) at `[sp]`. The `va_list` itself is at `[sp, #192]`. (The `ldr w11, [sp, #224]` reads the `va_arg` value; the optimizer folded the `va_arg` through the known `va_list` contents.)

## Varargs in the Caller

On Linux, a call to a variadic function uses the normal convention, so `printf("%d\n", x, 1.0)` puts the double in `d0`:

```asm
callprintf:                             // @callprintf
	.cfi_startproc
	str	x30, [sp, #-16]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -16
	fmov	d0, #1.00000000
	mov	w1, w0
	adrp	x0, .Lfmt
	add	x0, x0, :lo12:.Lfmt
	bl	printf
	ldr	x30, [sp], #16                  // 8-byte Folded Reload
	ret
```

On Darwin, `CCAssignFnForCall` returns `CC_AArch64_DarwinPCS_VarArg`, which puts every unnamed argument on the stack; that is why the hook takes an `IsVarArg` parameter.

## byval

A `byval` argument is a copy of an aggregate that the callee owns. `CCPassByVal<8, 8>` makes `CCState::HandleByVal` allocate a stack slot of the aggregate's size (at least 8, aligned to at least 8). The caller copies the aggregate into that slot with a memcpy node in `LowerCall`; the callee just uses the slot's address (see [LowerFormalArguments](#formal-arguments)). A callee that ignores the argument needs no code at all:

```asm
take_byval:                             // @take_byval
	.cfi_startproc
	ret
```

**Sources:** [llvm/lib/CodeGen/CallingConvLower.cpp:45-59](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CallingConvLower.cpp#L45-L59), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9384-9399](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9384-L9399)

## sret

In AAPCS64 the address of an indirect result goes in `x8`, not `x0`. The rule comes before the general `i64` rule so it wins:

```tablegen
  CCIfSRet<CCIfType<[i64], CCAssignToReg<[X8]>>>,
```

A caller of `void @make(ptr sret(%struct.Big))`, with the 32-byte struct on its own stack:

```asm
use_sret:                               // @use_sret
	.cfi_startproc
	sub	sp, sp, #48
	str	x30, [sp, #32]                  // 8-byte Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -16
	mov	x8, sp
	bl	make
	ldr	x0, [sp, #16]
	ldr	x30, [sp, #32]                  // 8-byte Reload
	add	sp, sp, #48
	ret
```

`mov x8, sp` passes the struct address; after the call the third field is loaded from `[sp, #16]`. On Windows the `inreg` variant puts it in `x0` or `x1` (rule at line 62-63), and `LowerFormalArguments` saves the pointer so `LowerReturn` can return it in `x0`.

**Sources:** [llvm/lib/Target/AArch64/AArch64CallingConvention.td:48-65](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L48-L65), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9680-9700](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9680-L9700)

## swifterror and other Swift registers

Swift passes an error value in a callee-saved register so that it survives calls; the callee may write it, and the caller reads it back after the call. The rule appears in both the argument list and `RetCC_AArch64_AAPCS`, because the value also comes back:

```tablegen
  // Pass SwiftSelf in a callee saved register.
  CCIfSwiftSelf<CCIfType<[i64], CCAssignToReg<[X20]>>>,

  // A SwiftError is passed in X21.
  CCIfSwiftError<CCIfType<[i64], CCAssignToReg<[X21]>>>,

  // Pass SwiftAsync in an otherwise callee saved register so that it will be
  // preserved for normal function calls.
  CCIfSwiftAsync<CCIfType<[i64], CCAssignToReg<[X22]>>>,
```

Because `X21` is normally callee-saved, functions with a `swifterror` argument use a different callee-saved list without it (`CSR_AArch64_AAPCS_SwiftError` at line 704), so the prologue does not save and the epilogue does not restore it.

**Sources:** [llvm/lib/Target/AArch64/AArch64CallingConvention.td:71-79](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L71-L79), [llvm/lib/Target/AArch64/AArch64CallingConvention.td:135](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L135), [llvm/lib/Target/AArch64/AArch64CallingConvention.td:704](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64CallingConvention.td#L704)

## For a New Target

Start with no varargs support (`VASTART` as `Custom` that reports an error, or omit it), no `byval` beyond `CCPassByVal`, and the default `sret` handling (the pointer is just the first argument). Add varargs once ordinary calls work: the key pieces are saving the unused argument registers in `LowerFormalArguments` and a `LowerVASTART` that matches your `va_list` layout (often just a pointer, with `VAARG` set to `Expand`).