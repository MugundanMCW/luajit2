# LowerCall

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)
- [llvm/include/llvm/CodeGen/TargetLowering.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetLowering.h)
- [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp)
- [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp)

</details>
`LowerCall` turns one call site into a sequence of DAG nodes: open a call frame, put each argument in its register or stack slot, emit the target's call node with a register mask, close the call frame, and copy the results out of their return registers. It is the largest of the three call-lowering hooks because it handles both the caller's side of the arguments and the callee's results.

## Purpose and Scope

The structure of AArch64's `LowerCall` and what each part produces. Tail calls are on [Tail Calls and Sibling Calls](#tail-calls); varargs and `byval` on [Varargs, byval, sret](#special-args). Line numbers for `AArch64ISelLowering.cpp` are from the committed file at `a2171756`.

## Entry

Generic code fills a `CallLoweringInfo` (callee, arguments as `Outs`/`OutVals`, expected results as `Ins`, calling convention, `IsTailCall`, `IsVarArg`) in `SelectionDAGBuilder::LowerCallTo`, and `TargetLowering::LowerCallTo` calls the target hook:

```cpp
  virtual SDValue
    LowerCall(CallLoweringInfo &/*CLI*/,
              SmallVectorImpl<SDValue> &/*InVals*/) const {
    llvm_unreachable("Not Implemented");
  }
```

**Sources:** [llvm/include/llvm/CodeGen/TargetLowering.h:5187-5191](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/include/llvm/CodeGen/TargetLowering.h#L5187-L5191), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp:9202](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp#L9202), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp:11333-11334](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp#L11333-L11334)

## The Node Sequence

```mermaid
flowchart TD
    A["analyze operands (CC_*) and results (RetCC_*)"] --> B{"tail call possible?"}
    B --> C["CALLSEQ_START NumBytes"]
    C --> D["argument values: extend / bitcast per LocInfo"]
    D --> E["registers: RegsToPass list"]
    D --> F["stack: store to SP + offset (MemOpChains)"]
    F --> G["TokenFactor of stores"]
    E --> H["CopyToReg chain, glued"]
    G --> H
    H --> I["AArch64ISD::CALL (callee, arg regs, regmask, glue)"]
    I --> J["CALLSEQ_END NumBytes"]
    J --> K["LowerCallResult: CopyFromReg per RetCC location"]
```

| Step | Lines | Notes |
| --- | --- | --- |
| Analyze operands and results | 10471-10492 | `analyzeCallOperands` (a static helper at 9977) and `AnalyzeCallResult` |
| Tail-call decision | 10516-10532 | See [Tail Calls](#tail-calls) |
| Stack size | 10535-10541 | `CCInfo.getStackSize()`, 0 for sibling calls |
| `CALLSEQ_START` | 10648-10649 | Not emitted for sibling calls |
| Argument registers and stores | 10666-10941 | `RegsToPass`, `MemOpChains` |
| Call node and mask | 10999-11083 | `CALL` or `TC_RETURN` |
| `CALLSEQ_END` | 11119-11122 | Records how many bytes the callee pops |
| Results | 11127-11129 | `LowerCallResult` (9875) |

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10442-10541](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10442-L10541), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9977](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9977), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:9875](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L9875)

## Analysis

```cpp
  // Analyze operands of the call, assigning locations to each operand.
  SmallVector<CCValAssign, 16> ArgLocs;
  CCState CCInfo(CallConv, IsVarArg, MF, ArgLocs, *DAG.getContext());
  ...
  analyzeCallOperands(*this, Subtarget, CLI, CCInfo);

  CCAssignFn *RetCC = CCAssignFnForReturn(CallConv);
  // Assign locations to each value returned by this call.
  SmallVector<CCValAssign, 16> RVLocs;
  CCState RetCCInfo(CallConv, IsVarArg, DAG.getMachineFunction(), RVLocs,
                    *DAG.getContext());
  RetCCInfo.AnalyzeCallResult(Ins, RetCC);
```

Two separate `CCState` objects are used: one for arguments, one for results, because the same registers (`x0`...) can appear in both.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10471-10492](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10471-L10492)

## Call Frame Markers

`CALLSEQ_START` and `CALLSEQ_END` bracket the call. They become the `ADJCALLSTACKDOWN` / `ADJCALLSTACKUP` pseudo instructions, which frame lowering later removes or turns into SP adjustments (`eliminateCallFramePseudoInstr`, see the [frame wiki](../frame-wiki/frame-wiki.html#tfl-hooks)). The byte count is the outgoing stack argument area:

```cpp
  // Get a count of how many bytes are to be pushed on the stack.
  unsigned NumBytes = CCInfo.getStackSize();
  ...
    Chain = DAG.getCALLSEQ_START(Chain, IsTailCall ? 0 : NumBytes, 0, DL);
  ...
  uint64_t CalleePopBytes =
      DoesCalleeRestoreStack(CallConv, TailCallOpt) ? alignTo(NumBytes, 16) : 0;

  Chain = DAG.getCALLSEQ_END(Chain, NumBytes, CalleePopBytes, InGlue, DL);
```

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10535](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10535), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10649](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10649), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:11119-11122](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L11119-L11122)

## Arguments

For each `CCValAssign`, the argument value is first converted according to `LocInfo` (`SExt` → `SIGN_EXTEND`, `BCvt` → `BITCAST`, ...). Then:

- **Register location:** the pair (register, value) is added to `RegsToPass` (line 10821). After all stores, the pairs become a chain of `CopyToReg` nodes glued together, so nothing can be scheduled between the copies and the call.
- **Stack location:** the value is stored at `SP + LocMemOffset`; the store chains are collected in `MemOpChains` and merged with one `TokenFactor` (lines 10940-10941). For a tail call the store goes to a fixed object in the caller's own incoming area instead (line 10880).

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10666](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10666), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10821](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10821), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10880](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10880), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10940-10941](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10940-L10941)

## The Call Node and the Register Mask

The operands of `AArch64ISD::CALL` are: chain, callee, one register operand per argument register (so the registers are live into the call), the register mask, and the glue.

```cpp
  unsigned Opc = IsTailCall ? AArch64ISD::TC_RETURN : AArch64ISD::CALL;

  std::vector<SDValue> Ops;
  Ops.push_back(Chain);
  Ops.push_back(Callee);
  ...
  // Add a register mask operand representing the call-preserved registers.
  const uint32_t *Mask;
  const AArch64RegisterInfo *TRI = Subtarget->getRegisterInfo();
  if (IsThisReturn) {
    ...
  } else
    Mask = TRI->getCallPreservedMask(MF, CallConv);
  ...
  assert(Mask && "Missing call preserved mask for calling convention");
  Ops.push_back(DAG.getRegisterMask(Mask));
```

The mask is what tells the register allocator which registers the call clobbers: every register not in the mask is dead after the call. It comes from the `CalleeSavedRegs` record through `getCallPreservedMask` (`AArch64RegisterInfo.cpp`, line 270-271). The regalloc wiki's [registers page](../regalloc-wiki/regalloc-wiki.html#registers-basics) explains how the allocator uses it.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10999-11003](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10999-L11003), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:11063-11083](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L11063-L11083), [llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp:270-271](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64RegisterInfo.cpp#L270-L271)

## Results

After `CALLSEQ_END`, `LowerCallResult` walks `RVLocs` and emits a `CopyFromReg` for each return register, glued to the call so the copies stay right after it, then undoes any extension:

```cpp
  // Handle result values, copying them out of physregs into vregs that we
  // return.
  SDValue Result = LowerCallResult(
      Chain, InGlue, CallConv, IsVarArg, RVLocs, DL, DAG, InVals, IsThisReturn,
      IsThisReturn ? OutVals[0] : SDValue(), RequiresSMChange);
```

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:11125-11129](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L11125-L11129)

## What It Looks Like After Selection

`llc -O2 -mtriple=aarch64-linux-gnu -stop-after=finalize-isel` for a call with ten `i64` arguments (`callee(x, 1, 2, ..., 9)`), first lines of the body:

```text
    %0:gpr64 = COPY $x0
    ADJCALLSTACKDOWN 16, 0, implicit-def dead $sp, implicit $sp
    %1:gpr64sp = COPY $sp
    %2:gpr32 = MOVi32imm 9
    %3:gpr64 = SUBREG_TO_REG killed %2, %subreg.sub_32
    STRXui killed %3, %1, 1 :: (store (s64) into stack + 8)
    %4:gpr32 = MOVi32imm 8
    %5:gpr64 = SUBREG_TO_REG killed %4, %subreg.sub_32
    STRXui killed %5, %1, 0 :: (store (s64) into stack)
    %6:gpr32 = MOVi32imm 1
    ...
    $x0 = COPY %0
    $x1 = COPY %7
    $x2 = COPY %9
    ...
```

`ADJCALLSTACKDOWN 16` is the `CALLSEQ_START` with 16 bytes for the two stack arguments; the two `STRXui` stores are the `MemOpChains`; the `$xN = COPY` lines are `RegsToPass`. The full function, including the `BL` with its register mask, is on the [walkthroughs page](#aarch64-walkthroughs).