# Tail Calls and Sibling Calls

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)
- [llvm/lib/CodeGen/CallingConvLower.cpp](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CallingConvLower.cpp)

</details>
A tail call replaces `call f; ret` with a jump to `f`, so `f` returns directly to our caller. It saves a stack frame and an instruction, and for `musttail` it is required for correctness. LLVM distinguishes a **sibling call** (a tail call that needs no change to the calling convention, because the callee's arguments fit in the space the caller already has) from a **guaranteed tail call** (`tailcc`, `swifttailcc`, or `fastcc` with `-tailcallopt`), where the callee pops its own arguments.

## Purpose and Scope

How AArch64 decides whether a call marked `tail` can really be a tail call, and what `LowerCall` does differently for it. Line numbers for `AArch64ISelLowering.cpp` are from the committed file at `a2171756`.

## The Decision in LowerCall

```cpp
  if (IsTailCall) {
    // Check if it's really possible to do a tail call.
    IsTailCall = isEligibleForTailCallOptimization(CLI);

    // A sibling call is one where we're under the usual C ABI and not planning
    // to change that but can still do a tail call:
    if (!ZAMarkerNode && !TailCallOpt && IsTailCall &&
        CallConv != CallingConv::Tail && CallConv != CallingConv::SwiftTail)
      IsSibCall = true;
    ...
  }

  if (!IsTailCall && CLI.CB && CLI.CB->isMustTailCall())
    report_fatal_error("failed to perform tail call elimination on a call "
                       "site marked musttail");
```

The IR `tail` marker is only a hint; the target decides. `musttail` turns a "no" into a fatal error.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10516-10532](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10516-L10532)

## isEligibleForTailCallOptimization

The checks, in order (function starts at line 10055):

| Check | Lines | Why |
| --- | --- | --- |
| Callee convention can be tail called (`mayTailCallThisCC`) | 10058-10059 | Some conventions never allow it |
| SME streaming / ZA state changes | 10071-10079 | State must be restored after the call |
| Windows convention on non-Windows OS | 10091-10096 | X18 must be saved and restored |
| Caller has a `byval` argument | 10098-10105 | The callee's arguments would overwrite it |
| Windows `inreg` sret mismatch | 10107-10121 | `x0` must be returned |
| Guaranteed TCO convention | 10126 | If so, eligible (the remaining checks are for sibcalls) |
| Weak external callee | 10129-10141 | Linker may replace the call with a NOP |
| Return values in the same places (`resultsCompatible`) | 10154-10158 | Callee's return goes straight to our caller |
| Callee preserves every register the caller must (`regmaskSubsetEqual`) | 10159-10169 | Otherwise our caller sees clobbered CSRs |
| Variadic stack arguments | 10181-10191 | Conservatively rejected |
| Stack arguments fit our incoming area | 10209-10212 | `CCInfo.getStackSize() > FuncInfo->getBytesInStackArgArea()` → no |
| Arguments in callee-saved registers match | 10215-10216 | `parametersInCSRMatch` |

The stack-size check is why `LowerFormalArguments` records `setBytesInStackArgArea` (see [LowerFormalArguments](#formal-arguments)).

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10055-10218](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10055-L10218), [llvm/lib/CodeGen/CallingConvLower.cpp:264](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/CodeGen/CallingConvLower.cpp#L264)

## What Changes in LowerCall

| | Normal call | Sibling call | Guaranteed tail call |
| --- | --- | --- | --- |
| `NumBytes` | Stack size of arguments | 0 | Aligned to 16; `FPDiff` = reusable bytes − needed |
| `CALLSEQ_START` | Yes | No | Yes, with 0 |
| Stack argument stores | `SP + offset` | Into the caller's incoming area | Into fixed objects offset by `FPDiff` |
| Node | `AArch64ISD::CALL` | `AArch64ISD::TC_RETURN` | `AArch64ISD::TC_RETURN` |
| After the node | `CALLSEQ_END`, result copies | Nothing: it ends the block | Nothing |

```cpp
  // Get a count of how many bytes are to be pushed on the stack.
  unsigned NumBytes = CCInfo.getStackSize();

  if (IsSibCall) {
    // Since we're not changing the ABI to make this a tail call, the memory
    // operands are already available in the caller's incoming argument space.
    NumBytes = 0;
  }
  ...
  // If we're doing a tall call, use a TC_RETURN here rather than an
  // actual call instruction.
  if (IsTailCall) {
    MF.getFrameInfo().setHasTailCall();
    SDValue Ret = DAG.getNode(Opc, DL, MVT::Other, Ops);
    ...
    return Ret;
  }
```

`setHasTailCall` tells frame lowering that the epilogue must be placed before the `TC_RETURN` jump (see the [frame wiki](../frame-wiki/frame-wiki.html#pei-pass)).

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:10534-10560](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L10534-L10560), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:11091-11105](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L11091-L11105)

## Example

```llvm
declare i64 @g(i64)
define i64 @sib(i64 %x) {
  %r = tail call i64 @g(i64 %x)
  ret i64 %r
}
define i64 @notail(i64 %x) {
  %r = call i64 @g(i64 %x)
  %s = add i64 %r, %x
  ret i64 %s
}
```

After instruction selection (`-stop-after=finalize-isel`), `sib` has no call frame and no return, just the tail-call pseudo carrying the register mask:

```text
    %0:gpr64 = COPY $x0
    $x0 = COPY %0
    TCRETURNdi @g, 0, csr_aarch64_aapcs, implicit $sp, implicit $x0
```

Final assembly (`llc -O2 -mtriple=aarch64-linux-gnu`):

```asm
sib:                                    // @sib
	.cfi_startproc
	b	g
.Lfunc_end0:
	.cfi_endproc
notail:                                 // @notail
	.cfi_startproc
	stp	x30, x19, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w19, -8
	.cfi_offset w30, -16
	mov	x19, x0
	bl	g
	add	x0, x0, x19
	ldp	x30, x19, [sp], #16             // 16-byte Folded Reload
	ret
```

`notail` cannot be a tail call because work remains after the call, so it needs a frame, a saved link register and a callee-saved register for `%x`.

## For a New Target

Tail calls are optional. Return `false` from your eligibility check (or ignore `CLI.IsTailCall`, setting it to `false`) until normal calls work; only `musttail` IR then fails. When adding sibling calls, start with the strictest version: same calling convention, no stack arguments, no `byval`, results in the same registers. Add a `TCRETURN` pseudo that the epilogue code recognizes and that expands to a branch after frame lowering.