# Data, Memory and Control Instructions

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td)
- [llvm/lib/Target/Hexagon/HexagonRegisterInfo.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonRegisterInfo.td)
- Qualcomm: *Hexagon V6x/V7x Programmer's Reference Manual*, instruction set chapters

</details>

This page tours the scalar instruction set by job: computing on data, moving data to and from memory, and changing control flow. It uses the algebraic syntax from [Encoding and Mnemonics](#encoding).

> Assembly on this page is illustrative and was not assembled.

## Purpose and Scope

This page covers ALU and multiply instructions, saturation and DSP-style operations, loads and stores with their addressing modes, atomics, and branches, calls, returns and hardware loops. Vector and floating-point instructions are on [FP, HVX and Alignment](#hvx).

## Map of the Instruction Set

```mermaid
flowchart TD
    ISA["Scalar Hexagon ISA"] --> D["Data"]
    ISA --> M["Memory"]
    ISA --> C["Control"]
    D --> D1["ALU32: add, sub, and, or, xor, mux, cmp"]
    D --> D2["XTYPE: mpy, shifts, bit ops, 64-bit, saturating DSP ops"]
    M --> M1["Loads: memb/memub/memh/memuh/memw/memd"]
    M --> M2["Stores, new-value stores"]
    M --> M3["Atomics: memw_locked, barriers"]
    C --> C1["jump, call, jumpr, dealloc_return"]
    C --> C2["Compare-and-jump, loop0/loop1"]
```

## Data Instructions

| Instruction | Meaning |
| --- | --- |
| `r0 = add(r1, r2)` / `r0 = add(r1, #-4)` | Add register or immediate |
| `r0 = sub(r1, r2)` | Subtract |
| `r0 = and(r1, r2)`, `or`, `xor`, `r0 = not(r1)` | Logic |
| `r0 = mux(p0, r1, r2)` | Select: `p0 ? r1 : r2` |
| `p0 = cmp.gt(r1, r2)`, `cmp.eq`, `cmp.gtu` | Compare into a predicate (signed/unsigned) |
| `r0 = mpyi(r1, r2)` | 32-bit multiply, low result |
| `r1:0 = mpy(r2, r3)` | 32×32 → 64-bit multiply into a pair |
| `r0 += mpyi(r1, r2)` | Multiply-accumulate |
| `r0 = asl(r1, #3)`, `asr`, `lsr` | Shifts |
| `r0 = add(r1, r2):sat` | Saturating add: clamps instead of wrapping |
| `r1:0 = add(r3:2, r5:4)` | 64-bit add on pairs |
| `r0 = vaddh(r1, r2)` | Two 16-bit adds packed in 32 bits (small scalar SIMD) |

Saturation and packed halfword/byte operations are why Hexagon suits audio and fixed-point DSP: overflow clamps to the maximum instead of wrapping (overflow is recorded in `usr`).

## Memory Instructions

| Load | Size | Store |
| --- | --- | --- |
| `r0 = memb(...)` / `memub` | 8-bit, signed / unsigned | `memb(...) = r0` |
| `r0 = memh(...)` / `memuh` | 16-bit | `memh(...) = r0` |
| `r0 = memw(...)` | 32-bit | `memw(...) = r0` |
| `r1:0 = memd(...)` | 64-bit into a pair | `memd(...) = r1:0` |

### Addressing Modes

| Mode | Syntax | Use |
| --- | --- | --- |
| Base + offset | `memw(r1 + #8)` | Struct fields |
| Base + scaled index | `memw(r1 + r2 << #2)` | Arrays |
| Post-increment | `memw(r1++#4)` | Walking arrays in loops |
| Post-increment by modifier | `memw(r1++m0)` | Step held in `m0`/`m1` |
| Circular | `memw(r1++#4:circ(m0))` | Ring buffers using `cs0`/`cs1` and `m0` |
| Absolute / GP-relative | `memw(#global)`, `memw(gp + #x)` | Globals and small data |

```mermaid
flowchart LR
    B["r1 = buffer start"] --> L["r0 = memw(r1++#4)"]
    L --> R["load from r1, then r1 = r1 + 4"]
    R --> L
```

Loads and stores run in slots 0 and 1, so a packet holds at most two memory operations. Accesses must be naturally aligned ([FP, HVX and Alignment](#hvx)).

### Atomics

Hexagon uses a load-locked / store-conditional pair:

```text
// illustrative: atomic increment of *r1
retry:
  r2 = memw_locked(r1)
  r2 = add(r2, #1)
  memw_locked(r1, p0) = r2         // p0 = true if the store succeeded
  if (!p0) jump retry
```

`barrier` orders memory operations between threads.

**Sources:** [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td:21720](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td#L21720), [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td:21995](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td#L21995), [llvm/lib/Target/Hexagon/HexagonRegisterInfo.td:166-178](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonRegisterInfo.td#L166-L178)

## Control Instructions

| Instruction | Meaning |
| --- | --- |
| `jump label` | Unconditional branch |
| `if (p0) jump:t label` | Conditional branch with a taken hint |
| `p0 = cmp.eq(r0, #0); if (p0.new) jump:nt label` | Compare and branch in one packet |
| `call func` | Call: return address to `r31` (`lr`) |
| `jumpr r31` | Return (jump to register) |
| `allocframe(#n)` / `deallocframe` | Push/pop `fp` and `lr` and reserve stack |
| `dealloc_return` | Restore frame and return in one instruction |
| `loop0(label, #N)` / `:endloop0` | Zero-overhead loop |

```mermaid
sequenceDiagram
    participant A as caller
    participant F as func
    A->>F: call func (r31 = return address)
    F->>F: allocframe(#16): save fp, lr; sp -= 16+8
    F->>F: body
    F->>A: dealloc_return: restore fp, lr, sp; jump to lr
```

A function in this style:

```text
// illustrative: int sum(int *p, int n)
sum:
  { loop0(.L1, r1)
    r2 = #0 }
.L1:
  { r3 = memw(r0++#4)
    r2 = add(r2, r3) }:endloop0
  { r0 = r2
    jumpr r31 }
```

**Sources:** [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td:5020](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td#L5020), [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td:5639-5656](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td#L5639-L5656)

## Key Points

- Data instructions include saturating, packed and multiply-accumulate forms for DSP work.
- Memory instructions have rich addressing: post-increment, modifiers, circular buffers; at most two per packet.
- Control uses predicates, compare-and-jump in one packet, `call`/`jumpr r31`, frame helpers and hardware loops.