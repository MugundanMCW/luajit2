# Hexagon Overview and Processor Properties

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/Hexagon/HexagonDepArch.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepArch.td)
- [llvm/lib/Target/Hexagon/Hexagon.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/Hexagon.td)
- [Wikipedia: Qualcomm Hexagon](https://en.wikipedia.org/wiki/Qualcomm_Hexagon)
- [Wikipedia: Very long instruction word](https://en.wikipedia.org/wiki/Very_long_instruction_word)
- Qualcomm: *Hexagon V6x/V7x Programmer's Reference Manual* and *HVX Programmer's Reference Manual* (Qualcomm developer network)

</details>

Hexagon is Qualcomm's digital signal processor (DSP) architecture, found in Snapdragon chips as the audio/sensor DSP and the compute DSP that Qualcomm markets as the **Hexagon NPU**. It is a 32-bit **VLIW** machine: the compiler groups up to four instructions into a **packet** that executes in one go, so the hardware does not need complex out-of-order logic. A wide vector unit, **HVX**, adds SIMD for image, audio and AI workloads.

> **About this wiki.** Facts about registers, encodings, instruction names and architecture versions are cited from the LLVM Hexagon backend at commit `a2171756`. Hardware details not visible in LLVM (cache sizes, thread counts, MMU behaviour) follow Qualcomm's public Hexagon reference manuals; they vary by chip and are marked as general. All assembly is illustrative: the local LLVM build does not include the Hexagon target, so nothing was assembled.

## Purpose and Scope

| # | Page | Covers |
| --- | --- | --- |
| 1 | [Overview](#overview) | What Hexagon is, processor properties, versions |
| 2 | [ISA Fundamentals](#fundamentals) | Packets, slots, `.new`, hardware loops, threads |
| 3 | [Registers](#registers) | General, pair, predicate, control, HVX registers; ABI |
| 4 | [Encoding and Mnemonics](#encoding) | 32-bit words, parse bits, extenders, duplexes, assembly syntax |
| 5 | [Data, Memory and Control](#instructions) | ALU, loads/stores, addressing, branches, loops, calls |
| 6 | [FP, HVX and Alignment](#hvx) | Scalar floating point, HVX vectors, alignment rules |
| 7 | [Caches, MMU and Glossary](#memory-system) | Cache hierarchy and maintenance, VTCM, MMU, glossary |

Background: VLIW and multithreading are explained in the [Computer Architecture wiki](../arch-wiki/arch-wiki.html#ilp).

## Processor Properties at a Glance

| Property | Hexagon |
| --- | --- |
| Word size | 32-bit (32-bit registers and addresses), 64-bit register pairs |
| Instruction size | 32 bits each; up to 4 per packet (16 bytes) |
| Issue model | VLIW: compiler-scheduled packets, in-order |
| Execution slots | 4 (slots 0-3) |
| Threads | Several hardware threads per core, interleaved (count depends on the chip) |
| Endianness | Little-endian |
| Memory accesses | Must be naturally aligned (scalar) |
| Vector extension | HVX: 32 vector registers of 64 or 128 bytes |
| Loops | Two zero-overhead hardware loops |
| Typical role | Low-power signal processing and ML inference next to the CPU |

## Why VLIW for a DSP?

```mermaid
flowchart LR
    subgraph OoO["Big CPU core (e.g. Arm Cortex-X)"]
        A1["Hardware finds parallelism<br/>rename, reorder, speculate"] --> A2["Fast single thread,<br/>high power"]
    end
    subgraph VLIW["Hexagon"]
        B1["Compiler finds parallelism<br/>packs up to 4 instructions"] --> B2["Simple in-order hardware,<br/>low power, predictable timing"]
    end
```

DSP code (filters, transforms, neural-network layers) is regular and loop-heavy, so a compiler can schedule it well ahead of time. That saves the power an out-of-order engine would spend, which matters in phones.

**Sources:** [Wikipedia: Qualcomm Hexagon](https://en.wikipedia.org/wiki/Qualcomm_Hexagon), [Wikipedia: Very long instruction word](https://en.wikipedia.org/wiki/Very_long_instruction_word)

## Where Hexagon Sits in a Snapdragon Chip

```mermaid
flowchart TB
    subgraph SoC["Snapdragon SoC (simplified)"]
        CPU["Arm CPU cores<br/>Android / Linux"]
        GPU["Adreno GPU"]
        subgraph DSP["Hexagon DSP / NPU"]
            SC["Scalar core<br/>VLIW, hardware threads"]
            HVX["HVX vector unit"]
            TCM["VTCM (local memory)"]
        end
        CPU <-->|"FastRPC: offload calls"| DSP
        MEM["Shared DRAM"]
        CPU --- MEM
        GPU --- MEM
        DSP --- MEM
    end
```

Applications on the Arm CPU offload work to the DSP through Qualcomm's FastRPC mechanism. The DSP runs its own real-time OS (QuRT).

## Architecture Versions

LLVM knows these Hexagon versions, each enabled by a subtarget feature such as `v68`:

| Versions in LLVM | Notes |
| --- | --- |
| V5, V55 | Older scalar DSPs |
| V60, V62, V65, V66 | HVX introduced in V60 |
| V67, V68, V69 | V68+ add HVX floating point (`hvx-qfloat`) |
| V71, V73, V75, V79, V81 | Recent NPU-generation cores |

Matching HVX versions (`hvxv60` … `hvxv81`), vector length (`hvx-length64b`, `hvx-length128b`) and options such as `audio` and `hvx-ieee-fp` are separate features.

```text
clang --target=hexagon -mcpu=hexagonv73 -mhvx -mhvx-length=128B -O2 -c kernel.c   (illustrative)
```

**Sources:** [llvm/lib/Target/Hexagon/HexagonDepArch.td:11-37](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepArch.td#L11-L37), [llvm/lib/Target/Hexagon/Hexagon.td:32-96](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/Hexagon.td#L32-L96)

## Key Points

- Hexagon is a 32-bit, in-order VLIW DSP that executes packets of up to four 32-bit instructions.
- HVX adds wide SIMD; versions V60 onward have it, V68 onward add vector floating point.
- It trades single-thread speed for low power and predictable timing.