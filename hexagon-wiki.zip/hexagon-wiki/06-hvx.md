# Floating Point, HVX and Alignment

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/Hexagon/Hexagon.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/Hexagon.td)
- [llvm/lib/Target/Hexagon/HexagonRegisterInfo.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonRegisterInfo.td)
- [Wikipedia: Digital signal processor](https://en.wikipedia.org/wiki/Digital_signal_processor)
- Qualcomm: *Hexagon HVX Programmer's Reference Manual*

</details>

Hexagon computes in three ways: scalar integer (previous page), scalar floating point in the general registers, and wide SIMD in the **HVX** vector unit. HVX is where most image, audio and neural-network throughput comes from. Both scalar and vector memory accesses have alignment rules worth learning early.

> Assembly on this page is illustrative and was not assembled. Instruction availability depends on the architecture version.

## Purpose and Scope

This page covers scalar floating point, the HVX programming model (vector registers, lanes, instruction syntax, vector predicates, floating point), HVX contexts, and alignment rules. Caches and VTCM are on [Caches, MMU and Glossary](#memory-system).

## Scalar Floating Point

Floating point uses the ordinary general registers: single precision in one register, double precision in a pair. There is no separate FP register file.

| Instruction (general form) | Meaning |
| --- | --- |
| `r0 = sfadd(r1, r2)` | Single-precision add |
| `r0 = sfmpy(r1, r2)` | Single-precision multiply |
| `r0 += sfmpy(r1, r2)` | Fused multiply-add |
| `p0 = sfcmp.gt(r1, r2)` | Compare into a predicate |
| `r0 = convert_sf2w(r1)` / `convert_w2sf` | Float ↔ integer |
| `r1:0 = dfadd(r3:2, r5:4)` | Double-precision add (newer versions) |

Rounding mode and exception flags live in `usr` ([Registers](#registers)).

## The HVX Model

```mermaid
flowchart LR
    subgraph Core["Hexagon core"]
        T0["thread 0"]
        T1["thread 1"]
        T2["thread 2"]
    end
    subgraph HVXU["HVX unit"]
        C0["HVX context A<br/>v0-v31, q0-q3"]
        C1["HVX context B"]
    end
    T0 -->|"acquire"| C0
    T2 -->|"acquire"| C1
    HVXU --> VT["VTCM / L2"]
```

| Concept | Meaning |
| --- | --- |
| Vector length | 64 bytes or 128 bytes (`hvx-length64b` / `hvx-length128b`); 128 B on recent chips |
| Registers | `v0`-`v31`, pairs `v1:0`…, predicates `q0`-`q3` |
| Lanes | The element type is written on the register: `.b` byte, `.h` halfword, `.w` word, `.ub`/`.uh` unsigned, `.sf`/`.hf` float |
| Contexts | Fewer HVX contexts than scalar threads; a thread must own one to run HVX code |
| Issue | HVX instructions sit in packets with scalar ones and use their own vector resources |

With 128-byte vectors one register holds 128 bytes, 64 halfwords or 32 words.

```text
// illustrative: c[i] = a[i] + b[i] for 32 words at a time (128-byte HVX)
{ v0 = vmem(r0++#1) }                 // load 128 bytes, advance by one vector
{ v1 = vmem(r1++#1) }
{ v2.w = vadd(v0.w, v1.w) }           // 32 word adds
{ vmem(r2++#1) = v2 }                 // store 128 bytes
```

| HVX operation family | Example |
| --- | --- |
| Arithmetic | `v2.h = vadd(v0.h, v1.h):sat` |
| Multiply / multiply-accumulate | `v3:2.w += vmpy(v0.h, v1.h)` (widening into a pair) |
| Compare into a vector predicate | `q0 = vcmp.gt(v0.w, v1.w)` |
| Predicated select | `v2 = vmux(q0, v0, v1)` |
| Permute / shuffle | `vshuff`, `vdeal`, `valign`, `vlut` |
| Reduce, saturate, narrow | `vasr`, `vsat`, `vpack` |

```mermaid
flowchart LR
    A["v0.w: a0 a1 ... a31"] --> ADD["vadd(.w)"]
    B["v1.w: b0 b1 ... b31"] --> ADD
    ADD --> R["v2.w: a0+b0 ... a31+b31"]
```

### HVX Floating Point

From V68, HVX can do floating point. LLVM has two feature switches: `hvx-qfloat` (Qualcomm's "qfloat" format with extra internal precision, converted to IEEE when stored) and `hvx-ieee-fp` (IEEE half and single precision arithmetic).

**Sources:** [llvm/lib/Target/Hexagon/Hexagon.td:32-96](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/Hexagon.td#L32-L96), [llvm/lib/Target/Hexagon/HexagonRegisterInfo.td:521](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonRegisterInfo.td#L521)

## Alignment

```mermaid
flowchart TD
    A["Memory access"] --> S{"Scalar or vector?"}
    S -->|"scalar memh/memw/memd"| N{"Address multiple of size?"}
    N -->|"yes"| OK["OK"]
    N -->|"no"| X["Misaligned access exception"]
    S -->|"vector vmem"| V["Address rounded down to the vector size<br/>(low bits ignored)"]
    S -->|"vector vmemu"| U["Unaligned load, costs more"]
```

| Access | Rule |
| --- | --- |
| `memh` / `memw` / `memd` | Must be 2-, 4-, 8-byte aligned; otherwise an exception |
| `vmem` | Treated as aligned to the vector size: low address bits are ignored, so a misaligned pointer silently reads the wrong bytes |
| `vmemu` | Unaligned vector load; slower |
| `valign` / `vlalign` | Combine two aligned loads into one unaligned vector, the usual fast technique |

Practical rule: align buffers for HVX to 128 bytes (`__attribute__((aligned(128)))` or an aligned allocator).

## Key Points

- Scalar FP uses general registers and pairs; HVX adds 32 vector registers of 64 or 128 bytes.
- HVX lanes are typed by suffix (`.b`, `.h`, `.w`, `.sf`); `q` registers mask lanes; V68+ adds vector FP.
- Scalar accesses must be naturally aligned; `vmem` silently aligns; use `vmemu` or `valign` for unaligned data.