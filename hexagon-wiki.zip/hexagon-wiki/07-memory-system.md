# Caches, MMU and Glossary

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td)
- Qualcomm: *Hexagon V6x/V7x Programmer's Reference Manual* (memory system) and *System-Level Specification*

</details>

Hexagon has a conventional cache hierarchy plus a fast local memory for vectors (VTCM), and an MMU that the real-time OS (QuRT) programs. Application code mostly meets the memory system through a handful of cache instructions: prefetch, clean, invalidate and zero.

> Cache sizes, associativity and MMU details vary by chip and are described generally here from Qualcomm's public manuals. Instruction names are cited from LLVM. Assembly is illustrative.

## Purpose and Scope

This page covers the memory hierarchy, VTCM, cache maintenance and prefetch instructions, the MMU and privilege model, and a glossary of the whole wiki.

## Memory Hierarchy

```mermaid
flowchart TD
    T["Hardware threads"] --> L1I["L1 instruction cache"]
    T --> L1D["L1 data cache (scalar)"]
    H["HVX unit"] -->|"vector loads bypass L1D"| L2["L2 cache (unified, shared by threads)"]
    H --> VT["VTCM: vector tightly coupled memory<br/>software-managed, low latency"]
    L1D --> L2
    L1I --> L2
    L2 --> DDR["System DRAM via the SoC interconnect"]
```

| Level | Notes (general) |
| --- | --- |
| L1 I / L1 D | Small, per core, shared by the core's threads |
| L2 | Larger, unified; HVX loads and stores go here rather than L1 D |
| VTCM | On-chip memory for HVX data; not a cache: software copies data in and out (often with DMA) |
| DRAM | Shared with the CPU and GPU |

## Cache Instructions

| Instruction | Effect | Typical use |
| --- | --- | --- |
| `dcfetch(r0)` / `dcfetch(r0+#n)` | Hint: bring a line into the data cache | Software prefetch |
| `l2fetch(r0, r1)` | Background prefetch of a 2-D block into L2 (width, height, stride in `r1`) | Prefetch image tiles ahead of an HVX loop |
| `dccleana(r0)` | Write a dirty line back to memory | Before another agent reads the buffer |
| `dcinva(r0)` | Invalidate a line, dropping its data | After another agent wrote the buffer |
| `dczeroa(r0)` | Allocate a line and fill it with zero, without reading memory | Fast zeroing of output buffers |
| `icinva(r0)` + `isync` | Invalidate instruction cache line, then resynchronise | After writing code |
| `barrier`, `syncht` | Order or drain memory operations | Synchronisation with other threads or devices |

```mermaid
sequenceDiagram
    participant D as DSP thread
    participant C as Cache
    participant M as Shared memory
    participant X as Other agent (CPU, DMA)
    D->>C: write results (dirty lines)
    D->>C: dccleana each line
    C->>M: write back
    D->>X: signal "buffer ready"
    X->>M: read results
    X->>M: write new input
    D->>C: dcinva each line (drop stale copies)
    D->>M: read new input
```

**Sources:** [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td:41156-41214](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td#L41156-L41214), [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td:41263](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td#L41263), [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td:41326-41374](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td#L41326-L41374), [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td:41490](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td#L41490), [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td:41611-41710](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td#L41611-L41710)

## MMU and Privilege

Hexagon has an MMU, managed by the operating system rather than by applications.

| Feature (general) | Description |
| --- | --- |
| Software-managed TLB | The OS fills a joint TLB on misses; no hardware page-table walker on classic designs |
| Page sizes | Several sizes, from small pages up to large ones for big buffers |
| Per-page attributes | Read/write/execute, user/supervisor, cacheability |
| Address-space IDs | Tag TLB entries per process, avoiding flushes on switches |
| Modes | User, guest-OS (supervisor), and monitor, with system registers only accessible above user mode |

```mermaid
flowchart LR
    VA["Virtual address"] --> TLB{"TLB hit?"}
    TLB -->|"yes"| PA["Physical address + attributes"]
    TLB -->|"no"| EX["TLB-miss exception"] --> OS["QuRT fills the TLB entry"] --> TLB
```

Background on paging and TLBs: [OS wiki: Memory Management](../os-wiki/os-wiki.html#memory).

## Glossary

| Term | Meaning | Page |
| --- | --- | --- |
| `.new` | Use a value produced in the same packet | [ISA Fundamentals](#fundamentals) |
| `:endloop0` | Marks the last packet of hardware loop 0 | [ISA Fundamentals](#fundamentals) |
| Constant extender | `immext` word supplying the high 26 bits of an immediate | [Encoding](#encoding) |
| Duplex | One word containing two 13-bit sub-instructions | [Encoding](#encoding) |
| FastRPC | Mechanism for CPU code to call DSP code | [Overview](#overview) |
| HVX | Hexagon Vector eXtensions, 64/128-byte SIMD | [FP, HVX and Alignment](#hvx) |
| HVX context | A set of vector registers a thread must hold to run HVX | [FP, HVX and Alignment](#hvx) |
| `l2fetch` | Background 2-D prefetch into L2 | this page |
| `lc0`/`sa0` | Loop count / start address of hardware loop 0 | [Registers](#registers) |
| Packet | Up to four instructions issued together | [ISA Fundamentals](#fundamentals) |
| Parse bits | Bits 15:14 marking packet end, loop end, or duplex | [Encoding](#encoding) |
| Predicate register | `p0`-`p3`, comparison results | [Registers](#registers) |
| QuRT | Qualcomm's real-time OS on Hexagon | [Overview](#overview) |
| Slot | One of four execution positions in a packet | [ISA Fundamentals](#fundamentals) |
| `usr` | User status register (flags, rounding) | [Registers](#registers) |
| VLIW | Very long instruction word: compiler-scheduled parallel issue | [Overview](#overview) |
| `vmem` / `vmemu` | Aligned / unaligned vector memory access | [FP, HVX and Alignment](#hvx) |
| VTCM | Software-managed local memory for HVX | this page |

## Key Points

- L1 caches serve scalar code; HVX goes to L2 and VTCM, which software manages.
- Prefetch, clean, invalidate and zero instructions keep data where it is needed and coherent with other agents.
- The OS-managed MMU uses a software-filled TLB with per-page attributes and address-space IDs.