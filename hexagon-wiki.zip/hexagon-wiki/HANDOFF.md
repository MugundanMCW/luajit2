# Handoff: Hexagon Programmer Model Wiki

## Status

- 7 beginner pages (`01-overview.md` … `07-memory-system.md`). HTML at `hexagon-wiki/hexagon-wiki.html`, built with `python %TEMP%\rawiki\wiki_build.py hexagon`: 7 sections, 19 Mermaid diagrams, 46 citations in 8 LLVM Hexagon backend files with 0 range problems, 0 cross-wiki link problems, 4 external links all HTTP 200.
- The `"hexagon"` entry is in `WIKIS` in `%TEMP%\rawiki\wiki_build.py`. The title has no apostrophe ("Hexagon Programmer Model") because an apostrophe breaks the generated build script.
- **Not done:** not added to `llvm-backend-guide.zip`.

## What was checked, and what was not

- **Checked against `llvm/lib/Target/Hexagon` at commit a2171756** (line numbers from searches, content read): register names and aliases (`r29`/`r30`/`r31` = `sp`/`fp`/`lr`), predicate and control registers, `HvxQR`/`DoubleRegs` classes, parse-bit values, extender/duplex fields, architecture versions V5-V81, HVX features, and instruction strings (`immext`, `loop0`, `endloop0`, `memw`, `memw_locked`, `dcfetch`, `dccleana`, `dcinva`, `dczeroa`, `icinva`, `isync`, `syncht`, `l2fetch`).
- **Not verified from a source** (written from general knowledge of Qualcomm's public Hexagon manuals, and labelled general on the pages): slot assignments per class, the 26/6-bit extender split, 13-bit duplex sub-instructions, ABI callee-/caller-saved ranges, cache hierarchy and VTCM behaviour, MMU and TLB details, thread and HVX-context counts. The `IntRegs`, `PredRegs`, `CtrRegs`, `HvxVR`, `HvxWR` class names are used but their definition lines were not looked up. Check these against the Qualcomm reference manuals before relying on them.
- **Not assembled:** all Hexagon assembly is illustrative; the local LLVM build targets only AArch64 and X86.

## Page ids

overview, fundamentals, registers, encoding, instructions, hvx, memory-system