# Registers

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/Hexagon/HexagonRegisterInfo.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonRegisterInfo.td)
- [llvm/lib/Target/Hexagon/HexagonCallingConv.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonCallingConv.td)
- Qualcomm: *Hexagon Application Binary Interface User Guide*

</details>

Hexagon has a small, regular register model: 32 general registers that can also be used as 16 pairs, 4 predicate registers, a set of control registers, and (with HVX) 32 wide vector registers with 4 vector predicates.

## Purpose and Scope

This page covers each register file, register pairs, the control registers, the HVX registers, and the calling-convention roles. How instructions use them is on [Data, Memory and Control](#instructions).

## The Register Files

```mermaid
flowchart TB
    subgraph Scalar["Scalar core (per hardware thread)"]
        R["R0-R31: 32 x 32-bit general<br/>(pairs R1:0 ... R31:30 = 64-bit)"]
        P["P0-P3: 4 x 8-bit predicates"]
        C["C0-C31: control registers<br/>loops, USR, PC, GP, CS, timers"]
    end
    subgraph Vec["HVX (per vector context)"]
        V["V0-V31: 64 or 128 bytes each<br/>(pairs W = V1:0 ... V31:30)"]
        Q["Q0-Q3: vector predicates"]
    end
```

| File | Count | Width | LLVM register class |
| --- | --- | --- | --- |
| General | 32 (`r0`-`r31`) | 32 bits | `IntRegs` |
| General pairs | 16 (`r1:0` … `r31:30`) | 64 bits | `DoubleRegs` (holds `i64`, `f64`, small vectors) |
| Predicate | 4 (`p0`-`p3`) | 8 bits | `PredRegs` |
| Control | `c0`-`c31` (not all defined) | 32 bits | `CtrRegs` |
| HVX vector | 32 (`v0`-`v31`) | 512 or 1024 bits | `HvxVR` |
| HVX pairs | 16 (`v1:0` …) | 2 × vector | `HvxWR` |
| HVX predicate | 4 (`q0`-`q3`) | 1 bit per vector byte | `HvxQR` |

**Sources:** [llvm/lib/Target/Hexagon/HexagonRegisterInfo.td:222](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonRegisterInfo.td#L222), [llvm/lib/Target/Hexagon/HexagonRegisterInfo.td:273-276](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonRegisterInfo.td#L273-L276), [llvm/lib/Target/Hexagon/HexagonRegisterInfo.td:521](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonRegisterInfo.td#L521), [llvm/lib/Target/Hexagon/HexagonRegisterInfo.td:552](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonRegisterInfo.td#L552)

## General Registers and Pairs

Three general registers have fixed jobs, defined with these aliases in LLVM:

| Register | Alias | Role |
| --- | --- | --- |
| `r29` | `sp` | Stack pointer |
| `r30` | `fp` | Frame pointer |
| `r31` | `lr` | Link register (return address, set by `call`) |

A pair `r1:0` is two consecutive registers used as one 64-bit value, high half in the odd register. Pairs must start at an even register.

```mermaid
flowchart LR
    PR["r1:0 (64-bit)"] --> HI["r1 = bits 63..32"]
    PR --> LO["r0 = bits 31..0"]
```

**Sources:** [llvm/lib/Target/Hexagon/HexagonRegisterInfo.td:116-118](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonRegisterInfo.td#L116-L118)

## Predicate Registers

`p0`-`p3` hold results of comparisons. They are 8 bits wide so that vector compares on 8 bytes (`vcmpb`) set one bit per byte; scalar compares set all bits. They drive conditional instructions, conditional jumps and `.new` forwarding ([ISA Fundamentals](#fundamentals)). Together they are also readable as control register `c4` (`p3:0`).

**Sources:** [llvm/lib/Target/Hexagon/HexagonRegisterInfo.td:141-144](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonRegisterInfo.td#L141-L144)

## Control Registers

| Number | Name | Purpose |
| --- | --- | --- |
| c0, c1 | `sa0`, `lc0` | Hardware loop 0: start address, loop count |
| c2, c3 | `sa1`, `lc1` | Hardware loop 1 |
| c4 | `p3:0` | All four predicates together |
| c6, c7 | `m0`, `m1` | Modifier registers for post-increment and circular addressing |
| c8 | `usr` | User status register: overflow flags, floating-point flags and rounding mode, loop configuration |
| c9 | `pc` | Program counter (read-only) |
| c10 | `ugp` | User general pointer (thread-local storage base) |
| c11 | `gp` | Global pointer for GP-relative small-data addressing |
| c12, c13 | `cs0`, `cs1` | Circular buffer start addresses |
| c14 | `upcyclelo` | Cycle counter (low; c15 high) |
| c16, c17 | `framelimit`, `framekey` | Stack overflow check limit, return-address scrambling key |
| c18 | `pktcountlo` | Packet counter |
| c30 | `utimerlo` | User timer |

Control registers are moved with `r0 = c8` style transfers (or by name, `r0 = usr`). Supervisor-only system registers exist in addition (see [Caches, MMU](#memory-system)).

**Sources:** [llvm/lib/Target/Hexagon/HexagonRegisterInfo.td:152-185](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonRegisterInfo.td#L152-L185)

## HVX Registers

Each `v` register is one full vector: 64 bytes in 64-byte mode or 128 bytes in 128-byte mode, chosen by the chip and `-mhvx-length`. The same register holds 128 bytes, 64 halfwords or 32 words (in 128-byte mode). `q` registers hold one bit per byte lane and act as masks. More on [FP, HVX and Alignment](#hvx).

## Calling Convention Roles

In the standard Hexagon ABI (general description; see the ABI guide):

| Registers | Role |
| --- | --- |
| `r0`-`r5` | First six 32-bit arguments (64-bit values in aligned pairs) |
| `r0` (`r1:0`) | Return value |
| `r6`-`r15`, `r28` | Caller-saved temporaries |
| `r16`-`r27` | Callee-saved |
| `r29`, `r30`, `r31` | `sp`, `fp`, `lr` |

LLVM's calling-convention description assigns `i32` and `i64` (and small vector) values to registers by type in this order; values that do not fit go on the stack.

**Sources:** [llvm/lib/Target/Hexagon/HexagonCallingConv.td:19-32](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonCallingConv.td#L19-L32)

## Key Points

- 32 general registers (`r29`/`r30`/`r31` = `sp`/`fp`/`lr`), usable as 64-bit even/odd pairs.
- 4 predicate registers drive conditional execution; control registers hold loops, `usr`, `pc`, `gp`, modifiers.
- HVX adds 32 wide vector registers, vector pairs, and 4 vector predicates.