# Instruction Encoding and Mnemonics

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/Hexagon/MCTargetDesc/HexagonBaseInfo.h](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/MCTargetDesc/HexagonBaseInfo.h)
- [llvm/lib/Target/Hexagon/HexagonInstrFormats.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonInstrFormats.td)
- [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td)
- Qualcomm: *Hexagon V6x/V7x Programmer's Reference Manual*, instruction encoding chapter

</details>

Every Hexagon instruction is one 32-bit word. Two bits inside each word, the **parse bits**, say where the packet ends, so the hardware can find packet boundaries without a separate header. Two tricks make code smaller and constants bigger: **duplexes** (two short instructions in one word) and **constant extenders** (an extra word that widens an immediate).

> Assembly on this page is illustrative and was not assembled.

## Purpose and Scope

This page covers the assembly syntax, the 32-bit word layout, parse bits, constant extenders, and duplexes. The instructions themselves are on [Data, Memory and Control](#instructions).

## Assembly Syntax: Algebraic Mnemonics

Hexagon assembly reads like assignments rather than opcode lists:

| Hexagon | Meaning | Typical other-ISA style |
| --- | --- | --- |
| `r0 = add(r1, r2)` | r0 = r1 + r2 | `add r0, r1, r2` |
| `r0 = memw(r1 + #8)` | load word | `ldr r0, [r1, #8]` |
| `memw(r1 + #8) = r0` | store word | `str r0, [r1, #8]` |
| `p0 = cmp.eq(r0, #5)` | compare | `cmp r0, #5` |
| `if (p0) jump target` | conditional branch | `beq target` |
| `r1:0 = memd(r2)` | 64-bit load into a pair | |
| `{ ... }` | a packet | |

Suffixes add meaning: `:sat` (saturate), `:rnd` (round), `:t`/`:nt` (branch hints), `.new` (same-packet value), `:endloop0` (loop end). LLVM's instruction definitions contain these strings directly, for example `"memw($Rs32+#$Ii) = $Rt32"` and `"loop0($Ii,#$II)"`.

**Sources:** [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td:5639](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td#L5639), [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td:21720](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td#L21720)

## The 32-bit Word

```mermaid
flowchart LR
    W["32-bit instruction word"] --> IC["bits 31..28<br/>ICLASS: instruction class"]
    W --> MID["bits 27..16<br/>opcode, registers, immediates"]
    W --> PB["bits 15..14<br/>PARSE bits"]
    W --> LOW["bits 13..0<br/>more fields"]
```

The class field selects the instruction group (loads, stores, ALU, jumps, ...); the remaining fields depend on the class.

## Parse Bits

| Bits 15:14 | LLVM name | Meaning |
| --- | --- | --- |
| `11` | `INST_PARSE_PACKET_END` | Last instruction of the packet |
| `10` | `INST_PARSE_LOOP_END` | Not last; marks a hardware-loop end (with position in the packet) |
| `01` | `INST_PARSE_NOT_END` | Not last; more instructions follow |
| `00` | `INST_PARSE_DUPLEX` | This word is a duplex (also used for extenders) |

```mermaid
flowchart LR
    I0["word 0<br/>parse 01"] --> I1["word 1<br/>parse 01"] --> I2["word 2<br/>parse 11 = end"]
    I2 --> N["next packet starts here"]
```

The `:endloop0` marker is not an instruction: it is encoded in the parse bits of the first and second words of the last packet of the loop.

**Sources:** [llvm/lib/Target/Hexagon/MCTargetDesc/HexagonBaseInfo.h:280-285](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/MCTargetDesc/HexagonBaseInfo.h#L280-L285)

## Constant Extenders

Instructions have only small immediate fields. For a full 32-bit constant or address, the assembler places an **extender** word, written `immext(#value)`, just before the instruction. The extender supplies the upper 26 bits and the instruction's own field supplies the low 6 bits. It uses one of the packet's four word positions.

```text
// illustrative
{ r0 = ##0x12345678 }          // "##" asks for an extended immediate
// encodes as two words: immext(#0x12345640); r0 = #0x38
```

LLVM records, per instruction, whether an operand is extendable and where (`ExtendedPos`) and how wide the field is (`ExtentBitsPos`).

**Sources:** [llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td:2604](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonDepInstrInfo.td#L2604), [llvm/lib/Target/Hexagon/MCTargetDesc/HexagonBaseInfo.h:132-141](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/MCTargetDesc/HexagonBaseInfo.h#L132-L141)

## Duplexes

Many common instructions (small adds, short loads and stores, moves, returns) have 13-bit **sub-instruction** forms. Two of them can be packed into one 32-bit **duplex** word, marked by parse bits `00`. The assembler does this automatically, which shrinks code significantly. A duplex occupies slots 0 and 1.

```mermaid
flowchart LR
    D["duplex word (parse bits 00)"] --> H["high sub-instruction<br/>e.g. r0 = memw(r1)"]
    D --> L["low sub-instruction<br/>e.g. r2 = add(r2, #1)"]
```

**Sources:** [llvm/lib/Target/Hexagon/HexagonInstrFormats.td:271-274](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonInstrFormats.td#L271-L274)

## Key Points

- Each instruction is 32 bits; parse bits 15:14 mark packet end, loop end, or duplex.
- `immext` extender words widen immediates to 32 bits; duplexes pack two short instructions in one word.
- Assembly is algebraic: `r0 = add(r1, r2)`, `memw(r1+#4) = r0`.