# ISA Fundamentals: Packets, Slots and Threads

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/Hexagon/HexagonInstrFormats.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonInstrFormats.td)
- [llvm/lib/Target/Hexagon/HexagonPseudo.td](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonPseudo.td)
- [Wikipedia: Barrel processor](https://en.wikipedia.org/wiki/Barrel_processor)
- Qualcomm: *Hexagon V6x/V7x Programmer's Reference Manual*, chapters on packets and pipeline

</details>

The single most important idea in Hexagon is the **packet**: a group of one to four instructions, written between `{` and `}`, that the hardware issues together. Everything else (slots, `.new` values, hardware loops) follows from it.

> Assembly on this page is illustrative and was not assembled.

## Purpose and Scope

This page covers packets and their rules, execution slots and instruction classes, reading values inside a packet (`.new`), predication, zero-overhead hardware loops, and hardware threads. Bit-level encoding is on [Encoding and Mnemonics](#encoding).

## The Team Analogy

| Kitchen team | Hexagon |
| --- | --- |
| A ticket listing up to four jobs that start together | A packet |
| Four stations, each able to do certain jobs | Slots 0-3 |
| Chef plans the tickets in advance | The compiler schedules packets |
| A job can use a result another job on the same ticket just made | `.new` operands |
| Several orders cooking at once, taking turns at the stations | Hardware threads |

## Packets

```text
// illustrative: four instructions issued together
{
  r1 = add(r2, r3)          // ALU
  r4 = memw(r5 + #8)        // load
  memw(r6 + #0) = r7        // store
  p0 = cmp.eq(r8, #0)       // compare
}
```

```mermaid
flowchart LR
    P["Packet {i0; i1; i2; i3}"] --> S3["Slot 3"]
    P --> S2["Slot 2"]
    P --> S1["Slot 1"]
    P --> S0["Slot 0"]
    S3 --> E["All instructions read operands,<br/>execute, then write results together"]
    S2 --> E
    S1 --> E
    S0 --> E
```

Rules that follow from "issued together":

| Rule | Consequence |
| --- | --- |
| Instructions in a packet see register values from **before** the packet | `{ r0 = r1; r1 = r0 }` swaps the two registers |
| Two instructions may not write the same register | The assembler rejects it |
| Resource limits per packet | At most two memory operations, one branch, limited slot types |
| The packet is atomic for interrupts | An interrupt is taken between packets, never inside one |

**Sources:** [llvm/lib/Target/Hexagon/HexagonInstrFormats.td:50](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonInstrFormats.td#L50)

## Slots and Instruction Classes

Each instruction belongs to a class that says which slots can run it. In general:

| Class | Typical instructions | Slots (general) |
| --- | --- | --- |
| LD (load) | `memw`, `memb`, `memd` reads | 0, 1 |
| ST (store) | stores | 0, 1 |
| ALU32 | add, sub, logical, simple moves, compares | 0-3 |
| XTYPE (complex) | multiply, shift, bit manipulation, 64-bit ops | 2, 3 |
| J (jump) | branches, calls | 2, 3 |
| CR (control register) | loops, predicate logic | 3 |
| HVX | vector instructions, with their own resources | see [HVX](#hvx) |

LLVM's instruction descriptions carry flags for these constraints, for example a flag restricting slot 1 to ALU-only instructions and one marking instructions that prefer slot 3.

**Sources:** [llvm/lib/Target/Hexagon/HexagonInstrFormats.td:75-77](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonInstrFormats.td#L75-L77), [llvm/lib/Target/Hexagon/HexagonInstrFormats.td:151-152](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonInstrFormats.td#L151-L152)

## Using a Result in the Same Packet: .new

Normally a packet only sees old values. A few instructions may consume a value produced *in the same packet* by writing `.new`:

```text
// illustrative
{ p0 = cmp.eq(r0, #0)              // produce predicate
  if (p0.new) jump:t done }        // use it in the same packet ("dot-new predicate")

{ r2 = add(r1, #1)
  memw(r3 + #0) = r2.new }         // store the value computed this packet ("new-value store")
```

```mermaid
sequenceDiagram
    participant C as cmp.eq (slot 2)
    participant J as jump (slot 3)
    C->>J: p0 forwarded inside the packet (.new)
    Note over C,J: without .new, the jump would see p0 from before the packet
```

`:t` / `:nt` are static branch hints (taken / not taken).

## Predication

Most instructions can be made conditional on a predicate register, which removes short branches:

```text
// illustrative: r0 = (r1 > r2) ? r3 : r4, without a branch
{ p0 = cmp.gt(r1, r2) }
{ if (p0)  r0 = add(r3, #0)
  if (!p0) r0 = add(r4, #0) }
```

The two writes to `r0` are allowed in one packet because their predicates are complementary.

## Zero-Overhead Hardware Loops

```text
// illustrative: sum 64 words
{ loop0(.Lbody, #64)          // start address, iteration count
  r0 = #0 }
.Lbody:
{ r1 = memw(r2++#4)
  r0 = add(r0, r1) }:endloop0 // end-of-loop marker; no branch instruction
```

```mermaid
flowchart LR
    L["loop0(start, N):<br/>SA0 = start, LC0 = N"] --> B["Loop body packets"]
    B --> E{"Packet marked :endloop0"}
    E -->|"LC0 > 1: LC0--, jump to SA0"| B
    E -->|"LC0 = 1: fall through"| X["After loop"]
```

There are two loops, `loop0` and `loop1` (which can nest), using control registers SA0/LC0 and SA1/LC1 ([Registers](#registers)). The end of the loop is marked by bits in the last packet's encoding, not by a branch, so the loop costs no extra cycles.

**Sources:** [llvm/lib/Target/Hexagon/HexagonPseudo.td:92-107](https://github.com/llvm/llvm-project/blob/a2171756dd5d690faf30bafe63810d1dc6cdb342/llvm/lib/Target/Hexagon/HexagonPseudo.td#L92-L107)

## Hardware Threads

A Hexagon core runs several hardware threads and interleaves their packets, so while one thread waits for memory others keep the pipeline busy. This resembles a **barrel processor**. Each thread has its own register set; caches and execution units are shared. HVX contexts are a separate, smaller pool that threads must acquire. See the [Architecture wiki: Multithreading](../arch-wiki/arch-wiki.html#multithreading).

**Sources:** [Wikipedia: Barrel processor](https://en.wikipedia.org/wiki/Barrel_processor)

## Key Points

- A packet of up to four instructions reads old values, executes together and writes together.
- Slots limit which instruction classes share a packet; `.new` passes a value within a packet.
- Predication and zero-overhead `loop0`/`loop1` remove most branch cost; hardware threads hide latency.