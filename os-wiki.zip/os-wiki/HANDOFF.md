# Handoff: Operating Systems Interview Wiki

## Status

- 11 beginner, interview-focused pages written (`01-overview.md` … `11-interview-qa.md`). HTML built at `os-wiki/os-wiki.html` with `python %TEMP%\rawiki\wiki_build.py os`: 11 sections, 11 nav entries, 54 Mermaid diagrams, 0 cross-wiki link problems.
- The `"os"` entry is in the `WIKIS` table of `%TEMP%\rawiki\wiki_build.py`.
- **Not done:** the wiki is not in `llvm-backend-guide.zip` (left alone, as with the IR and architecture wikis).

## Page format

Each page: everyday analogy, diagrams, a worked problem where interviews use one, "Common traps", "Interview questions" with model answers, "Key points". Page 11 is a quick-fire question bank, a problem-practice checklist and the glossary.

## How the content was checked

- All 43 Wikipedia links in the built HTML returned HTTP 200 (fetched with `curl --ssl-no-revoke`; the Windows certificate revocation check fails on this network). URLs with parentheses are written as `%28`/`%29`, because `build_html.py` cuts Markdown links at the first `)`.
- Computed with a Python script: page-replacement fault counts (FIFO/LRU/OPT, including the frame-by-frame tables), Bélády's anomaly, disk-scheduling totals, the banker's algorithm safe sequence and both follow-up requests, and TLB effective access time.
- Worked by hand and re-checked by hand (no script): the CPU-scheduling Gantt charts and averages on page 4, the `fork` count, address translation, and the page-fault EAT example.
- Code (C, POSIX, Arm assembly) is illustrative and was not compiled or run.
- Textbooks are named by chapter only.

## Conventions stated in worked problems

- Round Robin: a process arriving during a quantum joins the queue before the preempted process.
- SCAN/LOOK start moving toward cylinder 0; C-SCAN/C-LOOK move toward 199, and the return jump is counted (the C-SCAN total without the jump is also given).

## Page ids

overview, processes, threads, scheduling, synchronization, deadlock, memory, virtual-memory, files-io, kernel, interview-qa

## To add to the combined guide

Add a tuple for `os-wiki` to `WIKIS` in `%TEMP%\rawiki\guide_build.py`, then run `python %TEMP%\rawiki\guide_build.py`.