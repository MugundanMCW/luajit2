# Operating Systems Overview

<details>
<summary>Relevant source files</summary>

The following references were used as context for generating this wiki page:

- [Wikipedia: Operating system](https://en.wikipedia.org/wiki/Operating_system)
- [Wikipedia: Kernel (operating system)](https://en.wikipedia.org/wiki/Kernel_%28operating_system%29)
- [Wikipedia: System call](https://en.wikipedia.org/wiki/System_call)
- Book: Silberschatz, Galvin and Gagne, *Operating System Concepts*
- Book: Arpaci-Dusseau and Arpaci-Dusseau, *Operating Systems: Three Easy Pieces* (free online)

</details>

An operating system (OS) is the program that manages a computer's hardware and lets other programs share it safely. It decides which program runs on the CPU, gives each program its own memory, keeps files on disk, talks to devices, and stops programs from interfering with each other. This wiki explains the core ideas for complete beginners and is organised around the questions asked in operating systems interviews.

> **How to read this wiki.** Each page has an everyday analogy, diagrams, a worked problem where interviews use one, a "Common traps" list and a short set of interview questions with model answers. Diagrams, code and numbers are illustrative. Worked problems were calculated by hand for this wiki.

## Purpose and Scope

| # | Page | Interview topics |
| --- | --- | --- |
| 1 | [Overview](#overview) | What an OS does, kernel vs user mode, the big picture |
| 2 | [Processes](#processes) | Process states, PCB, context switch, `fork`/`exec`/`wait`, zombies, IPC |
| 3 | [Threads](#threads) | Thread vs process, user vs kernel threads, what threads share |
| 4 | [CPU Scheduling](#scheduling) | FCFS, SJF, SRTF, Round Robin, priority, MLFQ, worked Gantt charts |
| 5 | [Synchronization](#synchronization) | Race conditions, mutex, semaphore, condition variable, classic problems |
| 6 | [Deadlock](#deadlock) | Four conditions, prevention, avoidance (banker's), detection, priority inversion |
| 7 | [Memory Management](#memory) | Fragmentation, paging, segmentation, page tables, TLB |
| 8 | [Virtual Memory](#virtual-memory) | Demand paging, page faults, replacement (FIFO, LRU, OPT), thrashing, copy-on-write |
| 9 | [Files and I/O](#files-io) | Inodes, links, journaling, disk scheduling, interrupts, DMA |
| 10 | [Kernel and System Calls](#kernel) | System call path, interrupts vs traps, monolithic vs microkernel, boot |
| 11 | [Interview Q&A and Glossary](#interview-qa) | Quick-fire questions and all terms in one place |

The hardware side (caches, cores, memory ordering) is in the [Computer Architecture wiki](../arch-wiki/arch-wiki.html#overview).

## The Hotel Analogy

| Hotel | Operating system |
| --- | --- |
| Guests | Programs (processes) |
| Front desk | The kernel |
| Rooms, each with its own key | Each process's private memory (address space) |
| Shared facilities: lift, pool, kitchen | CPU, disk, network, devices |
| Booking the pool by time slots | CPU scheduling |
| "Ask the front desk; don't go into the boiler room" | System calls; user mode cannot touch hardware directly |
| Security stops one guest entering another's room | Memory protection |

## What an OS Does

```mermaid
flowchart TD
    OS["Operating system"] --> P["Process management<br/>create, schedule, terminate"]
    OS --> M["Memory management<br/>virtual memory, protection"]
    OS --> F["File systems<br/>files, directories, permissions"]
    OS --> IO["Device / I/O management<br/>drivers, interrupts"]
    OS --> S["Security and protection<br/>users, permissions, isolation"]
    OS --> N["Networking<br/>sockets, protocols"]
```

Two ways to describe the OS's job:

- **Resource manager**: shares limited CPU time, memory and devices fairly and efficiently between many programs.
- **Abstraction provider**: gives programs simple, portable ideas (processes, files, sockets, virtual memory) instead of raw hardware.

## The Layers

```mermaid
flowchart TB
    U["User programs<br/>browser, shell, your code"] --> L["Libraries<br/>libc, runtime"]
    L -->|"system calls"| K["Kernel<br/>scheduler, memory manager, file systems, drivers"]
    K --> H["Hardware<br/>CPU, memory, disk, network"]
    style K fill:#eef
```

| Mode | Who runs in it | What it may do |
| --- | --- | --- |
| **User mode** | Applications and libraries | Ordinary instructions only; cannot touch devices or other processes' memory |
| **Kernel mode** (supervisor) | The kernel | Everything: configure the MMU, talk to devices, disable interrupts |

The CPU enforces the two modes in hardware (on Arm, exception levels EL0 for user and EL1 for kernel). A program enters the kernel only through a **system call**, an interrupt or an exception, covered in [Kernel and System Calls](#kernel).

**Sources:** [Wikipedia: Operating system](https://en.wikipedia.org/wiki/Operating_system), [Wikipedia: Kernel (operating system)](https://en.wikipedia.org/wiki/Kernel_%28operating_system%29)

## Key Terms at a Glance

| Term | One-line meaning |
| --- | --- |
| Program | Code sitting in a file |
| Process | A program being run: code + memory + open files + CPU state |
| Thread | One flow of execution inside a process |
| Kernel | The always-resident core of the OS that runs in kernel mode |
| System call | A request from a program to the kernel (`read`, `fork`, `mmap`) |
| Context switch | Saving one thread's CPU state and loading another's |
| Virtual memory | Each process sees its own private address space |

## How to Prepare for OS Interviews

| Interviewers often ask you to... | Practise on |
| --- | --- |
| Explain the difference between two things (process vs thread, mutex vs semaphore) | Every page's "Interview questions" |
| Work a small problem on a whiteboard (Gantt chart, banker's algorithm, page faults) | [Scheduling](#scheduling), [Deadlock](#deadlock), [Virtual Memory](#virtual-memory), [Files and I/O](#files-io) |
| Write synchronization code (producer-consumer, thread-safe counter) | [Synchronization](#synchronization) |
| Trace what happens end to end ("what happens when you run `ls`?") | [Kernel and System Calls](#kernel), [Interview Q&A](#interview-qa) |
| Count processes created by `fork()` | [Processes](#processes) |

## Interview Questions

1. **What is an operating system?** Software that manages hardware resources and provides common services and abstractions to programs.
2. **Why do we need user and kernel mode?** So a buggy or malicious program cannot crash the machine, read other programs' memory, or access devices directly; it must ask the kernel.
3. **Is the shell part of the kernel?** No. The shell is an ordinary user program that makes system calls such as `fork`, `exec` and `wait`.

## Key Points

- The OS manages CPU, memory, storage and devices, and provides processes, files and virtual memory.
- The kernel runs in privileged mode; programs reach it only through system calls, interrupts and exceptions.
- Interviews test definitions, comparisons, small worked problems and end-to-end traces.