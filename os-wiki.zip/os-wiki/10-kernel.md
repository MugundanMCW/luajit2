# Kernel and System Calls

<details>
<summary>Relevant source files</summary>

The following references were used as context for generating this wiki page:

- [Wikipedia: Kernel (operating system)](https://en.wikipedia.org/wiki/Kernel_%28operating_system%29)
- [Wikipedia: System call](https://en.wikipedia.org/wiki/System_call)
- [Wikipedia: Protection ring](https://en.wikipedia.org/wiki/Protection_ring)
- [Wikipedia: Microkernel](https://en.wikipedia.org/wiki/Microkernel)
- [Wikipedia: Monolithic kernel](https://en.wikipedia.org/wiki/Monolithic_kernel)
- [Wikipedia: Interrupt](https://en.wikipedia.org/wiki/Interrupt)
- Book: Silberschatz, Galvin and Gagne, *Operating System Concepts*, chapter 2

</details>

The kernel is the part of the OS that runs with full hardware privilege. Programs cannot call it like an ordinary function; they must cross a hardware-enforced boundary using a **system call**. This page explains how that crossing works, the three ways the CPU enters the kernel, how kernels are structured, and what happens when the machine boots. It finishes with the classic interview trace: "what happens when you type `ls` and press Enter?"

> Assembly and traces on this page are illustrative.

## Purpose and Scope

This page covers privilege levels, the system call path, interrupts versus traps versus exceptions, monolithic, micro- and hybrid kernels, loadable modules, the boot sequence, and an end-to-end trace. Device interrupts in detail are on [Files and I/O](#files-io).

## The Bank Counter Analogy

| Bank | Computer |
| --- | --- |
| Customers in the public hall | User-mode programs |
| The vault behind the counter | Kernel memory and hardware |
| Filling in a form and handing it through the window | A **system call** |
| The teller checks the form before acting | The kernel validates arguments |
| The fire alarm interrupts everyone | A hardware **interrupt** |
| A customer faints: staff must respond | An **exception** (fault) |

## Privilege Levels

```mermaid
flowchart TB
    subgraph Arm["Arm A-profile exception levels"]
        EL0["EL0: applications"]
        EL1["EL1: OS kernel"]
        EL2["EL2: hypervisor"]
        EL3["EL3: secure monitor / firmware"]
    end
    subgraph X86["x86 protection rings"]
        R3["Ring 3: applications"]
        R0["Ring 0: kernel"]
    end
```

User code that tries a privileged instruction (change the page table base, disable interrupts) causes an exception, and the kernel usually kills the program.

**Sources:** [Wikipedia: Protection ring](https://en.wikipedia.org/wiki/Protection_ring)

## The System Call Path

```c
// illustrative: what a program writes
write(1, "hi\n", 3);
```

```mermaid
sequenceDiagram
    participant A as Application (user mode)
    participant L as libc wrapper
    participant C as CPU
    participant K as Kernel (kernel mode)
    A->>L: write(1, "hi\n", 3)
    L->>L: put syscall number and arguments in registers
    L->>C: SVC #0 (Arm) / syscall (x86-64)
    C->>K: switch to kernel mode, jump to the fixed entry point
    K->>K: save user registers, look up syscall table[number]
    K->>K: sys_write: check fd, copy data from user memory safely
    K-->>C: put return value in a register
    C-->>L: return to user mode (ERET / sysret)
    L-->>A: return 3 (or -1 and set errno)
```

```text
// illustrative Arm64 Linux: write(1, msg, 3)
mov  x0, #1          // fd
adr  x1, msg         // buffer
mov  x2, #3          // count
mov  x8, #64         // syscall number for write on arm64 Linux
svc  #0              // trap into the kernel
```

Key points:

- Entry is only through a fixed, kernel-chosen address; programs can't jump into arbitrary kernel code.
- The kernel must **never trust user pointers**; it checks them and copies with special routines (`copy_from_user`).
- A system call costs far more than a function call (mode switch, register saving, cache and TLB effects), so programs batch work (buffered I/O in `stdio`).

| Category | Examples |
| --- | --- |
| Process control | `fork`, `execve`, `exit`, `wait4`, `kill` |
| Files | `open`, `read`, `write`, `close`, `lseek`, `stat` |
| Memory | `mmap`, `munmap`, `brk` |
| Communication | `pipe`, `socket`, `send`, `recv` |
| Information | `getpid`, `clock_gettime` |

Some calls such as `clock_gettime` are often served in user mode through the **vDSO**, a small kernel-provided library, without a real mode switch.

**Sources:** [Wikipedia: System call](https://en.wikipedia.org/wiki/System_call)

## Three Ways into the Kernel

| Kind | Caused by | Synchronous? | Examples |
| --- | --- | --- | --- |
| **Interrupt** | A device or timer, outside the program | No: can arrive at any time | Timer tick, disk done, network packet |
| **Trap** (software interrupt) | The program on purpose | Yes | System call (`SVC`, `syscall`), breakpoint |
| **Exception / fault** | The program by accident | Yes | Page fault, divide by zero, illegal instruction |

```mermaid
flowchart TD
    U["User code running"] --> I["Interrupt<br/>(device, timer)"]
    U --> T["Trap<br/>(system call)"]
    U --> F["Fault<br/>(page fault, bad instruction)"]
    I --> V["Exception vector table<br/>in the kernel"]
    T --> V
    F --> V
    V --> H["Handler runs in kernel mode"]
    H --> R{"Outcome"}
    R --> RE["Return to the same program"]
    R --> SW["Schedule another thread"]
    R --> KI["Kill the program (SIGSEGV, SIGILL)"]
```

The **timer interrupt** is what makes preemptive scheduling possible ([CPU Scheduling](#scheduling)).

**Sources:** [Wikipedia: Interrupt](https://en.wikipedia.org/wiki/Interrupt)

## Kernel Designs

```mermaid
flowchart TB
    subgraph Mono["Monolithic kernel"]
        direction TB
        MU["Apps"] --> MK["Kernel: scheduler, memory, file systems,<br/>drivers, network stack — all in kernel mode"]
    end
    subgraph Micro["Microkernel"]
        direction TB
        UU["Apps"] --> SV["User-mode servers:<br/>file system, drivers, network"]
        SV -->|"IPC messages"| UK["Small kernel: scheduling,<br/>address spaces, IPC"]
        UU -->|"IPC"| UK
    end
```

| | Monolithic | Microkernel | Hybrid |
| --- | --- | --- | --- |
| In kernel mode | Everything | Only the minimum | Most services, some in user space |
| Speed | Fast: direct function calls | Slower: IPC for every service | In between |
| A driver crash | Can crash the whole system | Restart the server; system survives | Depends |
| Examples | Linux, traditional Unix | seL4, QNX, MINIX 3 | Windows NT, macOS XNU |

Linux is monolithic but **modular**: drivers can be loaded and unloaded at run time as **loadable kernel modules** (`insmod`, `modprobe`), still running in kernel mode.

**Sources:** [Wikipedia: Monolithic kernel](https://en.wikipedia.org/wiki/Monolithic_kernel), [Wikipedia: Microkernel](https://en.wikipedia.org/wiki/Microkernel)

## Booting

```mermaid
flowchart LR
    P["Power on"] --> R["Boot ROM / firmware<br/>(UEFI or BIOS; on Arm, trusted firmware)"]
    R --> B["Bootloader<br/>(GRUB, U-Boot)"]
    B --> K["Kernel: set up memory, MMU,<br/>interrupts, drivers"]
    K --> M["Mount root file system"]
    M --> I["Start init (PID 1)<br/>(systemd)"]
    I --> S["Services, login, shell"]
```

## End-to-End Trace: Typing `ls` in a Shell

A favourite interview question. A good answer touches most of this wiki:

```mermaid
sequenceDiagram
    participant KB as Keyboard
    participant K as Kernel
    participant SH as Shell
    participant LS as ls process
    KB->>K: key interrupts; driver buffers characters
    K->>SH: Enter pressed: shell's blocked read() returns "ls\n"
    SH->>SH: parse command, search PATH for /bin/ls
    SH->>K: fork()
    K-->>LS: child created (copy-on-write pages)
    LS->>K: execve("/bin/ls")
    K->>K: load ELF: map code, set up stack, dynamic linker loads libc
    LS->>K: openat("."), getdents64(): read directory entries
    K->>K: file system reads inodes/blocks (page cache or disk, DMA, interrupt)
    LS->>K: write(1, names): terminal driver displays them
    LS->>K: exit(0)
    K->>SH: SIGCHLD; shell's waitpid() returns
    SH->>K: write prompt, read() again (blocks)
```

| Step | Concept | Page |
| --- | --- | --- |
| Keyboard interrupt, driver buffer | Interrupts | [Files and I/O](#files-io) |
| Shell blocked in `read` wakes up | Process states | [Processes](#processes) |
| `fork` + `execve` + `waitpid` | Process creation | [Processes](#processes) |
| Child gets the CPU | Scheduling | [CPU Scheduling](#scheduling) |
| Pages loaded lazily; COW after fork | Virtual memory | [Virtual Memory](#virtual-memory) |
| Directory read through inodes | File systems | [Files and I/O](#files-io) |
| Every request to the kernel | System calls | this page |

## Common Traps

- A system call is not a normal function call; it changes privilege level.
- Interrupts are asynchronous; traps and faults are caused by the current instruction.
- "Monolithic" does not mean "not modular"; Linux has loadable modules.
- The kernel is not a process that runs alongside others; it runs in the context of whichever thread trapped into it (plus its own kernel threads).

## Interview Questions

1. **What happens during a system call?** The library puts the call number and arguments in registers and executes a trap instruction; the CPU switches to kernel mode at a fixed entry point; the kernel saves state, dispatches through the syscall table, validates arguments, does the work, and returns to user mode with a result.
2. **Interrupt vs trap vs exception?** Interrupt: asynchronous, from hardware. Trap: deliberate, from an instruction (syscall). Exception/fault: accidental, from an instruction (page fault, divide by zero).
3. **Monolithic vs microkernel?** Monolithic runs all services in kernel mode (fast, less isolated); a microkernel keeps only the essentials in the kernel and runs services in user space (more robust, more IPC overhead).
4. **Why can't user programs just disable interrupts?** It is a privileged instruction; allowing it would let one program take over the CPU.
5. **What is a kernel module?** Code (often a driver) loaded into a running kernel, running in kernel mode.
6. **What happens when you type `ls` and press Enter?** See the trace above: interrupt, read returns, fork, exec, file system reads, writes to the terminal, exit, wait.

## Key Points

- Hardware enforces user and kernel modes; programs cross into the kernel only via system calls, interrupts and exceptions.
- System calls go through a fixed entry point and a dispatch table, with careful checking of user arguments.
- Kernels are monolithic, micro or hybrid; Linux is monolithic with loadable modules.