# Interview Q&A and Glossary

<details>
<summary>Relevant source files</summary>

The following references were used as context for generating this wiki page:

- [Wikipedia: Operating system](https://en.wikipedia.org/wiki/Operating_system)
- Book: Silberschatz, Galvin and Gagne, *Operating System Concepts*
- Book: Arpaci-Dusseau and Arpaci-Dusseau, *Operating Systems: Three Easy Pieces* (free online)

</details>

This page is for revision just before an interview. It puts the whole wiki on one diagram, lists the most common questions with short model answers grouped by topic, gives a checklist of the worked problems to practise, and ends with a glossary.

## Purpose and Scope

This page covers a one-picture summary, a quick-fire question bank, the "X vs Y" comparisons interviewers like, a problem-practice checklist and the glossary. It introduces no new ideas; each answer links to the page that explains it.

## The Whole Wiki in One Picture

```mermaid
flowchart TD
    OS["Operating system"] --> CPU["Sharing the CPU"]
    OS --> MEM["Sharing memory"]
    OS --> IO["Storage and devices"]
    OS --> PROT["Protection"]

    CPU --> PR["Processes: PCB, states, fork/exec"]
    CPU --> TH["Threads: shared memory, own stack"]
    CPU --> SC["Scheduling: FCFS, SJF, SRTF, RR, MLFQ"]
    TH --> SY["Synchronization: mutex, semaphore, condvar"]
    SY --> DL["Deadlock: 4 conditions, banker's"]

    MEM --> PG["Paging, page tables, TLB"]
    PG --> VM["Virtual memory: faults, FIFO/LRU/OPT,<br/>thrashing, copy-on-write"]

    IO --> FS["File systems: inodes, links, journaling"]
    IO --> DS["Disk scheduling, interrupts, DMA"]

    PROT --> KM["User/kernel mode, system calls"]
    KM --> KD["Monolithic vs microkernel"]
```

## Quick-Fire Questions

### Processes and Threads

| Question | Short answer |
| --- | --- |
| Process vs program? | A program is code in a file; a process is it running, with memory, registers and resources ([Processes](#processes)) |
| Process vs thread? | Processes have separate address spaces; threads in a process share one, each with its own stack and registers ([Threads](#threads)) |
| What is a PCB? | The kernel's record of a process: PID, state, registers, PC, memory info, open files |
| What does `fork` return? | 0 in the child, the child's PID in the parent, −1 on error |
| `fork()` called 3 times in a row: how many processes? | 8 (7 new) |
| `exec` vs `fork`? | `fork` makes a copy; `exec` replaces the program in the current process (same PID) |
| Zombie vs orphan? | Zombie: finished, not yet reaped. Orphan: parent died, adopted by init |
| What is a context switch and why is it costly? | Saving one thread's state and loading another's; pure overhead plus cold caches and TLB |
| Fastest IPC? | Shared memory (but needs synchronization) |

### Scheduling

| Question | Short answer |
| --- | --- |
| Turnaround, waiting, response? | Completion − arrival; turnaround − burst; first run − arrival ([CPU Scheduling](#scheduling)) |
| Which minimises average waiting time? | SJF (non-preemptive) / SRTF (preemptive), if bursts are known |
| Convoy effect? | Short jobs stuck behind a long one in FCFS |
| Starvation fix? | Aging |
| RR quantum too big / too small? | Becomes FCFS / too many context switches |
| How does MLFQ work? | Several priority queues; jobs that use a full quantum are demoted; periodic boost |

### Synchronization and Deadlock

| Question | Short answer |
| --- | --- |
| Race condition? | Result depends on thread timing on shared data ([Synchronization](#synchronization)) |
| Critical section requirements? | Mutual exclusion, progress, bounded waiting |
| Mutex vs semaphore? | Mutex: owned lock for exclusion. Semaphore: counter any thread can signal |
| Spinlock vs mutex? | Spin for very short waits on multicore or where sleeping is impossible; otherwise sleep |
| Why `while` around `cond_wait`? | Spurious wakeups and condition already consumed by another thread |
| Four deadlock conditions? | Mutual exclusion, hold and wait, no preemption, circular wait ([Deadlock](#deadlock)) |
| Practical deadlock prevention? | Global lock ordering |
| Safe vs unsafe state? | Safe: some order lets every process finish. Unsafe: deadlock possible (not certain) |
| Priority inversion fix? | Priority inheritance |

### Memory

| Question | Short answer |
| --- | --- |
| Internal vs external fragmentation? | Waste inside a block / waste between blocks ([Memory Management](#memory)) |
| Why paging? | No external fragmentation; any page in any frame |
| Translate an address? | Split into page number and offset; frame from page table; frame × size + offset |
| What is the TLB? | Cache of page-table translations |
| TLB miss vs page fault? | Miss: walk the page table. Fault: page not present or access not allowed |
| Page fault steps? | Trap, check address, get frame (evict if needed), read from disk, update table, restart ([Virtual Memory](#virtual-memory)) |
| FIFO vs LRU vs OPT? | Oldest loaded / least recently used / used furthest in future (best possible) |
| Bélády's anomaly? | More frames, more faults; FIFO only |
| Thrashing? | Working sets exceed RAM; constant paging |
| Copy-on-write? | Share pages read-only after `fork`; copy on first write |

### Files, I/O and Kernel

| Question | Short answer |
| --- | --- |
| What is an inode? | File metadata and block pointers, no name ([Files and I/O](#files-io)) |
| Hard vs soft link? | Same inode / file holding a path |
| Journaling? | Log changes and commit before applying, so crashes can be recovered |
| Polling vs interrupts vs DMA? | CPU checks / device signals / device moves data itself |
| SSTF vs SCAN? | Nearest first (may starve) / elevator sweep (no starvation) |
| System call path? | Trap instruction, kernel entry, dispatch table, checks, return ([Kernel and System Calls](#kernel)) |
| Interrupt vs trap vs fault? | Asynchronous hardware / deliberate instruction / accidental instruction |
| Monolithic vs microkernel? | All services in kernel (fast) / minimal kernel, services in user space (robust) |

## Comparisons to Know Cold

```mermaid
flowchart LR
    A["Process"] <-->|"isolation vs sharing"| B["Thread"]
    C["Mutex"] <-->|"ownership vs counting"| D["Semaphore"]
    E["Paging"] <-->|"fixed vs variable size"| F["Segmentation"]
    G["Hard link"] <-->|"inode vs path"| H["Soft link"]
    I["Monolithic"] <-->|"speed vs isolation"| J["Microkernel"]
    K["Preemptive"] <-->|"can interrupt vs cannot"| L["Non-preemptive"]
```

Answer every "X vs Y" with three things: **what each is**, **the key difference**, and **when you would choose each**.

## Problem-Practice Checklist

| Problem | Worked example | Check yourself |
| --- | --- | --- |
| Scheduling Gantt chart and averages | [CPU Scheduling](#scheduling) | FCFS 8.75, SJF 7.75, SRTF 6.50, RR(q=4) 11.75 average waiting |
| Count `fork` processes | [Processes](#processes) | 3 forks → 8 processes |
| Producer-consumer with semaphores | [Synchronization](#synchronization) | `empty` = N, `full` = 0, `mutex` = 1; counting semaphore before mutex |
| Banker's safety check | [Deadlock](#deadlock) | Safe sequence P1, P3, P4, P0, P2 |
| Address translation | [Memory Management](#memory) | 0x3A7F with page 3 → frame 7 gives 0x7A7F |
| TLB effective access time | [Memory Management](#memory) | 90% hit, 100 ns memory: 110 ns |
| Page faults FIFO / LRU / OPT | [Virtual Memory](#virtual-memory) | 12-ref string, 3 frames: 10 / 9 / 7 |
| Bélády's anomaly | [Virtual Memory](#virtual-memory) | FIFO: 9 faults with 3 frames, 10 with 4 |
| Disk scheduling totals | [Files and I/O](#files-io) | Head 53: FCFS 640, SSTF 236, LOOK 208 |
| "What happens when you run `ls`?" | [Kernel and System Calls](#kernel) | Interrupt → read → fork → exec → syscalls → exit → wait |

## How to Answer Well

```mermaid
flowchart LR
    Q["Question"] --> D["Define the term<br/>in one sentence"]
    D --> W["Explain how it works<br/>(draw a diagram)"]
    W --> T["Give the trade-off<br/>or a trap"]
    T --> E["Give a real example<br/>(Linux, Arm, a bug)"]
```

- Say your assumptions out loud (tie-breaking in scheduling, direction in disk scheduling, page-replacement tie rules).
- Draw: Gantt charts, state diagrams and frame tables make answers easy to follow and check.
- When writing synchronization code, explain **why** each lock or semaphore is there.

## Glossary

| Term | Meaning | Page |
| --- | --- | --- |
| Aging | Raising a waiting process's priority over time to prevent starvation | [CPU Scheduling](#scheduling) |
| Banker's algorithm | Deadlock avoidance: grant a request only if a safe sequence remains | [Deadlock](#deadlock) |
| Bélády's anomaly | More frames causing more page faults (FIFO) | [Virtual Memory](#virtual-memory) |
| Burst time | CPU time a job needs before it blocks or ends | [CPU Scheduling](#scheduling) |
| Condition variable | Lets a thread sleep until signalled, used with a mutex | [Synchronization](#synchronization) |
| Context switch | Saving one thread's CPU state and restoring another's | [Processes](#processes) |
| Convoy effect | Short jobs delayed behind a long one in FCFS | [CPU Scheduling](#scheduling) |
| Copy-on-write | Share pages until written, then copy | [Virtual Memory](#virtual-memory) |
| Critical section | Code that accesses shared data | [Synchronization](#synchronization) |
| Deadlock | Threads waiting on each other forever | [Deadlock](#deadlock) |
| Demand paging | Loading pages only when first used | [Virtual Memory](#virtual-memory) |
| DMA | Device transfers data to memory without the CPU | [Files and I/O](#files-io) |
| File descriptor | Per-process integer handle for an open file | [Files and I/O](#files-io) |
| Fragmentation | Wasted memory: internal (inside blocks) or external (between) | [Memory Management](#memory) |
| Inode | File metadata and block locations, without the name | [Files and I/O](#files-io) |
| Interrupt | Asynchronous hardware signal to the CPU | [Kernel and System Calls](#kernel) |
| IPC | Inter-process communication: pipes, sockets, shared memory, signals | [Processes](#processes) |
| Journaling | Logging file-system changes before applying them | [Files and I/O](#files-io) |
| Kernel mode | Privileged CPU mode for the OS | [Overview](#overview) |
| Livelock | Threads active but making no progress | [Deadlock](#deadlock) |
| MLFQ | Multilevel feedback queue scheduler | [CPU Scheduling](#scheduling) |
| MMU | Hardware that translates virtual to physical addresses | [Memory Management](#memory) |
| Monitor | Data plus lock plus condition variables, one thread inside at a time | [Synchronization](#synchronization) |
| Mutex | Lock providing mutual exclusion, with an owner | [Synchronization](#synchronization) |
| Orphan | Process whose parent has exited | [Processes](#processes) |
| Page / frame | Fixed-size block of virtual / physical memory | [Memory Management](#memory) |
| Page fault | Trap when an accessed page is not present or not allowed | [Virtual Memory](#virtual-memory) |
| Page table | Map from page numbers to frame numbers | [Memory Management](#memory) |
| PCB | Process control block | [Processes](#processes) |
| Preemption | Taking the CPU from a running thread | [CPU Scheduling](#scheduling) |
| Priority inversion | High-priority task blocked by a low-priority lock holder | [Deadlock](#deadlock) |
| Race condition | Outcome depends on thread timing | [Synchronization](#synchronization) |
| Round Robin | Each ready process runs for one quantum in turn | [CPU Scheduling](#scheduling) |
| Safe state | Some ordering lets all processes finish | [Deadlock](#deadlock) |
| Semaphore | Counter with atomic wait and signal | [Synchronization](#synchronization) |
| Spinlock | Lock that busy-waits | [Synchronization](#synchronization) |
| Starvation | A process never gets a resource | [Deadlock](#deadlock) |
| System call | Controlled entry from a program into the kernel | [Kernel and System Calls](#kernel) |
| Thrashing | Constant paging; little useful work | [Virtual Memory](#virtual-memory) |
| Thread | Execution flow inside a process | [Threads](#threads) |
| TLB | Cache of address translations | [Memory Management](#memory) |
| Trap | Deliberate entry to the kernel by an instruction | [Kernel and System Calls](#kernel) |
| Turnaround time | Completion − arrival | [CPU Scheduling](#scheduling) |
| Virtual memory | Each process sees a private address space, possibly larger than RAM | [Virtual Memory](#virtual-memory) |
| Waiting time | Turnaround − burst | [CPU Scheduling](#scheduling) |
| Working set | Pages a process used recently | [Virtual Memory](#virtual-memory) |
| Zombie | Finished process not yet reaped by its parent | [Processes](#processes) |

## Further Reading

| Resource | Good for |
| --- | --- |
| Arpaci-Dusseau, *Operating Systems: Three Easy Pieces* (free online) | Clear beginner explanations of virtualisation, concurrency, persistence |
| Silberschatz, Galvin and Gagne, *Operating System Concepts* | The standard textbook; most interview problems come from here |
| The Wikipedia articles linked from each page | Quick refreshers |
| The [Computer Architecture wiki](../arch-wiki/arch-wiki.html#overview) | The hardware underneath: caches, memory ordering, multicore |